package okhttp3

/**
 * Заглушки OkHttp. Только объявления: тела не собирают клиент, иначе правило
 * срабатывает на самих заглушках. В прошлом прогоне так и вышло — находка на
 * строке 22, где build() возвращал OkHttpClient().
 */

interface Interceptor

class CertificatePinner {
    class Builder {
        fun add(pattern: String, vararg pins: String): Builder = TODO()
        fun build(): CertificatePinner = TODO()
    }
}

class OkHttpClient {
    class Builder {
        fun addInterceptor(i: Any): Builder = TODO()
        fun addNetworkInterceptor(i: Any): Builder = TODO()
        fun certificatePinner(p: CertificatePinner): Builder = TODO()
        fun hostnameVerifier(v: Any): Builder = TODO()
        fun sslSocketFactory(f: Any, tm: Any): Builder = TODO()
        fun connectTimeout(t: Long, u: Any): Builder = TODO()
        fun build(): OkHttpClient = TODO()
    }
}
