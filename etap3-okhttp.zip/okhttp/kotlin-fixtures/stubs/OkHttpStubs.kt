package okhttp3

/** Заглушки OkHttp под фикстуры. Только объявления, находок быть не должно. */

interface Interceptor

class CertificatePinner private constructor() {
    class Builder {
        fun add(pattern: String, vararg pins: String): Builder = this
        fun build(): CertificatePinner = CertificatePinner()
    }
}

class OkHttpClient private constructor() {
    class Builder {
        fun addInterceptor(i: Any): Builder = this
        fun addNetworkInterceptor(i: Any): Builder = this
        fun certificatePinner(p: CertificatePinner): Builder = this
        fun hostnameVerifier(v: Any): Builder = this
        fun sslSocketFactory(f: Any, tm: Any): Builder = this
        fun connectTimeout(t: Long, u: Any): Builder = this
        fun build(): OkHttpClient = OkHttpClient()
    }
}
