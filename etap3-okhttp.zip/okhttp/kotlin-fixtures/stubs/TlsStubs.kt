package javax.net.ssl

/** Заглушки TLS под фикстуры. */

interface SSLSession

interface HostnameVerifier {
    fun verify(hostname: String, session: SSLSession): Boolean
}

interface X509TrustManager {
    fun checkClientTrusted(chain: Array<java.security.cert.X509Certificate>, authType: String)
    fun checkServerTrusted(chain: Array<java.security.cert.X509Certificate>, authType: String)
    fun getAcceptedIssuers(): Array<java.security.cert.X509Certificate>
}

class SSLContext private constructor() {
    val socketFactory: Any = Any()
    fun init(km: Any?, tm: Array<X509TrustManager>?, sr: Any?) {}
    companion object {
        fun getInstance(protocol: String): SSLContext = SSLContext()
    }
}
