package ru.sberbank.cerbersdk.utils

import okhttp3.Interceptor
import okhttp3.OkHttpClient

/** Заглушки сетевого слоя CerberSDK под фикстуры. */

object NetworkUtils {
    fun getDefaultOkHttpClient(): OkHttpClient = OkHttpClient.Builder().build()
    fun getAuthorizedOtpOkHttpClient(): OkHttpClient = OkHttpClient.Builder().build()
    fun getSberMagOkHttpClient(): OkHttpClient = OkHttpClient.Builder().build()
}

class CerberPinningRetryInterceptor : Interceptor

class TrustedComponentsPinningInterceptor : Interceptor

interface NetworkSelectRepository {
    fun getDefaultOkHttpClient(): OkHttpClient
    fun getAuthorizedOtpOkHttpClient(): OkHttpClient
    fun getPinningInterceptor(): Interceptor
}
