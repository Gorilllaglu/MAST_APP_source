package ru.sberbank.cerbersdk.utils

import okhttp3.Interceptor
import okhttp3.OkHttpClient

/**
 * Заглушки сетевого слоя CerberSDK. Только объявления: тела фабрик не
 * собирают клиент. В прошлом прогоне правило сработало на строках 9, 10, 11
 * именно потому, что фабрики внутри вызывали OkHttpClient.Builder().
 */

object NetworkUtils {
    fun getDefaultOkHttpClient(): OkHttpClient = TODO()
    fun getAuthorizedOtpOkHttpClient(): OkHttpClient = TODO()
    fun getSberMagOkHttpClient(): OkHttpClient = TODO()
}

class CerberPinningRetryInterceptor : Interceptor

class TrustedComponentsPinningInterceptor : Interceptor

interface NetworkSelectRepository {
    fun getDefaultOkHttpClient(): OkHttpClient
    fun getAuthorizedOtpOkHttpClient(): OkHttpClient
    fun getPinningInterceptor(): Interceptor
}
