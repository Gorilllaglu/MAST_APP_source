package java.security.cert

/** Заглушка сертификата под фикстуры. */
class X509Certificate
