package ru.sberbank.cerbersdk.data.network

import okhttp3.OkHttpClient
import java.security.cert.X509Certificate
import javax.net.ssl.SSLContext
import javax.net.ssl.X509TrustManager

/**
 * Сторона TN по путям. Это код внутри SDK: канал телеметрии действительно
 * собирается с отключённой проверкой сертификата, и пиннинг там закомментирован.
 * Все правила партии должны здесь молчать за счёт paths.exclude — иначе на
 * боевом приложении они отчитаются о коде Цербера, а не о встраивании.
 */
internal object ClickStreamProvider {

    /** O-TN-SDK-1. Всё принимающий траст внутри SDK. */
    private val ignoreAllSSLErrors = object : X509TrustManager {
        override fun checkClientTrusted(chain: Array<X509Certificate>, authType: String) { }
        override fun checkServerTrusted(chain: Array<X509Certificate>, authType: String) { }
        override fun getAcceptedIssuers(): Array<X509Certificate> = arrayOf()
    }

    /** O-TN-SDK-2. Ручная сборка клиента без пиннинга внутри SDK. */
    fun getClickStreamClient(): OkHttpClient {
        val ctx = SSLContext.getInstance("TLS")
        ctx.init(null, arrayOf(ignoreAllSSLErrors), null)
        return OkHttpClient.Builder()
            .sslSocketFactory(ctx.socketFactory, ignoreAllSSLErrors)
            // .addInterceptor(getPinningInterceptor())
            .build()
    }
}
