package ru.corp.app.net

import okhttp3.OkHttpClient
import ru.sberbank.cerbersdk.utils.CerberPinningRetryInterceptor
import java.util.concurrent.TimeUnit

/**
 * Формы, поведение правила на которых заранее не известно. Это и есть
 * предмет теста: от них зависит, насколько правило устойчиво к обходу.
 */
object EdgeForms {

    /**
     * OK-PROBE-1. Сборка разорвана на три оператора: билдер в переменную,
     * настройка отдельным вызовом, build отдельно. Перехватчик подключён
     * правильно, но не в цепочке.
     * Ожидание: молчание — исключение правила описано как "в той же функции",
     * а не "в той же цепочке". Если сработает, значит движок не видит вызов
     * в соседнем операторе, и исключения работают только внутри цепочки.
     */
    fun splitCorrectBuild(): OkHttpClient {
        val builder = OkHttpClient.Builder()
        builder.addNetworkInterceptor(CerberPinningRetryInterceptor())
        builder.connectTimeout(30, TimeUnit.SECONDS)
        return builder.build()
    }

    /**
     * OK-PROBE-2. Та же разорванная сборка, но пиннинга нет вовсе.
     * Ожидание: находка. Нужен как контроль к PROBE-1: если молчат оба,
     * значит правило не видит разорванную сборку в принципе.
     */
    fun splitUnpinnedBuild(): OkHttpClient {
        val builder = OkHttpClient.Builder()
        builder.connectTimeout(30, TimeUnit.SECONDS)
        return builder.build()
    }

    /**
     * OK-PROBE-3. Клиент собран в геттере свойства.
     * Ожидание: пропуск. Тела геттеров свойств Kotlin движок не просматривает,
     * это измерено на этапе 1. Рабочий способ обойти правило.
     */
    val getterClient: OkHttpClient
        get() = OkHttpClient.Builder()
            .connectTimeout(30, TimeUnit.SECONDS)
            .build()

    /**
     * OK-PROBE-4. Клиент собран в инициализаторе свойства, не в функции.
     * Ожидание неочевидно: исключения правила описаны через fun, но позитивный
     * паттерн — просто вызов, и он должен сматчиться. То есть находка
     * ожидается, а исключение сюда не применится даже при правильном пиннинге.
     */
    val propertyClient: OkHttpClient = OkHttpClient.Builder()
        .addNetworkInterceptor(CerberPinningRetryInterceptor())
        .build()

    /**
     * OK-PROBE-5. Сборка внутри лямбды.
     * Ожидание: находка. Тела лямбд в Kotlin мы отдельно не мерили,
     * в Java они просматриваются.
     */
    fun lazyClient(): () -> OkHttpClient = {
        OkHttpClient.Builder()
            .connectTimeout(30, TimeUnit.SECONDS)
            .build()
    }

    /**
     * OK-PROBE-6. Правильный пиннинг есть, но в другой функции того же класса.
     * Ожидание: находка. Исключение привязано к функции, и это правильно:
     * иначе один корректный клиент в файле прикрыл бы все остальные.
     */
    fun unpinnedNeighbour(): OkHttpClient = OkHttpClient.Builder().build()

    fun pinnedNeighbour(): OkHttpClient =
        OkHttpClient.Builder()
            .addNetworkInterceptor(CerberPinningRetryInterceptor())
            .build()
}
