package ru.corp.app.net

import okhttp3.Interceptor
import okhttp3.OkHttpClient
import ru.sberbank.cerbersdk.utils.NetworkSelectRepository
import ru.sberbank.cerbersdk.utils.TrustedComponentsPinningInterceptor

/**
 * Сторона TP. Перехватчик пиннинга Цербера есть, но подключён как
 * application-интерцептор: сертификат сверяется после chain.proceed(),
 * когда хендшейк завершён, а тело запроса, клиентский сертификат и
 * корпоративные заголовки уже отправлены.
 *
 * Основание не предположение: TrustedComponentsPinningInterceptor сам бросает
 * SSLHandshakeException с текстом про необходимость network-интерцептора.
 */
object MisplacedPinning {

    /** OK-TP-6. Перехватчик из фабрики, подключён через addInterceptor. */
    fun viaFactory(repo: NetworkSelectRepository): OkHttpClient =
        OkHttpClient.Builder()
            .addInterceptor(repo.getPinningInterceptor())
            .build()

    /** OK-TP-7. Перехватчик создан на месте, подключён не туда. */
    fun viaInline(): OkHttpClient =
        OkHttpClient.Builder()
            .addInterceptor(TrustedComponentsPinningInterceptor())
            .build()

    /** OK-TP-8. Перехватчик лежит в параметре с говорящим именем. */
    fun viaVariable(pinningInterceptor: Interceptor): OkHttpClient =
        OkHttpClient.Builder()
            .addInterceptor(pinningInterceptor)
            .build()
}
