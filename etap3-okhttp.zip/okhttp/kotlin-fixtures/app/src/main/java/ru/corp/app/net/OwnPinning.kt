package ru.corp.app.net

import okhttp3.CertificatePinner
import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit

/**
 * Сторона TP. Разработчик сделал свой пиннинг штатным механизмом OkHttp.
 * По ТЗ эту форму надо именно отлавливать, поэтому исключения на неё нет.
 *
 * Признак однозначный: в SDK CertificatePinner не встречается ни разу,
 * значит любое вхождение написано разработчиком приложения.
 */
object OwnPinning {

    /** OK-TP-9. Пиннер собран отдельно и подключён в цепочку. */
    fun pinnedClient(): OkHttpClient {
        val pinner = CertificatePinner.Builder()
            .add("api.corp.ru", "sha256/AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=")
            .build()
        return OkHttpClient.Builder()
            .certificatePinner(pinner)
            .connectTimeout(30, TimeUnit.SECONDS)
            .build()
    }

    /** OK-TP-10. Пиннер собран прямо в цепочке. */
    fun pinnedInline(): OkHttpClient =
        OkHttpClient.Builder()
            .certificatePinner(
                CertificatePinner.Builder()
                    .add("api.corp.ru", "sha256/BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB=")
                    .build()
            )
            .build()
}
