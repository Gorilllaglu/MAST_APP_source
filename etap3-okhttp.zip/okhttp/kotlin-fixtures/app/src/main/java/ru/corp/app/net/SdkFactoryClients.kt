package ru.corp.app.net

import okhttp3.OkHttpClient
import ru.sberbank.cerbersdk.utils.NetworkSelectRepository
import ru.sberbank.cerbersdk.utils.NetworkUtils

/**
 * Сторона TN. Клиент получен из фабрики SDK — предписанная интеграция.
 * Вызова OkHttpClient.Builder() здесь нет, значит правило молчит
 * не по исключению, а потому что ловить нечего.
 */
object SdkFactoryClients {

    /** OK-TN-1. Статическая фабрика по умолчанию. */
    fun catalogClient(): OkHttpClient = NetworkUtils.getDefaultOkHttpClient()

    /** OK-TN-2. Фабрика авторизованного клиента через репозиторий. */
    fun authClient(repo: NetworkSelectRepository): OkHttpClient =
        repo.getAuthorizedOtpOkHttpClient()

    /** OK-TN-3. Клиент SberMag. */
    fun magClient(): OkHttpClient = NetworkUtils.getSberMagOkHttpClient()

    /** OK-TN-4. Сетевого кода нет вовсе. */
    fun describe(): String = "no network here"
}
