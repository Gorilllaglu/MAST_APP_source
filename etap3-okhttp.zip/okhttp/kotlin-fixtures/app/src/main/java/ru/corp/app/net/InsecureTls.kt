package ru.corp.app.net

import okhttp3.OkHttpClient
import java.security.cert.X509Certificate
import javax.net.ssl.HostnameVerifier
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLSession
import javax.net.ssl.X509TrustManager

/**
 * Сторона TP. Клиент собран вручную и валидация TLS снята. Для этого правила
 * это просто ручная сборка без пиннинга, то есть находка. Сам факт снятой
 * валидации — отдельный класс дефекта, ему место в своём правиле вне
 * набора проверок встраивания.
 */
object InsecureTls {

    private val acceptEverything = object : X509TrustManager {
        override fun checkClientTrusted(chain: Array<X509Certificate>, authType: String) { }
        override fun checkServerTrusted(chain: Array<X509Certificate>, authType: String) { }
        override fun getAcceptedIssuers(): Array<X509Certificate> = arrayOf()
    }

    private val acceptAnyHost = object : HostnameVerifier {
        override fun verify(hostname: String, session: SSLSession): Boolean = true
    }

    /** OK-TP-11. Своя фабрика сокетов и константный verifier. */
    fun insecureClient(): OkHttpClient {
        val ctx = SSLContext.getInstance("TLS")
        ctx.init(null, arrayOf(acceptEverything), null)
        return OkHttpClient.Builder()
            .sslSocketFactory(ctx.socketFactory, acceptEverything)
            .hostnameVerifier(acceptAnyHost)
            .build()
    }

    private val strictVerifier = object : HostnameVerifier {
        override fun verify(hostname: String, session: SSLSession): Boolean {
            return hostname == "api.corp.ru" || hostname == "mapi.corp.ru"
        }
    }

    /**
     * OK-TP-12. Verifier строгий, но клиент всё равно собран вручную
     * и пиннинга нет: находка ожидается и корректна.
     */
    fun strictButUnpinnedClient(): OkHttpClient =
        OkHttpClient.Builder()
            .hostnameVerifier(strictVerifier)
            .build()
}
