package ru.corp.app.net

import okhttp3.Interceptor
import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit

/**
 * Сторона TP, самая тяжёлая форма: ручная сборка и ни одного признака
 * пиннинга в функции. Корпоративный трафик идёт только на платформенном трасте.
 */
object ManualClients {

    /** OK-TP-1. Пустая сборка. */
    fun emptyClient(): OkHttpClient = OkHttpClient.Builder().build()

    /** OK-TP-2. Таймауты и обычный перехватчик, пиннинга нет. */
    fun loggingClient(loggingInterceptor: Interceptor): OkHttpClient =
        OkHttpClient.Builder()
            .connectTimeout(30, TimeUnit.SECONDS)
            .addInterceptor(loggingInterceptor)
            .build()

    /** OK-TP-3. Клиент возвращён через return из блочной функции. */
    fun returnedClient(): OkHttpClient {
        return OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .build()
    }

    /** OK-TP-4. Конструктор клиента напрямую, без билдера. */
    fun constructedClient(): OkHttpClient = OkHttpClient()

    /**
     * OK-TP-5. Форма из ТЗ дословно: прямой вызов билдера в методе,
     * имя которого намекает на выбор клиента.
     */
    fun selectAuthDmzOkHttpClient(): OkHttpClient =
        OkHttpClient.Builder()
            .connectTimeout(20, TimeUnit.SECONDS)
            .build()
}
