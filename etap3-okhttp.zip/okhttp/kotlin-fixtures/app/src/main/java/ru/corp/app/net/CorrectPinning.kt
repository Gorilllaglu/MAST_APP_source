package ru.corp.app.net

import okhttp3.OkHttpClient
import ru.sberbank.cerbersdk.utils.CerberPinningRetryInterceptor
import ru.sberbank.cerbersdk.utils.NetworkSelectRepository
import ru.sberbank.cerbersdk.utils.TrustedComponentsPinningInterceptor
import java.util.concurrent.TimeUnit

/**
 * Сторона TN по исключению. Клиент собран вручную, но перехватчик пиннинга
 * Цербера подключён на правильном месте — через addNetworkInterceptor.
 * Проверка идёт на соединении, до отправки запроса.
 *
 * Четыре формы соответствуют четырём исключениям правила.
 */
object CorrectPinning {

    /** OK-TN-5. Перехватчик из фабрики репозитория. */
    fun viaRepoFactory(repo: NetworkSelectRepository): OkHttpClient =
        OkHttpClient.Builder()
            .addNetworkInterceptor(repo.getPinningInterceptor())
            .connectTimeout(30, TimeUnit.SECONDS)
            .build()

    /** OK-TN-6. Перехватчик из фабрики без получателя. */
    fun viaBareFactory(): OkHttpClient =
        OkHttpClient.Builder()
            .addNetworkInterceptor(getPinningInterceptor())
            .build()

    /** OK-TN-7. Перехватчик trusted-компонентов создан на месте. */
    fun viaTrustedComponents(): OkHttpClient =
        OkHttpClient.Builder()
            .addNetworkInterceptor(TrustedComponentsPinningInterceptor())
            .build()

    /** OK-TN-8. Перехватчик пиннинга Цербера создан на месте. */
    fun viaCerberInterceptor(): OkHttpClient =
        OkHttpClient.Builder()
            .addNetworkInterceptor(CerberPinningRetryInterceptor())
            .build()

    private fun getPinningInterceptor() = CerberPinningRetryInterceptor()
}
