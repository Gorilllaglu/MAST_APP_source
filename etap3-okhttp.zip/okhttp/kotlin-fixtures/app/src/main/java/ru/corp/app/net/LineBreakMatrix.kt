package ru.corp.app.net

import okhttp3.Interceptor
import okhttp3.OkHttpClient
import ru.sberbank.cerbersdk.utils.CerberPinningRetryInterceptor
import ru.sberbank.cerbersdk.utils.NetworkSelectRepository
import java.util.concurrent.TimeUnit

/**
 * Одно измерение: запись цепочки одной строкой против разбитой по строкам.
 * Всё остальное одинаково — тело функции выражением, метод addInterceptor,
 * то есть исключений правила ни на одну клетку не распространяется.
 *
 * Повод: в матрице изоляции M01, M03, M04 сработали, а их близнецы TP-6,
 * TP-7, TP-8 в MisplacedPinning.kt повели себя иначе — TP-8 сработал,
 * TP-6 и TP-7 нет. Отличается только запись цепочки.
 *
 * Ожидание: все шесть клеток дают находку. Если молчат только L2, L4, L6,
 * значит движок иначе разбирает многострочную цепочку, и это надо учесть
 * во всех правилах, где есть цепочки вызовов.
 *
 *  маркер | запись        | аргумент
 *  L1     | одна строка   | repo.getPinningInterceptor()
 *  L2     | многострочно  | repo.getPinningInterceptor()
 *  L3     | одна строка   | CerberPinningRetryInterceptor()
 *  L4     | многострочно  | CerberPinningRetryInterceptor()
 *  L5     | одна строка   | переменная
 *  L6     | многострочно  | переменная
 */
object LineBreakMatrix {

    /** OK-L-1 */
    fun l1(repo: NetworkSelectRepository): OkHttpClient =
        OkHttpClient.Builder().addInterceptor(repo.getPinningInterceptor()).build()

    /** OK-L-2 */
    fun l2(repo: NetworkSelectRepository): OkHttpClient =
        OkHttpClient.Builder()
            .addInterceptor(repo.getPinningInterceptor())
            .build()

    /** OK-L-3 */
    fun l3(): OkHttpClient =
        OkHttpClient.Builder().addInterceptor(CerberPinningRetryInterceptor()).build()

    /** OK-L-4 */
    fun l4(): OkHttpClient =
        OkHttpClient.Builder()
            .addInterceptor(CerberPinningRetryInterceptor())
            .build()

    /** OK-L-5 */
    fun l5(someInterceptor: Interceptor): OkHttpClient =
        OkHttpClient.Builder().addInterceptor(someInterceptor).build()

    /** OK-L-6 */
    fun l6(someInterceptor: Interceptor): OkHttpClient =
        OkHttpClient.Builder()
            .addInterceptor(someInterceptor)
            .build()

    /**
     * OK-L-7. Контроль на лишний вызов в цепочке: многострочно, переменная,
     * плюс connectTimeout перед перехватчиком. Это форма TP-2, который молчал
     * при сработавшем TP-8 — у TP-8 лишнего вызова не было.
     */
    fun l7(someInterceptor: Interceptor): OkHttpClient =
        OkHttpClient.Builder()
            .connectTimeout(30, TimeUnit.SECONDS)
            .addInterceptor(someInterceptor)
            .build()

    /** OK-L-8. Тот же лишний вызов, но одной строкой. */
    fun l8(someInterceptor: Interceptor): OkHttpClient =
        OkHttpClient.Builder().connectTimeout(30, TimeUnit.SECONDS).addInterceptor(someInterceptor).build()
}
