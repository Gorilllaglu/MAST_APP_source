package ru.corp.app.net

import okhttp3.Interceptor
import okhttp3.OkHttpClient
import ru.sberbank.cerbersdk.utils.CerberPinningRetryInterceptor
import ru.sberbank.cerbersdk.utils.NetworkSelectRepository

/**
 * Матрица изоляции. В прошлом прогоне TN-5 сработал, а TP-2, TP-6, TP-7
 * промолчали, и ни одна гипотеза не объясняла все четыре случая разом.
 * Здесь три измерения меняются по одному, чтобы увидеть, какое из них решает.
 *
 * Измерение A — тело функции: выражение против блока.
 * Измерение B — метод подключения: addInterceptor против addNetworkInterceptor.
 * Измерение C — форма аргумента: вызов с получателем, вызов без получателя,
 *               конструктор, обычная переменная.
 *
 * Ожидание правила: молчание только там, где метод addNetworkInterceptor
 * И аргумент имеет форму из четырёх исключений. Во всех остальных клетках
 * ожидается находка.
 *
 *  маркер | тело       | метод                   | аргумент              | ожидание
 *  M01    | выражение  | addInterceptor          | repo.getPinning...()  | находка
 *  M02    | выражение  | addInterceptor          | getPinningInterceptor()| находка
 *  M03    | выражение  | addInterceptor          | CerberPinning...()    | находка
 *  M04    | выражение  | addInterceptor          | переменная            | находка
 *  M05    | выражение  | addNetworkInterceptor   | repo.getPinning...()  | молчание
 *  M06    | выражение  | addNetworkInterceptor   | getPinningInterceptor()| молчание
 *  M07    | выражение  | addNetworkInterceptor   | CerberPinning...()    | молчание
 *  M08    | выражение  | addNetworkInterceptor   | переменная            | находка
 *  M09    | блок       | addInterceptor          | repo.getPinning...()  | находка
 *  M10    | блок       | addInterceptor          | getPinningInterceptor()| находка
 *  M11    | блок       | addInterceptor          | CerberPinning...()    | находка
 *  M12    | блок       | addInterceptor          | переменная            | находка
 *  M13    | блок       | addNetworkInterceptor   | repo.getPinning...()  | молчание
 *  M14    | блок       | addNetworkInterceptor   | getPinningInterceptor()| молчание
 *  M15    | блок       | addNetworkInterceptor   | CerberPinning...()    | молчание
 *  M16    | блок       | addNetworkInterceptor   | переменная            | находка
 *  M17    | выражение  | перехватчика нет        | —                     | находка
 *  M18    | блок       | перехватчика нет        | —                     | находка
 */
object IsolationMatrix {

    private fun getPinningInterceptor(): Interceptor = CerberPinningRetryInterceptor()

    /** OK-M-01 */
    fun m01(repo: NetworkSelectRepository): OkHttpClient =
        OkHttpClient.Builder().addInterceptor(repo.getPinningInterceptor()).build()

    /** OK-M-02 */
    fun m02(): OkHttpClient =
        OkHttpClient.Builder().addInterceptor(getPinningInterceptor()).build()

    /** OK-M-03 */
    fun m03(): OkHttpClient =
        OkHttpClient.Builder().addInterceptor(CerberPinningRetryInterceptor()).build()

    /** OK-M-04 */
    fun m04(pinningInterceptor: Interceptor): OkHttpClient =
        OkHttpClient.Builder().addInterceptor(pinningInterceptor).build()

    /** OK-M-05 */
    fun m05(repo: NetworkSelectRepository): OkHttpClient =
        OkHttpClient.Builder().addNetworkInterceptor(repo.getPinningInterceptor()).build()

    /** OK-M-06 */
    fun m06(): OkHttpClient =
        OkHttpClient.Builder().addNetworkInterceptor(getPinningInterceptor()).build()

    /** OK-M-07 */
    fun m07(): OkHttpClient =
        OkHttpClient.Builder().addNetworkInterceptor(CerberPinningRetryInterceptor()).build()

    /** OK-M-08 */
    fun m08(loggingInterceptor: Interceptor): OkHttpClient =
        OkHttpClient.Builder().addNetworkInterceptor(loggingInterceptor).build()

    /** OK-M-09 */
    fun m09(repo: NetworkSelectRepository): OkHttpClient {
        return OkHttpClient.Builder().addInterceptor(repo.getPinningInterceptor()).build()
    }

    /** OK-M-10 */
    fun m10(): OkHttpClient {
        return OkHttpClient.Builder().addInterceptor(getPinningInterceptor()).build()
    }

    /** OK-M-11 */
    fun m11(): OkHttpClient {
        return OkHttpClient.Builder().addInterceptor(CerberPinningRetryInterceptor()).build()
    }

    /** OK-M-12 */
    fun m12(pinningInterceptor: Interceptor): OkHttpClient {
        return OkHttpClient.Builder().addInterceptor(pinningInterceptor).build()
    }

    /** OK-M-13 */
    fun m13(repo: NetworkSelectRepository): OkHttpClient {
        return OkHttpClient.Builder().addNetworkInterceptor(repo.getPinningInterceptor()).build()
    }

    /** OK-M-14 */
    fun m14(): OkHttpClient {
        return OkHttpClient.Builder().addNetworkInterceptor(getPinningInterceptor()).build()
    }

    /** OK-M-15 */
    fun m15(): OkHttpClient {
        return OkHttpClient.Builder().addNetworkInterceptor(CerberPinningRetryInterceptor()).build()
    }

    /** OK-M-16 */
    fun m16(loggingInterceptor: Interceptor): OkHttpClient {
        return OkHttpClient.Builder().addNetworkInterceptor(loggingInterceptor).build()
    }

    /** OK-M-17 */
    fun m17(): OkHttpClient = OkHttpClient.Builder().build()

    /** OK-M-18 */
    fun m18(): OkHttpClient {
        return OkHttpClient.Builder().build()
    }
}
