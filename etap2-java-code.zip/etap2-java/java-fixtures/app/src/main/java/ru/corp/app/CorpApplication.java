package ru.corp.app;

import android.app.Application;

import ru.sberbank.cerbersdk.sdk_framework.AuthorizationMode;
import ru.sberbank.cerbersdk.sdk_framework.BuildType;
import ru.sberbank.cerbersdk.sdk_framework.CerberSDKApplication;
import ru.sberbank.cerbersdk.sdk_framework.CerberSDKApplicationDelegate;

/**
 * Сторона TP по сборке делегата.
 *
 * Порядок аргументов конструктора — реальный, снятый с SberApps 3.6.2:
 *   1 authorizationMode   6 secureClipboard
 *   2 buildType           7 enableTestServerPinning
 *   3 isolated            8 sberMagOptions
 *   4 secureInitialCheck  9 whiteListOptions
 *   5 secureScreen       10 disablePasswordlessAuth
 *
 * Во всех классах этого файла, кроме помеченных для J08 и J16, режим стоит
 * CERBER и тип сборки PROM — чтобы правила J08 и J16 не срабатывали поверх
 * проверяемого аргумента и каждая клетка проверяла ровно одно правило.
 */
public final class CorpApplication {

    private CorpApplication() {
    }

    /** J05-TP-1. Конструктор без аргументов, все защиты выключены по умолчанию. */
    public static class DefaultCtorApplication extends Application implements CerberSDKApplication {
        private final CerberSDKApplicationDelegate delegate = new CerberSDKApplicationDelegate();

        @Override
        public CerberSDKApplicationDelegate getDelegate() {
            return delegate;
        }
    }

    /** J08-TP-1. Режим авторизации NONE. */
    public static class NoneModeApplication extends Application implements CerberSDKApplication {
        private final CerberSDKApplicationDelegate delegate = new CerberSDKApplicationDelegate(
                AuthorizationMode.NONE, BuildType.PROM, false, true, true, true, true, null, null, false);

        @Override
        public CerberSDKApplicationDelegate getDelegate() {
            return delegate;
        }
    }

    /** J08-TP-2. Режим авторизации PINCODE_ONLY. */
    public static class PincodeModeApplication extends Application implements CerberSDKApplication {
        private final CerberSDKApplicationDelegate delegate = new CerberSDKApplicationDelegate(
                AuthorizationMode.PINCODE_ONLY, BuildType.PROM, false, true, true, true, true, null, null, false);

        @Override
        public CerberSDKApplicationDelegate getDelegate() {
            return delegate;
        }
    }

    /** J10-TP-1. secureClipboard=false, шестой аргумент. */
    public static class ClipboardOffApplication extends Application implements CerberSDKApplication {
        private final CerberSDKApplicationDelegate delegate = new CerberSDKApplicationDelegate(
                AuthorizationMode.CERBER, BuildType.PROM, false, true, true, false, true, null, null, false);

        @Override
        public CerberSDKApplicationDelegate getDelegate() {
            return delegate;
        }
    }

    /** J11-TP-1. secureScreen=false, пятый аргумент. */
    public static class ScreenOffApplication extends Application implements CerberSDKApplication {
        private final CerberSDKApplicationDelegate delegate = new CerberSDKApplicationDelegate(
                AuthorizationMode.CERBER, BuildType.PROM, false, true, false, true, true, null, null, false);

        @Override
        public CerberSDKApplicationDelegate getDelegate() {
            return delegate;
        }
    }

    /** J21-TP-1. secureInitialCheck=false, четвёртый аргумент, RASP выключен. */
    public static class InitialCheckOffApplication extends Application implements CerberSDKApplication {
        private final CerberSDKApplicationDelegate delegate = new CerberSDKApplicationDelegate(
                AuthorizationMode.CERBER, BuildType.PROM, false, false, true, true, true, null, null, false);

        @Override
        public CerberSDKApplicationDelegate getDelegate() {
            return delegate;
        }
    }

    /** J18-TP-1. disablePasswordlessAuth=true, десятый и последний аргумент. */
    public static class PasswordlessOffApplication extends Application implements CerberSDKApplication {
        private final CerberSDKApplicationDelegate delegate = new CerberSDKApplicationDelegate(
                AuthorizationMode.CERBER, BuildType.PROM, false, true, true, true, true, null, null, true);

        @Override
        public CerberSDKApplicationDelegate getDelegate() {
            return delegate;
        }
    }

    /** J16-TP-1. Непродуктовый тип сборки IFT. */
    public static class IftApplication extends Application implements CerberSDKApplication {
        private final CerberSDKApplicationDelegate delegate = new CerberSDKApplicationDelegate(
                AuthorizationMode.CERBER, BuildType.IFT, false, true, true, true, true, null, null, false);

        @Override
        public CerberSDKApplicationDelegate getDelegate() {
            return delegate;
        }
    }

    /** J16-TP-2. Непродуктовый тип сборки DEV1. */
    public static class Dev1Application extends Application implements CerberSDKApplication {
        private final CerberSDKApplicationDelegate delegate = new CerberSDKApplicationDelegate(
                AuthorizationMode.CERBER, BuildType.DEV1, false, true, true, true, true, null, null, false);

        @Override
        public CerberSDKApplicationDelegate getDelegate() {
            return delegate;
        }
    }

    /** J14-TP-1. Наследует Application, интерфейс CerberSDKApplication не реализован. */
    public static class NoSdkInterfaceApplication extends Application {
        @Override
        public void onCreate() {
            android.util.Log.d("app", "no sdk interface");
        }
    }

    /** J13-TP-1. Поле delegate получено не свежим экземпляром, а из поставщика. */
    public static class SharedDelegateApplication extends Application implements CerberSDKApplication {
        private final CerberSDKApplicationDelegate delegate = DelegateHolder.INSTANCE;

        @Override
        public CerberSDKApplicationDelegate getDelegate() {
            return delegate;
        }
    }

    static final class DelegateHolder {
        static final CerberSDKApplicationDelegate INSTANCE = null;

        private DelegateHolder() {
        }
    }
}
