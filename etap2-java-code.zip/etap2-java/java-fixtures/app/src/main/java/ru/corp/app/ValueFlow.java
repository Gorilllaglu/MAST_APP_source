package ru.corp.app;

import ru.sberbank.cerbersdk.sdk_framework.AuthorizationMode;
import ru.sberbank.cerbersdk.sdk_framework.BuildType;
import ru.sberbank.cerbersdk.sdk_framework.CerberSDKApplicationDelegate;

/**
 * Непрямой поток значений: J09 — режим авторизации, J17 — тип сборки.
 *
 * По J09 ожидается кратность: класс ModeFromFactory попадает и в ветвь 2
 * (первым аргументом конструктора стоит не литерал режима), и в ветвь 3
 * (объявление и сборка делегата в одном классе). Две находки одного правила
 * на одной конструкции — это не дефект, а две ветви, сработавшие по делу.
 */
public final class ValueFlow {

    private ValueFlow() {
    }

    /** J09-TP-1. Режим NONE в локальной переменной. */
    public static AuthorizationMode insecureLocal() {
        AuthorizationMode mode = AuthorizationMode.NONE;
        return mode;
    }

    /** J09-TP-2. Режим PINCODE_ONLY возвращён из метода. */
    public static AuthorizationMode insecureReturn() {
        return AuthorizationMode.PINCODE_ONLY;
    }

    /** J09-TP-3. Режим NONE в положительной ветви тернарного оператора. */
    public static AuthorizationMode insecureTernaryThen(boolean debug) {
        return debug ? AuthorizationMode.NONE : AuthorizationMode.CERBER;
    }

    /** J09-TP-4. Режим NONE в отрицательной ветви тернарного оператора. */
    public static AuthorizationMode insecureTernaryElse(boolean prod) {
        return prod ? AuthorizationMode.CERBER : AuthorizationMode.NONE;
    }

    /** J09-TP-5. Режим NONE в поле private static final — форма перечислена в правиле. */
    private static final AuthorizationMode FALLBACK_MODE = AuthorizationMode.NONE;

    /** J09-TP-6. Режим NONE присвоен переменной повторно. */
    public static AuthorizationMode insecureReassign(boolean debug) {
        AuthorizationMode mode = AuthorizationMode.CERBER;
        if (debug) {
            mode = AuthorizationMode.NONE;
        }
        return mode;
    }

    /**
     * J09-PROBE-1. Режим NONE в поле public static final.
     *
     * Эта комбинация модификаторов намеренно НЕ перечислена в правиле. Клетка
     * отвечает на вопрос, поглощает ли движок модификаторы в шаблоне
     * "$TYPE $VAR = ...". Сработает — значит перечисление модификаторов в
     * правиле избыточно и его надо убрать. Промолчит — значит перечисление
     * обязательно, и в него надо дописать недостающие комбинации.
     */
    public static final AuthorizationMode PUBLIC_FALLBACK_MODE = AuthorizationMode.NONE;

    /**
     * J09-TN-1. Режим CERBER в локальной переменной.
     *
     * Регрессионный тест правки J09. Прежний регекс
     * \bAuthorizationMode\.[A-Z0-9_]+\b не отсеивал CERBER вообще, поэтому
     * правило срабатывало здесь, на корректном коде. Исправленная версия
     * привязывает режим метапеременной $MODE и проверяет только его имя.
     */
    public static AuthorizationMode secureLocal() {
        AuthorizationMode mode = AuthorizationMode.CERBER;
        return mode;
    }

    /** J09-TN-2. Режим CERBER возвращён из метода. */
    public static AuthorizationMode secureReturn() {
        return AuthorizationMode.CERBER;
    }

    /** J09-TN-3. Режим CERBER в поле private static final. */
    private static final AuthorizationMode SAFE_MODE = AuthorizationMode.CERBER;

    /**
     * J09-PROBE-2. Режим приходит параметром метода извне.
     * Статике неизвестно, какое значение придёт; ловить нечего, но
     * разработчики пишут именно так.
     */
    public static AuthorizationMode passThrough(AuthorizationMode mode) {
        return mode;
    }

    /** J09-TP-7. Ветвь 2: первым аргументом конструктора стоит переменная, а не литерал. */
    public static CerberSDKApplicationDelegate delegateFromVariable(AuthorizationMode mode) {
        return new CerberSDKApplicationDelegate(
                mode, BuildType.PROM, false, true, true, true, true, null, null, false);
    }

    /**
     * J09-TN-4. Ветвь 2: первым аргументом стоит литерал CERBER.
     * Исключение pattern-not: new CerberSDKApplicationDelegate(AuthorizationMode.$ANYMODE, ...)
     * обязано отсечь эту клетку.
     */
    public static CerberSDKApplicationDelegate delegateFromLiteral() {
        return new CerberSDKApplicationDelegate(
                AuthorizationMode.CERBER, BuildType.PROM, false, true, true, true, true, null, null, false);
    }

    /** J09-TP-8. Ветвь 3: объявление режима и сборка делегата в одном классе. */
    public static class ModeFromFactory {
        AuthorizationMode mode = AuthorizationMode.valueOf("NONE");

        CerberSDKApplicationDelegate delegate = new CerberSDKApplicationDelegate(
                mode, BuildType.PROM, false, true, true, true, true, null, null, false);
    }

    /** J17-TP-1. Непродуктовый тип сборки IFT в локальной переменной. */
    public static BuildType insecureBuildLocal() {
        BuildType buildType = BuildType.IFT;
        return buildType;
    }

    /** J17-TP-2. Непродуктовый тип сборки DEV1 возвращён из метода. */
    public static BuildType insecureBuildReturn() {
        return BuildType.DEV1;
    }

    /** J17-TP-3. Непродуктовый тип сборки PSI в тернарном операторе. */
    public static BuildType insecureBuildTernary(boolean debug) {
        return debug ? BuildType.PSI : BuildType.PROM;
    }

    /** J17-TN-1. Продуктовый тип сборки PROM. */
    public static BuildType secureBuild() {
        BuildType buildType = BuildType.PROM;
        return buildType;
    }
}
