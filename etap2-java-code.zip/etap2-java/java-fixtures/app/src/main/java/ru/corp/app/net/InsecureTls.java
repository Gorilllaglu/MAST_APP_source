package ru.corp.app.net;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.X509TrustManager;

import okhttp3.OkHttpClient;

/**
 * OJ-TP-8, OJ-TP-9. Проверка TLS отключена: это обесценивает и пиннинг, и
 * корпоративные корни, независимо от всего остального.
 */
public final class InsecureTls {

    private InsecureTls() {
    }

    /** OJ-TP-8. Свой доверяющий всему trust manager. */
    public static OkHttpClient trustAll(SSLSocketFactory factory, X509TrustManager manager) {
        return new OkHttpClient.Builder()
                .sslSocketFactory(factory, manager)
                .hostnameVerifier(new HostnameVerifier() {
                    @Override
                    public boolean verify(String hostname, Object session) {
                        return true;
                    }
                })
                .build();
    }

    /** OJ-TP-9. Константный HostnameVerifier на лямбде. */
    public static OkHttpClient constantVerifier() {
        return new OkHttpClient.Builder()
                .hostnameVerifier((hostname, session) -> true)
                .build();
    }
}
