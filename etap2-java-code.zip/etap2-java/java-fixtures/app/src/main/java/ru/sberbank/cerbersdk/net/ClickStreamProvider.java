package ru.sberbank.cerbersdk.net;

import okhttp3.OkHttpClient;

/**
 * OJ-TN-SDK-1. Файл лежит под путём /cerbersdk/, то есть попадает в
 * paths.exclude правила. Клиент здесь собирается напрямую и без пиннинга —
 * это код самого SDK, ему так и положено. Правило обязано промолчать, и
 * молчание проверяет именно исключение по путям, а не шаблон.
 */
public final class ClickStreamProvider {

    private ClickStreamProvider() {
    }

    public static OkHttpClient internalClient() {
        return new OkHttpClient.Builder().build();
    }
}
