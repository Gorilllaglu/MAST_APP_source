package ru.corp.app.clipboard;

import android.util.Log;

import ru.sberbank.cerbersdk.clipboard.CerberCopyPasteBuffer;
import ru.sberbank.cerbersdk.clipboard.WriteResult;

/**
 * J04: результат CerberCopyPasteBuffer.write() не проверен.
 *
 * Имя получателя во всех клетках содержит "buffer" — правило ограничено
 * регексом .*[Bb]uffer.*|.*[Cc]lipboard.*|.*[Cc]opy[Pp]aste.* по $BUF.
 */
public class ClipboardUsage {

    private final CerberCopyPasteBuffer buffer = new CerberCopyPasteBuffer();

    /** J04-TP-1. Результат отброшен полностью. */
    public void copyDiscard(String text) {
        buffer.write(text);
    }

    /** J04-TP-2. Результат объявлен, но только записан в журнал, не сверен. */
    public void copyLogOnly(String text) {
        WriteResult result = buffer.write(text);
        Log.d("clipboard", "write returned " + result);
    }

    /** J04-TN-1. Результат сверен через if. */
    public void copyCheckedIf(String text) {
        WriteResult result = buffer.write(text);
        if (result == WriteResult.SUCCESS) {
            Log.d("clipboard", "ok");
        }
    }

    /** J04-TN-2. Результат разобран через switch прямо по вызову. */
    public void copyCheckedSwitchInline(String text) {
        switch (buffer.write(text)) {
            case SUCCESS:
                Log.d("clipboard", "ok");
                break;
            case TRUNCATED:
                Log.w("clipboard", "truncated");
                break;
            default:
                Log.w("clipboard", "failed");
                break;
        }
    }

    /** J04-TN-6. Результат объявлен и разобран через switch по переменной. */
    public void copyCheckedSwitchVar(String text) {
        WriteResult result = buffer.write(text);
        switch (result) {
            case SUCCESS:
                Log.d("clipboard", "ok");
                break;
            default:
                Log.w("clipboard", "not ok");
                break;
        }
    }

    /**
     * J04-TN-3. Результат сверен в return через ==.
     *
     * Регрессионный тест правки J04. Сверка результата в return не была
     * покрыта исключениями, и правило срабатывало здесь, на корректном коде.
     * Тот же пробел был у котлиновского близнеца K03 и закрыт 2026-10-23.
     */
    public boolean copyCheckedReturnEquals(String text) {
        WriteResult result = buffer.write(text);
        return result == WriteResult.SUCCESS;
    }

    /** J04-TN-7. Результат сверен в return через !=. */
    public boolean copyCheckedReturnNotEquals(String text) {
        WriteResult result = buffer.write(text);
        return result != WriteResult.FAILURE;
    }

    /**
     * J04-TN-4. Результат сверен в return через equals.
     * Форма добавлена в правило специально для Java: для enum WriteResult
     * пишут и через ==, и через equals.
     */
    public boolean copyCheckedReturnEqualsMethod(String text) {
        WriteResult result = buffer.write(text);
        return result.equals(WriteResult.SUCCESS);
    }

    /** J04-TN-5. Результат сверен в return через отрицаемый equals. */
    public boolean copyCheckedReturnNegatedEquals(String text) {
        WriteResult result = buffer.write(text);
        return !result.equals(WriteResult.FAILURE);
    }

    /**
     * J04-PROBE-1. Результат передан в другой метод, но нигде не сравнён.
     * Формально это не сверка, и ожидается сработка. Нужно ваше решение:
     * считать такую передачу обработкой результата или нет.
     */
    public void copyDelegateResult(String text) {
        WriteResult result = buffer.write(text);
        handle(result);
    }

    private void handle(WriteResult result) {
        Log.d("clipboard", String.valueOf(result));
    }
}
