package ru.corp.app.net;

import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;

/** OJ-TP-1..3. Ручная сборка клиента без пиннинга — самый тяжёлый случай. */
public final class ManualClients {

    private ManualClients() {
    }

    /** OJ-TP-1. Пустая сборка билдером. */
    public static OkHttpClient plainBuilder() {
        return new OkHttpClient.Builder().build();
    }

    /** OJ-TP-2. Конструктор клиента напрямую, без билдера. */
    public static OkHttpClient plainConstructor() {
        return new OkHttpClient();
    }

    /** OJ-TP-3. Настроены таймауты, пиннинга нет. */
    public static OkHttpClient withTimeouts() {
        return new OkHttpClient.Builder()
                .connectTimeout(20, TimeUnit.SECONDS)
                .readTimeout(20, TimeUnit.SECONDS)
                .build();
    }
}
