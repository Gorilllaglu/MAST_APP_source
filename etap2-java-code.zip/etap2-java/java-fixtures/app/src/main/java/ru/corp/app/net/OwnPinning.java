package ru.corp.app.net;

import java.util.concurrent.TimeUnit;

import okhttp3.CertificatePinner;
import okhttp3.OkHttpClient;

/**
 * OJ-TP-7. Свой CertificatePinner вместо механизма SDK. По ТЗ это находка,
 * а не исключение: технически нативный пиннер строже, он обрывает соединение
 * до отправки запроса, но пины придётся вращать руками, тогда как SDK
 * скачивает наборы в рантайме. Триаж должен зафиксировать владельца ротации.
 */
public final class OwnPinning {

    private OwnPinning() {
    }

    /** OJ-TP-7 */
    public static OkHttpClient withOwnPinner() {
        CertificatePinner pinner = new CertificatePinner.Builder()
                .add("api.corp.example", "sha256/AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=")
                .build();
        return new OkHttpClient.Builder()
                .certificatePinner(pinner)
                .connectTimeout(15, TimeUnit.SECONDS)
                .build();
    }
}
