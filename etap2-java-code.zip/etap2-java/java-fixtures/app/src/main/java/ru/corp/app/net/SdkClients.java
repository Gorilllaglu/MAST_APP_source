package ru.corp.app.net;

import okhttp3.OkHttpClient;

import ru.sberbank.cerbersdk.utils.NetworkUtils;

/** OJ-TN-1..3. Клиент берётся из фабрики SDK. Вызова конструктора нет, правило молчит. */
public final class SdkClients {

    private SdkClients() {
    }

    /** OJ-TN-1 */
    public static OkHttpClient defaultClient() {
        return NetworkUtils.getDefaultOkHttpClient();
    }

    /** OJ-TN-2 */
    public static OkHttpClient otpClient(Object cert, Object key) {
        return NetworkUtils.getAuthorizedOtpOkHttpClient(cert, key);
    }

    /** OJ-TN-3 */
    public static OkHttpClient sberMagClient() {
        return NetworkUtils.getSberMagOkHttpClient();
    }
}
