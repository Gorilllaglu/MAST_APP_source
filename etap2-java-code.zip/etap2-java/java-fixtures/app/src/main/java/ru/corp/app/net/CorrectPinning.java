package ru.corp.app.net;

import okhttp3.OkHttpClient;

import ru.sberbank.cerbersdk.pinning.CerberPinningRetryInterceptor;
import ru.sberbank.cerbersdk.pinning.NetworkSelectRepository;
import ru.sberbank.cerbersdk.pinning.TrustedComponentsPinningInterceptor;

/**
 * OJ-TN-4..7. Ручная сборка, но перехватчик пиннинга подключён правильно,
 * через addNetworkInterceptor. Исключения правила обязаны отсечь все клетки.
 */
public final class CorrectPinning {

    private CorrectPinning() {
    }

    /** OJ-TN-4. Аргумент — вызов с получателем. */
    public static OkHttpClient viaRepository(NetworkSelectRepository repo) {
        return new OkHttpClient.Builder()
                .addNetworkInterceptor(repo.getPinningInterceptor())
                .build();
    }

    /** OJ-TN-5. Аргумент — конструктор перехватчика доверенных компонентов. */
    public static OkHttpClient viaTrustedComponents() {
        return new OkHttpClient.Builder()
                .addNetworkInterceptor(new TrustedComponentsPinningInterceptor())
                .build();
    }

    /** OJ-TN-6. Аргумент — конструктор перехватчика с повтором. */
    public static OkHttpClient viaRetryInterceptor() {
        return new OkHttpClient.Builder()
                .addNetworkInterceptor(new CerberPinningRetryInterceptor())
                .build();
    }

    /**
     * OJ-TN-7. Разорванная сборка: билдер лежит в переменной, перехватчик
     * подключается отдельным оператором. Цепочечное исключение здесь не
     * работает — Builder() не является получателем в цепочке — и клетку
     * должно отсечь исключение по МЕТОДУ. В Java у каждого метода блочное
     * тело, поэтому это исключение применяется всегда; в Kotlin та же клетка
     * спасалась только при блочном теле.
     */
    public static OkHttpClient brokenUpBuild(NetworkSelectRepository repo) {
        OkHttpClient.Builder builder = new OkHttpClient.Builder();
        builder.addNetworkInterceptor(repo.getPinningInterceptor());
        return builder.build();
    }
}
