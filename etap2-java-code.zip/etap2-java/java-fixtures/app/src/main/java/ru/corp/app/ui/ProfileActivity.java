package ru.corp.app.ui;

import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;

import ru.sberbank.cerbersdk.sdk_framework.CerberAuth;

/**
 * J01: onResume() переопределён без запроса авторизации.
 * J02: класс-экран вовсе не переопределяет onResume().
 *
 * Правила дополняют друг друга: J01 требует наличия onResume, J02 — его
 * отсутствия, поэтому на одном классе они одновременно не срабатывают.
 * Имена классов содержат "Activity", базовый класс тоже — иначе регексы
 * $ACT и $BASE не пропустят клетку.
 */
public final class ProfileActivity {

    private ProfileActivity() {
    }

    /** J01-TP-1. onResume переопределён, авторизация при возврате не запрашивается. */
    public static class UnguardedProfileActivity extends AppCompatActivity {
        @Override
        protected void onResume() {
            Log.d("ui", "resumed");
        }
    }

    /**
     * J01-TN-1. onResume переопределён и запрашивает авторизацию.
     * Это же эталон для J03: в классе есть и observeAuthState.
     */
    public static class GuardedProfileActivity extends AppCompatActivity {
        @Override
        protected void onResume() {
            CerberAuth.requestCerberAuth(this);
        }

        void observe() {
            CerberAuth.observeAuthState(this);
        }
    }

    /**
     * J01-PROBE-1. onResume не переопределён вовсе.
     *
     * Экран авторизацию при возврате не проверяет, дефект по сути тот же, но
     * J01 построено на переопределении, поэтому ожидается молчание J01 и
     * сработка J02. Ровно эта клетка на Kotlin (K01-PROBE-1) и показала, что
     * текст сообщения J01 придётся уточнять.
     */
    public static class NoLifecycleProfileActivity extends AppCompatActivity {
        @Override
        protected void onCreate() {
            Log.d("ui", "created");
        }
    }

    /** J02-TP-1. Экран без onResume. */
    public static class HistoryActivity extends AppCompatActivity {
        void load() {
            Log.d("ui", "loading");
        }
    }

    /** J02-TN-1. Экран с onResume. */
    public static class DetailsActivity extends AppCompatActivity {
        @Override
        protected void onResume() {
            CerberAuth.requestCerberAuth(this);
        }

        void observe() {
            CerberAuth.observeAuthState(this);
        }
    }
}
