package ru.corp.app.callbacks;

import android.os.Process;
import android.util.Log;

/**
 * Пустые и неполные коллбэки: J12, J15, J19, J20, J22.
 *
 * Ожидается кратность по onRootDetected: J19 ловит отсутствие завершения
 * процесса, J20 — пустое тело и тело с одним return. На клетках J20-TP-1 и
 * J20-TP-2 оба правила срабатывают по делу, это не дефект.
 *
 * Классы намеренно не реализуют CerberCallbacks: интерфейс потребовал бы все
 * пять методов в каждом классе, и клетки перестали бы быть изолированными.
 */
public final class CerberCallbacksImpl {

    private CerberCallbacksImpl() {
    }

    /** J12-TP-1. onLogout с пустым телом: сессия хоста не завершается. */
    public static class EmptyLogout {
        public void onLogout() {
        }
    }

    /** J12-TN-1. onLogout чистит состояние. */
    public static class RealLogout {
        public void onLogout() {
            Log.d("cb", "clearing session");
        }
    }

    /** J15-TP-1. onNoAuthDetected с пустым телом: отсутствие авторизации проигнорировано. */
    public static class EmptyNoAuth {
        public void onNoAuthDetected() {
        }
    }

    /** J15-TN-1. onNoAuthDetected уводит на экран входа. */
    public static class RealNoAuth {
        public void onNoAuthDetected() {
            Log.d("cb", "redirect to login");
        }
    }

    /**
     * J19-TP-1. Root обнаружен, процесс не завершён, только запись в журнал.
     * J20-TN-1: тело не пустое и не из одного return, правило на попытку
     * обхода обязано промолчать.
     */
    public static class LoggingRoot {
        public void onRootDetected() {
            Log.w("cb", "device is rooted");
        }
    }

    /** J19-TP-2, J20-TP-1. Пустое тело: оба правила обязаны сработать. */
    public static class EmptyRoot {
        public void onRootDetected() {
        }
    }

    /** J19-TP-3, J20-TP-2. Тело из одного return: оба правила обязаны сработать. */
    public static class ReturningRoot {
        public void onRootDetected() {
            return;
        }
    }

    /** J19-TN-1. Процесс завершён через System.exit. */
    public static class ExitingRoot {
        public void onRootDetected() {
            System.exit(1);
        }
    }

    /** J19-TN-2. Процесс завершён через Process.killProcess. */
    public static class KillingRoot {
        public void onRootDetected() {
            Process.killProcess(Process.myPid());
        }
    }

    /** J19-TN-3. Процесс завершён через Runtime. */
    public static class RuntimeExitingRoot {
        public void onRootDetected() {
            Runtime.getRuntime().exit(1);
        }
    }

    /** J22-TP-1. onUserChanged с пустым телом: смена пользователя проигнорирована. */
    public static class EmptyUserChanged {
        public void onUserChanged() {
        }
    }

    /** J22-TP-2. onUserChanged из одного return. */
    public static class ReturningUserChanged {
        public void onUserChanged() {
            return;
        }
    }

    /** J22-TN-1. onUserChanged сбрасывает данные прежнего пользователя. */
    public static class RealUserChanged {
        public void onUserChanged() {
            Log.d("cb", "wiping previous user data");
        }
    }
}
