package ru.corp.app.ui;

import android.util.Log;

import ru.sberbank.cerbersdk.sdk_framework.CerberAuth;

/**
 * J03: requestCerberAuth() вызван, а observeAuthState() в том же классе нет.
 *
 * Имена классов содержат "Presenter": регекс $CLS правила J03 пропускает
 * Activity, Processor, Presenter и ViewModel, а регексы J01 и J02 требуют
 * Activity или Fragment, поэтому эти клетки им не достанутся.
 */
public final class AuthFlow {

    private AuthFlow() {
    }

    static class BasePresenter {
    }

    /** J03-TP-1. Авторизация запрошена, состояние не наблюдается. */
    public static class LoginPresenter extends BasePresenter {
        void start() {
            CerberAuth.requestCerberAuth(this);
        }
    }

    /** J03-TN-1. Запрос и наблюдение в одном классе. */
    public static class CorrectPresenter extends BasePresenter {
        void start() {
            CerberAuth.requestCerberAuth(this);
        }

        void observe() {
            CerberAuth.observeAuthState(this);
        }
    }

    /**
     * J03-PROBE-1. Наблюдение вынесено в отдельный класс.
     *
     * Интеграция корректная, но правило требует вызова в том же классе,
     * поэтому вероятна сработка на правильном коде. Нужно ваше решение:
     * мириться с этим фолзом или расширять правило до уровня файла.
     */
    public static class SplitPresenter extends BasePresenter {
        void start() {
            CerberAuth.requestCerberAuth(this);
        }
    }

    public static class SplitPresenterObserver extends BasePresenter {
        void observe() {
            CerberAuth.observeAuthState(this);
            Log.d("auth", "observing");
        }
    }
}
