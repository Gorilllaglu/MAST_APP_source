package ru.corp.app.net;

import java.util.concurrent.Callable;

import okhttp3.OkHttpClient;

/**
 * Краевые формы. Поведение правила на них заранее не известно и является
 * предметом измерения.
 *
 * Клетка OJ-PROBE-1 проверяет главное отличие Java-версии от котлиновской:
 * у котлиновского правила известное ограничение — клиент, собранный в
 * property getter, в находки не попадает, движок не обходит аксессоры
 * свойств. В Java геттер это обычный метод, и он должен обходиться. Если
 * клетка сработает, оговорку об ограничении можно не писать в message, и
 * покрытие Java-версии действительно выше.
 */
public final class EdgeForms {

    private EdgeForms() {
    }

    /** OJ-PROBE-1. Сборка в геттере. Ожидается сработка, в отличие от Kotlin. */
    public static class ClientHolder {
        public OkHttpClient getClient() {
            return new OkHttpClient.Builder().build();
        }
    }

    /** OJ-PROBE-2. Сборка внутри лямбды. */
    public static Callable<OkHttpClient> lambdaClient() {
        return () -> new OkHttpClient.Builder().build();
    }

    /** OJ-PROBE-3. Сборка внутри анонимного класса. */
    public static Callable<OkHttpClient> anonymousClient() {
        return new Callable<OkHttpClient>() {
            @Override
            public OkHttpClient call() {
                return new OkHttpClient.Builder().build();
            }
        };
    }

    /** OJ-PROBE-4. Сборка в инициализаторе поля. */
    public static class FieldInit {
        private final OkHttpClient client = new OkHttpClient.Builder().build();

        public OkHttpClient client() {
            return client;
        }
    }

    /** OJ-PROBE-5. Сборка в статическом блоке инициализации. */
    public static class StaticInit {
        static final OkHttpClient CLIENT;

        static {
            CLIENT = new OkHttpClient.Builder().build();
        }
    }

    /** OJ-PROBE-6. Сборка в конструкторе. */
    public static class CtorInit {
        private final OkHttpClient client;

        public CtorInit() {
            this.client = new OkHttpClient.Builder().build();
        }
    }
}
