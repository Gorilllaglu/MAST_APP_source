package ru.corp.app.net;

import okhttp3.OkHttpClient;

import ru.sberbank.cerbersdk.pinning.CerberPinningRetryInterceptor;
import ru.sberbank.cerbersdk.pinning.NetworkSelectRepository;
import ru.sberbank.cerbersdk.pinning.TrustedComponentsPinningInterceptor;

/**
 * OJ-TP-4..6, OJ-TP-10. Перехватчик пиннинга подключён через addInterceptor,
 * то есть как прикладной перехватчик: сертификат сверяется ПОСЛЕ
 * chain.proceed(), когда рукопожатие завершено, а тело запроса, клиентский
 * сертификат и корпоративные заголовки уже ушли. Правило обязано сработать.
 */
public final class MisplacedPinning {

    private MisplacedPinning() {
    }

    /** OJ-TP-4. Перехватчик с повтором не на своём месте. */
    public static OkHttpClient retryAsApplicationInterceptor() {
        return new OkHttpClient.Builder()
                .addInterceptor(new CerberPinningRetryInterceptor())
                .build();
    }

    /** OJ-TP-5. Перехватчик из фабрики репозитория не на своём месте. */
    public static OkHttpClient repositoryAsApplicationInterceptor(NetworkSelectRepository repo) {
        return new OkHttpClient.Builder()
                .addInterceptor(repo.getPinningInterceptor())
                .build();
    }

    /** OJ-TP-6. Перехватчик доверенных компонентов не на своём месте. */
    public static OkHttpClient trustedComponentsAsApplicationInterceptor() {
        return new OkHttpClient.Builder()
                .addInterceptor(new TrustedComponentsPinningInterceptor())
                .build();
    }

    /** OJ-TP-10. Разорванная сборка, перехватчик подключён прикладным. */
    public static OkHttpClient brokenUpWithApplicationInterceptor(NetworkSelectRepository repo) {
        OkHttpClient.Builder builder = new OkHttpClient.Builder();
        builder.addInterceptor(repo.getPinningInterceptor());
        return builder.build();
    }
}
