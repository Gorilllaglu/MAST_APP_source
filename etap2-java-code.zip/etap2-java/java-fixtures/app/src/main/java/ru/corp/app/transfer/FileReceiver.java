package ru.corp.app.transfer;

import android.net.Uri;
import android.util.Log;

import java.util.Arrays;
import java.util.List;

/**
 * J07: onFileReceived() не сверяет callingPackage.
 * J06: тело onFileReceived() пустое.
 *
 * Классы намеренно НЕ реализуют CerberCallbacks: иначе пришлось бы объявить
 * ещё четыре коллбэка, и правила J12, J15, J19, J20 сработали бы поверх.
 */
public final class FileReceiver {

    static final String ALLOWED = "ru.sberbank.sberapps";
    static final List<String> ALLOWED_LIST = Arrays.asList("ru.sberbank.sberapps", "ru.sberbank.sbermail");

    private FileReceiver() {
    }

    /**
     * J07-TP-1. callingPackage не используется вообще.
     * J06-TN-1: тело не пустое, правило на пустой коллбэк обязано промолчать.
     */
    public static class IgnoringReceiver {
        public void onFileReceived(Uri uri, String callingPackage) {
            Log.d("transfer", "got " + uri);
        }
    }

    /** J07-TP-2. callingPackage только записан в журнал, не сверен. */
    public static class LoggingReceiver {
        public void onFileReceived(Uri uri, String callingPackage) {
            Log.d("transfer", "got " + uri + " from " + callingPackage);
        }
    }

    /** J07-TN-1. Сверка с белым списком через equals. */
    public static class EqualsReceiver {
        public void onFileReceived(Uri uri, String callingPackage) {
            if (callingPackage.equals(ALLOWED)) {
                Log.d("transfer", "accepted " + uri);
            }
        }
    }

    /**
     * J07-TN-2. Ранний выход через отрицаемый equals.
     *
     * Регрессионный тест правки J07. Отрицание не было покрыто исключениями,
     * и правило срабатывало на корректной сверке. В Kotlin тот же пробел
     * закрыли формами с "!=" у близнеца K05, в Java добавлен отрицаемый
     * equals: для String это основная форма сверки.
     */
    public static class NegatedEqualsReceiver {
        public void onFileReceived(Uri uri, String callingPackage) {
            if (!callingPackage.equals(ALLOWED)) {
                return;
            }
            Log.d("transfer", "accepted " + uri);
        }
    }

    /** J07-TN-3. Ранний выход через неравенство ссылок. */
    public static class NotEqualsReceiver {
        public void onFileReceived(Uri uri, String callingPackage) {
            if (callingPackage != ALLOWED) {
                return;
            }
            Log.d("transfer", "accepted " + uri);
        }
    }

    /** J07-TN-4. Ранний выход через отрицаемый contains по белому списку. */
    public static class NegatedContainsReceiver {
        public void onFileReceived(Uri uri, String callingPackage) {
            if (!ALLOWED_LIST.contains(callingPackage)) {
                return;
            }
            Log.d("transfer", "accepted " + uri);
        }
    }

    /** J07-TN-5. Сверка через contains по белому списку. */
    public static class ContainsReceiver {
        public void onFileReceived(Uri uri, String callingPackage) {
            if (ALLOWED_LIST.contains(callingPackage)) {
                Log.d("transfer", "accepted " + uri);
            }
        }
    }

    /**
     * J06-TP-1. Тело коллбэка пустое.
     * J07 обязано промолчать: у него есть исключение на пустое тело.
     */
    public static class EmptyReceiver {
        public void onFileReceived(Uri uri, String callingPackage) {
        }
    }

    /**
     * J07-PROBE-1. Метод объявлен без модификатора public.
     * Шаблон правила записан как "void onFileReceived(Uri $URI, String $PKG)".
     * Клетка отвечает на вопрос, поглощает ли движок модификаторы: если
     * сработают и эта клетка, и public-клетки выше, то перечислять
     * модификаторы в правилах не нужно нигде.
     */
    static class PackagePrivateReceiver {
        void onFileReceived(Uri uri, String callingPackage) {
            Log.d("transfer", "got " + uri);
        }
    }
}
