package ru.corp.app;

import android.app.Application;

import ru.sberbank.cerbersdk.sdk_framework.AuthorizationMode;
import ru.sberbank.cerbersdk.sdk_framework.BuildType;
import ru.sberbank.cerbersdk.sdk_framework.CerberSDKApplication;
import ru.sberbank.cerbersdk.sdk_framework.CerberSDKApplicationDelegate;

/** Сторона TN по сборке делегата. Все правила этой группы обязаны промолчать. */
public final class CorpApplicationTn {

    private CorpApplicationTn() {
    }

    /**
     * J05-TN-1. Эталонная интеграция: десять аргументов, все значения безопасные.
     *
     * Это регрессионный тест правки J05. Движок трактует пустые скобки шаблона
     * как "любые аргументы", поэтому без исключения
     * pattern-not: new CerberSDKApplicationDelegate($ARG, ...)
     * правило срабатывало именно здесь — на корректном коде.
     *
     * Одновременно это сторона TN для остальных правил группы:
     * J08-TN-1 (режим CERBER), J10-TN-1 (secureClipboard=true),
     * J11-TN-1 (secureScreen=true), J14-TN-1 (интерфейс SDK реализован),
     * J16-TN-1 (тип сборки PROM), J18-TN-1 (disablePasswordlessAuth=false),
     * J21-TN-1 (secureInitialCheck=true).
     */
    public static class SecureApplication extends Application implements CerberSDKApplication {
        private final CerberSDKApplicationDelegate delegate = new CerberSDKApplicationDelegate(
                AuthorizationMode.CERBER, BuildType.PROM, false, true, true, true, true, null, null, false);

        @Override
        public CerberSDKApplicationDelegate getDelegate() {
            return delegate;
        }
    }

    /**
     * J10-TN-2. isolated=false третьим аргументом, остальные защиты включены.
     *
     * Регрессионный тест исправления позиции в cerber-java-insecure-clipboard-disabled.
     * Прежняя версия правила искала false ТРЕТЬИМ аргументом, а третий параметр
     * конструктора — isolated, не secureClipboard. На этой клетке прежнее
     * правило срабатывало, хотя защита буфера обмена включена: isolated=false
     * это нормальное значение любой интеграции SberApps. Исправленное правило
     * обязано промолчать.
     */
    public static class IsolatedFalseApplication extends Application implements CerberSDKApplication {
        private final CerberSDKApplicationDelegate delegate = new CerberSDKApplicationDelegate(
                AuthorizationMode.CERBER, BuildType.PROM, false, true, true, true, true, null, null, false);

        @Override
        public CerberSDKApplicationDelegate getDelegate() {
            return delegate;
        }
    }

    /**
     * J10-TN-3. isolated=true третьим аргументом при secureClipboard=true.
     *
     * Вторая половина того же регрессионного теста: позиция 3 меняется, позиция 6
     * остаётся безопасной. Правило обязано промолчать при любом значении isolated.
     */
    public static class IsolatedTrueApplication extends Application implements CerberSDKApplication {
        private final CerberSDKApplicationDelegate delegate = new CerberSDKApplicationDelegate(
                AuthorizationMode.CERBER, BuildType.PROM, true, true, true, true, true, null, null, false);

        @Override
        public CerberSDKApplicationDelegate getDelegate() {
            return delegate;
        }
    }

    /** J13-TN-1. Делегат получен свежим экземпляром, как и требуется. */
    public static class FreshDelegateApplication extends Application implements CerberSDKApplication {
        private final CerberSDKApplicationDelegate delegate = new CerberSDKApplicationDelegate(
                AuthorizationMode.CERBER, BuildType.PROM, false, true, true, true, true, null, null, false);

        @Override
        public CerberSDKApplicationDelegate getDelegate() {
            return delegate;
        }
    }

    /**
     * J14-PROBE-1. Класс не наследует Application, интерфейс SDK ему не нужен.
     * Правило построено на наследовании от Application, ожидается молчание.
     */
    public static class NotAnApplication {
        public void doWork() {
            android.util.Log.d("app", "plain class");
        }
    }
}
