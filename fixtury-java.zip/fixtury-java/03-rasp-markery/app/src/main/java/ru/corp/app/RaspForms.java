package ru.corp.app;

import android.view.WindowManager;
import ru.sberbank.cerbersdk.sdk_framework.DebugBypassChecker;

/**
 * JA-DB debug-bypass-checker-present
 * JA-FS flag-secure-cleared
 * JA-TC trusted-components-usage-marker
 */

class LaunchGate extends Activity {

    /** JA-DB-TP-1. Прямое обращение к отладочному чекеру. */
    boolean skipRootCheck() {
        return DebugBypassChecker.shouldBypassRootEmulatorCheck();
    }

    /** JA-DB-TP-2. Второй метод чекера. */
    boolean skipScreenGuard() {
        return DebugBypassChecker.shouldBypassSecureScreen();
    }

    /**
     * JA-DB-TN-1. Имя класса и метода в строковых литералах. Это не код,
     * ожидается молчание.
     */
    void reportPosture() {
        Host.log("analytics", "DebugBypassChecker.shouldBypassRootEmulatorCheck");
        Host.log("analytics", "-keep class ru.sberbank.cerbersdk.sdk_framework.DebugBypassChecker");
    }

    /**
     * JA-DB-TN-2. Метод-омоним у своего класса. Ожидается сработка, ложная:
     * тип получателя на этом движке не ограничивается. Известная цена правила.
     */
    boolean localHomonym(LocalSecurityGate gate) {
        return gate.shouldBypassRootEmulatorCheck();
    }

    /** JA-FS-TP-1. Снятие FLAG_SECURE именованной константой. */
    void allowScreenshots() {
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_SECURE);
    }

    /** JA-FS-TP-2. Снятие числовым литералом. */
    void allowScreenshotsNumeric() {
        getWindow().clearFlags(8192);
    }

    /** JA-FS-TP-3. Снятие через setFlags(0, FLAG_SECURE). */
    void allowScreenshotsViaSetFlags() {
        getWindow().setFlags(0, WindowManager.LayoutParams.FLAG_SECURE);
    }

    /** JA-FS-TN-1. Защита выставляется, а не снимается. Молчание. */
    void protectScreen() {
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
    }

    /** JA-FS-TN-2. Снимается другой флаг именованной константой. Молчание. */
    void stopKeepingScreenOn() {
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }

    /** JA-FS-TN-3. Снимается другой флаг числом. Молчание. */
    void stopKeepingScreenOnNumeric() {
        getWindow().clearFlags(128);
    }

    /**
     * JA-FS-PROBE-1. Метод-омоним с тем же числом на своём держателе битов.
     * Ожидается молчание: шаблон привязан к окну.
     */
    void dropAnalyticsFeature(FeatureFlagMask mask) {
        mask.clearFlags(8192);
    }
}

/** Свой гейт с методом-омонимом. Нужен для JA-DB-TN-2. */
class LocalSecurityGate {
    boolean shouldBypassRootEmulatorCheck() { return false; }
}

/** Свой держатель битовых признаков. Нужен для JA-FS-PROBE-1. */
class FeatureFlagMask {
    private int mask;

    void clearFlags(int flags) {
        mask = mask & ~flags;
    }
}

/** JA-TC trusted-components-usage-marker. Обратная логика: ценность в молчании. */
class NetworkBootstrap {
    private final Delegate delegate = new Delegate();

    /** JA-TC-TP-1. Чтение кеша доверенных компонентов. */
    Object warmCache() {
        return delegate.getTrustedComponents();
    }

    /** JA-TC-TP-2. Загрузка доверенных компонентов. */
    void download() {
        Host.log("net", String.valueOf(delegate.trustedComponents));
    }
}
