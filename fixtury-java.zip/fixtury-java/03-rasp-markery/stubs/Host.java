package ru.corp.app;

import android.view.Window;

public class Host {
    public static void log(String tag, String msg) { }
}

class Activity {
    public Window getWindow() { return new Window(); }
}

class Delegate {
    Object trustedComponents;

    Object getTrustedComponents() { return trustedComponents; }
}
