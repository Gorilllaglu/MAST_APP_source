# Фикстуры на весь джава-блок

Восемь наборов, 218 клеток, покрыты все 48 правил блока. У каждого набора свои заглушки, поэтому объявления типов между наборами не сталкиваются.

    --config rules/   по корню этого дерева

| Набор | Правил | Клеток | Что в нём |
|---|---|---|---|
| `01-delegat-i-auth` | 14 | 40 | Конструктор делегата, интерфейс Application, режим авторизации, тип сборки, экраны и авторизация в onResume |
| `02-zhiznennyj-cikl` | 9 | 45 | Колбэки, приём файлов, реакция на root, разбор результата проверок |
| `03-rasp-markery` | 3 | 13 | Отладочный обход, FLAG_SECURE, доверенные компоненты |
| `04-pinning` | 1 | 12 | Свои клиенты OkHttp |
| `05-ipc-i-fajly` | 4 | 19 | Идентичность вызывающего, временные файлы, срок сертификата |
| `06-poverhnost-vyvoda` | 10 | 44 | Буфер обмена, выделение текста, перетаскивание, WebView, шаринг, внешняя память, печать, свой PIN |
| `07-celostnost` | 1 | 9 | Проверка подлинности контрагента |
| `08-xml` | 6 | 36 | Манифест и ресурсы; две подпапки, потому что в одном приложении двух манифестов не бывает |

## Имена клеток

Префикс содержит правило: `JA-D` default-constructor-used, `JA-IC` secure-initial-check-disabled, `JA-SC` insecure-screen-disabled, `JA-CB` insecure-clipboard-disabled, `JA-PW` passwordless-auth-disabled, `JA-AM`/`JA-AV` insecure-auth-mode и его вариант через переменную, `JA-BT`/`JA-BV` non-production-build-type и вариант, `JA-I` missing-sdk-application-interface, `JA-M` missing-delegate-creation, `JA-AR` activity-missing-auth-onresume, `JA-LC` activity-no-lifecycle-override, `JA-OB` auth-requested-but-not-observed, `JA-LG` logout, `JA-NA` no-auth, `JA-UC` user-changed, `JA-FE` file-received-callback-empty, `JA-FM` file-received-no-caller-check, `JA-FC` received-file-not-copied, `JA-RB` root-detection-bypass-attempt, `JA-RT` root-detected-no-termination, `JA-SK` secure-check-wrong-state-comparison, `JA-DB` debug-bypass, `JA-FS` flag-secure-cleared, `JA-TC` trusted-components, `JA-OK` direct-okhttp-client, `JA-IF` ipc-identity-fallback-open, `JA-IP` ipc-identity-from-payload, `JA-TF` transfer-temp-file-not-deleted, `JA-CE` own-certificate-expiry-logic, `JA-CL` host-clipboard-bypass, `JA-CW` clipboard-write-result-ignored, `JA-TS` text-selection-without-sdk-actions, `JA-SB` selection-callback-not-sdk, `JA-DD` text-drag-and-drop, `JA-WV` webview-selection-unrestricted, `JA-SH` system-share-channel, `JA-ES` external-storage-export, `JA-PR` print-channel, `JA-PN` host-pin-screen, `JA-IG` app-integrity-check-marker.

В наборе 08 имена клеток котлиновские (`E02`, `E05`, `E12`, `E15`, `E16`, `K10`): файлы перенесены из котлиновского архива без изменений, а XML-правила в джавовском блоке — побайтовые копии котлиновских. Результат по этому набору обязан совпасть с котлиновским прогоном.

## Главное при разборе

**Этот прогон первый для всего джава-блока.** 21 правило из 48 никогда не прогонялось: пятнадцать написаны с нуля, шесть перенесены из XML-блока. Расхождения ожидаются в первую очередь там.

**Клетки `TN` обязаны молчать, клетки `TP` — сработать.** Если правило погасло целиком, это видно по молчанию его `TP`. В каждом наборе есть эталонный класс, где все защиты включены верно: `SecureApplication` в наборе 01, `RealCallbacks` в наборе 02.

**Где заранее известна цена.** Клетка `JA-DB-TN-2` даст ложную: свой класс с методом-омонимом `shouldBypassRootEmulatorCheck`, тип получателя на этом движке не ограничивается — та же известная ложная, что в котлиновском блоке. Клетка `JA-IG-PROBE-1` даст ложную по той же причине: свой метод с именем `checkSignatures`. Клетки `JA-RT-PROBE-2` (завершение в хелпере), `JA-RT-PROBE-3` (два уровня вложенности), `JA-TF-PROBE-1` (удаление в хелпере) — ложные по построению, правила видят только тело одной функции.

**Что меряется впервые.** `JA-SK-PROBE-2` — разбор результата проверок через `switch`: в котлине аналогичная форма через `when` не ловится, для джавы это не измерялось. `JA-OK-PROBE-1` и `JA-OK-PROBE-2` — разорванная на операторы сборка клиента: в котлине пара отработала верно, у джавы исключения описаны через `$RET $F(...)`, и это другой шаблон. `JA-IP-PROBE-1` — нейтральное имя ключа, граница правила по перечню имён.

**Java-синтаксис заглушек.** В одном `.java` может быть только один публичный тип верхнего уровня, поэтому вспомогательные типы в заглушках объявлены без `public`. Если движок на этом споткнётся, скажите — разнесу по файлам.
