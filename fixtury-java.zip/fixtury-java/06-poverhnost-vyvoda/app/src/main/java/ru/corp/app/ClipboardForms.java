package ru.corp.app;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import ru.sberbank.cerbersdk.sdk_framework.CerberCopyPasteBuffer;

/**
 * JA-CL host-clipboard-bypass
 * JA-CW clipboard-write-result-ignored
 */

class ClipboardUsage {
    private final Context ctx = new Context();

    /** JA-CL-TP-1. Получение системного менеджера по строковой константе. */
    ClipboardManager manager() {
        return (ClipboardManager) ctx.getSystemService(Context.CLIPBOARD_SERVICE);
    }

    /** JA-CL-TP-2. Сборка и запись одним выражением. Находка должна быть одна. */
    void copyInline(ClipboardManager cm, String text) {
        cm.setPrimaryClip(ClipData.newPlainText("label", text));
    }

    /** JA-CL-TP-3. Запись готовой вырезки из переменной. Одна находка. */
    void copyPrepared(ClipboardManager cm, ClipData clip) {
        cm.setPrimaryClip(clip);
    }

    /** JA-CL-TP-4. Только сборка вырезки, записи нет. Одна находка. */
    ClipData buildOnly(String text) {
        return ClipData.newPlainText("label", text);
    }

    /** JA-CL-TP-5. Сборка через newRawUri и запись одним выражением. Одна находка. */
    void copyRawUri(ClipboardManager cm, Object uri) {
        cm.setPrimaryClip(ClipData.newRawUri("label", uri));
    }

    /** JA-CL-TP-6. Получение менеджера литералом класса. */
    ClipboardManager managerByClass() {
        return (ClipboardManager) ctx.getSystemService(ClipboardManager.class);
    }

    /** JA-CL-TN-1. Запись через буфер SDK. Молчание. */
    void copyViaSdk(String text) {
        CerberCopyPasteBuffer.write(text);
    }

    /** JA-CW-TP-1. Результат записи в буфер SDK не прочитан. */
    void copyIgnoringResult(String text) {
        CerberCopyPasteBuffer.write(text);
        Host.show("copied");
    }

    /** JA-CW-TN-1. Результат разобран через switch. Молчание. */
    void copyHandled(String text) {
        switch (CerberCopyPasteBuffer.write(text)) {
            case SUCCESS:
                Host.show("ok");
                break;
            case TRUNCATED:
                Host.show("truncated");
                break;
            default:
                Host.show("failed");
        }
    }

    /** JA-CW-TN-2. Результат связан переменной. Молчание. */
    void copyBound(String text) {
        CerberCopyPasteBuffer.WriteResult result = CerberCopyPasteBuffer.write(text);
        if (result == CerberCopyPasteBuffer.WriteResult.TRUNCATED) {
            Host.show("truncated");
        }
    }

    /** JA-CW-TN-3. Результат возвращён вызывающему. Молчание. */
    CerberCopyPasteBuffer.WriteResult copyReturning(String text) {
        return CerberCopyPasteBuffer.write(text);
    }

    /**
     * JA-CW-TN-4. Регрессия на сужение якоря. Прежний якорь ловил любой write,
     * включая потоки и логгеры. Здесь правило обязано молчать.
     */
    void writeToStream(java.io.OutputStream stream, byte[] bytes) throws java.io.IOException {
        stream.write(bytes);
    }
}
