package ru.corp.app;

import android.widget.TextView;
import ru.sberbank.cerbersdk.sdk_framework.AllowedTextActionsCallBack;

/**
 * JA-TS text-selection-without-sdk-actions
 * JA-SB selection-callback-not-sdk
 * JA-DD text-drag-and-drop
 */

class SelectionScreens {

    /** JA-TS-TP-1. Выделение включено, штатный колбэк не поставлен. */
    void enableSelection(TextView view) {
        view.setTextIsSelectable(true);
    }

    /** JA-TS-TN-1. Выделение включено и штатный колбэк поставлен. Молчание. */
    void enableSelectionWithSdkCallback(TextView view) {
        view.setTextIsSelectable(true);
        view.setCustomSelectionActionModeCallback(AllowedTextActionsCallBack.INSTANCE);
    }

    /** JA-TS-TN-2. Выделение выключено. Молчание. */
    void disableSelection(TextView view) {
        view.setTextIsSelectable(false);
    }

    /** JA-SB-TP-1. Поставлен свой колбэк выделения. */
    void setOwnSelectionCallback(TextView view) {
        view.setCustomSelectionActionModeCallback(new OwnActionModeCallback());
    }

    /** JA-SB-TP-2. Поставлен свой колбэк курсора. */
    void setOwnInsertionCallback(TextView view) {
        view.setCustomInsertionActionModeCallback(new OwnActionModeCallback());
    }

    /** JA-SB-TN-1. Штатный объект с INSTANCE. Молчание. */
    void setSdkCallbackInstance(TextView view) {
        view.setCustomSelectionActionModeCallback(AllowedTextActionsCallBack.INSTANCE);
    }

    /** JA-SB-TN-2. Штатный объект на курсоре. Молчание. */
    void setSdkInsertionCallback(TextView view) {
        view.setCustomInsertionActionModeCallback(AllowedTextActionsCallBack.INSTANCE);
    }

    /** JA-DD-TP-1. Запуск перетаскивания. */
    void startDrag(TextView view, Object data) {
        view.startDragAndDrop(data, null, null, 256);
    }

    /** JA-DD-TP-2. Устаревшая форма запуска перетаскивания. */
    void startDragLegacy(TextView view, Object data) {
        view.startDrag(data, null, null, 0);
    }
}

class OwnActionModeCallback { }
