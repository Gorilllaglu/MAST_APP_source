package ru.sberbank.cerbersdk.sdk_framework;

public enum SecureCheck {
    ROOT_DETECTED,
    EMULATOR_DETECTED,
    DEVICE_LOCKED,
    SBERAPPS_NOT_FOUND,
    SBERAPPS_STORE_UNAVAILABLE,
    MDM_CONFIG_TAMPERED,
    DEVICE_COMPLIANT
}
