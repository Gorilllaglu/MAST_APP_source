package ru.corp.app;

import ru.sberbank.cerbersdk.sdk_framework.SecureCheck;
import ru.sberbank.cerbersdk.sdk_framework.SecureChecker;

/** JA-SK secure-check-wrong-state-comparison. Шесть небезопасных состояний из семи. */

class LaunchGates {
    private final SecureChecker checker = new SecureChecker();

    /** JA-SK-TP-1. Сравнение с ROOT_DETECTED. */
    void gateRoot() {
        if (checker.performChecks() == SecureCheck.ROOT_DETECTED) {
            Host.log("app", "root");
        }
    }

    /** JA-SK-TP-2. Отрицание по EMULATOR_DETECTED. */
    void gateEmulator() {
        if (checker.performChecks() != SecureCheck.EMULATOR_DETECTED) {
            Host.log("app", "ok");
        }
    }

    /** JA-SK-TP-3. Сравнение с DEVICE_LOCKED. */
    void gateLocked() {
        if (checker.performChecks() == SecureCheck.DEVICE_LOCKED) {
            Host.log("app", "locked");
        }
    }

    /** JA-SK-TP-4. Дописанное состояние SBERAPPS_NOT_FOUND. */
    void gateStoreMissing() {
        if (checker.performChecks() == SecureCheck.SBERAPPS_NOT_FOUND) {
            Host.log("app", "store missing");
        }
    }

    /** JA-SK-TP-5. Дописанное состояние SBERAPPS_STORE_UNAVAILABLE, отрицание. */
    void gateStoreDown() {
        if (checker.performChecks() != SecureCheck.SBERAPPS_STORE_UNAVAILABLE) {
            Host.log("app", "allow");
        }
    }

    /** JA-SK-TP-6. Дописанное состояние MDM_CONFIG_TAMPERED. */
    void gateMdm() {
        if (checker.performChecks() == SecureCheck.MDM_CONFIG_TAMPERED) {
            Host.log("app", "mdm tampered");
        }
    }

    /** JA-SK-TP-7. Форма через equals. */
    void gateEquals() {
        if (checker.performChecks().equals(SecureCheck.ROOT_DETECTED)) {
            Host.log("app", "root");
        }
    }

    /** JA-SK-TP-8. Форма через equals на дописанном состоянии. */
    void gateEqualsMdm() {
        if (checker.performChecks().equals(SecureCheck.MDM_CONFIG_TAMPERED)) {
            Host.log("app", "mdm tampered");
        }
    }

    /** JA-SK-TN-1. Сравнение с DEVICE_COMPLIANT: правильная форма. */
    void gateCompliant() {
        if (checker.performChecks() == SecureCheck.DEVICE_COMPLIANT) {
            Host.log("app", "allow");
        }
    }

    /** JA-SK-TN-2. Отрицание по DEVICE_COMPLIANT: тоже правильная форма. */
    void gateNotCompliant() {
        if (checker.performChecks() != SecureCheck.DEVICE_COMPLIANT) {
            Host.log("app", "deny");
        }
    }

    /** JA-SK-TN-3. equals с DEVICE_COMPLIANT. */
    void gateEqualsCompliant() {
        if (checker.performChecks().equals(SecureCheck.DEVICE_COMPLIANT)) {
            Host.log("app", "allow");
        }
    }

    /**
     * JA-SK-PROBE-1. Результат положен в переменную и сверяется ниже.
     * Ожидается пропуск: шаблоны требуют вызов на месте сравнения.
     */
    void gateViaVariable() {
        SecureCheck state = checker.performChecks();
        if (state == SecureCheck.ROOT_DETECTED) {
            Host.log("app", "root");
        }
    }

    /**
     * JA-SK-PROBE-2. Разбор через switch. Ожидается пропуск:
     * сравнения как выражения тут нет.
     */
    void gateViaSwitch() {
        switch (checker.performChecks()) {
            case ROOT_DETECTED:
                Host.log("app", "root");
                break;
            default:
                Host.log("app", "allow");
        }
    }
}
