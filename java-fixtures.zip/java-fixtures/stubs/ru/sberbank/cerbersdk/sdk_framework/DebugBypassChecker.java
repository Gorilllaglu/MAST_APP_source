package ru.sberbank.cerbersdk.sdk_framework;

/** Заглушка под фикстуры. */
public final class DebugBypassChecker {
    private DebugBypassChecker() { }
    public static boolean shouldBypassRootEmulatorCheck() { return false; }
    public static boolean shouldBypassSecureScreen() { return false; }
}
