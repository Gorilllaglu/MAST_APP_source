package ru.sberbank.cerbersdk.sdk_framework;

/** Заглушка под фикстуры. Объявления, вызовов нет. */
public enum SecureCheck {
    DEVICE_COMPLIANT,
    ROOT_DETECTED,
    EMULATOR_DETECTED,
    DEVICE_LOCKED
}
