package ru.sberbank.cerbersdk.sdk_framework;

import java.util.List;

/** Заглушка под фикстуры. */
public interface TrustedComponents {
    List<String> getFromCache();
    List<String> download();
}
