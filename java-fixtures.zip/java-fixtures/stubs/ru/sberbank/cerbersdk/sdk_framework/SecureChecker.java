package ru.sberbank.cerbersdk.sdk_framework;

/** Заглушка под фикстуры. */
public final class SecureChecker {
    private SecureChecker() { }
    public static SecureCheck performChecks() { return SecureCheck.DEVICE_COMPLIANT; }
}
