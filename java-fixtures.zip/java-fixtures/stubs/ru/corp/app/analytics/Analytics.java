package ru.corp.app.analytics;

/** Заглушка аналитики host-app. */
public interface Analytics {
    void track(String event);
}
