package ru.corp.app.di;

import ru.sberbank.cerbersdk.sdk_framework.DebugBypassChecker;
import ru.sberbank.cerbersdk.sdk_framework.TrustedComponents;

/** Заглушка делегата host-app. Отдаёт trustedComponents и геттером, и полем. */
public interface CerberSdkDelegate {
    TrustedComponents trustedComponents = null;
    TrustedComponents getTrustedComponents();
    DebugBypassChecker getDebugBypassChecker();
}
