package ru.corp.app.ui;

import android.app.Activity;
import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;
import androidx.appcompat.app.AppCompatActivity;

/** Правило 2, сторона TP. Java-специфика: окно через getWindow(). */
public class ReceiptPreviewActivity extends AppCompatActivity {

    /** J2-TP-1. Именованная константа, получатель getWindow() без префикса. */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_SECURE);
    }

    /** J2-TP-2. Числовой литерал, получатель с префиксом объекта. */
    public static void allowScreenshotsForOnboarding(Activity activity) {
        activity.getWindow().clearFlags(8192);
    }

    /** J2-TP-3. Шестнадцатеричная запись того же значения. */
    public static void allowScreenshotsHex(Activity activity) {
        activity.getWindow().clearFlags(0x2000);
    }

    /** J2-TP-4. Снятие флага через setFlags с нулевой маской. */
    public static void dropViaSetFlags(Activity activity) {
        activity.getWindow().setFlags(0, WindowManager.LayoutParams.FLAG_SECURE);
    }

    /**
     * J2-PROBE-1. Окно сохранено в локальную переменную.
     * Альтернатива $WIN.clearFlags(CONST) получателя не ограничивает,
     * поэтому с именованной константой находка ожидается, а с числом 8192 нет:
     * числовые формы привязаны к getWindow().
     */
    public static void viaLocalWindow(Activity activity) {
        Window w = activity.getWindow();
        w.clearFlags(WindowManager.LayoutParams.FLAG_SECURE);
        w.clearFlags(8192);
    }

    /**
     * J2-PROBE-2. Снятие бита через составное присваивание.
     * Бинарные выражения в шаблонах sastav не поддерживает, ожидается пропуск.
     * Эффект при этом тот же, что у clearFlags.
     */
    public static void dropSecureFlagWithBitmask(Activity activity) {
        WindowManager.LayoutParams attrs = activity.getWindow().getAttributes();
        attrs.flags &= ~WindowManager.LayoutParams.FLAG_SECURE;
        activity.getWindow().setAttributes(attrs);
    }
}
