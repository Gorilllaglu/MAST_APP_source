package ru.corp.app.ui;

import android.app.Activity;
import android.os.Bundle;
import android.view.WindowManager;
import androidx.appcompat.app.AppCompatActivity;

/**
 * Правило 2, сторона TN. Любая находка здесь, кроме J2-TN-5 и J2-PROBE-3,
 * означает переcрабатывание.
 */
public class StatementActivity extends AppCompatActivity {

    /** J2-TN-1. Защита выставляется, а не снимается. Молчание. */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        getWindow().setFlags(
                WindowManager.LayoutParams.FLAG_SECURE,
                WindowManager.LayoutParams.FLAG_SECURE);
    }

    /** J2-TN-2. Снимается другой флаг, именованной константой. Молчание. */
    public static void stopKeepingScreenOn(Activity activity) {
        activity.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }

    /** J2-TN-3. Снимается другой флаг, числом 128. Молчание. */
    public static void stopKeepingScreenOnNumeric(Activity activity) {
        activity.getWindow().clearFlags(128);
    }

    /** J2-TN-4. Состояние читается, а не меняется. Молчание. */
    public static boolean isScreenProtected(Activity activity) {
        int flags = activity.getWindow().getAttributes().flags;
        return (flags & WindowManager.LayoutParams.FLAG_SECURE) != 0;
    }

    /** J2-TN-5. Защита снята и возвращена в finally. Находка ожидается и корректна. */
    public static void withProtectionTemporarilyOff(Activity activity, Runnable block) {
        activity.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_SECURE);
        try {
            block.run();
        } finally {
            activity.getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        }
    }

    /**
     * J2-PROBE-3. Метод-омоним clearFlags у своего класса и то же число 8192.
     * В Kotlin-версии эта форма давала ложное срабатывание, и мы закрыли её
     * привязкой числовой формы к окну. Здесь привязка сделана к getWindow(),
     * поэтому ожидается молчание. Маркер проверяет, что приём перенесён верно.
     */
    public static void dropAnalyticsFeature(FeatureFlagMask mask) {
        mask.clearFlags(8192);
    }
}

/** Свой держатель битовых признаков приложения. К окну отношения не имеет. */
class FeatureFlagMask {
    private int mask;
    FeatureFlagMask(int mask) { this.mask = mask; }
    void clearFlags(int flags) { this.mask &= ~flags; }
}
