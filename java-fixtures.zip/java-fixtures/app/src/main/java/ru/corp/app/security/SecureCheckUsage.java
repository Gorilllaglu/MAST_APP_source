package ru.corp.app.security;

import android.util.Log;
import ru.sberbank.cerbersdk.sdk_framework.SecureCheck;
import ru.sberbank.cerbersdk.sdk_framework.SecureChecker;

/**
 * Правило 3. На sastav реализуема одна форма дефекта — сверка с конкретным
 * небезопасным состоянием вместо DEVICE_COMPLIANT. Остальные формы здесь
 * размечены, чтобы зафиксировать пропуски как измеренный факт, а не догадку.
 */
public final class SecureCheckUsage {

    private SecureCheckUsage() { }

    /** J3-TP-1. Сверка с ROOT_DETECTED через ==. Ожидается сработка. */
    public static boolean isCompliantPartialEq(SecureChecker checker) {
        return checker.performChecks() == SecureCheck.ROOT_DETECTED;
    }

    /** J3-TP-2. Сверка с EMULATOR_DETECTED через !=. Ожидается сработка. */
    public static boolean isCompliantPartialNeq(SecureChecker checker) {
        if (checker.performChecks() != SecureCheck.EMULATOR_DETECTED) {
            return true;
        }
        return false;
    }

    /**
     * J3-TP-3. Сверка через equals. Java-специфика: это вызов метода,
     * а не бинарное выражение, поэтому в отличие от Kotlin ловится.
     */
    public static boolean isCompliantPartialEquals(SecureChecker checker) {
        return checker.performChecks().equals(SecureCheck.DEVICE_LOCKED);
    }

    /** J3-TN-1. Сверка с DEVICE_COMPLIANT через ==. Молчание обязательно. */
    public static boolean enforceCompliance(SecureChecker checker) {
        return checker.performChecks() == SecureCheck.DEVICE_COMPLIANT;
    }

    /** J3-TN-2. Сверка с DEVICE_COMPLIANT через !=. Молчание обязательно. */
    public static boolean enforceComplianceNeq(SecureChecker checker) {
        if (checker.performChecks() != SecureCheck.DEVICE_COMPLIANT) {
            return false;
        }
        return true;
    }

    /** J3-TN-3. Сверка с DEVICE_COMPLIANT через equals. Молчание обязательно. */
    public static boolean enforceComplianceEquals(SecureChecker checker) {
        return checker.performChecks().equals(SecureCheck.DEVICE_COMPLIANT);
    }

    /** J3-TN-4. Результат сохранён и сверен с эталоном. Молчание обязательно. */
    public static boolean enforceViaLocal(SecureChecker checker) {
        SecureCheck result = checker.performChecks();
        return result == SecureCheck.DEVICE_COMPLIANT;
    }

    /** J3-TN-5. Результат возвращён вызывающему. Молчание обязательно. */
    public static SecureCheck currentPosture(SecureChecker checker) {
        return checker.performChecks();
    }

    /**
     * J3-PROBE-1. Вызов отдельным оператором, результат отброшен.
     * Исходная формулировка правила в чистом виде. На Kotlin оказалась
     * недостижима: нужен операторный ... , которого в движке нет.
     * Ожидается пропуск. Это дефект.
     */
    public static void warmUpSecurityChecks(SecureChecker checker) {
        checker.performChecks();
    }

    /**
     * J3-PROBE-2. Результат уходит в журнал через конкатенацию.
     * На Kotlin недостижимо: бинарные выражения в шаблонах не поддержаны.
     * Ожидается пропуск. Это дефект.
     */
    public static void logSecurityPosture(SecureChecker checker) {
        Log.d("compliance", "posture=" + checker.performChecks());
    }

    /**
     * J3-PROBE-3. Результат сохранён и ни с чем не сверен.
     * Нужен анализ потока данных. Ожидается пропуск. Это дефект.
     */
    public static void storeAndForget(SecureChecker checker) {
        SecureCheck result = checker.performChecks();
        Log.d("compliance", result.toString());
    }

    /**
     * J3-PROBE-4. Java-специфика: switch по результату, безопасное состояние
     * обработано, остальные проваливаются в default как разрешённые.
     * Правилом не покрыто, ожидается пропуск. Это дефект, которого
     * в Kotlin-наборе не было.
     */
    public static boolean isCompliantSwitch(SecureChecker checker) {
        switch (checker.performChecks()) {
            case ROOT_DETECTED:
                return false;
            default:
                return true;
        }
    }
}
