package ru.corp.app.security;

import ru.sberbank.cerbersdk.sdk_framework.SecureCheck;
import ru.sberbank.cerbersdk.sdk_framework.SecureChecker;
import ru.corp.app.analytics.Analytics;

/**
 * Правило 1, сторона TN. Любая находка здесь, кроме J1-TN-4, означает
 * переcрабатывание.
 */
public final class CorrectLaunchGate {

    private CorrectLaunchGate() { }

    /** J1-TN-1. Эталонная интеграция: проверки есть, послабления нет. Молчание. */
    public static boolean isDeviceTrustedForLaunch() {
        SecureCheck posture = SecureChecker.performChecks();
        return posture == SecureCheck.DEVICE_COMPLIANT;
    }

    /** J1-TN-2. Свои фича-флаги с похожими именами. Молчание. */
    public static boolean warmCaches() {
        if (AppFeatureGate.shouldBypassCache()) {
            return true;
        }
        return AppFeatureGate.shouldBypassRootCheck();
    }

    /** J1-TN-3. Имя класса и метода в строковых литералах. Это не код, молчание. */
    public static void reportIntegrationPosture(Analytics analytics) {
        analytics.track("cerber_debug_bypass_checker_absent");
        analytics.track("DebugBypassChecker.shouldBypassRootEmulatorCheck");
        analytics.track("-keep class ru.sberbank.cerbersdk.sdk_framework.DebugBypassChecker { *; }");
    }

    /**
     * J1-TN-4. Метод-омоним у своего класса приложения.
     * Ожидается сработка по альтернативе $X.shouldBypassRootEmulatorCheck(),
     * и она будет ложной. В Kotlin-прогоне эта форма сработала так же.
     */
    public static boolean localHomonym(LocalSecurityGate gate) {
        return gate.shouldBypassRootEmulatorCheck();
    }

    /** J1-TN-5. Геттер в Java это обычный метод, вызов внутри обязан находиться. */
    public static final class BypassFacade {
        public boolean isRootCheckDisabled() {
            return ru.sberbank.cerbersdk.sdk_framework.DebugBypassChecker
                    .shouldBypassRootEmulatorCheck();
        }
    }

    /** J1-TN-6. Потребитель обёртки: вызова SDK нет, молчание. */
    public static boolean useFacade(BypassFacade facade) {
        return facade.isRootCheckDisabled();
    }
}

/** Свои фича-флаги приложения. К CerberSDK отношения не имеют. */
final class AppFeatureGate {
    private AppFeatureGate() { }
    static boolean shouldBypassCache() { return false; }
    static boolean shouldBypassRootCheck() { return false; }
}

/** Свой гейт приложения с методом-омонимом. Нужен для J1-TN-4. */
final class LocalSecurityGate {
    boolean shouldBypassRootEmulatorCheck() { return false; }
}
