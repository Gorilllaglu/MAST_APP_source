package ru.corp.app.network;

import java.util.List;
import ru.corp.app.di.CerberSdkDelegate;
import ru.sberbank.cerbersdk.sdk_framework.TrustedComponents;

/**
 * Правило 4, сторона TP. Файл в host-app, вне путей из paths.exclude.
 * Java-специфика: свойство Kotlin видно как getTrustedComponents().
 */
public final class TrustedComponentsBootstrap {

    private TrustedComponentsBootstrap() { }

    /** J4-TP-1. Доступ через геттер. Ожидаются две находки. */
    public static void primeTrustedComponents(CerberSdkDelegate delegate) {
        List<String> cached = delegate.getTrustedComponents().getFromCache();
        if (cached.isEmpty()) {
            delegate.getTrustedComponents().download();
        }
    }

    /** J4-TP-2. Доступ к полю, если SDK отдаёт его полем. Ожидаются две находки. */
    public static void primeViaField(CerberSdkDelegate delegate) {
        delegate.trustedComponents.getFromCache();
        delegate.trustedComponents.download();
    }

    /**
     * J4-PROBE-1. Доступ через промежуточную переменную.
     * Широкие альтернативы вида $TC.download(...) в правило сознательно
     * не включены: download слишком частое имя, и для маркера с логикой
     * "падать при нуле находок" ложное срабатывание опаснее пропуска.
     * Ожидается пропуск.
     */
    public static void refreshViaAlias(CerberSdkDelegate delegate) {
        TrustedComponents tc = delegate.getTrustedComponents();
        tc.getFromCache();
        tc.download();
    }

    /** J4-PROBE-2. Доступ после проверки на null — типовая Java-форма. */
    public static void refreshIfPresent(CerberSdkDelegate delegate) {
        if (delegate != null && delegate.getTrustedComponents() != null) {
            delegate.getTrustedComponents().getFromCache();
        }
    }
}
