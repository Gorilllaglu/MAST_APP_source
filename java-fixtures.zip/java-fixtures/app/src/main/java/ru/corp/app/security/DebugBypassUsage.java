package ru.corp.app.security;

import ru.sberbank.cerbersdk.sdk_framework.DebugBypassChecker;
import ru.sberbank.cerbersdk.sdk_framework.SecureCheck;
import ru.sberbank.cerbersdk.sdk_framework.SecureChecker;
import ru.corp.app.di.CerberSdkDelegate;

import static ru.sberbank.cerbersdk.sdk_framework.DebugBypassChecker.shouldBypassRootEmulatorCheck;

/**
 * Правило 1, сторона TP. Java-специфика против Kotlin: статический импорт,
 * тернарный оператор, анонимный класс, лямбда.
 */
public final class DebugBypassUsage {

    private DebugBypassUsage() { }

    /** J1-TP-1. Прямой статический вызов. Подходит под три альтернативы правила. */
    public static boolean isDeviceTrustedForLaunch() {
        if (DebugBypassChecker.shouldBypassRootEmulatorCheck()) {
            return true;
        }
        return SecureChecker.performChecks() == SecureCheck.DEVICE_COMPLIANT;
    }

    /** J1-TP-2. Экземплярный получатель плюс парный метод. Ожидаются две находки. */
    public static boolean applyDebugRelaxations(CerberSdkDelegate delegate) {
        DebugBypassChecker bypass = delegate.getDebugBypassChecker();
        boolean skipRootCheck = bypass.shouldBypassRootEmulatorCheck();
        boolean skipScreenGuard = DebugBypassChecker.shouldBypassSecureScreen();
        return skipRootCheck || skipScreenGuard;
    }

    /** J1-TP-3. Вызов в тернарном операторе: получатель есть, должен ловиться. */
    public static String describePosture() {
        return DebugBypassChecker.shouldBypassRootEmulatorCheck() ? "relaxed" : "enforced";
    }

    /** J1-TP-4. Вызов внутри анонимного класса: проверяет, заходит ли движок внутрь. */
    public static Runnable relaxLater() {
        return new Runnable() {
            @Override
            public void run() {
                if (DebugBypassChecker.shouldBypassRootEmulatorCheck()) {
                    System.out.println("relaxed");
                }
            }
        };
    }

    /** J1-TP-5. Вызов внутри лямбды: то же для лямбд. */
    public static Runnable relaxLaterLambda() {
        return () -> {
            if (DebugBypassChecker.shouldBypassRootEmulatorCheck()) {
                System.out.println("relaxed");
            }
        };
    }

    /**
     * J1-PROBE-1. Статический импорт: вызов без получателя.
     * Ни одна альтернатива правила получателя не опускает, поэтому ожидается пропуск.
     * Это Java-специфичный разрыв, в Kotlin-версии его нет.
     */
    public static boolean viaStaticImport() {
        return shouldBypassRootEmulatorCheck();
    }

    /** J1-PROBE-2. Вызов через рефлексию по строке имени. Правило такой формы не описывает. */
    public static boolean reflectiveRelaxation() throws Exception {
        Class<?> cls = Class.forName("ru.sberbank.cerbersdk.sdk_framework.DebugBypassChecker");
        return (boolean) cls.getMethod("shouldBypassRootEmulatorCheck").invoke(null);
    }
}
