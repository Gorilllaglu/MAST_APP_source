package ru.sberbank.cerbersdk.data;

import ru.corp.app.di.CerberSdkDelegate;

/**
 * Правило 4, сторона TN. Те же вызовы внутри библиотеки: путь содержит
 * cerber-sdk, должен отсекаться paths.exclude. Находок быть не должно.
 */
public final class TrustedComponentsRepositoryImpl {

    private final CerberSdkDelegate delegate;

    public TrustedComponentsRepositoryImpl(CerberSdkDelegate delegate) {
        this.delegate = delegate;
    }

    /** J4-TN-1. Внутренний вызов библиотеки, чтение кеша. */
    public void warmCache() {
        delegate.getTrustedComponents().getFromCache();
    }

    /** J4-TN-2. Внутренний вызов библиотеки, загрузка. */
    public void syncFromServer() {
        delegate.getTrustedComponents().download();
    }
}
