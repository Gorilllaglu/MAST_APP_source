# dart_misc — Dart/Flutter порт (misc: zip-slip · logging · manifest · NSC)

Консолидирует **4** уязвимых приложения нативного стенда: две на уровне
Dart-кода (14, 21) и две на уровне манифеста/ресурсов (10, 11).

## Что объединено

| Оригинал | Где | Класс уязвимости | Sink |
|---|---|---|---|
| `14-zip-slip` | [lib/vuln14_zip_slip.dart](lib/vuln14_zip_slip.dart) | Zip-Slip (CWE-22, CVE-2018-1002200) | `'${targetDir.path}/${entry.name}'` + `writeAsBytes` без проверки `..` |
| `21-logging-grabbag` | [lib/vuln21_logging.dart](lib/vuln21_logging.dart) | Sensitive data in logs | `print`/`developer.log` с password/token/PII · `dio LogInterceptor(requestBody/responseBody: true)` |
| `10-manifest-flags-grabbag` | [android/.../AndroidManifest.xml](android/app/src/main/AndroidManifest.xml) | Опасные манифест-флаги | `debuggable` · `allowBackup` · `hasFragileUserData` · `requestLegacyExternalStorage` |
| `11-nsc-misconfig` | [android/.../res/xml/network_security_config.xml](android/app/src/main/res/xml/network_security_config.xml) | NSC misconfig | trust `user` CA + `cleartextTrafficPermitted="true"` |

## Раскладка файлов

```
dart_misc/
├── README.md
├── pubspec.yaml                    ← deps: archive (zip) + dio (LogInterceptor)
├── lib/
│   ├── main.dart                   ← меню; initState дёргает zip-slip + logging
│   ├── vuln14_zip_slip.dart
│   └── vuln21_logging.dart
└── android/app/src/main/
    ├── AndroidManifest.xml         ← VULN-10: 4 опасных флага + ссылка на NSC
    └── res/xml/
        └── network_security_config.xml   ← VULN-11
```

## Особенности Dart-порта

- **14 / 21 — на уровне Dart** (в `libapp.so`): zip-slip через `archive`,
  логирование через `print`/`developer.log` + `dio LogInterceptor` (точный
  аналог OkHttp `HttpLoggingInterceptor.Level.BODY`).
- **10 / 11 — манифест/ресурсный уровень** (нативная обёртка Flutter-проекта).
  Эти две **ловятся сканером обычным путём** (манифест/`res/xml`), в отличие
  от Dart-логики. Манифест приведён в реалистичном для Flutter виде.

## Форма

Src-снапшот: `lib/` + `pubspec.yaml` + те части `android/`, где живут
манифест/NSC-уязвимости. Полный `flutter create` скаффолд не входит.
