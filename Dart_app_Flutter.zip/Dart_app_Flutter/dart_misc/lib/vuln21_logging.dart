import 'dart:developer' as developer;

import 'package:dio/dio.dart';

/// VULN-21: логирование чувствительных данных.
class Logging {
  static void leakViaLogs() {
    const username = 'alice';
    const password = 'hunter2';
    const authToken = 'eyJhbGciOiJIUzI1NiJ9.fakepayload.fakesig';

    // (1) print / developer.log со чувствительными данными.
    // На Android оба уходят в logcat.
    print('user=$username pass=$password');                     // <-- VULN: password в логе
    developer.log('issued token=$authToken', name: 'Auth');     // <-- VULN: токен в логе
    print('credit_card=4242 4242 4242 4242 cvv=123');           // <-- VULN: PII в логе
  }

  /// (2) dio LogInterceptor с requestBody/responseBody=true — пишет ВСЁ
  /// тело запроса/ответа (включая Authorization-заголовок и тело логина
  /// с password) в лог. Аналог OkHttp HttpLoggingInterceptor.Level.BODY.
  static Dio buildLoggingClient() {
    final dio = Dio();
    dio.interceptors.add(LogInterceptor(
      requestHeader: true,
      requestBody: true,    // <-- VULN
      responseBody: true,   // <-- VULN
    ));
    return dio;
  }
}
