import 'dart:io';

import 'package:flutter/material.dart';

import 'vuln14_zip_slip.dart';
import 'vuln21_logging.dart';

void main() => runApp(const MiscApp());

class MiscApp extends StatelessWidget {
  const MiscApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Dart Misc',
      theme: ThemeData(useMaterial3: true),
      home: const HomeScreen(),
    );
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  void initState() {
    super.initState();
    // VULN-14: имитируем «скачали zip и распаковываем». Несуществующий
    // файл просто приведёт к ошибке (поглощается внутри unzip).
    final tmp = Directory.systemTemp;
    ZipUtil.unzip(
        File('${tmp.path}/downloaded.zip'), Directory('${tmp.path}/unpacked'));

    // VULN-21: логирование секретов + клиент с LogInterceptor(BODY).
    Logging.leakViaLogs();
    Logging.buildLoggingClient();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('VULN: misc')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: const [
          Text('VULN-14: zip-slip (unzip без проверки "../")'),
          SizedBox(height: 8),
          Text('VULN-21: secrets в print/log + dio LogInterceptor BODY'),
          SizedBox(height: 8),
          Text('VULN-10: manifest flags (debuggable/allowBackup/…) — '
              'android/app/src/main/AndroidManifest.xml'),
          SizedBox(height: 8),
          Text('VULN-11: NSC (trust user CA + cleartext) — '
              'android/app/src/main/res/xml/network_security_config.xml'),
        ],
      ),
    );
  }
}
