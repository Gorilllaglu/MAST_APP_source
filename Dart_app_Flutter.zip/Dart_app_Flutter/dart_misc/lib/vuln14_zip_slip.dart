import 'dart:io';

import 'package:archive/archive.dart';

/// VULN-14: zip-slip — распаковка zip без проверки имён entries.
///
/// Имена записей в архиве могут содержать `../` и приводить к записи
/// файла за пределы целевой директории (Zip-Slip, CVE-2018-1002200).
/// Здесь путь строится как `${targetDir.path}/${entry.name}` без
/// `canonicalize`/проверки, что результат остаётся внутри targetDir.
///
/// Безопасный вариант (НЕ реализован):
///   final outPath = p.normalize('${targetDir.path}/${entry.name}');
///   if (!outPath.startsWith(targetDir.path + Platform.pathSeparator)) {
///     throw Exception('zip-slip blocked: ${entry.name}');
///   }
class ZipUtil {
  static Future<void> unzip(File zipFile, Directory targetDir) async {
    try {
      if (!targetDir.existsSync()) targetDir.createSync(recursive: true);
      final bytes = await zipFile.readAsBytes();
      final archive = ZipDecoder().decodeBytes(bytes);
      for (final entry in archive) {
        final outPath = '${targetDir.path}/${entry.name}'; // <-- VULN sink: нет проверки '..'
        if (entry.isFile) {
          final outFile = File(outPath);
          outFile.parent.createSync(recursive: true);
          await outFile.writeAsBytes(entry.content as List<int>); // <-- VULN: запись за пределы targetDir
        } else {
          Directory(outPath).createSync(recursive: true);
        }
      }
    } catch (_) {}
  }
}
