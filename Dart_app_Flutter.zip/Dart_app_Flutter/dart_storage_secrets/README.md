# dart_storage_secrets — Dart/Flutter порт (storage & secrets)

Консолидирует **3** уязвимых приложения нативного MAST-стенда в одно
Flutter-приложение (по решению: на Dart часть приложений объединяется
тематически, т.к. Flutter = одна `FlutterActivity` с экранами-модулями).

## Что объединено

| Оригинал | Dart-файл | Класс уязвимости | Sink |
|---|---|---|---|
| `01-storage-plaintext-prefs` | [lib/vuln01_plaintext_prefs.dart](lib/vuln01_plaintext_prefs.dart) | Plaintext creds in SharedPreferences (MASVS-STORAGE-1, CWE-312) | `SharedPreferences.setString('password'/'auth_token', …)` |
| `16-creds-and-keys-shipped` | [lib/vuln16_hardcoded_secrets.dart](lib/vuln16_hardcoded_secrets.dart) | Hardcoded secrets shipped в APK | Dart `const` (JWT/AWS/admin) + `rootBundle.loadString(assets/*)` |
| `37-keys-and-certs-in-resources` | [lib/vuln37_keys_in_assets.dart](lib/vuln37_keys_in_assets.dart) | Key/cert material в assets (R026–R029) | `rootBundle.load(assets/*.pem/.p12/.bks/.bin)` + hardcoded container passwords |

## Раскладка файлов

```
dart_storage_secrets/
├── README.md                       ← этот файл (компоновка)
├── pubspec.yaml                    ← deps (shared_preferences) + декларация assets
├── lib/
│   ├── main.dart                   ← меню-экран; в initState вызывает все 3 модуля
│   ├── vuln01_plaintext_prefs.dart
│   ├── vuln16_hardcoded_secrets.dart
│   └── vuln37_keys_in_assets.dart
└── assets/                         ← реальный секретный/ключевой материал (скопирован 1:1 из оригиналов)
    ├── api_credentials.txt         (vuln16)
    ├── server_cert.pem             (vuln16)
    ├── public_cert_x509.pem        (vuln37, R026)
    ├── public_key_rsa.pem          (vuln37, R026)
    ├── private_unencrypted_pkcs8.pem  (vuln37, R027)
    ├── private_unencrypted_rsa.pem    (vuln37, R027)
    ├── private_encrypted_pkcs8.pem    (vuln37, R028)
    ├── client_pkcs12.p12              (vuln37, R028)
    ├── client_bouncy.bks              (vuln37, R028)
    └── mystery_key.bin                (vuln37, R029)
```

## Особенности Dart-порта (важно для анализа)

- **Dart-логика компилируется в AOT `libapp.so`** — sink'и (литералы секретов,
  вызовы API) **не видны в DEX/jadx**. SAST-материал — `lib/*.dart`; из
  собранного APK достаётся через `strings libapp.so` / reFlutter / blutter.
- **Манифест/ресурсные уязвимости здесь отсутствуют** — всё в Dart + assets.
  Ассеты при этом лежат в APK дословно (`assets/flutter_assets/…`) и ловятся
  обычным unzip'ом — это «shipped material»-сигнал.
- **Парсинг ключей** в Dart-порте сведён к чтению байтов: оригиналы — placeholder'ы,
  которые не парсятся валидным PEM/PKCS#12, а нативного `KeyStore`/`CertificateFactory`
  в Dart нет. Hardcoded-пароли (`changeit`/`android`) сохранены как литералы.

## Форма

Src-снапшот: `lib/` + `pubspec.yaml` + `assets/`, без полного `flutter create`
скаффолда (`android/`, `ios/`). Для сборки в APK — поместить в Flutter-каркас
и выполнить `flutter pub get && flutter build apk`.
