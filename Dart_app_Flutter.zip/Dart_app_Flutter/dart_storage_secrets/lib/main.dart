import 'package:flutter/material.dart';

import 'vuln01_plaintext_prefs.dart';
import 'vuln16_hardcoded_secrets.dart';
import 'vuln37_keys_in_assets.dart';

void main() => runApp(const StorageSecretsApp());

class StorageSecretsApp extends StatelessWidget {
  const StorageSecretsApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Dart Storage & Secrets',
      theme: ThemeData(useMaterial3: true),
      home: const HomeScreen(),
    );
  }
}

/// Экран-меню. В initState все три уязвимых модуля вызываются
/// безусловно (аналог нативного onCreate) — чтобы у сканера с
/// reachability-анализом call-site был достижим и Dart-tree-shaking
/// их не выкинул. Кнопки — для ручного повторного запуска.
class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  void initState() {
    super.initState();
    PlaintextPrefs.savePlaintextCreds();
    HardcodedSecrets.useSecrets();
    KeyMaterialUsage.loadAll();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('VULN: storage & secrets')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          ElevatedButton(
            onPressed: PlaintextPrefs.savePlaintextCreds,
            child: const Text('VULN-01: plaintext SharedPreferences'),
          ),
          ElevatedButton(
            onPressed: HardcodedSecrets.useSecrets,
            child: const Text('VULN-16: hardcoded secrets shipped'),
          ),
          ElevatedButton(
            onPressed: KeyMaterialUsage.loadAll,
            child: const Text('VULN-37: key material in assets'),
          ),
        ],
      ),
    );
  }
}
