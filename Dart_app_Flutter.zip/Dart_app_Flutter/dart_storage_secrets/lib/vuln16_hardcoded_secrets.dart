import 'dart:developer' as developer;

import 'package:flutter/services.dart' show rootBundle;

/// VULN-16 (часть 1): hardcoded секреты прямо в Dart-константах.
///
/// В отличие от Kotlin/Java эти литералы попадают НЕ в DEX, а в
/// AOT-снапшот `lib/arm64-v8a/libapp.so`. jadx их не покажет —
/// достаются через `strings libapp.so` / reFlutter / blutter.
/// Сам факт «секрет зашит в бинарь» — та же уязвимость.
class SecretsHolder {
  // подпись JWT, которую сервер использует для верификации
  static const String jwtSigningKey = 's3cr3t-jwt-signing-key-do-not-share';

  // ключ AWS (формат намеренно похож на настоящий)
  static const String awsAccessKeyId = 'AKIAIOSFODNN7EXAMPLE';
  static const String awsSecretAccessKey =
      'wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY';

  // токен админа на staging (часто забывают убрать)
  static const String adminBearerToken =
      'eyJhbGciOiJIUzI1NiJ9.eyJyb2xlIjoiYWRtaW4ifQ.fakeFakeFake';

  // VULN-16 (часть 2): аналог секретов из strings.xml.
  // В Flutter нет res/values/strings.xml для Dart-кода — эквивалент
  // «строкового ресурса» это const в коде или строка в assets.
  static const String apiSecretToken = 'sk_live_4eC39HqLyjWDarjtT1zdp7dc';
  static const String hardcodedAdminPassword = 'P@ssw0rd-Admin-2024';
}

class HardcodedSecrets {
  static Future<void> useSecrets() async {
    // Используем секреты, чтобы их не вырезал tree-shaking.
    developer.log('loaded ${SecretsHolder.jwtSigningKey.length} chars',
        name: 'Vuln16');
    developer.log('admin pwd len=${SecretsHolder.hardcodedAdminPassword.length}',
        name: 'Vuln16');

    // VULN-16 (часть 3): секретный материал, отгруженный как assets.
    // В APK ассеты лежат в flutter_assets/ дословно — извлекается unzip'ом.
    final creds = await rootBundle.loadString('assets/api_credentials.txt'); // <-- VULN: shipped creds
    final cert = await rootBundle.loadString('assets/server_cert.pem');      // <-- VULN: shipped private key/cert
    developer.log(
        'api_credentials=${creds.length}B server_cert=${cert.length}B',
        name: 'Vuln16');
  }
}
