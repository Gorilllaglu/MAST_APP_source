import 'package:shared_preferences/shared_preferences.dart';

/// VULN-01: Plaintext credentials in SharedPreferences (MASVS-STORAGE-1, CWE-312).
///
/// Flutter-плагин `shared_preferences` на Android пишет в тот же
/// механизм SharedPreferences, что и нативный код — файл
///   /data/data/<pkg>/shared_prefs/FlutterSharedPreferences.xml
/// в открытом виде, без какого-либо слоя шифрования. Значения
/// тривиально достаются с rooted-устройства, через `adb backup`
/// или любым кодом, читающим приватное хранилище приложения.
class PlaintextPrefs {
  static Future<void> savePlaintextCreds() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('password', 'hunter2');                                   // <-- VULN sink
    await prefs.setString('auth_token', 'eyJhbGciOiJIUzI1NiJ9.fakepayload.fakesig'); // <-- VULN sink
  }
}
