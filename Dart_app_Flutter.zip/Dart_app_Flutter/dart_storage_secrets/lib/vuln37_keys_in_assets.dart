import 'dart:developer' as developer;
import 'dart:typed_data';

import 'package:flutter/services.dart' show rootBundle;

/// VULN-37: ключевой/сертификатный материал, зашитый в assets APK
/// (R026–R029).
///
/// Восемь файлов реально читаются из бандла, чтобы у сканера была
/// видна связка «файл в assets» ↔ «использование в коде». Содержимое —
/// placeholder'ы (не парсятся как валидный PEM/PKCS#12), поэтому в
/// Dart-порте мы ограничиваемся чтением байтов + использованием
/// hardcoded-паролей к зашифрованным контейнерам (нативный
/// CertificateFactory/KeyStore-парс в Dart недоступен без тяжёлого
/// pointycastle и на placeholder'ах всё равно упал бы).
class KeyMaterialUsage {
  // Hardcoded passwords к зашифрованным контейнерам — typical defaults.
  // Бонусный сигнал для правил «слабый пароль keystore'а» (R022/R023).
  static const String encryptedPemPassword = 'changeit';
  static const String pkcs12Password = 'changeit';
  static const String bksPassword = 'android';

  static Future<void> loadAll() async {
    // === R026: публичные ключи / сертификаты ===
    await _read('assets/public_cert_x509.pem', 'X.509 cert');
    await _read('assets/public_key_rsa.pem', 'RSA public key');

    // === R027: приватные ключи БЕЗ пароля ===
    await _read('assets/private_unencrypted_pkcs8.pem', 'unencrypted PKCS#8 priv');
    await _read('assets/private_unencrypted_rsa.pem', 'legacy RSA priv');

    // === R028: приватные ключи / keystore'ы С паролем ===
    await _read('assets/private_encrypted_pkcs8.pem',
        'encrypted PEM (pwd=$encryptedPemPassword)');
    await _readBytes('assets/client_pkcs12.p12', 'PKCS#12 (pwd=$pkcs12Password)');
    await _readBytes('assets/client_bouncy.bks', 'BKS (pwd=$bksPassword)');

    // === R029: «общая категория» — generic key blob без явного типа ===
    await _readBytes('assets/mystery_key.bin', 'mystery key blob');
  }

  static Future<void> _read(String asset, String label) async {
    try {
      final pem = await rootBundle.loadString(asset); // <-- VULN: shipped key material
      developer.log('$label loaded: ${pem.length} chars from $asset',
          name: 'Vuln37');
    } catch (_) {}
  }

  static Future<void> _readBytes(String asset, String label) async {
    try {
      final ByteData data = await rootBundle.load(asset); // <-- VULN: shipped key material
      developer.log('$label loaded: ${data.lengthInBytes} bytes from $asset',
          name: 'Vuln37');
    } catch (_) {}
  }
}
