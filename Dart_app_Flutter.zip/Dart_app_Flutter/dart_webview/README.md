# dart_webview — Dart/Flutter порт (WebView misuse)

Консолидирует **3** уязвимых приложения нативного стенда. WebView в Flutter
реализован пакетом `webview_flutter` (обёртка над нативным `android.webkit.WebView`),
поэтому эти уязвимости переносятся хорошо.

## Что объединено

| Оригинал | Dart-файл | Класс уязвимости | Sink |
|---|---|---|---|
| `23-webview-jsbridge-no-origin` | [lib/vuln23_jsbridge.dart](lib/vuln23_jsbridge.dart) | JS bridge без origin-check | `addJavaScriptChannel('Native', …)` + `runJavaScript(…)` ответ |
| `24-webview-arbitrary-url` | [lib/vuln24_arbitrary_url.dart](lib/vuln24_arbitrary_url.dart) | Arbitrary URL в WebView | `loadRequest(Uri.parse(externalUrl))` без allowlist |
| `25-webview-token-injection` | [lib/vuln25_token_injection.dart](lib/vuln25_token_injection.dart) | Token injection без origin-check | `onPageFinished → runJavaScript("window.__authToken=…")` |

## Раскладка файлов

```
dart_webview/
├── README.md
├── pubspec.yaml                    ← deps: webview_flutter + shared_preferences
└── lib/
    ├── main.dart                   ← меню; кнопки открывают 3 экрана с WebView
    ├── vuln23_jsbridge.dart        ← JsBridgeScreen (StatefulWidget)
    ├── vuln24_arbitrary_url.dart   ← ArbitraryUrlScreen(url) — url извне
    └── vuln25_token_injection.dart ← TokenInjectionScreen(url) — url извне
```

## Маппинг нативных API → webview_flutter

| Натив (Kotlin/Java) | Dart (webview_flutter v4) |
|---|---|
| `addJavascriptInterface(obj, "Native")` | `addJavaScriptChannel('Native', onMessageReceived:)` |
| `settings.javaScriptEnabled = true` | `setJavaScriptMode(JavaScriptMode.unrestricted)` |
| `loadUrl(url)` | `loadRequest(Uri.parse(url))` |
| `evaluateJavascript(js, null)` | `runJavaScript(js)` |
| `WebViewClient.onPageFinished` | `NavigationDelegate(onPageFinished:)` |

## Особенности Dart-порта

- **JS-bridge семантика чуть иная:** в нативе `@JavascriptInterface` —
  синхронный вызов JS→натив с возвратом значения; в `webview_flutter`
  каналы односторонние (JS→Dart `postMessage`), поэтому «возврат токена»
  смоделирован как ответный `runJavaScript(...)` в DOM. Суть уязвимости
  (нативная функция доступна любой странице без origin-check) сохранена.
- **Источник URL** (`intent.getStringExtra("url")`) в Flutter становится
  аргументом экрана / deeplink-параметром — sink `loadRequest` идентичен.
- Экраны достижимы через навигацию из меню (call-site в `main.dart`),
  Dart-логика — в `libapp.so`.

## Форма

Src-снапшот: `lib/` + `pubspec.yaml`. Манифест-уязвимостей нет.
