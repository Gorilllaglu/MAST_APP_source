import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

/// VULN-25: token injection в WebView без проверки origin.
///
/// URL приходит снаружи; сразу после загрузки страницы приложение через
/// `runJavaScript` инжектит auth-token в DOM (авто-логин), НЕ сверяя host'а.
/// Атакующий хостит свою страницу и читает `window.__authToken`.
class TokenInjectionScreen extends StatefulWidget {
  final String url;
  const TokenInjectionScreen({super.key, required this.url});

  @override
  State<TokenInjectionScreen> createState() => _TokenInjectionScreenState();
}

class _TokenInjectionScreenState extends State<TokenInjectionScreen> {
  static const String _authToken = 'eyJhbGciOiJIUzI1NiJ9.fake.fake';
  late final WebViewController _controller;

  @override
  void initState() {
    super.initState();
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setNavigationDelegate(NavigationDelegate(
        onPageFinished: (String url) {
          // <-- VULN sink: инжектируем токен в любой только что
          // загруженный URL, не сверяя host'а.
          _controller.runJavaScript("window.__authToken='$_authToken'; "
              "window.dispatchEvent(new Event('app-token-ready'));");
        },
      ))
      ..loadRequest(Uri.parse(widget.url));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('VULN-25: token injection')),
      body: WebViewWidget(controller: _controller),
    );
  }
}
