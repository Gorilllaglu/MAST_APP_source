import 'package:flutter/material.dart';

import 'vuln23_jsbridge.dart';
import 'vuln24_arbitrary_url.dart';
import 'vuln25_token_injection.dart';

void main() => runApp(const WebviewApp());

class WebviewApp extends StatelessWidget {
  const WebviewApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Dart WebView Misuse',
      theme: ThemeData(useMaterial3: true),
      home: const HomeScreen(),
    );
  }
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  void _open(BuildContext ctx, Widget screen) {
    Navigator.of(ctx).push(MaterialPageRoute(builder: (_) => screen));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('VULN: WebView misuse')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          ElevatedButton(
            onPressed: () => _open(context, const JsBridgeScreen()),
            child: const Text('VULN-23: JS bridge without origin check'),
          ),
          ElevatedButton(
            // URL извне (аналог intent extra / deeplink) — без allowlist.
            onPressed: () => _open(context,
                const ArbitraryUrlScreen(url: 'https://attacker.example/phish.html')),
            child: const Text('VULN-24: arbitrary URL from external source'),
          ),
          ElevatedButton(
            onPressed: () => _open(context,
                const TokenInjectionScreen(url: 'https://attacker.example/grab.html')),
            child: const Text('VULN-25: token injection on any origin'),
          ),
        ],
      ),
    );
  }
}
