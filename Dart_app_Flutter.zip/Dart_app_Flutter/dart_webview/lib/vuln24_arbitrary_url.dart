import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

/// VULN-24: WebView грузит произвольный URL из внешнего источника
/// без allowlist'а доменов.
///
/// `url` приходит снаружи — аналог `intent.getStringExtra("url")` в
/// нативе (в Flutter это deeplink-параметр / аргумент навигации).
/// Любой, кто умеет открыть этот экран с подконтрольным URL, показывает
/// свою страницу внутри нашего приложения (phishing: логотип/чрома наши).
class ArbitraryUrlScreen extends StatefulWidget {
  final String url;
  const ArbitraryUrlScreen({super.key, required this.url});

  @override
  State<ArbitraryUrlScreen> createState() => _ArbitraryUrlScreenState();
}

class _ArbitraryUrlScreenState extends State<ArbitraryUrlScreen> {
  late final WebViewController _controller;

  @override
  void initState() {
    super.initState();
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..loadRequest(Uri.parse(widget.url)); // <-- VULN sink: без проверки домена
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('VULN-24: arbitrary URL')),
      body: WebViewWidget(controller: _controller),
    );
  }
}
