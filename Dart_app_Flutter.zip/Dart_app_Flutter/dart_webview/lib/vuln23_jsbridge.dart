import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:webview_flutter/webview_flutter.dart';

/// VULN-23: JavaScript bridge без проверки origin.
///
/// `addJavaScriptChannel('Native', …)` доступен JS с ЛЮБОЙ страницы,
/// загруженной в этот WebView (включая редирект на сторонний домен из-за
/// open redirect в backend'е). Никакой проверки `controller.currentUrl()`
/// перед выполнением sensitive операций нет.
///
/// Безопасный паттерн (НЕ реализован): перед ответом сверять origin,
/// например `if (url.startsWith('https://app.example.com/')) …`.
class JsBridgeScreen extends StatefulWidget {
  const JsBridgeScreen({super.key});

  @override
  State<JsBridgeScreen> createState() => _JsBridgeScreenState();
}

class _JsBridgeScreenState extends State<JsBridgeScreen> {
  late final WebViewController _controller;

  @override
  void initState() {
    super.initState();
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted) // нужно для bridge
      // VULN sink: канал 'Native' без origin-check — любая страница
      // может вызвать sensitive-операции нативной стороны.
      ..addJavaScriptChannel('Native', onMessageReceived: _onBridgeMessage)
      ..loadRequest(Uri.parse('https://app.example.com/profile'));
  }

  Future<void> _onBridgeMessage(JavaScriptMessage message) async {
    // Никакой проверки источника. Обрабатываем команды любого caller-а.
    if (message.message == 'getAuthToken') {
      // <-- VULN sink: отдаём токен обратно в DOM любому caller-у
      _controller.runJavaScript(
          "window.__nativeToken='eyJhbGciOiJIUzI1NiJ9.fakejwt.fakesig';");
    } else if (message.message.startsWith('save:')) {
      // <-- VULN sink: пишем произвольные данные в SharedPreferences
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('bridge_data', message.message.substring(5));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('VULN-23: JS bridge no origin')),
      body: WebViewWidget(controller: _controller),
    );
  }
}
