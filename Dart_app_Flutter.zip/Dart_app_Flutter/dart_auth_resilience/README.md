# dart_auth_resilience — Dart/Flutter порт (auth & resilience)

Консолидирует **2** уязвимых приложения нативного стенда.

## Что объединено

| Оригинал | Dart-файл | Класс уязвимости | Sink |
|---|---|---|---|
| `31-auth-misconfig-grabbag` | [lib/vuln31_auth_misconfig.dart](lib/vuln31_auth_misconfig.dart) | Biometric без CryptoObject · OAuth без PKCE/state · hardcoded backdoor | `LocalAuthentication.authenticate()` (bool) → unlock-флаг · OAuth-URL без `code_challenge`/`state` · сравнение с `admin:debugbypass` |
| `32-no-protections-baseline` | [lib/vuln32_no_protections.dart](lib/vuln32_no_protections.dart) | Отсутствие RASP-проверок | (отсутствие root/emu/debugger/Frida/integrity/screen-lock — sink = absence) |

## Раскладка файлов

```
dart_auth_resilience/
├── README.md
├── pubspec.yaml                    ← deps: local_auth + shared_preferences
└── lib/
    ├── main.dart                   ← меню; initState дёргает OAuth/backdoor/baseline
    ├── vuln31_auth_misconfig.dart
    └── vuln32_no_protections.dart
```

## Особенности Dart-порта

- **Биометрия без CryptoObject — это дефолт `local_auth`.** Плагин
  возвращает только `bool`; привязки к ключу AndroidKeyStore (как
  `BiometricPrompt.CryptoObject` в нативе) во Flutter-плагине нет вовсе.
  То есть «биометрия как yes/no-флаг» здесь не «забыли сделать», а
  единственный доступный путь — уязвимость по построению.
- **VULN-32** — чистое «отсутствие защит»: сканер репортит по факту
  ненахождения соответствующих API/зависимостей. Код-маркер тривиален.
- Dart-логика (OAuth-URL, backdoor-строка) — в `libapp.so`.

## Форма

Src-снапшот: `lib/` + `pubspec.yaml`. Манифест-уязвимостей нет.
