/// VULN-32: «vanilla» приложение БЕЗ каких-либо защитных проверок.
///
/// Намеренно НЕ содержит:
///   - root detection (нет RootBeer/SafetyNet/Play Integrity, нет ручных
///     проверок su/Magisk/Xposed);
///   - emulator detection (нет проверок Build.FINGERPRINT/MODEL/HARDWARE
///     через device_info_plus);
///   - debugger detection (нет проверки FLAG_DEBUGGABLE);
///   - Frida detection (нет поиска /data/local/tmp/frida-server, hooked
///     классов);
///   - app integrity check (нет сверки подписи APK);
///   - screen-lock check (нет KeyguardManager.isDeviceSecure через плагин).
///
/// Сканер должен сообщить, что эти защиты ОТСУТСТВУЮТ. Сама проверка
/// делается по факту отсутствия в проекте соответствующих вызовов/
/// зависимостей — поэтому код тривиален.
class NoProtectionsBaseline {
  static void noop() {
    // намеренно пусто — отсутствие проверок и есть «уязвимость»
  }
}
