import 'dart:developer' as developer;

import 'package:flutter/material.dart';

import 'vuln31_auth_misconfig.dart';
import 'vuln32_no_protections.dart';

void main() => runApp(const AuthResilienceApp());

class AuthResilienceApp extends StatelessWidget {
  const AuthResilienceApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Dart Auth & Resilience',
      theme: ThemeData(useMaterial3: true),
      home: const HomeScreen(),
    );
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  void initState() {
    super.initState();
    // (2) OAuth-URL без PKCE/state.
    final url = AuthFlows.buildOAuthUrlNoPkceNoState();
    developer.log('oauth url len=${url.length}', name: 'Vuln31');
    // (3) Hardcoded backdoor.
    AuthFlows.tryHardcodedBackdoor('admin:debugbypass');
    // (4) Отсутствие RASP-проверок (baseline).
    NoProtectionsBaseline.noop();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('VULN: auth & resilience')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          ElevatedButton(
            onPressed: AuthFlows.biometricPromptNoCryptoObject,
            child: const Text('VULN-31: biometric without CryptoObject'),
          ),
          ElevatedButton(
            onPressed: () =>
                AuthFlows.tryHardcodedBackdoor('admin:debugbypass'),
            child: const Text('VULN-31: OAuth no-PKCE / hardcoded backdoor'),
          ),
          const SizedBox(height: 12),
          const Text('VULN-32: no root/emulator/debugger/Frida/integrity/'
              'screen-lock checks (absence is the finding)'),
        ],
      ),
    );
  }
}
