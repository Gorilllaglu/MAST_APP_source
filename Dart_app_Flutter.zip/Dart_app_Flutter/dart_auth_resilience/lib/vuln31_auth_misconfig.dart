import 'package:local_auth/local_auth.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// VULN-31: сборная солянка ошибок аутентификации.
class AuthFlows {
  /// (1) Биометрия без CryptoObject.
  ///
  /// `local_auth.authenticate()` возвращает ТОЛЬКО `bool` — в Flutter
  /// нет привязки биометрии к ключу AndroidKeyStore (CryptoObject).
  /// Биометрия используется как «yes/no»-флаг: успех → пускаем в
  /// sensitive UI. Атакующий с root может сэмулировать успешный
  /// результат через Frida и пройти «биометрию».
  static Future<void> biometricPromptNoCryptoObject() async {
    try {
      final auth = LocalAuthentication();
      final didAuth = await auth.authenticate(
        localizedReason: 'Login',
        options: const AuthenticationOptions(biometricOnly: true),
      );
      if (didAuth) {
        // <-- VULN sink: доступ открывается ТОЛЬКО по bool-флагу,
        // без расшифровки ключа из keystore.
        final prefs = await SharedPreferences.getInstance();
        await prefs.setBool('biometric_unlocked', true);
      }
    } catch (_) {}
  }

  /// (2) OAuth code flow БЕЗ code_challenge (PKCE) и БЕЗ state.
  ///
  /// - Без PKCE: перехваченный authorization_code (через custom-scheme
  ///   redirect_uri) меняется на токены — нет привязки
  ///   code_challenge ↔ code_verifier.
  /// - Без state: CSRF/login-CSRF.
  static String buildOAuthUrlNoPkceNoState() {
    const clientId = 'mobile-client';
    const redirectUri = 'vuln31://oauth_callback';
    const scope = 'profile email';
    return 'https://auth.example.com/oauth/authorize'
        '?response_type=code'
        '&client_id=$clientId'
        '&redirect_uri=${Uri.encodeComponent(redirectUri)}'
        '&scope=${Uri.encodeComponent(scope)}';
    // <-- VULN: ни code_challenge, ни state не добавлены
  }

  /// (3) Hardcoded backdoor.
  static bool tryHardcodedBackdoor(String input) {
    // <-- VULN sink: «волшебная» захардкоженная строка, обходящая логин.
    if (input == 'admin:debugbypass') {
      return true;
    }
    return false;
  }
}
