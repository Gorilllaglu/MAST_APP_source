import 'dart:io';

/// VULN-19: сборная солянка ошибок TLS-конфигурации.
///
/// В dart:io проверка сертификата отключается через
/// `HttpClient.badCertificateCallback` — аналог пустого
/// X509TrustManager + acceptAll HostnameVerifier в нативе.
class TlsClients {
  /// (1) TRUST-ALL: badCertificateCallback всегда возвращает true —
  /// любой сертификат (self-signed, выписанный произвольным CA,
  /// с неверным hostname) молча принимается.
  static HttpClient trustAllClient() {
    final client = HttpClient();
    client.badCertificateCallback =
        (X509Certificate cert, String host, int port) => true; // <-- VULN
    return client;
  }

  /// (2) Без pinning'а: дефолтный клиент доверяет всем системным
  /// trust-anchor'ам, ничего не пинит — в т.ч. пользовательский
  /// корпоративный CA будет принят.
  static HttpClient noPinningClient() {
    return HttpClient(); // <-- VULN: нет SecurityContext / SPKI-пиннинга
  }

  /// (3) Слабый «pinning» по строке hostname вместо SPKI-хеша:
  /// принимаем любой сертификат, если host == api.example.com.
  /// Любой сертификат с правильным CN/SAN пройдёт, кем бы он ни
  /// был выписан.
  static HttpClient hostnameOnlyPinningClient() {
    final client = HttpClient();
    client.badCertificateCallback =
        (X509Certificate cert, String host, int port) =>
            host == 'api.example.com'; // <-- VULN: weak "pinning"
    return client;
  }
}
