import 'dart:developer' as developer;
import 'dart:io';

/// VULN-33: чувствительные данные в транзите.
class SensitiveTransit {
  static const String authToken = 'eyJhbGciOiJIUzI1NiJ9.fake.fake';
  static const String username = 'alice';

  static Future<void> run() async {
    final client = HttpClient();

    // (1) HTTPS-запрос с токеном В query-параметрах URL.
    //     Серверы и proxy логируют URL целиком (access.log), плюс
    //     URL уходит в Referer при последующих запросах.
    try {
      final url = Uri.parse('https://api.example.com/profile'
          '?token=${Uri.encodeComponent(authToken)}'                  // <-- VULN sink
          '&user=${Uri.encodeComponent(username)}');
      final req = await client.getUrl(url);
      await req.close();
    } catch (_) {}

    // (2) WebSocket-сообщение содержит JWT прямо в payload.
    try {
      final ws = await WebSocket.connect('wss://realtime.example.com/socket');
      ws.add(                                                          // <-- VULN sink
          '{"action":"auth","jwt":"$authToken","user":"$username"}');
      await ws.close();
    } catch (_) {}

    // (3) POST с password в URL (попадает в access.log, если сервер
    //     логирует query-параметры).
    try {
      final req = await client.postUrl(Uri.parse(
          'https://api.example.com/legacy_login?password=hunter2')); // <-- VULN: password в URL
      await req.close();
    } catch (_) {}

    client.close();
    developer.log('sensitive transit done', name: 'Vuln33');
  }
}
