import 'package:flutter/material.dart';

import 'vuln06_cleartext_http.dart';
import 'vuln19_tls_misconfig.dart';
import 'vuln33_sensitive_transit.dart';

void main() => runApp(const NetworkTlsApp());

class NetworkTlsApp extends StatelessWidget {
  const NetworkTlsApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Dart Network & TLS',
      theme: ThemeData(useMaterial3: true),
      home: const HomeScreen(),
    );
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  void initState() {
    super.initState();
    // Безусловный запуск всех модулей (аналог onCreate, против tree-shaking).
    CleartextHttp.fetchInsecure();
    // Сами методы выполняют уязвимое присваивание badCertificateCallback.
    TlsClients.trustAllClient().close();
    TlsClients.noPinningClient().close();
    TlsClients.hostnameOnlyPinningClient().close();
    SensitiveTransit.run();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('VULN: network & TLS')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          ElevatedButton(
            onPressed: CleartextHttp.fetchInsecure,
            child: const Text('VULN-06: cleartext HTTP + Bearer'),
          ),
          ElevatedButton(
            onPressed: () {
              TlsClients.trustAllClient().close();
              TlsClients.noPinningClient().close();
              TlsClients.hostnameOnlyPinningClient().close();
            },
            child: const Text('VULN-19: trust-all / no-pinning / weak pinning'),
          ),
          ElevatedButton(
            onPressed: SensitiveTransit.run,
            child: const Text('VULN-33: token in URL / JWT in WebSocket'),
          ),
        ],
      ),
    );
  }
}
