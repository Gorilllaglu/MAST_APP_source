import 'dart:convert';
import 'dart:developer' as developer;
import 'dart:io';

/// VULN-06: Cleartext HTTP traffic (MASVS-NETWORK-1, CWE-319).
///
/// Два усиливающих фактора:
///   1. AndroidManifest: android:usesCleartextTraffic="true"
///      (см. android/app/src/main/AndroidManifest.xml). Без него
///      Android (target API 28+) блокирует http:// по умолчанию.
///   2. Реальный HTTP (не HTTPS) запрос на hardcoded URL, при этом
///      пользователь предполагается авторизованным — Authorization
///      заголовок добавлен, чтобы утечка была реалистичной.
class CleartextHttp {
  static Future<void> fetchInsecure() async {
    try {
      final client = HttpClient();
      final req = await client.getUrl(
          Uri.parse('http://api.example.com/v1/profile')); // <-- VULN sink: plain HTTP
      req.headers.set(HttpHeaders.authorizationHeader,
          'Bearer eyJhbGciOiJIUzI1NiJ9.fake.fake');
      final resp = await req.close();
      final body = await resp.transform(utf8.decoder).join();
      developer.log('got ${body.length} bytes', name: 'Vuln06');
      client.close();
    } catch (_) {}
  }
}
