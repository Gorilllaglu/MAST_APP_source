# dart_network_tls — Dart/Flutter порт (network & TLS)

Консолидирует **3** уязвимых приложения нативного MAST-стенда.

## Что объединено

| Оригинал | Dart-файл | Класс уязвимости | Sink |
|---|---|---|---|
| `06-network-cleartext-http` | [lib/vuln06_cleartext_http.dart](lib/vuln06_cleartext_http.dart) | Cleartext HTTP (MASVS-NETWORK-1, CWE-319) | `HttpClient.getUrl(http://…)` + Authorization Bearer **+ манифест** `usesCleartextTraffic="true"` |
| `19-tls-misconfig-grabbag` | [lib/vuln19_tls_misconfig.dart](lib/vuln19_tls_misconfig.dart) | TLS misconfig (trust-all / no-pinning / weak pinning) | `HttpClient.badCertificateCallback => true` и `=> host == 'api.example.com'` |
| `33-sensitive-transit-grabbag` | [lib/vuln33_sensitive_transit.dart](lib/vuln33_sensitive_transit.dart) | Sensitive data in transit | токен в query-URL · JWT в `WebSocket.add(...)` · password в URL POST |

## Раскладка файлов

```
dart_network_tls/
├── README.md
├── pubspec.yaml                    ← deps: только flutter sdk (сеть на dart:io)
├── lib/
│   ├── main.dart                   ← меню; initState дёргает все 3 модуля
│   ├── vuln06_cleartext_http.dart
│   ├── vuln19_tls_misconfig.dart
│   └── vuln33_sensitive_transit.dart
└── android/app/src/main/
    └── AndroidManifest.xml         ← VULN-06: usesCleartextTraffic="true" (манифест-уровень)
```

## Особенности Dart-порта

- **Сеть — на чистом `dart:io`** (`HttpClient`, `WebSocket`): никаких доп.
  пакетов. Trust-all реализован через `badCertificateCallback` (идиоматичный
  способ отключить проверку сертификата в Dart — аналог пустого
  `X509TrustManager` в нативе).
- **VULN-06 — единственная манифест-уровневая** в этой группе: флаг
  `usesCleartextTraffic` лежит в `android/app/src/main/AndroidManifest.xml`
  (нативная обёртка Flutter-проекта) и **ловится сканером обычным путём**,
  в отличие от Dart-логики (она в `libapp.so`).
- Манифест приведён в реалистичном для Flutter виде (FlutterActivity,
  `flutterEmbedding=2`).

## Форма

Src-снапшот: `lib/` + `pubspec.yaml` + только тот кусок `android/`, где живёт
манифест-уязвимость. Полный скаффолд (`flutter create`) не входит.
