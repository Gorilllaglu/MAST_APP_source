# dart_crypto — Dart/Flutter порт (crypto misuse)

Содержит **1** уязвимое приложение нативного стенда. Оставлено отдельным
аппом, т.к. crypto-misuse — крупный самостоятельный класс с 7 разными
sink'ами (каждому соответствует отдельное правило сканера).

## Что объединено

| Оригинал | Dart-файл | Класс уязвимости | Sinks |
|---|---|---|---|
| `17-crypto-misuse-grabbag` | [lib/vuln17_crypto_util.dart](lib/vuln17_crypto_util.dart) | Crypto misuse grab-bag | hardcoded key · AES/ECB · AES/CBC static IV · DES · MD5 · SHA-1 · PBKDF2 1000 iter + weak salt |

## Раскладка файлов

```
dart_crypto/
├── README.md
├── pubspec.yaml                    ← deps: crypto (md5/sha1) + pointycastle (AES/DES/PBKDF2)
└── lib/
    ├── main.dart                   ← меню; initState дёргает все 7 sink'ов
    └── vuln17_crypto_util.dart
```

## Маппинг на пакеты

| Sink | Dart API |
|---|---|
| AES/ECB | `PaddedBlockCipherImpl(PKCS7Padding(), ECBBlockCipher(AESEngine()))` |
| AES/CBC static IV | `CBCBlockCipher(AESEngine())` + `ParametersWithIV(key, staticIv=0)` |
| DES | `CBCBlockCipher(DESEngine())` |
| MD5 / SHA-1 | `package:crypto` `md5.convert` / `sha1.convert` |
| weak PBKDF2 | `PBKDF2KeyDerivator(HMac(SHA1Digest(),64))` + `Pbkdf2Parameters(salt, 1000, 16)` |
| hardcoded key / salt / IV | Dart `const` / `static final` литералы |

## Особенности Dart-порта

- В Dart нет нативного JCE — низкоуровневые примитивы берём из
  `pointycastle` (тот же движок, что под `package:encrypt`). MD5/SHA-1
  идиоматичнее через `package:crypto`.
- Все литералы (ключ `ThisIsTheKey1234`, соль `saltsalt`, нулевой IV)
  и выбор слабых алгоритмов компилируются в `libapp.so` — для SAST
  смотреть `lib/*.dart`, из APK достаётся reFlutter/blutter.

## Форма

Src-снапшот: `lib/` + `pubspec.yaml`. Манифест-уязвимостей нет → `android/`
не нужен.
