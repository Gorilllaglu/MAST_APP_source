import 'dart:developer' as developer;

import 'package:flutter/material.dart';

import 'vuln17_crypto_util.dart';

void main() => runApp(const CryptoApp());

class CryptoApp extends StatelessWidget {
  const CryptoApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Dart Crypto Misuse',
      theme: ThemeData(useMaterial3: true),
      home: const HomeScreen(),
    );
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  void initState() {
    super.initState();
    _runAll();
  }

  void _runAll() {
    // Дёргаем все методы, чтобы tree-shaking их не выкинул (аналог onCreate).
    try {
      developer.log('ecb=${CryptoUtil.aesEcb('hello').length}', name: 'Vuln17');
      developer.log('iv =${CryptoUtil.aesWithStaticIv('hello').length}', name: 'Vuln17');
      developer.log('des=${CryptoUtil.weakDes('hello').length}', name: 'Vuln17');
      developer.log('md5=${CryptoUtil.md5Hash('password')}', name: 'Vuln17');
      developer.log('sha1=${CryptoUtil.sha1Hash('password')}', name: 'Vuln17');
      developer.log('pbkdf=${CryptoUtil.weakPbkdf('password').length}', name: 'Vuln17');
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('VULN-17: crypto misuse')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          ElevatedButton(onPressed: _runAll, child: const Text('Re-run all crypto sinks')),
          const SizedBox(height: 12),
          const Text('Sinks: hardcoded key · AES/ECB · static IV · DES · MD5 · SHA-1 · weak PBKDF'),
        ],
      ),
    );
  }
}
