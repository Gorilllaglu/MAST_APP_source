import 'dart:convert';
import 'dart:typed_data';

import 'package:crypto/crypto.dart' as crypto;
import 'package:pointycastle/export.dart';

/// VULN-17: сборная солянка криптографических ошибок. Каждый метод —
/// отдельный класс уязвимости, по нему сканер должен иметь отдельное правило.
///
/// 1. HARDCODED_KEY — ключ зашит как String-константа в коде.
/// 2. aesEcb — AES/ECB: раскрывает паттерны (одинаковые блоки → одинаковый ct).
/// 3. aesWithStaticIv — AES/CBC с константным IV (нули) → детерминированный ct.
/// 4. weakDes — DES: 56-битный ключ, brute-force за дни.
/// 5. md5Hash — MD5: коллизии, непригоден.
/// 6. sha1Hash — SHA-1: коллизии, deprecated.
/// 7. weakPbkdf — PBKDF2 с iterationCount=1000 (OWASP: ≥600000) + слабая соль.
class CryptoUtil {
  // (1) hardcoded key (16 байт → AES-128)
  static const String hardcodedKey = 'ThisIsTheKey1234';

  // (3) static IV (нули)
  static final Uint8List staticIv = Uint8List(16);

  // (7) weak salt
  static final Uint8List weakSalt = Uint8List.fromList(utf8.encode('saltsalt'));

  static Uint8List _keyBytes() => Uint8List.fromList(utf8.encode(hardcodedKey));

  static Uint8List aesEcb(String plaintext) {
    final cipher = PaddedBlockCipherImpl(PKCS7Padding(), ECBBlockCipher(AESEngine())); // <-- VULN: ECB
    cipher.init(true, PaddedBlockCipherParameters(KeyParameter(_keyBytes()), null));
    return cipher.process(Uint8List.fromList(utf8.encode(plaintext)));
  }

  static Uint8List aesWithStaticIv(String plaintext) {
    final cipher = PaddedBlockCipherImpl(PKCS7Padding(), CBCBlockCipher(AESEngine()));
    cipher.init(
        true,
        PaddedBlockCipherParameters(
            ParametersWithIV(KeyParameter(_keyBytes()), staticIv), null)); // <-- VULN: static IV
    return cipher.process(Uint8List.fromList(utf8.encode(plaintext)));
  }

  static Uint8List weakDes(String plaintext) {
    final key = Uint8List.fromList(utf8.encode('8byteKey'));
    final iv = Uint8List(8)..fillRange(0, 8, 1);
    final cipher = PaddedBlockCipherImpl(PKCS7Padding(), CBCBlockCipher(DESEngine())); // <-- VULN: weak cipher
    cipher.init(
        true, PaddedBlockCipherParameters(ParametersWithIV(KeyParameter(key), iv), null));
    return cipher.process(Uint8List.fromList(utf8.encode(plaintext)));
  }

  static String md5Hash(String input) {
    return crypto.md5.convert(utf8.encode(input)).toString(); // <-- VULN: weak hash
  }

  static String sha1Hash(String input) {
    return crypto.sha1.convert(utf8.encode(input)).toString(); // <-- VULN: weak hash
  }

  static Uint8List weakPbkdf(String password) {
    final derivator = PBKDF2KeyDerivator(HMac(SHA1Digest(), 64))
      ..init(Pbkdf2Parameters(weakSalt, 1000, 16)); // <-- VULN: low iter (1000) + weak salt
    return derivator.process(Uint8List.fromList(utf8.encode(password)));
  }
}
