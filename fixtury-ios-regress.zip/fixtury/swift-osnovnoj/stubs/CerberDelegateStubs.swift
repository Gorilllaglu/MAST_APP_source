// Расширенный протокол делегата. ПРЕДПОЛОЖЕНИЕ: подтверждены только четыре
// метода — didLogin, didFailLogin, userChanged, wipe. Остальные четыре имени
// отчёт берёт из андроидных названий, что для Swift нехарактерно, поэтому в
// клетках они даны в нескольких написаниях: сработает то, которое существует.
// Протокол объявлен без тел. В первом прогоне правила на пустое тело
// сработали и здесь: движок принял объявление без тела за пустое тело.
// В правила добавлено исключение pattern-not-inside на protocol, и этот
// файл служит второй его проверкой — находок на нём быть не должно.

import Foundation

public protocol CerberDelegateFull: AnyObject {
    func didLogin()
    func didFailLogin()
    func userChanged()
    func wipe()
    func didDetectJailbreak(isJailbroken: Bool)
    func didLogout()
    func onNoAuthDetected()
    func onFileReceived(_ url: URL)
}

public final class CerberFile { public let id: String = ""; public let url: URL = URL(fileURLWithPath: "/") }
