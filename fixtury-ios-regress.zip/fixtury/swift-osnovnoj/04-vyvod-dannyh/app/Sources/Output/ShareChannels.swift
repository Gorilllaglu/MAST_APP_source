// Системный лист «Поделиться» и ограничение получателей.

import UIKit
import SwiftUI

final class ShareChannels {

    /// IS-SH-TP-1. Лист с полным перечнем получателей.
    func shareText(_ text: String, from vc: UIViewController) {
        let sheet = UIActivityViewController(activityItems: [text], applicationActivities: nil)
        vc.present(sheet, animated: true)
    }

    /// IS-SH-TP-2. Лист с файлом.
    func shareFile(_ file: URL, from vc: UIViewController) {
        let sheet = UIActivityViewController(activityItems: [file])
        vc.present(sheet, animated: true)
    }

    /// IS-SH-TP-4, IS-SE-TP-1. Получатели ограничены: ни AirDrop, ни почта,
    /// ни сохранение в «Файлы». Маркер ограничений обязан это найти,
    /// правило на сам лист — тоже сработать: канал всё равно есть, и это
    /// не ложная сработка, а назначение правила. У семейства SH своей
    /// клетки TN нет: лист отправки — поверхность, молчать правилу негде.
    func shareRestricted(_ text: String, from vc: UIViewController) {
        let sheet = UIActivityViewController(activityItems: [text], applicationActivities: nil)
        sheet.excludedActivityTypes = [.airDrop, .mail, .message, .copyToPasteboard]
        vc.present(sheet, animated: true)
    }
}

struct ShareRow: View {

    let document: URL

    /// IS-SH-TP-3. Лист «Поделиться» средствами SwiftUI.
    var body: some View {
        ShareLink(item: document)
    }
}
