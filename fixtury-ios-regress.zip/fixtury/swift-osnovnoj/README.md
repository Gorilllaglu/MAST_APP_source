# Дерево фикстур для 59 правил на Swift

188 клеток, фикстура есть у каждого из 59 swift-правил. Прогонять с правилами из `rules/` по корню дерева. Семь правил по `Info.plist` и `.entitlements` лежат в деревьях `../plist-*`.

Блоки соответствуют группам набора: `01-sdk-i-options` — группа A, `02-delegat` — B, `03-bufer` — C, `04-vyvod-dannyh` — D, `05-webview` — E, `06-ekran-i-vvod` — F, `07-hranenie` — G, `08-set` — H, `09-vhodyashchie` — I.

## Карта правил

| Код | Правило | Полка | Клетки |
|---|---|---|---|
| `AC` | `cerber-ios-app-group-container-write` | WARNING+INFO | `TP-1`, `TP-2`, `TN-1` |
| `BS` | `cerber-ios-background-snapshot-unprotected` | WARNING+INFO | `TP-1`, `TP-2`, `TP-3` |
| `CP` | `cerber-ios-custom-pasteboard-created` | WARNING+MEDIUM | `TP-1`, `TP-2`, `TP-3`, `TN-1` |
| `LG` | `cerber-ios-debug-logging-enabled` | WARNING+MEDIUM | `TP-1`, `TN-1`, `TN-2` |
| `DL` | `cerber-ios-delegate-not-set` | WARNING+INFO | `TP-1`, `TP-2` |
| `DI` | `cerber-ios-did-login-handler-empty` | WARNING+INFO | `TP-1`, `TP-2`, `TN-1` |
| `US` | `cerber-ios-direct-urlsession` | WARNING+LOW | `TP-1`, `TP-2`, `TN-1`, `PROBE-1` |
| `DE` | `cerber-ios-document-export` | WARNING+INFO | `TP-1` |
| `DD` | `cerber-ios-drag-and-drop-enabled` | ERROR+MEDIUM | `TP-1`, `TP-2`, `TP-3`, `TN-1` |
| `DR` | `cerber-ios-drop-destination-open` | WARNING+INFO | `TP-1`, `TP-2`, `PROBE-1` |
| `FP` | `cerber-ios-file-protection-none` | WARNING+MEDIUM | `TP-1`, `TP-2`, `TN-1` |
| `FR` | `cerber-ios-file-received-handler-empty` | WARNING+INFO | `TP-1`, `TP-2`, `TN-1` |
| `PB` | `cerber-ios-host-pasteboard-bypass` | ERROR+HIGH | `TP-1`, `TP-2`, `TP-3`, `TP-4`, `TP-5`, `TP-6`, `TP-7`, `TN-1` |
| `UP` | `cerber-ios-identity-from-url-payload` | WARNING+INFO | `TP-1`, `TN-1` |
| `JD` | `cerber-ios-jailbreak-check-disabled` | ERROR+MEDIUM | `TP-1`, `TN-1` |
| `JV` | `cerber-ios-jailbreak-check-variable` | WARNING+INFO | `TP-1`, `TN-1` |
| `JW` | `cerber-ios-jailbreak-check-weak` | WARNING+MEDIUM | `TP-1`, `TN-1` |
| `JE` | `cerber-ios-jailbreak-handler-empty` | WARNING+MEDIUM | `TP-1`, `TP-2`, `TN-1` |
| `JM` | `cerber-ios-jailbreak-handler-missing` | WARNING+INFO | `TP-1` |
| `AG` | `cerber-ios-keychain-access-group-nil` | WARNING+INFO | `TP-1`, `TN-1` |
| `KA` | `cerber-ios-keychain-weak-accessibility` | ERROR+MEDIUM | `TP-1`, `TP-2`, `TN-1`, `TN-2` |
| `LO` | `cerber-ios-logout-handler-empty` | WARNING+MEDIUM | `TP-1`, `TP-2`, `TN-1`, `PROBE-1` |
| `MA` | `cerber-ios-menu-actions-unrestricted` | WARNING+MEDIUM | `TP-1`, `TP-2`, `TN-1` |
| `MR` | `cerber-ios-menu-restriction-marker` | WARNING+INFO | `TP-1`, `TP-2` |
| `NA` | `cerber-ios-no-auth-handler-empty` | ERROR+MEDIUM | `TP-1`, `TP-2`, `TP-3`, `TN-1`, `TN-2` |
| `MD` | `cerber-ios-non-production-mode` | WARNING+INFO | `TP-1`, `TP-2`, `TN-1`, `TN-2`, `PROBE-1`, `PROBE-2`, `PROBE-3` |
| `MV` | `cerber-ios-non-production-mode-variable` | WARNING+INFO | `TP-1`, `TN-1` |
| `OU` | `cerber-ios-open-url-no-source-check` | ERROR+MEDIUM | `TP-1`, `TP-2`, `TN-1`, `PROBE-1` |
| `BI` | `cerber-ios-own-biometry-policy` | WARNING+MEDIUM | `TP-1`, `TP-2`, `TN-1` |
| `CE` | `cerber-ios-own-certificate-expiry-logic` | WARNING+LOW | `TP-1`, `TP-2` |
| `OP` | `cerber-ios-own-pin-screen` | WARNING+INFO | `TP-1`, `TP-2`, `TP-3`, `TN-1` |
| `PW` | `cerber-ios-passwordless-auth-disabled` | WARNING+MEDIUM | `TP-1`, `TN-1`, `PROBE-1` |
| `PV` | `cerber-ios-passwordless-auth-variable` | WARNING+INFO | `TP-1`, `TN-1` |
| `PR` | `cerber-ios-pasteboard-read` | WARNING+INFO | `TP-1`, `TP-2`, `TP-3`, `TN-1` |
| `PO` | `cerber-ios-pasteboard-without-options` | WARNING+MEDIUM | `TP-1`, `TN-1` |
| `PT` | `cerber-ios-print-channel` | WARNING+INFO | `TP-1`, `TP-2`, `TP-3`, `TN-1` |
| `RF` | `cerber-ios-received-file-not-copied` | WARNING+MEDIUM | `TP-1`, `TP-2`, `TN-1`, `TN-2` |
| `CA` | `cerber-ios-screen-capture-not-observed` | WARNING+INFO | `TP-1`, `TP-2`, `TP-3` |
| `BW` | `cerber-ios-sdk-buffer-write-result-ignored` | WARNING+MEDIUM | `TP-1`, `TP-2`, `TN-1`, `TN-2`, `TN-3`, `TN-4` |
| `ST` | `cerber-ios-sdk-not-started` | WARNING+INFO | `TP-1`, `TP-2`, `TP-3` |
| `SC` | `cerber-ios-secure-clipboard-disabled` | WARNING+INFO | `TP-1`, `TN-1` |
| `SS` | `cerber-ios-secure-screen-disabled` | ERROR+HIGH | `TP-1`, `TN-1` |
| `SN` | `cerber-ios-secure-screen-not-set` | WARNING+INFO | `TP-1`, `TN-1` |
| `TE` | `cerber-ios-secure-text-entry-disabled` | WARNING+MEDIUM | `TP-1`, `TN-1`, `PROBE-1` |
| `UD` | `cerber-ios-sensitive-in-userdefaults` | WARNING+LOW | `TP-1`, `TP-2`, `TN-1` |
| `SE` | `cerber-ios-share-exclusions-marker` | WARNING+INFO | `TP-1` |
| `SU` | `cerber-ios-swiftui-text-selection` | WARNING+MEDIUM | `TP-1`, `TP-2`, `TP-3`, `TN-1`, `PROBE-1` |
| `SH` | `cerber-ios-system-share-sheet` | WARNING+INFO | `TP-1`, `TP-2`, `TP-3`, `TP-4` |
| `TF` | `cerber-ios-temp-file-not-deleted` | WARNING+LOW | `TP-1`, `TP-2`, `TN-1` |
| `SP` | `cerber-ios-test-ssl-pinning-enabled` | WARNING+MEDIUM | `TP-1`, `TN-1` |
| `TS` | `cerber-ios-text-selection-enabled` | WARNING+MEDIUM | `TP-1`, `TP-2`, `TN-1` |
| `TR` | `cerber-ios-trust-all-certificates` | ERROR+HIGH | `TP-1`, `TN-1` |
| `UL` | `cerber-ios-universal-link-surface` | WARNING+INFO | `TP-1` |
| `UC` | `cerber-ios-user-changed-handler-empty` | WARNING+MEDIUM | `TP-1`, `TP-2`, `TN-1`, `TN-2`, `PROBE-1` |
| `WF` | `cerber-ios-webview-file-access-enabled` | ERROR+MEDIUM | `TP-1`, `TP-2`, `TP-3`, `TN-1` |
| `WJ` | `cerber-ios-webview-javascript-enabled` | WARNING+MEDIUM | `TP-1`, `TP-2`, `TN-1` |
| `WH` | `cerber-ios-webview-load-html-string` | WARNING+INFO | `TP-1`, `TP-2`, `TN-1` |
| `WS` | `cerber-ios-webview-selection-unrestricted` | WARNING+MEDIUM | `TP-1`, `TP-2`, `TN-1`, `TN-2` |
| `WP` | `cerber-ios-wipe-handler-empty` | ERROR+HIGH | `TP-1`, `TP-2`, `TN-1`, `TN-2`, `PROBE-1`, `PROBE-2`, `PROBE-3` |
## Где что лежит

| Файл | Коды правил |
|---|---|
| `01-sdk-i-options/app/Sources/Setup/SdkStartup.swift` | `DL`, `ST` |
| `01-sdk-i-options/app/Sources/Setup/SecureScreenNotSet.swift` | `SN` |
| `01-sdk-i-options/app/Sources/Setup/SetupClean.swift` | `AG`, `JD`, `JV`, `JW`, `LG`, `MD`, `MV`, `PV`, `PW`, `SC`, `SN`, `SP`, `SS` |
| `01-sdk-i-options/app/Sources/Setup/SetupDefect.swift` | `AG`, `JD`, `JV`, `JW`, `LG`, `MD`, `MV`, `PV`, `PW`, `SC`, `SP`, `SS` |
| `01-sdk-i-options/app/Sources/Setup/SetupProbes.swift` | `MD`, `PW` |
| `02-delegat/app/Sources/Delegate/DefectCoordinator.swift` | `DI`, `FR`, `JE`, `LO`, `NA`, `UC`, `WP` |
| `02-delegat/app/Sources/Delegate/DelegateProbes.swift` | `LO`, `UC`, `WP` |
| `02-delegat/app/Sources/Delegate/ReferenceCoordinator.swift` | `DI`, `FR`, `JE`, `JM`, `LO`, `NA`, `UC`, `WP` |
| `02-delegat/app/Sources/Delegate/ReturnOnlyCoordinator.swift` | `DI`, `FR`, `JE`, `LO`, `NA`, `UC`, `WP` |
| `03-bufer/app/Sources/Pasteboard/BufferWrites.swift` | `BW` |
| `03-bufer/app/Sources/Pasteboard/PasteboardClean.swift` | `BW`, `PB`, `PO` |
| `03-bufer/app/Sources/Pasteboard/PasteboardSurface.swift` | `CP`, `PR` |
| `03-bufer/app/Sources/Pasteboard/PasteboardWrites.swift` | `PB`, `PO` |
| `04-vyvod-dannyh/app/Sources/Output/DragAndDrop.swift` | `DD`, `DR` |
| `04-vyvod-dannyh/app/Sources/Output/OutputProbes.swift` | `DR`, `SU` |
| `04-vyvod-dannyh/app/Sources/Output/PrintChannel.swift` | `PT` |
| `04-vyvod-dannyh/app/Sources/Output/SelectionSwiftUI.swift` | `MR`, `SU` |
| `04-vyvod-dannyh/app/Sources/Output/SelectionUIKit.swift` | `MA`, `MR`, `TS` |
| `04-vyvod-dannyh/app/Sources/Output/ShareChannels.swift` | `SE`, `SH` |
| `05-webview/app/Sources/WebView/WebViewClean.swift` | `WF`, `WH`, `WJ`, `WS` |
| `05-webview/app/Sources/WebView/WebViewSetup.swift` | `WF`, `WH`, `WJ`, `WS` |
| `06-ekran-i-vvod/app/Sources/Screen/ScreenProtection.swift` | `BS`, `CA` |
| `06-ekran-i-vvod/app/Sources/Screen/SecureInput.swift` | `BI`, `OP`, `TE` |
| `07-hranenie/app/Sources/Storage/StorageClean.swift` | `AC`, `FP`, `KA`, `TF` |
| `07-hranenie/app/Sources/Storage/StorageDefect.swift` | `AC`, `DE`, `FP`, `KA`, `TF`, `UD` |
| `08-set/app/Sources/Network/NetworkClean.swift` | `TR`, `US` |
| `08-set/app/Sources/Network/NetworkDefect.swift` | `CE`, `TR`, `US` |
| `09-vhodyashchie/app/Sources/Inbound/FileIntake.swift` | `RF` |
| `09-vhodyashchie/app/Sources/Inbound/InboundProbes.swift` | `OU` |
| `09-vhodyashchie/app/Sources/Inbound/UrlHandlers.swift` | `OU`, `UL`, `UP` |
## Чего в этих фикстурах нет

Objective-C. Если в продукте есть части на ObjC, их надо считать непокрытыми: правил под этот язык в наборе нет, и клеток тоже.

Сборки. Дерево не компилируется и не задумано компилируемым: заглушки покрывают API CerberSDK, но не UIKit, WebKit, SwiftUI и Security — их объявления берутся из системных фреймворков, которых здесь нет. Для статического анализа это не нужно, для разбора глазами достаточно.

## Что в этом дереве проверяется, кроме самих правил

**Столкновение имён.** Клетка `IS-BW-TN-4` — свой класс со методом `write`, получатель не похож на буфер SDK. На андроидном наборе такое столкновение давало 35–53 ложных срабатывания на приложение, пока получателя не сузили регуляркой. Клетка `IS-LO-PROBE-1` — свой метод `logout()` с пустым телом: на андроиде в Efir нашлось двадцать своих `onLogout` вне колбэка SDK, и правило спасло только то, что тела у них непустые.

**Ложная сработка на объявлении без тела.** Клетки `IS-WP-TN-2` и `IS-UC-TN-2` — объявления в протоколе. На андроидном наборе близнецы этих правил ловили объявления в интерфейсе, включая заглушку SDK, и лечилось это исключением `pattern-not-inside` на `interface`. Ожидание было — молчание без всяких исключений, потому что у объявления в протоколе Swift тела нет вовсе. Прогон 1 показал обратное: сработали все восемь правил группы B, тринадцать находок на объявлениях в фикстуре и в заглушках. В правила добавлено `pattern-not-inside` на `protocol` в двух формах, с наследованием и без, и эти клетки теперь проверяют исключение, а не прогноз.

**Форма, которую отчёт объявил неприменимой.** Клетка `IS-PT-TN-1` — функция языка `print()`, пишущая в консоль. Исходный отчёт спутал её с системной печатью и на этом основании решил, что канал печати в iOS отсутствует. Клетка `IS-PT-TP-1` рядом — настоящая системная печать через `UIPrintInteractionController`.

**Цена слабых ветвей.** Три клетки сработают, и это заранее известно: `IS-TE-PROBE-1` (числовое поле SwiftUI шаблоном не отличить от поля PIN), `IS-OU-PROBE-1` (проверка источника вынесена в отдельную функцию, шаблон её не видит), `IS-UD-TN-1` граничная по эвристике имени ключа. Клетки нужны, чтобы цена этих ветвей была видна в отчёте, а не обнаруживалась на живом приложении.
