// Хранение: формы, которые правила обязаны найти.

import Foundation

final class StorageDefect {

    /// IS-UD-TP-1. Токен в UserDefaults: plist в контейнере, попадает в
    /// резервные копии, читается с устройства с jailbreak.
    func saveToken(_ token: String) {
        UserDefaults.standard.set(token, forKey: "accessToken")
    }

    /// IS-UD-TP-2. Код в UserDefaults через setValue.
    func savePasscode(_ code: String) {
        UserDefaults.standard.setValue(code, forKey: "userPasscode")
    }

    /// IS-UD-TN-1. Ключ не похож на учётные данные: правило обязано
    /// промолчать. Правило эвристическое, и граница у него именно здесь.
    func saveHintShown() {
        UserDefaults.standard.set(true, forKey: "hasSeenKeyboardHint")
    }

    /// IS-KA-TP-1. Запись keychain доступна при заблокированном устройстве.
    func storeAlways(_ data: Data) {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrAccount as String: "corp.session",
            kSecValueData as String: data,
            kSecAttrAccessible as String: kSecAttrAccessibleAlways
        ]
        SecItemAdd(query as CFDictionary, nil)
    }

    /// IS-KA-TP-2. Доступна с первой разблокировки после загрузки.
    func storeAfterFirstUnlock(_ data: Data) {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrAccount as String: "corp.refresh",
            kSecValueData as String: data,
            kSecAttrAccessible as String: kSecAttrAccessibleAfterFirstUnlock
        ]
        SecItemAdd(query as CFDictionary, nil)
    }

    /// IS-FP-TP-1. Файл записан без файловой защиты.
    func writeUnprotected(_ data: Data, to url: URL) throws {
        try data.write(to: url)
        try FileManager.default.setAttributes(
            [.protectionKey: FileProtectionType.none],
            ofItemAtPath: url.path
        )
    }

    /// IS-FP-TP-2. Ослабленный класс защиты.
    func writeUntilFirstAuth(_ url: URL) throws {
        try FileManager.default.setAttributes(
            [.protectionKey: FileProtectionType.completeUntilFirstUserAuthentication],
            ofItemAtPath: url.path
        )
    }

    /// IS-TF-TP-1. Временный файл создан, удаления рядом нет.
    func stageForUpload(_ data: Data) throws -> URL {
        let staged = FileManager.default.temporaryDirectory.appendingPathComponent("upload.bin")
        try data.write(to: staged)
        Uploader.shared.send(staged)
        return staged
    }

    /// IS-TF-TP-2. Путь через NSTemporaryDirectory.
    func legacyTemp() -> URL {
        return URL(fileURLWithPath: NSTemporaryDirectory())
    }

    /// IS-AC-TP-1. Запись в общий контейнер группы приложений.
    func sharedContainer() -> URL? {
        return FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: "group.corp.shared")
    }

    /// IS-AC-TP-2. Общие настройки группы.
    func sharedDefaults() -> UserDefaults? {
        return UserDefaults(suiteName: "group.corp.shared")
    }

    /// IS-DE-TP-1. Выгрузка документа в выбранное пользователем место.
    func exportDocument(_ url: URL, from vc: UIViewController) {
        let picker = UIDocumentPickerViewController(forExporting: [url])
        vc.present(picker, animated: true)
    }
}

final class Uploader { static let shared = Uploader(); func send(_ url: URL) {} }
