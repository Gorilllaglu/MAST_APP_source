// Сторона TN хранения.

import Foundation
import SwiftUI

final class StorageClean {

    /// IS-KA-TN-1. Класс доступности требует разблокированного устройства
    /// и не выходит за пределы этого устройства.
    func storeTight(_ data: Data) {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrAccount as String: "corp.tight",
            kSecValueData as String: data,
            kSecAttrAccessible as String: kSecAttrAccessibleWhenUnlockedThisDeviceOnly
        ]
        SecItemAdd(query as CFDictionary, nil)
    }

    /// IS-KA-TN-2. Класс, требующий установленного код-пароля.
    func storePasscodeBound(_ data: Data) {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrAccount as String: "corp.bound",
            kSecValueData as String: data,
            kSecAttrAccessible as String: kSecAttrAccessibleWhenPasscodeSetThisDeviceOnly
        ]
        SecItemAdd(query as CFDictionary, nil)
    }

    /// IS-FP-TN-1. Полная файловая защита.
    func writeProtected(_ url: URL) throws {
        try FileManager.default.setAttributes(
            [.protectionKey: FileProtectionType.complete],
            ofItemAtPath: url.path
        )
    }

    /// IS-TF-TN-1. Временный файл создан и удалён в том же методе.
    func stageAndClean(_ data: Data) throws {
        let staged = FileManager.default.temporaryDirectory.appendingPathComponent("tmp.bin")
        try data.write(to: staged)
        Uploader.shared.send(staged)
        try FileManager.default.removeItem(at: staged)
    }

    /// IS-AC-TN-1. Запись в приватный каталог приложения, не в группу.
    func privateContainer() throws -> URL {
        return try FileManager.default.url(
            for: .documentDirectory,
            in: .userDomainMask,
            appropriateFor: nil,
            create: true
        )
    }
}
