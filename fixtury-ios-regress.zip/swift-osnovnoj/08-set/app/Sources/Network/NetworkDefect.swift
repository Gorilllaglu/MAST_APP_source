// Сеть.

import Foundation

final class NetworkDefect: NSObject {

    /// IS-US-TP-1. Своя сессия в обход фабрики SDK.
    func makeSession() -> URLSession {
        let configuration = URLSessionConfiguration.default
        return URLSession(configuration: configuration)
    }

    /// IS-US-TP-2. Прямой запрос через общую сессию.
    func fetch(_ request: URLRequest, _ completion: @escaping (Data?) -> Void) {
        URLSession.shared.dataTask(with: request) { data, _, _ in
            completion(data)
        }.resume()
    }

    /// IS-CE-TP-1. Своё чтение срока действия сертификата.
    func expiry(of certificate: SecCertificate) -> CFDictionary? {
        let keys = [kSecOIDX509V1ValidityNotAfter] as CFArray
        return SecCertificateCopyValues(certificate, keys, nil)
    }

    /// IS-CE-TP-2. Своё вычисление доверия.
    func evaluate(_ trust: SecTrust) -> Bool {
        return SecTrustEvaluateWithError(trust, nil)
    }
}

extension NetworkDefect: URLSessionDelegate {

    /// IS-TR-TP-1. Запрос доверия закрыт принятием предъявленной цепочки:
    /// соединение примет сертификат от любого, кто способен его перехватить.
    func urlSession(_ session: URLSession,
                    didReceive challenge: URLAuthenticationChallenge,
                    completionHandler: @escaping (URLSession.AuthChallengeDisposition, URLCredential?) -> Void) {
        completionHandler(.useCredential, URLCredential(trust: challenge.protectionSpace.serverTrust!))
    }
}
