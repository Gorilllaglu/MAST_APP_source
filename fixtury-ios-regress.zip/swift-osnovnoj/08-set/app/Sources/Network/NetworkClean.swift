// Сторона TN сети.

import Foundation

final class NetworkClean: NSObject {

    private let cerber = Cerber.shared

    /// IS-US-TN-1. Сессия получена у SDK — своей конфигурации нет.
    /// Клетка условная: есть ли у iOS-сборки SDK фабрика сессии, не
    /// подтверждено. Если фабрики нет, этой формы в природе не существует,
    /// и правило о своей сессии будет срабатывать у всех.
    func sdkSession() -> URLSession? {
        return SdkNetwork.session
    }
}

extension NetworkClean: URLSessionDelegate {

    /// IS-TR-TN-1. Цепочка сверена с закреплённой, при несовпадении запрос
    /// отклонён.
    func urlSession(_ session: URLSession,
                    didReceive challenge: URLAuthenticationChallenge,
                    completionHandler: @escaping (URLSession.AuthChallengeDisposition, URLCredential?) -> Void) {
        guard let trust = challenge.protectionSpace.serverTrust,
              Pinning.matchesPinnedChain(trust) else {
            completionHandler(.cancelAuthenticationChallenge, nil)
            return
        }
        completionHandler(.performDefaultHandling, nil)
    }
}

enum SdkNetwork { static let session: URLSession? = nil }
enum Pinning { static func matchesPinnedChain(_ trust: SecTrust) -> Bool { return false } }
