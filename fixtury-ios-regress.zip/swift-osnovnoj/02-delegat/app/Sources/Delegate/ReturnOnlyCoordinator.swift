// Второй вид пустого тела: единственный return. Отдельный файл, потому что
// текст совпавшего узла должен отличаться от клеток в DefectCoordinator —
// иначе движок свернёт находки одного правила в одну.

import Foundation

final class ReturnOnlyCoordinator {
    let cerber = Cerber.shared
}

extension ReturnOnlyCoordinator: CerberDelegateFull {

    /// IS-DI-TP-2. Тело из одного return.
    func didLogin() {
        return
    }

    func didFailLogin() {
        return
    }

    /// IS-UC-TP-2. Тело из одного return.
    func userChanged() {
        return
    }

    /// IS-WP-TP-2. Тело из одного return.
    func wipe() {
        return
    }

    /// IS-JE-TP-2. Тело из одного return.
    func didDetectJailbreak(isJailbroken: Bool) {
        return
    }

    /// IS-LO-TP-2. Тело из одного return.
    func didLogout() {
        return
    }

    /// IS-NA-TP-3. Тело из одного return.
    func onNoAuthDetected() {
        return
    }

    /// IS-FR-TP-2. Тело из одного return.
    func onFileReceived(_ url: URL) {
        return
    }
}
