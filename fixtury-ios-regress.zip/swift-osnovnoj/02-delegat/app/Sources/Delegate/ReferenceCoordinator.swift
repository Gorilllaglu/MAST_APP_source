// Сторона TN: эталонная реализация делегата. Все клетки обязаны промолчать.
// IS-JM-TP-1 — маркер наличия обработчика jailbreak, он обязан сработать
// именно здесь: его ценность в молчании на проекте, где обработчика нет.

import Foundation

final class ReferenceCoordinator {

    let cerber = Cerber.shared
    private let store = LocalStore()
    private let keychain = KeychainService()

    func start() {
        cerber.setDelegateManager(delegate: self)
        cerber.start()
    }
}

extension ReferenceCoordinator: CerberDelegateFull {

    /// IS-DI-TN-1. Вход обработан: состояние поднято, данные перезапрошены.
    func didLogin() {
        store.unlock()
        store.refresh()
    }

    /// IS-NA-TN-1. Отказ входа обработан: данные снесены, вход показан заново.
    func didFailLogin() {
        store.wipeAll()
        Router.shared.showAuthentication()
    }

    /// IS-UC-TN-1. Смена пользователя обработана: кеши и идентификаторы сняты.
    /// Форма взята из SberApps, где userChanged удаляет clickstreamId.
    func userChanged() {
        keychain.delete(key: .clickstreamId)
        store.dropPerUserCaches()
    }

    /// IS-WP-TN-1. Требование очистки обработано.
    func wipe() {
        store.wipeAll()
        keychain.deleteAll()
        Router.shared.showAuthentication()
    }

    /// IS-JM-TP-1. Маркер: обработчик вердикта по jailbreak существует.
    /// IS-JE-TN-1. И его тело не пустое.
    func didDetectJailbreak(isJailbroken: Bool) {
        guard isJailbroken else { return }
        store.wipeAll()
        keychain.deleteAll()
        Router.shared.showCompromisedDevice()
    }

    /// IS-LO-TN-1. Выход обработан.
    func didLogout() {
        store.endSession()
        Router.shared.showAuthentication()
    }

    /// IS-NA-TN-2. Вердикт об отсутствии авторизации обработан.
    func onNoAuthDetected() {
        store.wipeAll()
        Router.shared.showAuthentication()
    }

    /// IS-FR-TN-1. Принятый файл скопирован в своё хранилище.
    func onFileReceived(_ url: URL) {
        let destination = store.documentsDirectory.appendingPathComponent(url.lastPathComponent)
        try? FileManager.default.copyItem(at: url, to: destination)
        store.register(destination)
    }
}

final class LocalStore {
    let documentsDirectory = URL(fileURLWithPath: "/documents")
    func unlock() {}
    func refresh() {}
    func wipeAll() {}
    func dropPerUserCaches() {}
    func endSession() {}
    func register(_ url: URL) {}
}

final class KeychainService {
    enum Key { case clickstreamId, accessToken }
    func delete(key: Key) {}
    func deleteAll() {}
}

final class Router {
    static let shared = Router()
    func showAuthentication() {}
    func showCompromisedDevice() {}
}
