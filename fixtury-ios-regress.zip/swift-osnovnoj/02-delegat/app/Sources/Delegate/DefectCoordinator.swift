// Сторона TP колбэков: тела пустые. Это та форма, которую правила ищут,
// и на андроидном наборе она встречается в продакшене — в SberApps андроид
// пустые onRootDetected, onUserChanged и onNoAuthDetected, в Efir пустые
// onFileReceived и onNoAuthDetected.

import Foundation

final class DefectCoordinator {
    let cerber = Cerber.shared
    func start() { cerber.setDelegateManager(delegate: self) }
}

extension DefectCoordinator: CerberDelegateFull {

    /// IS-DI-TP-1. Вход состоялся, приложение не реагирует.
    func didLogin() {
    }

    /// IS-NA-TP-1. Отказ входа проигнорирован.
    func didFailLogin() {
    }

    /// IS-UC-TP-1. Смена пользователя проигнорирована: кеши прежнего остались.
    func userChanged() {
    }

    /// IS-WP-TP-1. SDK потребовал уничтожить данные, приложение их оставило.
    func wipe() {
    }

    /// IS-JE-TP-1. Вердикт по jailbreak получен и отброшен.
    func didDetectJailbreak(isJailbroken: Bool) {
    }

    /// IS-LO-TP-1. Выход вне приложения проигнорирован.
    func didLogout() {
    }

    /// IS-NA-TP-2. Вердикт об отсутствии авторизации проигнорирован.
    func onNoAuthDetected() {
    }

    /// IS-FR-TP-1. Принятый файл выброшен.
    func onFileReceived(_ url: URL) {
    }
}
