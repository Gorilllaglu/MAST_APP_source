// Сторона TP параметров SetupOptions. Каждая клетка — отдельный вызов,
// текст совпавшего узла у всех разный, иначе движок свернёт находки в одну.
// Вызовы намеренно многострочные: так их пишут в жизни.

import Foundation

enum SetupDefect {

    /// IS-PW-TP-1. Беспарольный вход выключен литералом.
    static func passwordlessOff(_ cerber: Cerber) {
        cerber.options = SetupOptions(
            mode: .prod,
            loginOptions: LoginOptions(),
            isPasswordlessEnabled: false,
            jailbreakCheckerType: .full,
            accessGroupID: "group.corp.sso",
            loggerOptions: [],
            enableTestSSLPinning: false
        )
    }

    /// IS-PV-TP-1. Беспарольный вход приходит выражением, а не литералом.
    static func passwordlessFromFlag(_ cerber: Cerber, _ flag: Bool) {
        cerber.options = SetupOptions(
            mode: .prod,
            loginOptions: LoginOptions(),
            isPasswordlessEnabled: flag,
            jailbreakCheckerType: .full,
            accessGroupID: "group.corp.pv",
            loggerOptions: [],
            enableTestSSLPinning: false
        )
    }

    /// IS-MD-TP-1. Непродуктовый режим литералом, краткая форма перечисления.
    static func devMode(_ cerber: Cerber) {
        cerber.options = SetupOptions(
            mode: .dev2,
            loginOptions: LoginOptions(),
            isPasswordlessEnabled: true,
            jailbreakCheckerType: .full,
            accessGroupID: "group.corp.md",
            loggerOptions: [],
            enableTestSSLPinning: false
        )
    }

    /// IS-MD-TP-2. То же полной формой: сработка подтверждает, что
    /// metavariable-regex видит квалифицированное имя перечисления.
    static func iftModeQualified(_ cerber: Cerber) {
        cerber.options = SetupOptions(
            mode: Mode.ift,
            loginOptions: LoginOptions(),
            isPasswordlessEnabled: true,
            jailbreakCheckerType: .full,
            accessGroupID: "group.corp.md2",
            loggerOptions: [],
            enableTestSSLPinning: false
        )
    }

    /// IS-MV-TP-1. Режим приходит вычисляемым свойством — форма SberApps.
    static func modeFromConfiguration(_ cerber: Cerber) {
        cerber.options = SetupOptions(
            mode: AppConfiguration.cerberMode,
            loginOptions: LoginOptions(),
            isPasswordlessEnabled: true,
            jailbreakCheckerType: .full,
            accessGroupID: "group.corp.mv",
            loggerOptions: [],
            enableTestSSLPinning: false
        )
    }

    /// IS-SP-TP-1. Тестовый пиннинг включён литералом — форма SberApps.
    static func testPinningOn(_ cerber: Cerber) {
        cerber.options = SetupOptions(
            mode: .prod,
            loginOptions: LoginOptions(),
            isPasswordlessEnabled: true,
            jailbreakCheckerType: .full,
            accessGroupID: "group.corp.sp",
            loggerOptions: [],
            enableTestSSLPinning: true
        )
    }

    /// IS-JW-TP-1. Облегчённый профиль проверки jailbreak — форма SberApps.
    static func liteChecker(_ cerber: Cerber) {
        cerber.options = SetupOptions(
            mode: .prod,
            loginOptions: LoginOptions(),
            isPasswordlessEnabled: true,
            jailbreakCheckerType: .lite,
            accessGroupID: "group.corp.jw",
            loggerOptions: [],
            enableTestSSLPinning: false
        )
    }

    /// IS-JD-TP-1. Проверка jailbreak отключена значением перечисления.
    static func checkerOff(_ cerber: Cerber) {
        cerber.options = SetupOptions(
            mode: .prod,
            loginOptions: LoginOptions(),
            isPasswordlessEnabled: true,
            jailbreakCheckerType: .none,
            accessGroupID: "group.corp.jd",
            loggerOptions: [],
            enableTestSSLPinning: false
        )
    }

    /// IS-JV-TP-1. Профиль проверки приходит выражением.
    static func checkerFromConfiguration(_ cerber: Cerber) {
        cerber.options = SetupOptions(
            mode: .prod,
            loginOptions: LoginOptions(),
            isPasswordlessEnabled: true,
            jailbreakCheckerType: AppConfiguration.checker,
            accessGroupID: "group.corp.jv",
            loggerOptions: [],
            enableTestSSLPinning: false
        )
    }

    /// IS-LG-TP-1. Отладочное и файловое логирование — форма SberApps.
    static func debugLogging(_ cerber: Cerber) {
        cerber.options = SetupOptions(
            mode: .prod,
            loginOptions: LoginOptions(),
            isPasswordlessEnabled: true,
            jailbreakCheckerType: .full,
            accessGroupID: "group.corp.lg",
            loggerOptions: [.logEnabled, .debug, .fileLogEnabled],
            enableTestSSLPinning: false
        )
    }

    /// IS-AG-TP-1. Группа доступа keychain не задана — форма SberApps.
    static func noAccessGroup(_ cerber: Cerber) {
        cerber.options = SetupOptions(
            mode: .prod,
            loginOptions: LoginOptions(),
            isPasswordlessEnabled: true,
            jailbreakCheckerType: .full,
            accessGroupID: nil,
            loggerOptions: [],
            enableTestSSLPinning: false
        )
    }

    /// IS-SS-TP-1. Защита экрана выключена литералом.
    /// Клетка проверяет предполагаемое имя параметра: если его в API нет,
    /// правило обязано молчать, и это тоже результат замера.
    static func secureScreenOff(_ cerber: Cerber) {
        cerber.options = SetupOptions(
            mode: .prod,
            loginOptions: LoginOptions(),
            isPasswordlessEnabled: true,
            jailbreakCheckerType: .full,
            accessGroupID: "group.corp.ss",
            loggerOptions: [],
            enableTestSSLPinning: false,
            secureScreen: false
        )
    }

    /// IS-SC-TP-1. Защита буфера выключена литералом.
    static func secureClipboardOff(_ cerber: Cerber) {
        cerber.options = SetupOptions(
            mode: .prod,
            loginOptions: LoginOptions(),
            isPasswordlessEnabled: true,
            jailbreakCheckerType: .full,
            accessGroupID: "group.corp.sc",
            loggerOptions: [],
            enableTestSSLPinning: false,
            secureClipboard: false
        )
    }
}

enum AppConfiguration {
    enum BuildType: String { case dev, majorcheck, majorgo, prod, testProd }
    static let buildType = BuildType.prod

    /// Источник значения для IS-MV-TP-1. Вычисляемое свойство со switch —
    /// ровно так написано в AppConfiguration.swift у SberApps.
    static var cerberMode: Mode {
        switch buildType {
        case .dev: return .dev2
        case .majorcheck: return .majorCheck
        case .majorgo: return .majorGo
        case .prod, .testProd: return .prod
        }
    }

    static var checker: JailbreakCheckerType { return .full }
}
