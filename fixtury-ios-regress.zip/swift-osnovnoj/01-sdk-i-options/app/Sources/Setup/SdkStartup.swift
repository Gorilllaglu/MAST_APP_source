// Маркеры запуска SDK и регистрации делегата. У маркера ценность в молчании,
// поэтому все клетки здесь TP: правило обязано их найти, а ноль находок на
// реальном проекте будет означать, что запуска или регистрации нет.

import Foundation

final class CerberFlowCoordinator {

    let cerber = Cerber.shared

    /// IS-ST-TP-1. Запуск через Cerber.shared напрямую.
    func startDirect() {
        Cerber.shared.start()
    }

    /// IS-ST-TP-2. Запуск через свойство с именем cerber — форма SberApps.
    /// IS-DL-TP-1. Регистрация делегата в том же методе.
    func start() {
        cerber.setDelegateManager(delegate: self)
        cerber.start()
    }

    /// IS-ST-TP-3. Присваивание options — вторая форма маркера запуска.
    func configure() {
        cerber.options = SetupOptions(
            mode: .prod,
            loginOptions: LoginOptions(),
            isPasswordlessEnabled: true,
            jailbreakCheckerType: .full,
            accessGroupID: "group.corp.start",
            loggerOptions: [],
            enableTestSSLPinning: false,
            secureScreen: true,
            secureClipboard: true
        )
    }

    /// IS-DL-TP-2. Регистрация без имени аргумента.
    func registerPositional(_ manager: CerberDelegate) {
        cerber.setDelegateManager(delegate: manager)
    }
}

extension CerberFlowCoordinator: CerberDelegate {
    func didLogin() { Log.d("login") }
    func didFailLogin() { Log.d("fail") }
    func userChanged() { Log.d("user") }
    func wipe() { Log.d("wipe") }
}

enum Log { static func d(_ s: String) {} }
