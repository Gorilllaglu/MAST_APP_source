// Клетка правила, построенного на отсутствии параметра в вызове.
// Внимание при разборе отчёта: это правило срабатывает на КАЖДОМ вызове
// SetupOptions без имени secureScreen, то есть и в SetupDefect.swift, и в
// SetupProbes.swift. Ожидаемое число находок записано в README дерева.

import Foundation

enum SecureScreenNotSet {

    /// IS-SN-TP-1. Защита экрана не названа — значение берётся из умолчания SDK.
    static func defaultsOnly(_ cerber: Cerber) {
        cerber.options = SetupOptions(
            mode: .prod,
            loginOptions: LoginOptions(),
            isPasswordlessEnabled: true,
            jailbreakCheckerType: .full,
            accessGroupID: "group.corp.sn",
            loggerOptions: [.logEnabled],
            enableTestSSLPinning: false
        )
    }
}
