// Сторона TN тех же правил: эталонная настройка. Все перечисленные клетки
// обязаны промолчать. Одна находка здесь означает ложное срабатывание.

import Foundation

enum SetupClean {

    /// IS-PW-TN-1, IS-PV-TN-1, IS-MD-TN-1, IS-MV-TN-1, IS-SP-TN-1,
    /// IS-JW-TN-1, IS-JD-TN-1, IS-JV-TN-1, IS-LG-TN-1, IS-AG-TN-1,
    /// IS-SS-TN-1, IS-SC-TN-1, IS-SN-TN-1.
    /// Эталон: продуктовый режим, беспарольный вход включён, полный профиль
    /// проверки, тестовый пиннинг выключен, логирование пустое, группа доступа
    /// задана, защиты экрана и буфера включены явно.
    static func reference(_ cerber: Cerber) {
        cerber.options = SetupOptions(
            mode: .prod,
            loginOptions: LoginOptions(),
            isPasswordlessEnabled: true,
            jailbreakCheckerType: .full,
            accessGroupID: "group.corp.reference",
            loggerOptions: [.logEnabled],
            enableTestSSLPinning: false,
            secureScreen: true,
            secureClipboard: true
        )
    }

    /// IS-MD-TN-2. Продуктовый режим полной формой перечисления.
    static func referenceQualifiedMode(_ cerber: Cerber) {
        cerber.options = SetupOptions(
            mode: Mode.prod,
            loginOptions: LoginOptions(),
            isPasswordlessEnabled: true,
            jailbreakCheckerType: .full,
            accessGroupID: "group.corp.reference2",
            loggerOptions: [.logEnabled],
            enableTestSSLPinning: false,
            secureScreen: true,
            secureClipboard: true
        )
    }

    /// IS-LG-TN-2. Логирование без отладочных и файловых опций.
    static func referenceQuietLogging(_ cerber: Cerber) {
        cerber.options = SetupOptions(
            mode: .testProd,
            loginOptions: LoginOptions(),
            isPasswordlessEnabled: true,
            jailbreakCheckerType: .full,
            accessGroupID: "group.corp.reference3",
            loggerOptions: [.logEnabled],
            enableTestSSLPinning: false,
            secureScreen: true,
            secureClipboard: true
        )
    }
}
