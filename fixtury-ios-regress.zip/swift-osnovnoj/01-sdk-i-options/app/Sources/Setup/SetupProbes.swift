// Замеры границ диалекта на группе A. Ожидание каждой клетки записано рядом:
// у PROBE оно заранее не известно, и ответ даёт сам прогон.

import Foundation

enum SetupProbes {

    /// IS-PW-PROBE-1. Тот же дефект, что IS-PW-TP-1, но вызов в одну строку.
    /// Если сработает только эта клетка, а многострочные молчат — многоточие
    /// в списке аргументов не переходит через перевод строки, и все шаблоны
    /// группы A надо переписывать под реальное форматирование кода.
    static func singleLine(_ cerber: Cerber) {
        cerber.options = SetupOptions(mode: .prod, loginOptions: LoginOptions(), isPasswordlessEnabled: false, jailbreakCheckerType: .full, accessGroupID: "p1", loggerOptions: [], enableTestSSLPinning: false)
    }

    /// IS-MD-PROBE-1. Нарушающий аргумент стоит первым, то есть многоточие перед
    /// ним пустое. На котлиновском фронтенде такая форма матчится; для Swift
    /// не измерена.
    static func firstArgument(_ cerber: Cerber) {
        cerber.options = SetupOptions(
            mode: .dev1,
            loginOptions: LoginOptions(),
            isPasswordlessEnabled: true,
            jailbreakCheckerType: .full,
            accessGroupID: "p2",
            loggerOptions: [],
            enableTestSSLPinning: false
        )
    }

    /// IS-MD-PROBE-2. Та же настройка через сокращённую форму инициализатора.
    /// Наши шаблоны ставят якорь на имя типа, поэтому ожидание — молчание.
    /// Если клетка сработает, движок разворачивает .init до типа, и это надо
    /// записать в диалект: тогда якорь на имя типа покрывает обе формы.
    static func dotInit(_ cerber: Cerber) {
        cerber.options = .init(
            mode: .dev2,
            loginOptions: LoginOptions(),
            isPasswordlessEnabled: false,
            jailbreakCheckerType: .none,
            accessGroupID: nil,
            loggerOptions: [.debug],
            enableTestSSLPinning: true
        )
    }

    /// IS-MD-PROBE-3. Настройка собрана в переменную и присвоена отдельно.
    /// Так пишут, когда настройка зависит от окружения. Ожидание — сработка:
    /// якорь стоит на вызове, а не на присваивании.
    static func builtSeparately(_ cerber: Cerber) {
        let options = SetupOptions(
            mode: .uat,
            loginOptions: LoginOptions(),
            isPasswordlessEnabled: false,
            jailbreakCheckerType: .lite,
            accessGroupID: nil,
            loggerOptions: [.debug],
            enableTestSSLPinning: true
        )
        cerber.options = options
    }
}
