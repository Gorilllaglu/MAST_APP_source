// Выделение текста и меню редактирования в UIKit.

import UIKit

final class ArticleViewController: UIViewController {

    private let body = UITextView()
    private let caption = UILabel()

    /// IS-TS-TP-1. Выделение включено явно.
    func enableSelection() {
        body.isSelectable = true
    }

    /// IS-TS-TP-2. Включено перетаскивание выделенного текста.
    func enableTextDrag() {
        body.textDragInteraction?.isEnabled = true
    }

    /// IS-TS-TN-1. Выделение выключено явно.
    func disableSelection() {
        let notice = UITextView()
        notice.isSelectable = false
    }

    /// IS-MA-TP-1. Переопределение есть, но возвращает ответ суперкласса,
    /// то есть не ограничивает ничего.
    override func canPerformAction(_ action: Selector, withSender sender: Any?) -> Bool {
        return super.canPerformAction(action, withSender: sender)
    }
}

final class PermissiveTextView: UITextView {

    /// IS-MA-TP-2. Возвращает true на любое действие.
    override func canPerformAction(_ action: Selector, withSender sender: Any?) -> Bool {
        return true
    }
}

final class RestrictedTextView: UITextView {

    /// IS-MA-TN-1, IS-MR-TP-1. Меню ограничено: разрешено только копирование,
    /// и маркер ограничения обязан эту форму найти.
    override func canPerformAction(_ action: Selector, withSender sender: Any?) -> Bool {
        if action == #selector(UIResponderStandardEditActions.copy(_:)) {
            return true
        }
        return false
    }
}
