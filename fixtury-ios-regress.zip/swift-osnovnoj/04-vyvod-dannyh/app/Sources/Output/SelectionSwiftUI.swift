// Выделение и экспорт в SwiftUI. Это iOS-аналог поверхности, которую на
// андроиде закрывают два compose-правила: отчёт объявил их неприменимыми,
// но модификаторы существуют, просто называются иначе.

import SwiftUI

struct DocumentBody: View {

    let text: String

    /// IS-SU-TP-1. Выделение включено модификатором.
    var body: some View {
        Text(text)
            .textSelection(.enabled)
            .padding()
    }
}

struct DocumentBodyQualified: View {

    let text: String

    /// IS-SU-TP-2. То же полной формой перечисления.
    var body: some View {
        Text(text)
            .textSelection(TextSelectability.enabled)
    }
}

struct DocumentRow: View {

    let item: String

    /// IS-SU-TP-3. Значение объявлено копируемым.
    var body: some View {
        Text(item)
            .copyable([item])
    }
}

struct ProtectedBody: View {

    let text: String

    /// IS-SU-TN-1, IS-MR-TP-2. Выделение выключено явно, и это же форма,
    /// которую обязан найти маркер ограничения меню.
    var body: some View {
        Text(text)
            .textSelection(.disabled)
    }
}
