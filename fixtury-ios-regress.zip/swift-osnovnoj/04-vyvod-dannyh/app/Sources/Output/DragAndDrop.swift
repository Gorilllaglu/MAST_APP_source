// Перетаскивание наружу и приём перетаскивания внутрь.

import UIKit
import SwiftUI

final class DragSurface: NSObject {

    /// IS-DD-TP-1. Перетаскивание из представления включено взаимодействием.
    func enableDrag(on view: UIView) {
        let interaction = UIDragInteraction(delegate: self)
        view.addInteraction(interaction)
    }

    /// IS-DD-TP-2. Перетаскивание текста включено флагом.
    func enableTextViewDrag(_ textView: UITextView) {
        textView.dragInteractionEnabled = true
    }

    /// IS-DR-TP-1. Приём перетаскивания внутрь.
    func enableDrop(on view: UIView) {
        let interaction = UIDropInteraction(delegate: self)
        view.addInteraction(interaction)
    }

    /// IS-DD-TN-1. Перетаскивание выключено явно.
    func disableDrag(_ textView: UITextView) {
        textView.dragInteractionEnabled = false
    }
}

extension DragSurface: UIDragInteractionDelegate, UIDropInteractionDelegate {}

struct DraggableCard: View {

    let payload: String

    /// IS-DD-TP-3. Перетаскивание средствами SwiftUI.
    var body: some View {
        Text(payload)
            .draggable(payload)
    }
}

struct DropZone: View {

    @State private var received: [String] = []

    /// IS-DR-TP-2. Приём перетаскивания средствами SwiftUI.
    var body: some View {
        Color.clear
            .dropDestination(for: String.self, action: { items, _ in
                received.append(contentsOf: items)
                return true
            })
    }
}
