// Замеры границ на группе D.

import SwiftUI

struct ModifierChainProbe: View {

    let text: String

    /// IS-SU-PROBE-1. Модификатор выделения стоит в середине длинной цепочки.
    /// Шаблон написан как вызов на метапеременной, и ожидание — сработка.
    /// Если клетка молчит, шаблоны на модификаторы SwiftUI надо писать иначе,
    /// и это касается всех правил, где якорь — модификатор.
    var body: some View {
        Text(text)
            .font(.body)
            .foregroundStyle(.primary)
            .textSelection(.enabled)
            .lineLimit(3)
            .padding(.horizontal, 16)
    }
}

struct TrailingClosureProbe: View {

    @State private var items: [String] = []

    /// IS-DR-PROBE-1. Приём перетаскивания записан замыкающим замыканием,
    /// а не именованным аргументом action. Так пишут в жизни. Шаблон правила
    /// перечисляет форму с именованным аргументом и общую форму с многоточием;
    /// клетка показывает, покрывает ли вторая замыкающую запись.
    var body: some View {
        Color.clear
            .dropDestination(for: String.self) { dropped, _ in
                items.append(contentsOf: dropped)
                return true
            }
    }
}
