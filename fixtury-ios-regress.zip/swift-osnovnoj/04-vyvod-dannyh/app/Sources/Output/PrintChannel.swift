// Печать. Отчёт объявил этот канал неприменимым к iOS, спутав системную
// печать с функцией print() языка Swift. UIPrintInteractionController
// в iOS есть, и канал ровно такой же, как андроидный.

import UIKit

final class PrintChannel {

    /// IS-PT-TP-1. Печать документа через общий контроллер.
    func printDocument(_ data: Data, from vc: UIViewController) {
        let controller = UIPrintInteractionController.shared
        controller.printingItem = data
        controller.present(animated: true, completionHandler: nil)
    }

    /// IS-PT-TP-2. Печать нескольких элементов.
    func printAll(_ items: [Data]) {
        let controller = UIPrintInteractionController()
        controller.printingItems = items
    }

    /// IS-PT-TP-3. Печать размеченного текста через форматтер.
    func printMarkup(_ html: String) {
        let formatter = UIMarkupTextPrintFormatter(markupText: html)
        let controller = UIPrintInteractionController.shared
        controller.printFormatter = formatter
    }

    /// IS-PT-TN-1. Функция языка Swift, пишущая в консоль. Правило обязано
    /// промолчать: это не системная печать. Клетка существует ровно потому,
    /// что исходный отчёт на этом и ошибся.
    func logToConsole(_ message: String) {
        print(message)
    }
}
