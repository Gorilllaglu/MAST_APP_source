// Заглушки API CerberSDK iOS. ПРЕДПОЛОЖЕНИЕ, НЕ ИСТИНА.
// Форма взята из дословной выдержки кода SberApps в отчёте: вызов SetupOptions
// состоит из семи именованных параметров. Параметры secureScreen и
// secureClipboard в той выдержке отсутствуют — здесь они объявлены, потому что
// правила на них есть, и фикстура должна дать им форму для замера. Если
// окажется, что в API 3.3.0 этих параметров нет, из заглушки и из клеток
// IS-SS-*, IS-SC-*, IS-SN-* их надо убрать вместе с правилами.
// Протокол CerberDelegate: подтверждены четыре метода, остальные — предположение.

import Foundation

public enum Mode { case dev, dev1, dev2, ift, uat, psi, majorCheck, majorGo, prod, testProd }
public enum JailbreakCheckerType { case none, lite, full }
public struct LoggerOption: Hashable {
    public static let logEnabled = LoggerOption()
    public static let debug = LoggerOption()
    public static let fileLogEnabled = LoggerOption()
}
public struct LoginOptions { public init() {} }

public struct SetupOptions {
    public init(mode: Mode,
                loginOptions: LoginOptions,
                isPasswordlessEnabled: Bool,
                jailbreakCheckerType: JailbreakCheckerType,
                accessGroupID: String?,
                loggerOptions: [LoggerOption],
                enableTestSSLPinning: Bool,
                secureScreen: Bool = true,
                secureClipboard: Bool = true) {}
}

public protocol CerberDelegate: AnyObject {
    func didLogin()
    func didFailLogin()
    func userChanged()
    func wipe()
}

public final class CerberCopyPasteBuffer {
    public func write(_ text: String) -> Bool { return true }
}

public final class Cerber {
    public static let shared = Cerber()
    public var options: SetupOptions?
    public let buffer = CerberCopyPasteBuffer()
    public func setDelegateManager(delegate: CerberDelegate) {}
    public func start() {}
}
