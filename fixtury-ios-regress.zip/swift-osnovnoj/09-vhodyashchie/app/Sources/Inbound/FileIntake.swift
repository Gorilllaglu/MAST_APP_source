// Приём файлов.

import UIKit

final class FileIntake {

    /// IS-RF-TP-1. Файл используется по месту: он остаётся во владении
    /// отправителя, который может подменить содержимое между проверкой
    /// и чтением.
    func handle(_ url: URL, options: [UIApplication.OpenURLOptionsKey: Any]) {
        if let inPlace = options[.openInPlace] as? Bool, inPlace {
            Preview.shared.show(url)
        }
    }

    /// IS-RF-TP-2. Выбор документа без копирования.
    func pickWithoutCopy(from vc: UIViewController) {
        let picker = UIDocumentPickerViewController(forOpeningContentTypes: [.pdf], asCopy: false)
        vc.present(picker, animated: true)
    }

    /// IS-RF-TN-1. Файл скопирован в своё хранилище, дальше работа с копией.
    func handleByCopy(_ url: URL) throws {
        let documents = try FileManager.default.url(
            for: .documentDirectory,
            in: .userDomainMask,
            appropriateFor: nil,
            create: true
        )
        let copy = documents.appendingPathComponent(url.lastPathComponent)
        try FileManager.default.copyItem(at: url, to: copy)
        Preview.shared.show(copy)
    }

    /// IS-RF-TN-2. Выбор документа с копированием в контейнер.
    func pickAsCopy(from vc: UIViewController) {
        let picker = UIDocumentPickerViewController(forOpeningContentTypes: [.pdf], asCopy: true)
        vc.present(picker, animated: true)
    }
}

final class Preview {
    static let shared = Preview()
    func show(_ url: URL) {}
}
