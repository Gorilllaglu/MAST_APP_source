// Замеры границ на группе I.

import UIKit

final class IndirectCheck: UIResponder, UIApplicationDelegate {

    /// IS-OU-PROBE-1. Источник проверяется, но в отдельной функции, вызванной
    /// из обработчика. Исключения правила перечисляют чтение sourceApplication
    /// внутри тела обработчика, поэтому ожидание — ложная сработка. Клетка
    /// нужна, чтобы цена этой границы была видна: на андроидном близнеце
    /// ровно такой пропуск признан платой за правило.
    func application(_ app: UIApplication,
                     open url: URL,
                     options: [UIApplication.OpenURLOptionsKey: Any]) -> Bool {
        guard CallerGate.isTrusted(options) else { return false }
        Router.shared.handle(url, declaredCaller: nil)
        return true
    }
}

enum CallerGate {
    static func isTrusted(_ options: [UIApplication.OpenURLOptionsKey: Any]) -> Bool {
        guard let source = options[.sourceApplication] as? String else { return false }
        return TrustedCallers.allowed.contains(source)
    }
}
