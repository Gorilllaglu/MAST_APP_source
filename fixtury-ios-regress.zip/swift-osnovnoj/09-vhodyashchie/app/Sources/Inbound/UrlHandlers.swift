// Входящие поверхности: своя URL-схема — это iOS-аналог андроидного
// exported-компонента без permission. Открыть её может любое приложение.

import UIKit

final class OpenUrlDefect: UIResponder, UIApplicationDelegate {

    /// IS-OU-TP-1. Источник не проверяется: команда из URL исполняется сразу.
    /// IS-UP-TP-1. И личность берётся из содержимого URL.
    func application(_ app: UIApplication,
                     open url: URL,
                     options: [UIApplication.OpenURLOptionsKey: Any]) -> Bool {
        let components = URLComponents(url: url, resolvingAgainstBaseURL: false)
        let caller = components?.queryItems?.first(where: { $0.name == "caller" })?.value
        Router.shared.handle(url, declaredCaller: caller)
        return true
    }
}

final class SceneOpenUrlDefect: UIResponder, UIWindowSceneDelegate {

    /// IS-OU-TP-2. То же в форме сцены.
    func scene(_ scene: UIScene, openURLContexts URLContexts: Set<UIOpenURLContext>) {
        for context in URLContexts {
            Router.shared.handle(context.url, declaredCaller: nil)
        }
    }
}

final class OpenUrlClean: UIResponder, UIApplicationDelegate {

    /// IS-OU-TN-1, IS-UP-TN-1. Источник взят у платформы и сверен с перечнем
    /// разрешённых, содержимое разбирается только после этого.
    func application(_ app: UIApplication,
                     open url: URL,
                     options: [UIApplication.OpenURLOptionsKey: Any]) -> Bool {
        guard let source = options[.sourceApplication] as? String,
              TrustedCallers.allowed.contains(source) else {
            return false
        }
        Router.shared.handle(url, declaredCaller: source)
        return true
    }
}

final class UniversalLinks: UIResponder, UIApplicationDelegate {

    /// IS-UL-TP-1. Обработчик универсальных ссылок.
    func application(_ application: UIApplication,
                     continue userActivity: NSUserActivity,
                     restorationHandler: @escaping ([UIUserActivityRestoring]?) -> Void) -> Bool {
        guard let incoming = userActivity.webpageURL else { return false }
        Router.shared.handle(incoming, declaredCaller: nil)
        return true
    }
}

enum TrustedCallers { static let allowed: Set<String> = ["ru.corp.sberapps"] }
