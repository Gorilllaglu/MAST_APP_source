// Сторона TN буфера: корректная запись через буфер SDK и ограниченная
// запись в системный буфер.

import UIKit

final class PasteboardClean {

    private let cerber = Cerber.shared

    /// IS-PB-TN-1, IS-BW-TN-1. Копирование идёт через буфер SDK,
    /// результат записи прочитан.
    func copyThroughSdk(_ text: String) -> Bool {
        let written = cerber.buffer.write(text)
        if !written {
            Log.d("buffer overflow, copy rejected")
        }
        return written
    }

    /// IS-BW-TN-2. Результат разобран условием.
    func copyAndNotify(_ text: String) {
        if cerber.buffer.write(text) {
            Toast.show("Скопировано")
        } else {
            Toast.show("Текст слишком длинный")
        }
    }

    /// IS-BW-TN-3. Результат проверен через guard.
    func copyOrFail(_ text: String) throws {
        guard cerber.buffer.write(text) else {
            throw CopyError.tooLong
        }
    }

    /// IS-PO-TN-1. Запись в системный буфер с опциями: только это устройство
    /// и срок жизни две минуты.
    func copyWithLimits(_ text: String) {
        UIPasteboard.general.setItems(
            [["public.utf8-plain-text": text]],
            options: [
                .localOnly: true,
                .expirationDate: Date().addingTimeInterval(120)
            ]
        )
    }
}

enum CopyError: Error { case tooLong }
enum Toast { static func show(_ s: String) {} }
