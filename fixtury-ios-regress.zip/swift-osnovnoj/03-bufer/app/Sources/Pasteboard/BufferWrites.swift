// Сторона TP правила о непрочитанном результате записи в буфер SDK.
// Регулярка правила сужает получателя до имён, похожих на буфер SDK:
// без сужения на андроидном наборе правило ловило буферы okio.

import Foundation

final class BufferWrites {

    private let cerber = Cerber.shared
    private let buffer = Cerber.shared.buffer

    /// IS-BW-TP-1. Результат записи отброшен, и пользователю безусловно
    /// сказано, что копирование состоялось. Это ровно та форма, которую
    /// нашли в продакшене Efir на андроиде: delegate.buffer.write(text)
    /// и тост «скопировано» следом.
    func copyAndConfirm(_ text: String) {
        buffer.write(text)
        Toast.show("Скопировано")
    }

    /// IS-BW-TP-2. То же через цепочку от Cerber.shared.
    func copyViaShared(_ text: String) {
        Cerber.shared.buffer.write(text)
    }

    /// IS-BW-TN-4. Чужой буфер с тем же именем метода: получатель не похож
    /// на буфер SDK, правило обязано промолчать. На андроиде именно такие
    /// совпадения давали по 35–53 ложных на приложение, пока получатель
    /// не сузили регуляркой.
    func writeToStream(_ data: Data, _ sink: OutputStream) {
        let payload = Payload()
        payload.write(data)
        _ = sink
    }
}

final class Payload { func write(_ data: Data) {} }
