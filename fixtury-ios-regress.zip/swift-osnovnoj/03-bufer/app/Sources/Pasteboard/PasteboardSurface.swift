// Свой именованный буфер и чтение системного.

import UIKit

final class PasteboardSurface {

    /// IS-CP-TP-1. Создание именованного буфера.
    func privateBoard() -> UIPasteboard {
        return UIPasteboard(name: UIPasteboard.Name("corp.transfer"), create: true)
    }

    /// IS-CP-TP-2. Буфер с уникальным именем.
    func temporaryBoard() -> UIPasteboard {
        return UIPasteboard.withUniqueName()
    }

    /// IS-CP-TP-3. Удаление именованного буфера по имени.
    func dropBoard() {
        UIPasteboard.remove(withName: UIPasteboard.Name("corp.transfer"))
    }

    /// IS-PR-TP-1. Чтение строки из системного буфера.
    func pastedText() -> String? {
        let text = UIPasteboard.general.string
        return text
    }

    /// IS-PR-TP-2. Проверка наличия строки.
    func canPaste() -> Bool {
        return UIPasteboard.general.hasStrings
    }

    /// IS-PR-TP-3. Типизированное чтение.
    func pastedTyped() -> String? {
        return UIPasteboard.general.string(forPasteboardType: "public.utf8-plain-text")
    }

    /// IS-PR-TN-1. Запись, а не чтение: правило чтения обязано промолчать,
    /// иначе шаблон на свойство совпадает с левой частью присваивания.
    /// Эта клетка — причина, по которой в правиле перечислены только
    /// однозначные формы чтения.
    func writeOnly(_ text: String) {
        UIPasteboard.general.string = text
    }

    /// IS-CP-TN-1. Обращение к системному буферу по имени general:
    /// именованный буфер не создаётся, правило обязано промолчать.
    func systemBoard() -> UIPasteboard {
        return UIPasteboard.general
    }
}
