// Сторона TP записи в системный буфер. Текст каждой клетки отличается,
// иначе движок свернёт находки одного правила в одну.

import UIKit

final class PasteboardWrites {

    /// IS-PB-TP-1. Запись строки в системный буфер.
    func copyAccountNumber(_ number: String) {
        UIPasteboard.general.string = number
    }

    /// IS-PB-TP-2. Запись массива строк.
    func copyAllNumbers(_ numbers: [String]) {
        UIPasteboard.general.strings = numbers
    }

    /// IS-PB-TP-3. Запись ссылки.
    func copyDocumentLink(_ link: URL) {
        UIPasteboard.general.url = link
    }

    /// IS-PB-TP-4. Запись изображения — так уходит снимок документа.
    func copyScan(_ scan: UIImage) {
        UIPasteboard.general.image = scan
    }

    /// IS-PB-TP-5. Запись набора элементов.
    /// IS-PO-TP-1. И без словаря опций: ни localOnly, ни срока жизни.
    func copyItems(_ items: [[String: Any]]) {
        UIPasteboard.general.setItems(items)
    }

    /// IS-PB-TP-6. Запись значения с типом.
    func copyTyped(_ value: Any) {
        UIPasteboard.general.setValue(value, forPasteboardType: "public.text")
    }

    /// IS-PB-TP-7. Запись через буфер, взятый в переменную.
    func copyViaLocal(_ text: String) {
        let board = UIPasteboard.general
        board.string = text
    }
}
