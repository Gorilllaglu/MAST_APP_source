// Сторона TN веб-представлений.

import WebKit

final class SafeWebViewController: UIViewController {

    /// IS-WJ-TN-1. Скрипты выключены явно.
    func makeQuietWebView() -> WKWebView {
        let preferences = WKWebpagePreferences()
        preferences.allowsContentJavaScript = false
        let configuration = WKWebViewConfiguration()
        configuration.defaultWebpagePreferences = preferences
        let webView = WKWebView(frame: .zero, configuration: configuration)
        webView.allowsLinkPreview = false
        return webView
    }

    /// IS-WF-TN-1. Локальная страница загружена через обработчик схемы
    /// с явным перечнем разрешённого, без выдачи доступа к каталогу.
    func loadThroughSchemeHandler(_ configuration: WKWebViewConfiguration, _ handler: WKURLSchemeHandler) {
        configuration.setURLSchemeHandler(handler, forURLScheme: "corp-docs")
    }

    /// IS-WH-TN-1. Страница загружена по адресу, которым владеет продукт.
    func loadOwnPage(_ webView: WKWebView, _ url: URL) {
        webView.load(URLRequest(url: url))
    }

    /// IS-WS-TN-1. Меню в контроллере-хозяине ограничено.
    override func canPerformAction(_ action: Selector, withSender sender: Any?) -> Bool {
        return false
    }
}
