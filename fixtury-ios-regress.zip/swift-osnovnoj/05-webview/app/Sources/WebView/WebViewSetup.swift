// Веб-представления.

import WebKit

final class DocumentWebViewController: UIViewController {

    /// IS-WJ-TP-1. Скрипты включены устаревшим свойством.
    /// IS-WS-TP-1. И само представление создано без ограничения меню.
    func makeLegacyWebView() -> WKWebView {
        let configuration = WKWebViewConfiguration()
        configuration.preferences.javaScriptEnabled = true
        return WKWebView(frame: .zero, configuration: configuration)
    }

    /// IS-WJ-TP-2. Скрипты включены современным свойством.
    func makeModernWebView() -> WKWebView {
        let preferences = WKWebpagePreferences()
        preferences.allowsContentJavaScript = true
        let configuration = WKWebViewConfiguration()
        configuration.defaultWebpagePreferences = preferences
        return WKWebView(frame: .zero, configuration: configuration)
    }

    /// IS-WS-TP-2. Предпросмотр ссылки включён: долгое нажатие открывает
    /// карточку со своим действием «поделиться».
    func enableLinkPreview(_ webView: WKWebView) {
        webView.allowsLinkPreview = true
    }

    /// IS-WF-TP-1. Доступ к файлам из file-URL через приватный ключ настроек.
    func allowFileAccess(_ preferences: WKPreferences) {
        preferences.setValue(true, forKey: "allowFileAccessFromFileURLs")
    }

    /// IS-WF-TP-2. Универсальный доступ: страница из контейнера сможет
    /// отправить прочитанное по сети.
    func allowUniversalAccess(_ configuration: WKWebViewConfiguration) {
        configuration.setValue(true, forKey: "allowUniversalAccessFromFileURLs")
    }

    /// IS-WF-TP-3. Доступ на чтение выдан целому каталогу.
    func loadLocalBundle(_ webView: WKWebView, _ page: URL, _ directory: URL) {
        webView.loadFileURL(page, allowingReadAccessTo: directory)
    }

    /// IS-WH-TP-1. Разметка собрана строкой, источник уникальный.
    func renderComposed(_ webView: WKWebView, _ body: String) {
        let html = "<html><body>" + body + "</body></html>"
        webView.loadHTMLString(html, baseURL: nil)
    }

    /// IS-WH-TP-2. То же с заданным источником.
    func renderWithBase(_ webView: WKWebView, _ body: String, _ base: URL) {
        webView.loadHTMLString(body, baseURL: base)
    }
}
