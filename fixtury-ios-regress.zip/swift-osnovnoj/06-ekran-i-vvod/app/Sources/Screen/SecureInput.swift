// Ввод секретов и своя аутентификация.

import UIKit
import LocalAuthentication
import SwiftUI

final class PinViewController: UIViewController {

    private let pinField = UITextField()
    private let amountField = UITextField()

    /// IS-TE-TP-1. Защищённый ввод выключен явно у поля, которое им должно быть.
    func configureVisiblePin() {
        pinField.isSecureTextEntry = false
    }

    /// IS-OP-TP-1. Свой экран ввода PIN: числовая клавиатура плюс
    /// защищённый ввод в двух соседних инструкциях.
    func configureOwnPin() {
        pinField.keyboardType = .numberPad
        pinField.isSecureTextEntry = true
    }

    /// IS-OP-TP-2. Поле объявлено полем одноразового кода.
    func configureOtp(_ field: UITextField) {
        field.textContentType = .oneTimeCode
    }

    /// IS-TE-TN-1. Защищённый ввод включён.
    func configureHiddenPin(_ field: UITextField) {
        field.isSecureTextEntry = true
    }

    /// IS-OP-TN-1. Числовое поле без защищённого ввода — это поле суммы,
    /// а не PIN. Правило своего PIN-экрана обязано промолчать.
    func configureAmount() {
        amountField.keyboardType = .decimalPad
        amountField.placeholder = "Сумма"
    }
}

final class BiometryGate {

    /// IS-BI-TP-1. Своя проверка биометрии вместо сценария SDK.
    func unlock(_ completion: @escaping (Bool) -> Void) {
        LAContext().evaluatePolicy(
            .deviceOwnerAuthenticationWithBiometrics,
            localizedReason: "Подтвердите вход",
            reply: { success, _ in completion(success) }
        )
    }

    /// IS-BI-TP-2. Проверка доступности политики.
    func isAvailable() -> Bool {
        let context = LAContext()
        var error: NSError?
        return context.canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, error: &error)
    }

    /// IS-BI-TN-1. Вход делегирован SDK, своей политики нет.
    func unlockThroughSdk() {
        Cerber.shared.start()
    }
}

struct PinEntry: View {

    @State private var code: String = ""

    /// IS-OP-TP-3. Свой экран ввода PIN средствами SwiftUI.
    var body: some View {
        SecureField("Код", text: $code)
            .keyboardType(.numberPad)
    }
}

struct AmountEntry: View {

    @State private var amount: String = ""

    /// IS-TE-PROBE-1. Числовое поле SwiftUI без SecureField. Третья ветвь
    /// правила — слабый детектор: по этой форме нельзя отличить поле суммы
    /// от поля PIN. Ожидание — сработка, и она будет ложной. Клетка нужна,
    /// чтобы цена этой ветви была видна в отчёте.
    var body: some View {
        TextField("Сумма", text: $amount)
            .keyboardType(.numberPad)
    }
}
