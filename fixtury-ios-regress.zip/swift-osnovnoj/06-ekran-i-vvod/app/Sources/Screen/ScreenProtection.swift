// Защита экрана. В iOS нет флага окна, запрещающего скриншот, поэтому
// все клетки этой группы — маркеры: приложение либо реагирует на захват
// и прячет содержимое перед уходом в фон, либо нет.

import UIKit

final class ScreenGuard {

    private var window: UIWindow?
    private var cover: UIView?

    /// IS-CA-TP-1. Подписка на изменение состояния захвата.
    func observeCapture() {
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(captureChanged),
            name: UIScreen.capturedDidChangeNotification,
            object: nil
        )
    }

    /// IS-CA-TP-2. Чтение состояния захвата.
    @objc private func captureChanged() {
        if UIScreen.main.isCaptured {
            cover?.isHidden = false
        }
    }

    /// IS-CA-TP-3. Чтение состояния зеркалирования экрана.
    func isMirrored(_ screen: UIScreen) -> Bool {
        return screen.isMirrored
    }
}

final class SceneGuard: UIResponder, UIWindowSceneDelegate {

    private var cover: UIView?

    /// IS-BS-TP-1. Содержимое накрыто перед уходом в фон: системный снимок
    /// для переключателя приложений получит заглушку, а не последний экран.
    func sceneWillResignActive(_ scene: UIScene) {
        cover?.isHidden = false
    }

    /// IS-BS-TP-2. Вторая точка того же жизненного цикла.
    func sceneDidEnterBackground(_ scene: UIScene) {
        cover?.isHidden = false
    }
}

final class LegacyGuard: UIResponder, UIApplicationDelegate {

    /// IS-BS-TP-3. Старая точка жизненного цикла приложения.
    func applicationWillResignActive(_ application: UIApplication) {
        Log.d("resign")
    }
}
