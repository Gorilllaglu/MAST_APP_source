package ru.corp.app.di

import ru.sberbank.cerbersdk.sdk_framework.DebugBypassChecker
import ru.sberbank.cerbersdk.sdk_framework.SecureChecker
import ru.sberbank.cerbersdk.sdk_framework.TrustedComponents

/** Делегат host-app: объявления под фикстуры, вызовов нет. */
interface CerberSdkDelegate {
    val trustedComponents: TrustedComponents
    val debugBypassChecker: DebugBypassChecker
    val secureChecker: SecureChecker
}
