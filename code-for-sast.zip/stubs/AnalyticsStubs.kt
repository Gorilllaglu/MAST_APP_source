package ru.corp.app.analytics

/** Аналитика host-app: объявление под фикстуру R1-TN-3, вызовов нет. */
interface Analytics {
    fun track(event: String)
}
