package ru.sberbank.cerbersdk.sdk_framework

/**
 * Минимальные объявления под фикстуры: нужны только чтобы файлы читались
 * и при желании компилировались. Это объявления, не вызовы, поэтому ни одно
 * из четырёх правил здесь срабатывать не должно — файл работает как контроль.
 */

enum class SecureCheck {
    DEVICE_COMPLIANT,
    ROOT_DETECTED,
    EMULATOR_DETECTED,
    DEVICE_LOCKED
}

object SecureChecker {
    fun performChecks(): SecureCheck = SecureCheck.DEVICE_COMPLIANT
}

object DebugBypassChecker {
    fun shouldBypassRootEmulatorCheck(): Boolean = false
    fun shouldBypassSecureScreen(): Boolean = false
}

interface TrustedComponents {
    fun getFromCache(): List<String>
    fun download(): List<String>
}
