package ru.corp.app.network

import ru.corp.app.di.CerberSdkDelegate

/**
 * Правило cerber-trusted-components-usage-marker, сторона TP.
 * Файл в host-app, вне путей из paths.exclude: находки здесь и есть
 * доказательство наличия интеграции.
 */
object TrustedComponentsBootstrap {

    /** R4-TP-1. Плоский доступ, формы из правила. Прогон 2026-10-22: сработка, верно. */
    fun primeTrustedComponents(delegate: CerberSdkDelegate) {
        val cached = delegate.trustedComponents.getFromCache()
        if (cached.isEmpty()) {
            delegate.trustedComponents.download()
        }
    }

    /** R4-TP-2. Формы с ?. и !! на втором хопе. Прогон: сработка, верно. */
    fun refreshTrustedComponents(delegate: CerberSdkDelegate) {
        delegate.trustedComponents?.getFromCache()
        delegate.trustedComponents!!.download()
    }

    /**
     * R4-PROBE-1. Безопасный вызов на ПЕРВОМ хопе. Прогон: находки НЕТ.
     * Для marker-правила это ложное падение CI на работающем коде.
     */
    fun refreshViaNullableDelegate(delegate: CerberSdkDelegate?) {
        delegate?.trustedComponents?.getFromCache()
        delegate?.trustedComponents?.download()
    }

    /**
     * R4-PROBE-2. Доступ через промежуточную переменную. Прогон: находки НЕТ.
     * Та же проблема: интеграция есть, маркер её не видит.
     */
    fun refreshViaAlias(delegate: CerberSdkDelegate) {
        val tc = delegate.trustedComponents
        tc.getFromCache()
        tc.download()
    }
}
