package ru.corp.app.security

import ru.sberbank.cerbersdk.sdk_framework.DebugBypassChecker

/**
 * R1-PROBE-3. Импорт отладочного чекера есть, вызовов нет.
 * Прогон 2026-10-22: находки нет. Решение по формулировке сообщения правила:
 * оно обещает "found in code", а ловит только вызовы.
 */
object DebugBypassImportOnly {

    fun describeDependency(): String {
        return "integration references " + DebugBypassChecker::class.java.simpleName
    }
}
