package ru.corp.app.security

import ru.sberbank.cerbersdk.sdk_framework.DebugBypassChecker
import ru.sberbank.cerbersdk.sdk_framework.SecureCheck
import ru.sberbank.cerbersdk.sdk_framework.SecureChecker
import ru.corp.app.analytics.Analytics

/**
 * Правило cerber-debug-bypass-checker-present, сторона TN.
 * Любая находка здесь, кроме R1-TN-5, означает переcрабатывание.
 */
object CorrectLaunchGate {

    /** R1-TN-1. Эталонная интеграция: проверки есть, послабления нет. Молчание. */
    fun isDeviceTrustedForLaunch(): Boolean {
        val posture = SecureChecker.performChecks()
        return posture == SecureCheck.DEVICE_COMPLIANT
    }

    /** R1-TN-2. Свои фича-флаги с похожими именами. Молчание. */
    fun warmCaches(): Boolean {
        if (AppFeatureGate.shouldBypassCache()) {
            return true
        }
        return AppFeatureGate.shouldBypassRootCheck()
    }

    /** R1-TN-3. Имя класса и метода в строковых литералах. Это не код, молчание. */
    fun reportIntegrationPosture(analytics: Analytics) {
        analytics.track("cerber_debug_bypass_checker_absent")
        analytics.track("DebugBypassChecker.shouldBypassRootEmulatorCheck")
        val keepRule = "-keep class ru.sberbank.cerbersdk.sdk_framework.DebugBypassChecker { *; }"
        analytics.track(keepRule)
    }

    /** R1-TN-4. Метод-омоним у своего класса. Прогон 2026-10-22: сработка, ложная. */
    fun localHomonym(gate: LocalSecurityGate): Boolean {
        return gate.shouldBypassRootEmulatorCheck()
    }

    /** R1-TN-5. Вызов внутри геттера. Прогон 2026-10-22: находки НЕТ, это разрыв правила. */
    object BypassFacade {
        val rootCheckDisabled: Boolean
            get() = DebugBypassChecker.shouldBypassRootEmulatorCheck()
    }

    /** R1-TN-6. Потребитель обёртки, вызова SDK нет. Молчание. */
    fun useFacade(): Boolean {
        return BypassFacade.rootCheckDisabled
    }
}

/** Свои фича-флаги приложения. К CerberSDK отношения не имеют. */
object AppFeatureGate {
    fun shouldBypassCache(): Boolean = false
    fun shouldBypassRootCheck(): Boolean = false
}

/** Свой гейт приложения с методом-омонимом. Нужен для R1-TN-4. */
class LocalSecurityGate {
    fun shouldBypassRootEmulatorCheck(): Boolean = false
}
