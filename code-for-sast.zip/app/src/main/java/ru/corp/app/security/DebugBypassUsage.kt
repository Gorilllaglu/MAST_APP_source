package ru.corp.app.security

import ru.sberbank.cerbersdk.sdk_framework.DebugBypassChecker
import ru.sberbank.cerbersdk.sdk_framework.SecureCheck
import ru.sberbank.cerbersdk.sdk_framework.SecureChecker
import ru.corp.app.di.CerberSdkDelegate

/**
 * Правило cerber-debug-bypass-checker-present, сторона TP.
 * Сценарий: приложение оставило в релизной ветке отладочное послабление проверок.
 */
object LaunchGate {

    /** R1-TP-1. Прямой статический вызов. Подходит сразу под три альтернативы правила. */
    fun isDeviceTrustedForLaunch(): Boolean {
        if (DebugBypassChecker.shouldBypassRootEmulatorCheck()) {
            return true
        }
        return SecureChecker.performChecks() == SecureCheck.DEVICE_COMPLIANT
    }

    /** R1-TP-2. Экземплярный получатель плюс парный метод чекера. Ожидаются две находки. */
    fun applyDebugRelaxations(delegate: CerberSdkDelegate): Boolean {
        val bypass = delegate.debugBypassChecker
        val skipRootCheck = bypass.shouldBypassRootEmulatorCheck()
        val skipScreenGuard = DebugBypassChecker.shouldBypassSecureScreen()
        return skipRootCheck || skipScreenGuard
    }

    /** R1-PROBE-1. Вызов через рефлексию по строке имени. Правило такой формы не описывает. */
    fun reflectiveRelaxation(): Boolean {
        val cls = Class.forName("ru.sberbank.cerbersdk.sdk_framework.DebugBypassChecker")
        val m = cls.getMethod("shouldBypassRootEmulatorCheck")
        return m.invoke(null) as Boolean
    }
}
