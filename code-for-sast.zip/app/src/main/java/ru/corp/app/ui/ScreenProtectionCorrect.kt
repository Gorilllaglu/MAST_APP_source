package ru.corp.app.ui

import android.app.Activity
import android.os.Bundle
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity

/**
 * Правило cerber-flag-secure-cleared, сторона TN.
 * Любая находка здесь, кроме R2-TN-5 и R2-PROBE-3, означает переcрабатывание.
 */
class StatementActivity : AppCompatActivity() {

    /** R2-TN-1. Защита выставляется, а не снимается. Прогон: молчание, верно. */
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        window.setFlags(
            WindowManager.LayoutParams.FLAG_SECURE,
            WindowManager.LayoutParams.FLAG_SECURE
        )
    }
}

/** R2-TN-2. Снимается другой флаг, именованной константой. Прогон: молчание, верно. */
fun stopKeepingScreenOn(activity: Activity) {
    activity.window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
}

/** R2-TN-3. Снимается другой флаг, числом 128. Прогон: молчание, верно. */
fun stopKeepingScreenOnNumeric(activity: Activity) {
    activity.window.clearFlags(128)
}

/** R2-TN-4. Состояние читается, а не меняется. Прогон: молчание, верно. */
fun isScreenProtected(activity: Activity): Boolean {
    val flags = activity.window.attributes.flags
    return flags and WindowManager.LayoutParams.FLAG_SECURE != 0
}

/** R2-TN-5. Защита снята и возвращена в finally. Прогон: сработка, и она корректна. */
fun withProtectionTemporarilyOff(activity: Activity, block: () -> Unit) {
    activity.window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
    try {
        block()
    } finally {
        activity.window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
    }
}

/** Свой держатель битовых признаков приложения. К окну отношения не имеет. */
class FeatureFlagMask(private var mask: Int) {
    fun clearFlags(flags: Int) {
        mask = mask and flags.inv()
    }
}

/** R2-PROBE-3. Метод-омоним с тем же числом. Прогон: сработка, ложная — нужна привязка к окну. */
fun dropAnalyticsFeature(mask: FeatureFlagMask) {
    mask.clearFlags(8192)
}
