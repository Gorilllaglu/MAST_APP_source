package ru.corp.app.security

import ru.sberbank.cerbersdk.sdk_framework.SecureCheck
import ru.sberbank.cerbersdk.sdk_framework.SecureChecker
import android.util.Log

/**
 * Правило cerber-secure-check-result-ignored.
 * Прогон 2026-10-22: сработали ВСЕ семь TN. Причина — pattern-not сравнивает
 * диапазон совпадения, а исключения описывают объемлющие конструкции.
 */
object DeviceComplianceGate {

    /** R3-TP-1. Вызов самостоятельным оператором. Прогон: сработка, верно. */
    fun warmUpSecurityChecks(checker: SecureChecker) {
        checker.performChecks()
    }

    /** R3-TP-2. Результат только в журнал. Прогон: сработка, верно. */
    fun logSecurityPosture(checker: SecureChecker) {
        Log.d("compliance", "posture=" + checker.performChecks())
    }

    /** R3-TN-1. val плюс сверка. Прогон: сработка, ложная. */
    fun enforceCompliance(checker: SecureChecker): Boolean {
        val result = checker.performChecks()
        if (result != SecureCheck.DEVICE_COMPLIANT) {
            return false
        }
        return true
    }

    /** R3-TN-2. val с явным типом. Прогон: сработка, ложная. */
    fun enforceComplianceTyped(checker: SecureChecker): Boolean {
        val result: SecureCheck = checker.performChecks()
        return result == SecureCheck.DEVICE_COMPLIANT
    }

    /** R3-TN-3. var. Прогон: сработка, ложная. */
    fun enforceComplianceVar(checker: SecureChecker): Boolean {
        var result = checker.performChecks()
        return result == SecureCheck.DEVICE_COMPLIANT
    }

    /** R3-TN-4. Присваивание в объявленную переменную. Прогон: сработка, ложная. */
    fun enforceComplianceReassign(checker: SecureChecker): Boolean {
        var result: SecureCheck = SecureCheck.DEVICE_COMPLIANT
        result = checker.performChecks()
        return result == SecureCheck.DEVICE_COMPLIANT
    }

    /** R3-TN-5. Результат возвращён. Прогон: сработка, ложная. */
    fun currentPosture(checker: SecureChecker): SecureCheck {
        return checker.performChecks()
    }

    /** R3-TN-6. Сверка в условии, равенство. Прогон: сработка, ложная. */
    fun isCompliantEq(checker: SecureChecker): Boolean {
        if (checker.performChecks() == SecureCheck.DEVICE_COMPLIANT) {
            return true
        }
        return false
    }

    /** R3-TN-7. Сверка в условии, неравенство. Прогон: сработка, ложная. */
    fun isCompliantNeq(checker: SecureChecker): Boolean {
        if (checker.performChecks() != SecureCheck.DEVICE_COMPLIANT) {
            return false
        }
        return true
    }

    /** R3-PROBE-1. Результат сохранён и ни с чем не сверен. Семантически дефект. */
    fun storeAndForget(checker: SecureChecker) {
        val result = checker.performChecks()
        Log.d("compliance", result.toString())
    }

    /** R3-PROBE-2. Сверка с одним плохим состоянием вместо DEVICE_COMPLIANT. Прогон: сработка, верно. */
    fun isCompliantPartial(checker: SecureChecker): Boolean {
        if (checker.performChecks() != SecureCheck.ROOT_DETECTED) {
            return true
        }
        return false
    }
}
