package ru.sberbank.cerbersdk.data

import ru.corp.app.di.CerberSdkDelegate

/**
 * Правило cerber-trusted-components-usage-marker, сторона TN.
 * Те же вызовы внутри библиотеки: путь содержит cerber-sdk.
 * Прогон 2026-10-22: молчание, paths.exclude работает в заданной форме.
 */
internal class TrustedComponentsRepositoryImpl(
    private val delegate: CerberSdkDelegate
) {

    /** R4-TN-1. Внутренний вызов библиотеки, чтение кеша. */
    fun warmCache() {
        delegate.trustedComponents.getFromCache()
    }

    /** R4-TN-2. Внутренний вызов библиотеки, загрузка. */
    fun syncFromServer() {
        delegate.trustedComponents.download()
    }
}
