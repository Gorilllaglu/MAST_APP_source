# 24 правила: изменился только текст

Шаблоны и полки не тронуты. Прогон не нужен, вставить в состав надо.

Одиннадцать утверждений о поведении SDK были неверны или неполны. Все проверены по декомпилированному коду SDK в пяти сборках из пяти приложений; версии разные, и две ошибки были именно версионными — поведение одной сборки я описал как свойство всех.

| Правило | Что утверждалось | Что в коде |
|---|---|---|
| `default-constructor-used` | конструктор без аргументов выключает три защиты | защиты по умолчанию `true`; по умолчанию `buildType = IFT`, и из-за него у делегата нет пиннинга |
| `non-production-build-type`, `-variable` | «ослабленный пиннинг» | пиннинг включается условием `buildType == PROM \|\| enableTestServerPinning` — на нерабочем типе сборки его нет вовсе |
| `root-detected-no-termination` | экран `DeviceNotSecureActivity` обходится через Frida | класса нет в одной из пяти сборок; реакция SDK — колбэк и телеметрический сигнал, завершения нет ни в одной |
| `auth-requested-but-not-observed` | состояния «Authorized→Pin, timeout, logout» | у `CerberAuth` два значения: `AUTHORIZED`, `NOT_AUTHORIZED` |
| `activity-no-lifecycle-override` | без `onResume` авторизацию проверить нельзя | SDK ставит свои `ActivityLifecycleCallbacks` и монитор переднего плана и сам запускает экран авторизации |
| `app-integrity-check-marker` | пропускается «на управляемом корпоративном устройстве» | пропускается для приложения, которое MDM считает корпоративным (`MDMAppType.CORP`), а не BYOD |
| `debug-bypass-checker-present` | отключает детект root и эмулятора | две точки входа: вторая снимает установку FLAG_SECURE |
| `flag-secure-cleared` | FLAG_SECURE ставится при `secureScreen=true` | ставится всегда; при сохранённой политике побеждает серверное `screenshotsForbidden` |
| `secure-initial-check-disabled` (джава) | флаг приходит из конфигурации как `secureChecks` | такого имени нет ни в одном из пяти приложений; флаг закрывает цикл по значениям `SecureCheck` в `performChecks()` |
| `missing-sdk-application-interface` (джава) | «for proper initialization» | текст был короче котлиновского; выровнен |
| `trusted-components-usage-marker` | вызовы без префикса делегата | API достаётся через `delegate.trustedComponents` |

Текст `insecure-screen-disabled` в джавовском варианте и `selection-callback-not-sdk` поправлены там же, где и котлиновские, но котлиновские версии этих двух правил ушли в папку под прогон — у них менялись и шаблоны.
