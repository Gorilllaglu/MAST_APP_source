package android.os;

public final class Process {
    private Process() {
    }

    public static int myPid() {
        throw new UnsupportedOperationException("stub");
    }

    public static void killProcess(int pid) {
        throw new UnsupportedOperationException("stub");
    }
}
