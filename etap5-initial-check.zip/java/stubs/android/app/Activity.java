package android.app;

public class Activity {
    protected void onResume() {
        throw new UnsupportedOperationException("stub");
    }

    protected void onCreate() {
        throw new UnsupportedOperationException("stub");
    }

    public void finish() {
        throw new UnsupportedOperationException("stub");
    }
}
