package android.net;

public class Uri {
    public static Uri parse(String value) {
        throw new UnsupportedOperationException("stub");
    }
}
