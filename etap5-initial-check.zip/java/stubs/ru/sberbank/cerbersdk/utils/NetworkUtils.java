package ru.sberbank.cerbersdk.utils;

import okhttp3.OkHttpClient;

public final class NetworkUtils {

    private NetworkUtils() {
    }

    public static OkHttpClient getDefaultOkHttpClient() {
        throw new UnsupportedOperationException("stub");
    }

    public static OkHttpClient getAuthorizedOtpOkHttpClient(Object cert, Object privateKey) {
        throw new UnsupportedOperationException("stub");
    }

    public static OkHttpClient getSberMagOkHttpClient() {
        throw new UnsupportedOperationException("stub");
    }
}
