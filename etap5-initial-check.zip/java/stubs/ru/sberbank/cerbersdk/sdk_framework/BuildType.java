package ru.sberbank.cerbersdk.sdk_framework;

public enum BuildType {
    PROM,
    IFT,
    PSI,
    DEV1,
    DEV2
}
