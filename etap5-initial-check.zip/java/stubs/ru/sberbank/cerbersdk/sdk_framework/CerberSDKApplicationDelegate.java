package ru.sberbank.cerbersdk.sdk_framework;

/**
 * Порядок параметров повторяет реальный, снятый с SberApps 3.6.2:
 *   1 authorizationMode   6 secureClipboard
 *   2 buildType           7 enableTestServerPinning
 *   3 isolated            8 sberMagOptions
 *   4 secureInitialCheck  9 whiteListOptions
 *   5 secureScreen       10 disablePasswordlessAuth
 */
public class CerberSDKApplicationDelegate {

    public CerberSDKApplicationDelegate() {
        throw new UnsupportedOperationException("stub");
    }

    public CerberSDKApplicationDelegate(AuthorizationMode authorizationMode,
                                        BuildType buildType,
                                        boolean isolated,
                                        boolean secureInitialCheck,
                                        boolean secureScreen,
                                        boolean secureClipboard,
                                        boolean enableTestServerPinning,
                                        Object sberMagOptions,
                                        Object whiteListOptions,
                                        boolean disablePasswordlessAuth) {
        throw new UnsupportedOperationException("stub");
    }
}
