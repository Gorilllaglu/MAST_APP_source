package ru.sberbank.cerbersdk.sdk_framework;

public final class CerberAuth {

    private CerberAuth() {
    }

    public static void requestCerberAuth(Object screen) {
        throw new UnsupportedOperationException("stub");
    }

    public static void observeAuthState(Object screen) {
        throw new UnsupportedOperationException("stub");
    }
}
