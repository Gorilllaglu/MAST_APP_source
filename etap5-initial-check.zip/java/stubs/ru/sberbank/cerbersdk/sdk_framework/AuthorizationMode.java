package ru.sberbank.cerbersdk.sdk_framework;

public enum AuthorizationMode {
    CERBER,
    NONE,
    PINCODE_ONLY
}
