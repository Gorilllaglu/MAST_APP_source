package ru.sberbank.cerbersdk.pinning;

import okhttp3.Interceptor;

public class NetworkSelectRepository {
    public Interceptor getPinningInterceptor() {
        throw new UnsupportedOperationException("stub");
    }
}
