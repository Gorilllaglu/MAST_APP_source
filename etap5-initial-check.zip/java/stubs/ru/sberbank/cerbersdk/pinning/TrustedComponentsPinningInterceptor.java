package ru.sberbank.cerbersdk.pinning;

import okhttp3.Interceptor;

public class TrustedComponentsPinningInterceptor implements Interceptor {
    @Override
    public Object intercept(Object chain) {
        throw new UnsupportedOperationException("stub");
    }
}
