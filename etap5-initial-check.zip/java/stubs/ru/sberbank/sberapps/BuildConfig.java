package ru.sberbank.sberapps;

public final class BuildConfig {
    public static final String FLAVOR = "promDef";
    public static final boolean DEBUG = false;

    private BuildConfig() {
    }
}
