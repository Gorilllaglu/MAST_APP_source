package ru.corp.app;

import android.app.Application;

import ru.sberbank.cerbersdk.sdk_framework.AuthorizationMode;
import ru.sberbank.cerbersdk.sdk_framework.BuildType;
import ru.sberbank.cerbersdk.sdk_framework.CerberSDKApplication;
import ru.sberbank.cerbersdk.sdk_framework.CerberSDKApplicationDelegate;
import ru.sberbank.sberapps.BuildConfig;

/**
 * J21 cerber-java-secure-initial-check-disabled, переработанное правило.
 *
 * В Java именованных аргументов нет, поэтому проверяется позиция. Порядок
 * параметров конструктора, снятый с SberApps 3.6.2:
 *   1 authorizationMode   6 secureClipboard
 *   2 buildType           7 enableTestServerPinning
 *   3 isolated            8 sberMagOptions
 *   4 secureInitialCheck  9 whiteListOptions
 *   5 secureScreen       10 disablePasswordlessAuth
 *
 * Ветка правила с метапеременной в четвёртой позиции не измерялась ни разу:
 * клетка J21-TP-1 всегда давала литерал. Клетки TP-2 и TP-3 закрывают пробел.
 */
public final class InitialCheckFormsJava {

    /** Канонический динамический флаг. */
    private static final boolean secureChecks =
            BuildConfig.FLAVOR.toLowerCase().contains("prom");

    /** Чужой флаг: имя не secureChecks, правило обязано сработать. */
    private static final boolean raspEnabled = true;

    /** Тот же флаг методом: правило обязано промолчать. */
    private static boolean secureChecks() {
        return BuildConfig.FLAVOR.toLowerCase().contains("prom");
    }

    private InitialCheckFormsJava() {
    }

    /** J21-TP-1. Литерал false четвёртым аргументом. Форма измерена ранее. */
    public static class InitialCheckOffApplication extends Application implements CerberSDKApplication {
        private final CerberSDKApplicationDelegate delegate = new CerberSDKApplicationDelegate(
                AuthorizationMode.CERBER, BuildType.PROM, false, false, true, true, true, null, null, false);

        @Override
        public CerberSDKApplicationDelegate getDelegate() {
            return delegate;
        }
    }

    /** J21-TP-2. Чужое имя флага. Вторая ветка правила, измеряется впервые. */
    public static class ForeignFlagApplication extends Application implements CerberSDKApplication {
        private final CerberSDKApplicationDelegate delegate = new CerberSDKApplicationDelegate(
                AuthorizationMode.CERBER, BuildType.PROM, false, raspEnabled, true, true, true, null, null, false);

        @Override
        public CerberSDKApplicationDelegate getDelegate() {
            return delegate;
        }
    }

    /** J21-TP-3. Значение вычислено выражением на месте. */
    public static class ExpressionFlagApplication extends Application implements CerberSDKApplication {
        private final CerberSDKApplicationDelegate delegate = new CerberSDKApplicationDelegate(
                AuthorizationMode.CERBER, BuildType.PROM, false, !BuildConfig.DEBUG, true, true, true, null, null, false);

        @Override
        public CerberSDKApplicationDelegate getDelegate() {
            return delegate;
        }
    }

    /** J21-TN-1. Литерал true. Молчание. */
    public static class InitialCheckOnApplication extends Application implements CerberSDKApplication {
        private final CerberSDKApplicationDelegate delegate = new CerberSDKApplicationDelegate(
                AuthorizationMode.CERBER, BuildType.PROM, false, true, true, true, true, null, null, false);

        @Override
        public CerberSDKApplicationDelegate getDelegate() {
            return delegate;
        }
    }

    /** J21-TN-2. Канонический флаг полем. Главная клетка правки. */
    public static class DynamicFlagApplication extends Application implements CerberSDKApplication {
        private final CerberSDKApplicationDelegate delegate = new CerberSDKApplicationDelegate(
                AuthorizationMode.CERBER, BuildType.PROM, false, secureChecks, true, true, true, null, null, false);

        @Override
        public CerberSDKApplicationDelegate getDelegate() {
            return delegate;
        }
    }

    /** J21-TN-3. Тот же флаг методом. Молчание. */
    public static class MethodFlagApplication extends Application implements CerberSDKApplication {
        private final CerberSDKApplicationDelegate delegate = new CerberSDKApplicationDelegate(
                AuthorizationMode.CERBER, BuildType.PROM, false, secureChecks(), true, true, true, null, null, false);

        @Override
        public CerberSDKApplicationDelegate getDelegate() {
            return delegate;
        }
    }

    /** J21-TN-4. Флаг через this. Молчание. */
    public static class ThisFlagApplication extends Application implements CerberSDKApplication {
        private final boolean secureChecks = BuildConfig.FLAVOR.toLowerCase().contains("prom");

        private final CerberSDKApplicationDelegate delegate = new CerberSDKApplicationDelegate(
                AuthorizationMode.CERBER, BuildType.PROM, false, this.secureChecks, true, true, true, null, null, false);

        @Override
        public CerberSDKApplicationDelegate getDelegate() {
            return delegate;
        }
    }
}
