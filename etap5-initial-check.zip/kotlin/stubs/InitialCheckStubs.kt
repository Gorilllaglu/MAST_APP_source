package ru.sberbank.cerbersdk.sdk_framework

/** Заглушки под фикстуры K16 и K17: только объявления, находок быть не должно. */

enum class AuthorizationMode { CERBER, NONE, EXTERNAL, LEGACY }

enum class BuildType { PROM, DEV1, DEV2, IFT, PSI }

interface CerberSDKApplication {
    fun initializeSdk()
}

/**
 * Подпись повторяет реальную, снятую с SberApps 3.6.2, все параметры именованные:
 *   1 authorizationMode   6 secureClipboard
 *   2 buildType           7 enableTestServerPinning
 *   3 isolated            8 sberMagOptions
 *   4 secureInitialCheck  9 whiteListOptions
 *   5 secureScreen       10 disablePasswordlessAuth
 */
class CerberSDKApplicationDelegate(
    val authorizationMode: AuthorizationMode = AuthorizationMode.CERBER,
    val buildType: BuildType = BuildType.PROM,
    val isolated: Boolean = false,
    val secureInitialCheck: Boolean = false,
    val secureScreen: Boolean = false,
    val secureClipboard: Boolean = false,
    val enableTestServerPinning: Boolean = false,
    val sberMagOptions: Any? = null,
    val whiteListOptions: Any? = null,
    val disablePasswordlessAuth: Boolean = false
) : CerberSDKApplication {
    override fun initializeSdk() {}
}
