package ru.corp.app

/** Платформенные и сборочные заглушки. */

open class Application

annotation class HiltAndroidApp

object BuildConfig {
    const val FLAVOR = "promDef"
    const val DEBUG = false
}

enum class FlavorStand(val stand: String) {
    PROM("prom"),
    IFT("ift")
}

val cerberBuildType = ru.sberbank.cerbersdk.sdk_framework.BuildType.PROM

/** Чужой флаг: имя не secureChecks, правило обязано сработать. */
val raspEnabled = true

/** Форма через функцию: правило обязано промолчать. */
fun secureChecks(): Boolean = BuildConfig.FLAVOR.contains(FlavorStand.PROM.stand, true)
