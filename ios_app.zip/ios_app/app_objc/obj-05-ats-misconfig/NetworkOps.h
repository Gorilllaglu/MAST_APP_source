#import <Foundation/Foundation.h>

/// VULN-IPA-05 (Objective-C): HTTP-запрос с bearer-токеном.
/// Работает в паре с ослаблениями ATS в Info.plist (NSAllowsArbitraryLoads и др.).
@interface NetworkOps : NSObject
+ (void)fetchInsecure;
@end
