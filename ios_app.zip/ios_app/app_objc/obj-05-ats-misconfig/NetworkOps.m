#import "NetworkOps.h"

static NSString *const kAuthBearer  = @"Bearer eyJhbGciOiJIUzI1NiJ9.fake.fake";
static NSString *const kHttpEndpoint = @"http://insecure.example.com/v1/profile";

@implementation NetworkOps

+ (void)fetchInsecure {
    NSURL *url = [NSURL URLWithString:kHttpEndpoint];   // <-- VULN: http://
    if (url == nil) { return; }
    NSMutableURLRequest *req = [NSMutableURLRequest requestWithURL:url];
    req.HTTPMethod = @"GET";
    [req addValue:kAuthBearer forHTTPHeaderField:@"Authorization"];  // <-- VULN: токен в HTTP
    NSURLSessionDataTask *task =
        [[NSURLSession sharedSession] dataTaskWithRequest:req
                                        completionHandler:^(NSData *data,
                                                            NSURLResponse *response,
                                                            NSError *error) {
            // намеренно ничего не делаем с ответом
            (void)data;
        }];
    [task resume];
}

@end
