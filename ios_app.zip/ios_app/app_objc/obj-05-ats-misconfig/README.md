# OBJ-05 (Objective-C) — Небезопасная конфигурация ATS

Objective-C аналог Swift-приложения
[`app_swift/ipa-05-ats-misconfig`](../../app_swift/ipa-05-ats-misconfig).
Двойной сигнал: **манифест** (Info.plist ослабляет ATS) **+ код** (реальный HTTP).

## Что заложено

**Info.plist** (скопирован 1:1 со Swift-версии) — `NSAppTransportSecurity` с
максимальным набором ослаблений (R012):
`NSAllowsArbitraryLoads`, `…ForMedia`, `…InWebContent`, `NSAllowsLocalNetworking`,
+ `NSExceptionDomains → insecure.example.com` (`NSExceptionAllowsInsecureHTTPLoads=true`,
`NSExceptionMinimumTLSVersion=TLSv1.0`, `NSExceptionRequiresForwardSecrecy=false`).

**Код** ([NetworkOps.m](NetworkOps.m)) реально использует это разрешение —
`-[NSURLSession dataTaskWithRequest:]` на `http://insecure.example.com/...`
с заголовком `Authorization: Bearer …` (R092 + R087).

## Раскладка файлов

```
obj-05-ats-misconfig/   (Objective-C)
├── README.md
├── Info.plist          ← VULN: NSAppTransportSecurity ослаблен (R012)
├── AppDelegate.h/.m
├── ViewController.h/.m
└── NetworkOps.h/.m     ← sink: NSURLSession + http:// + Authorization
```

## Objective-C ↔ Swift

- **Манифест-часть идентична** (тот же Info.plist) — ловится сканером
  обычным путём, независимо от языка кода.
- **Код-часть:** `[NSURLSession sharedSession] dataTaskWithRequest:]` —
  тот же API, что Swift `URLSession.shared.dataTask`. `http://`-литерал и
  Bearer-токен — в Mach-O strings.

## Форма

Src-снапшот без `.xcodeproj`.
