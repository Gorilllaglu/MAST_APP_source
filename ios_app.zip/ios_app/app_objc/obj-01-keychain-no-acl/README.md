# IPA-01 (Objective-C) — Keychain item без access control

Objective-C аналог Swift-приложения
[`app_swift/ipa-01-keychain-no-acl`](../../app_swift/ipa-01-keychain-no-acl).
Та же уязвимость, тот же набор sink'ов — другой язык.

## Что заложено

`+[KeychainOps runAll]` (вызывается из `AppDelegate`) пишет в Keychain
**три** записи со слабыми access-атрибутами:

| Запись | Атрибут | Sink |
|---|---|---|
| `auth_token` | `kSecAttrAccessibleAlways` | худший класс — читается даже на залоченном устройстве (R151) |
| `api_password` | `kSecAttrAccessibleAfterFirstUnlock`, без `kSecAttrAccessControl` | фоновый доступ без user-presence (R151) |
| `session_token` | `kSecAttrAccessibleWhenUnlocked` + `kSecAttrSynchronizable=true` | синхронизация в iCloud Keychain (R151 / R031) |

Три hardcoded-литерала (`kAuthToken`, `kApiPassword`, `kSessionToken`) →
в Mach-O как plaintext strings (R031 + R032).

## Раскладка файлов

```
obj-01-keychain-no-acl/   (Objective-C)
├── README.md
├── Info.plist            ← идентичен Swift-версии
├── AppDelegate.h/.m
├── ViewController.h/.m
└── KeychainOps.h/.m      ← sink'и: SecItemAdd + kSecAttrAccessible*
```

## Objective-C ↔ Swift: что меняется для анализа

- **API те же.** Security.framework (`SecItemAdd`, `kSecClass*`,
  `kSecAttrAccessible*`) — это C API; в ObjC доступ через `(__bridge id)`
  каст CF-констант в `NSDictionary`. Sink идентичен Swift-версии.
- **Метаданные богаче.** В отличие от Swift, ObjC-рантайм хранит полные
  имена классов/методов в Mach-O → `class-dump` восстановит
  `KeychainOps`, `saveTokenAccessibleAlways` и т.д. почти как исходник.
  То есть MAST-from-binary по ObjC заметно проще, чем по Swift.
- Литералы-секреты в ObjC лежат в `__TEXT,__cstring` так же, как в Swift
  (`strings` их видит в обоих случаях).

## Форма

Src-снапшот: исходники + `Info.plist`, без `.xcodeproj` (как и Swift-оригинал —
там сборка через `xcodegen`). Для сборки — завести xcodegen/Xcode-таргет
на эти файлы.
