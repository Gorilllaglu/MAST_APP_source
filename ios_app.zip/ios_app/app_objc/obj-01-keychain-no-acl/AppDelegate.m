#import "AppDelegate.h"
#import "ViewController.h"
#import "KeychainOps.h"

@implementation AppDelegate

- (BOOL)application:(UIApplication *)application
    didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    self.window = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
    self.window.rootViewController = [ViewController new];
    [self.window makeKeyAndVisible];
    // Заложенные уязвимости — Keychain без access control
    [KeychainOps runAll];
    return YES;
}

@end
