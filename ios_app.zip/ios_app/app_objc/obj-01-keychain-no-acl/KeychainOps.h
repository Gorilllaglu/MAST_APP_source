#import <Foundation/Foundation.h>

/// VULN-IPA-01 (Objective-C): Keychain item записан с самым слабым
/// access-control'ом. Сканер должен видеть `SecItemAdd` +
/// `kSecAttrAccessibleAlways` / `…AfterFirstUnlock` без
/// `kSecAttrAccessControl`, плюс hardcoded-литералы токена/пароля.
@interface KeychainOps : NSObject
+ (void)runAll;
+ (OSStatus)saveTokenAccessibleAlways;
+ (OSStatus)savePasswordAfterFirstUnlockNoAccessControl;
+ (OSStatus)saveSessionWithSyncedAccess;
@end
