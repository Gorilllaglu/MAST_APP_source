#import "KeychainOps.h"
#import <Security/Security.h>

// Hardcoded literals — попадают в Mach-O как plaintext strings (виден `strings`).
static NSString *const kService      = @"com.masttest.stingapp";
static NSString *const kAuthToken    = @"eyJhbGciOiJIUzI1NiJ9.fake.fake";
static NSString *const kApiPassword  = @"P@ssw0rd-2024";
static NSString *const kSessionToken = @"sess_live_4eC39HqLyjWDarjtT1zdp7dc";

@implementation KeychainOps

+ (void)runAll {
    [self saveTokenAccessibleAlways];
    [self savePasswordAfterFirstUnlockNoAccessControl];
    [self saveSessionWithSyncedAccess];
}

/// Худшая категория: `kSecAttrAccessibleAlways` — токен в Keychain
/// читается даже когда устройство залочено, любым процессом с тем же
/// keychain-access-group.
+ (OSStatus)saveTokenAccessibleAlways {
    NSDictionary *query = @{
        (__bridge id)kSecClass:          (__bridge id)kSecClassGenericPassword,
        (__bridge id)kSecAttrService:    kService,
        (__bridge id)kSecAttrAccount:    @"auth_token",
        (__bridge id)kSecValueData:      [kAuthToken dataUsingEncoding:NSUTF8StringEncoding],
        (__bridge id)kSecAttrAccessible: (__bridge id)kSecAttrAccessibleAlways   // <-- VULN sink
    };
    SecItemDelete((__bridge CFDictionaryRef)query);
    return SecItemAdd((__bridge CFDictionaryRef)query, NULL);
}

/// `kSecAttrAccessibleAfterFirstUnlock` без `kSecAttrAccessControl` —
/// доступ из любого процесса (включая background fetch) после первой
/// разблокировки; нет требования биометрии/passcode.
+ (OSStatus)savePasswordAfterFirstUnlockNoAccessControl {
    NSDictionary *query = @{
        (__bridge id)kSecClass:          (__bridge id)kSecClassGenericPassword,
        (__bridge id)kSecAttrService:    kService,
        (__bridge id)kSecAttrAccount:    @"api_password",
        (__bridge id)kSecValueData:      [kApiPassword dataUsingEncoding:NSUTF8StringEncoding],
        (__bridge id)kSecAttrAccessible: (__bridge id)kSecAttrAccessibleAfterFirstUnlock  // <-- VULN sink
        // kSecAttrAccessControl с .userPresence / .biometryAny НЕ задан
    };
    SecItemDelete((__bridge CFDictionaryRef)query);
    return SecItemAdd((__bridge CFDictionaryRef)query, NULL);
}

/// `kSecAttrSynchronizable = true` + `kSecAttrAccessibleWhenUnlocked` —
/// токен уезжает в iCloud Keychain и реплицируется на все устройства
/// под этим Apple ID.
+ (OSStatus)saveSessionWithSyncedAccess {
    NSDictionary *query = @{
        (__bridge id)kSecClass:             (__bridge id)kSecClassGenericPassword,
        (__bridge id)kSecAttrService:       kService,
        (__bridge id)kSecAttrAccount:       @"session_token",
        (__bridge id)kSecValueData:         [kSessionToken dataUsingEncoding:NSUTF8StringEncoding],
        (__bridge id)kSecAttrAccessible:    (__bridge id)kSecAttrAccessibleWhenUnlocked,
        (__bridge id)kSecAttrSynchronizable:(__bridge id)kCFBooleanTrue                    // <-- VULN sink
    };
    SecItemDelete((__bridge CFDictionaryRef)query);
    return SecItemAdd((__bridge CFDictionaryRef)query, NULL);
}

@end
