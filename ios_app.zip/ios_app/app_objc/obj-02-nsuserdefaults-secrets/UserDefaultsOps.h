#import <Foundation/Foundation.h>

/// VULN-IPA-02 (Objective-C): чувствительная информация в NSUserDefaults.
/// `[NSUserDefaults standardUserDefaults]` пишет в незашифрованный plist
/// ~/Library/Preferences/<bundle>.plist — попадает в backup, читается с
/// jailbroken/физического доступа.
@interface UserDefaultsOps : NSObject
+ (void)runAll;
@end
