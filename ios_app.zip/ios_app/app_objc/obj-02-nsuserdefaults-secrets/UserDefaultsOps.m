#import "UserDefaultsOps.h"

// Hardcoded literals — попадают в Mach-O как plaintext strings.
static NSString *const kAuthToken = @"eyJhbGciOiJIUzI1NiJ9.userdefaults.fake";
static NSString *const kPassword  = @"hunter2-prod";
static NSString *const kApiKey    = @"AIzaSyA_INTENTIONALLY_FAKE_FOR_TESTING";
static NSString *const kPinCode   = @"1234";

@implementation UserDefaultsOps

+ (void)runAll {
    NSUserDefaults *d = [NSUserDefaults standardUserDefaults];
    // Каждый set — отдельный sink. Имена ключей очевидные — grep-сканер
    // ловит по имени ключа в plist / имени переменной.
    [d setObject:kAuthToken forKey:@"auth_token"];      // <-- VULN sink
    [d setObject:kPassword  forKey:@"user_password"];   // <-- VULN sink
    [d setObject:kApiKey    forKey:@"google_api_key"];  // <-- VULN sink
    [d setObject:kPinCode   forKey:@"unlock_pin"];      // <-- VULN sink

    // Дополнительно — словарь с creditCard данными.
    NSDictionary *card = @{
        @"pan": @"4242424242424242",
        @"cvv": @"123",
        @"exp": @"12/29"
    };
    [d setObject:card forKey:@"saved_card"];            // <-- VULN sink

    // Bonus: synchronize() — deprecated в iOS 12+, всё ещё встречается.
    [d synchronize];
}

@end
