# OBJ-02 (Objective-C) — Чувствительная информация в NSUserDefaults

Objective-C аналог Swift-приложения
[`app_swift/ipa-02-nsuserdefaults-secrets`](../../app_swift/ipa-02-nsuserdefaults-secrets).

## Что заложено

`+[UserDefaultsOps runAll]` (вызывается из `AppDelegate`) пишет в
`[NSUserDefaults standardUserDefaults]` пять чувствительных значений:

| Ключ | Класс данных | Категория |
|---|---|---|
| `auth_token` | bearer / JWT | R075 |
| `user_password` | password | R075 |
| `google_api_key` | third-party API key (`AIzaSy…`) | R075 + R030 |
| `unlock_pin` | PIN | R075 |
| `saved_card` | PII платёжной карты (dict pan/cvv/exp) | R075 |

Плюс deprecated `synchronize`. Все литералы → в Mach-O strings (R031).

## Раскладка файлов

```
obj-02-nsuserdefaults-secrets/   (Objective-C)
├── README.md
├── Info.plist
├── AppDelegate.h/.m
├── ViewController.h/.m
└── UserDefaultsOps.h/.m   ← sink'и: -[NSUserDefaults setObject:forKey:]
```

## Objective-C ↔ Swift

- **API тот же:** `[NSUserDefaults standardUserDefaults]` +
  `setObject:forKey:` (Swift `d.set(_:forKey:)` — это он же).
- `class-dump` восстановит `UserDefaultsOps`/`runAll` из ObjC-метаданных.
- Literal-ключи (`auth_token`, `user_password`, …) и значения — в
  `__TEXT,__cstring`, видны `strings`.

## Форма

Src-снапшот без `.xcodeproj`.
