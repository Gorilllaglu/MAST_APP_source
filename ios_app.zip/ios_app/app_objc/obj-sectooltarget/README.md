# OBJ-SecToolTarget (Objective-C) — эталонный уязвимый iOS-таргет

Objective-C версия SecToolTarget — минимального device-`.ipa` с **ровно 5
заложенными дефектами** и ничего лишнего. Источник —
[`iOS-VulnTarget`](../../../iOS-VulnTarget) (его `src/main.m` уже на ObjC;
здесь он размещён в структуре порта рядом с C++-версией `cpp-sectooltarget`).

В отличие от obj-01/02/05 это **не UIKit-апп**, а минимальный бинарь:
`main()` без `AppDelegate`/`ViewController` (так задумано — меньше «шума»
для сканера).

## 5 заложенных дефектов

| # | Уязвимость | Где | Триггер |
|---|---|---|---|
| 1 | Секреты в исполняемом файле | [main.m](main.m) `kHardcodedSecrets[]` | строки `sk_live_…`, `AKIA…`, `AWS_SECRET…`, `DB_PASSWORD=`, `BEGIN … PRIVATE KEY` в `strings` |
| 2 | Нет stack-canary | [make_ipa.sh](make_ipa.sh) `-fno-stack-protector` | отсутствие `___stack_chk_guard/_fail` (PIE/NX/ARC — в норме) |
| 3 | Файл зависимостей в бандле | [Package.resolved](Package.resolved) | наличие SwiftPM lock в `.app` |
| 4 | Build-скрипт в бандле | [build.sh](build.sh) | наличие `*.sh` в `.app` |
| 5 | Keychain plaintext | [main.m](main.m) `storePlaintextSecretInKeychain()` | `SecItemAdd` + `kSecAttrAccessibleAlways` + `kSecValueData` |

## Раскладка файлов

```
obj-sectooltarget/   (Objective-C)
├── README.md
├── main.m              ← VULN-1 (секреты) + VULN-5 (Keychain plaintext)
├── make_ipa.sh         ← VULN-2 (-fno-stack-protector); собирает .ipa
├── Info.plist          ← кладётся в .app
├── Package.resolved    ← кладётся в .app  (VULN-3)
└── build.sh            ← кладётся в .app  (VULN-4)
```

## Objective-C ↔ C++ (порт)

- Здесь Keychain пишется через `NSDictionary`-литерал + `(__bridge id)`-касты;
  в [`cpp-sectooltarget`](../../app_cpp/cpp-sectooltarget) то же — через
  `CFDictionary` на чистом C++.
- ObjC-метаданные минимальны (нет своих классов — только `main`/static-функция),
  поэтому `class-dump` тут и так почти пуст; основной материал — `strings` +
  импорты Security. Это сближает ObjC- и C++-версии по поверхности анализа.

## Сборка

```bash
sh make_ipa.sh   # → SecToolTarget.ipa  (нужен macOS + Xcode CLT, iPhoneOS SDK)
```
