//
//  main.m
//  SecToolTarget (Objective-C) — намеренно уязвимый iOS-таргет для проверки
//  сработок MAST-инструмента. Ровно 5 заложенных дефектов (см. README.md).
//
//  Язык — Objective-C + ARC специально: чтобы ARC/PIE/NX оставались в норме
//  и не порождали посторонних сработок; убран ТОЛЬКО stack-canary (VULN-2,
//  флаг `-fno-stack-protector` в make_ipa.sh).
//

#import <Foundation/Foundation.h>
#import <Security/Security.h>

#pragma mark - [VULN-1] Чувствительная информация в исполняемом файле
// C-строковые литералы → секция __TEXT,__cstring → видны в `strings`.
// __attribute__((used)) удерживает их в бинаре даже без рантайм-использования.
__attribute__((used)) static const char * const kHardcodedSecrets[] = {
    "API_KEY=sk_live_51PvulnTOOLtarget9aZ3bQ7c1dE5fG8hJ0kL2mN",       // Stripe-style secret key
    "AWS_ACCESS_KEY_ID=AKIAIOSFODNN7VULNTOOL",                        // AWS access key id
    "AWS_SECRET_ACCESS_KEY=wJalrXUtnFEMI/K7MDENG/bPxRfiCEYSECRETKEY", // AWS secret access key
    "DB_PASSWORD=Sup3rS3cr3t!Prod#2024",                              // database password
    "PRIVATE_KEY=-----BEGIN RSA PRIVATE KEY-----MIIBVAIBADANBgkqhkiG9w0BAQEFAASCATEST-----END RSA PRIVATE KEY-----",
};

#pragma mark - [VULN-5] Хранение sensitive-данных в KeyChain в открытом виде
static void storePlaintextSecretInKeychain(void) {
    // Значение кладётся как есть, без прикладного шифрования, со «слабым»
    // классом доступности kSecAttrAccessibleAlways: нет гейта по паролю/
    // биометрии, элемент попадает в iCloud Keychain / резервную копию.
    NSString *sessionToken =
        @"session_token=eyJhbGciOiJIUzI1NiJ9.eyJ1IjoicHJvZCJ9.PLAINTEXT_SECRET_DO_NOT_SHIP";

    NSDictionary *item = @{
        (__bridge id)kSecClass:          (__bridge id)kSecClassGenericPassword,
        (__bridge id)kSecAttrService:    @"com.appsec.sectooltarget.credentials",
        (__bridge id)kSecAttrAccount:    @"prod_user",
        (__bridge id)kSecValueData:      [sessionToken dataUsingEncoding:NSUTF8StringEncoding],
        (__bridge id)kSecAttrAccessible: (__bridge id)kSecAttrAccessibleAlways,   // <-- VULN sink
    };

    SecItemDelete((__bridge CFDictionaryRef)item);
    SecItemAdd((__bridge CFDictionaryRef)item, NULL);                            // <-- VULN sink
}

int main(int argc, char *argv[]) {
    @autoreleasepool {
        storePlaintextSecretInKeychain();
    }
    return 0;
}
