#!/bin/sh
# Reproducible build of SecToolTarget.ipa (Objective-C). Ровно 5 заложенных
# дефектов (см. README.md). Собирает device (arm64, platform=iphoneos) .ipa.
# Запуск: sh make_ipa.sh
set -eu

HERE="$(cd "$(dirname "$0")" && pwd)"
APPNAME="SecToolTarget"
APP="$HERE/Payload/$APPNAME.app"
BIN="$APP/$APPNAME"
SDK="$(xcrun --sdk iphoneos --show-sdk-path)"

rm -rf "$HERE/Payload" "$HERE/$APPNAME.ipa"
mkdir -p "$APP"

# 1) Компиляция device-бинаря:
#    -fobjc-arc            → ARC присутствует (нет ложной сработки «no ARC»)
#    -fno-stack-protector  → VULN-2: нет stack-canary
#    PIE/NX — дефолты clang, оставлены намеренно (отсутствует ТОЛЬКО canary).
xcrun --sdk iphoneos clang -arch arm64 -mios-version-min=14.0 -isysroot "$SDK" \
  -fobjc-arc -fno-stack-protector -O0 \
  -framework Foundation -framework Security \
  "$HERE/main.m" -o "$BIN"

strip "$BIN"   # убрать debug/local-символы; секреты в __TEXT,__cstring переживают strip

# 2) Сборка .app-бандла
cp "$HERE/Info.plist"       "$APP/Info.plist"
cp "$HERE/Package.resolved" "$APP/Package.resolved"   # VULN-3: файл зависимостей в бандле
cp "$HERE/build.sh"         "$APP/build.sh"            # VULN-4: build-скрипт в бандле
chmod 0755 "$APP/build.sh"

# 3) Ad-hoc подпись (без entitlements → нет get-task-allow; без provisioning)
codesign -f -s - "$APP"

# 4) Упаковка в .ipa
( cd "$HERE" && zip -r -q "$APPNAME.ipa" Payload )
echo "built: $HERE/$APPNAME.ipa"
