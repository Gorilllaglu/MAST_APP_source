# SecToolTarget — эталонный уязвимый iOS-таргет (.ipa) для проверки сработок MAST-инструмента

Намеренно уязвимое iOS-приложение, собранное как **device `.ipa`** (`arm64`, `platform = iphoneos`).
Содержит **ровно 5 заложенных дефектов** из ТЗ и **ничего лишнего** — чтобы проверить, что
инструмент срабатывает именно на них и не даёт посторонних находок.

- **Артефакт:** `SecToolTarget.ipa`
- **Bundle ID:** `com.appsec.sectooltarget` · **App:** `SecToolTarget` · **Версия:** 1.0 (1) · **min iOS:** 14.0
- **Подпись:** ad-hoc (`codesign -s -`), **без** entitlements и **без** provisioning profile (намеренно — чтобы не появилось `get-task-allow`/debuggable).
- **Сборка:** `sh make_ipa.sh` (воспроизводимо). Исходник: `src/main.m`.

## Структура пакета

```
SecToolTarget.ipa
└── Payload/
    └── SecToolTarget.app/
        ├── SecToolTarget          ← Mach-O arm64 (исполняемый файл)   [VULN-1, VULN-2, VULN-5]
        ├── Info.plist             ← минимальный, без секретов
        ├── Package.resolved       ← файл зависимостей в бандле         [VULN-3]
        ├── build.sh               ← build-скрипт в бандле              [VULN-4]
        └── _CodeSignature/CodeResources
```

## Сводка: уязвимость → расположение → строки-триггеры

| # | Уязвимость (ТЗ) | Где (внутри IPA) | На что реагирует инструмент |
|---|---|---|---|
| 1 | Чувствительная информация в исполняемом файле | `Payload/SecToolTarget.app/SecToolTarget`, секция `__TEXT,__cstring` | строки-секреты (см. ниже) в выводе `strings` |
| 2 | Нет защиты от переполнений (нет stack-canary) | тот же бинарь, символьная таблица | **отсутствие** `___stack_chk_guard` / `___stack_chk_fail` |
| 3 | Файл зависимостей в бандле | `Payload/SecToolTarget.app/Package.resolved` | наличие файла `Package.resolved` (SwiftPM lock) |
| 4 | Скрипт сборки в бандле | `Payload/SecToolTarget.app/build.sh` | наличие `*.sh` / build-скрипта в `.app` |
| 5 | Sensitive в KeyChain в открытом виде | бинарь: импорты Security + строка-значение | `SecItemAdd` + `kSecAttrAccessibleAlways` + `kSecValueData` |

---

## VULN-1 — Чувствительная информация в исполняемом файле

**Где:** `Payload/SecToolTarget.app/SecToolTarget` → секция `__TEXT,__cstring`.
**Источник:** `src/main.m`, массив `kHardcodedSecrets[]` (помечен `__attribute__((used))`, поэтому литералы гарантированно остаются в бинаре).

**Строки-триггеры (полные литералы в бинаре):**
```
API_KEY=sk_live_51PvulnTOOLtarget9aZ3bQ7c1dE5fG8hJ0kL2mN
AWS_ACCESS_KEY_ID=AKIAIOSFODNN7VULNTOOL
AWS_SECRET_ACCESS_KEY=wJalrXUtnFEMI/K7MDENG/bPxRfiCEYSECRETKEY
DB_PASSWORD=Sup3rS3cr3t!Prod#2024
PRIVATE_KEY=-----BEGIN RSA PRIVATE KEY-----MIIBVAIBADANBgkqhkiG9w0BAQEFAASCATEST-----END RSA PRIVATE KEY-----
```
Подходящие regex-маркеры: `sk_live_[0-9A-Za-z]+`, `AKIA[0-9A-Z]{12,}`, `AWS_SECRET_ACCESS_KEY=`, `(?i)db_password=`, `-----BEGIN [A-Z ]*PRIVATE KEY-----`.

**Проверка:**
```bash
strings -a Payload/SecToolTarget.app/SecToolTarget | grep -E "sk_live_|AKIA|AWS_SECRET|DB_PASSWORD|PRIVATE KEY"
```
**Фикс:** секреты не хранить в коде/бинаре; брать с сервера/Keychain в рантайме; ротация скомпрометированных ключей.

---

## VULN-2 — Приложение не использует функции защиты от переполнений (нет stack-canary)

**Где:** `Payload/SecToolTarget.app/SecToolTarget` (свойство бинаря).
**Как заложено:** компиляция с `-fno-stack-protector` → компилятор не вставляет stack-canary. PIE/NX/ARC при этом **оставлены в норме** специально, чтобы отсутствовал **только** canary.

**На что реагирует инструмент:** в бинаре **нет** символов `___stack_chk_guard` и `___stack_chk_fail` (в терминах MobSF — `stack_canary: has_canary = false`).

**Проверка:**
```bash
otool -Iv Payload/SecToolTarget.app/SecToolTarget | grep -i stack_chk   # → пусто = canary отсутствует
# для контраста, ДОЛЖНЫ присутствовать (не являются находкой):
otool -hv  Payload/SecToolTarget.app/SecToolTarget | grep -o PIE        # PIE есть
otool -Iv  Payload/SecToolTarget.app/SecToolTarget | grep objc_release  # ARC есть
```
**Фикс:** собирать со stack-protector (`-fstack-protector-strong`, в Xcode по умолчанию ВКЛ).

---

## VULN-3 — Файл с зависимостями проекта в bundle-приложения

**Где:** `Payload/SecToolTarget.app/Package.resolved` (lock-файл SwiftPM — фиксированные версии зависимостей).
**На что реагирует инструмент:** наличие в `.app` файла зависимостей. Имена-триггеры (эквиваленты): `Package.resolved`, `Podfile.lock`, `Podfile`, `Cartfile.resolved`, `Package.swift`. В этом таргете используется `Package.resolved`.

**Строки-триггеры внутри файла:** `"pins"`, `"remoteSourceControl"`, `github.com/Alamofire/Alamofire.git`, `github.com/jrendel/SwiftKeychainWrapper.git`.

**Проверка:**
```bash
unzip -l SecToolTarget.ipa | grep -E "Package.resolved|Podfile.lock|Cartfile"
```
**Фикс:** не включать lock/манифесты зависимостей в поставляемый бандл (исключать из Copy Bundle Resources).

---

## VULN-4 — Скрипт сборки в собранном пакете приложения

**Где:** `Payload/SecToolTarget.app/build.sh` (shell-скрипт стадии сборки/CI).
**На что реагирует инструмент:** наличие исполняемого скрипта (`*.sh`, shebang `#!/bin/sh`) внутри `.app`.

**Строки-триггеры внутри файла:** `#!/bin/sh`, `xcodebuild archive`, `xcodebuild -exportArchive`, `CODE_SIGN_IDENTITY`, `PROVISIONING_PROFILE_SPECIFIER`.

**Проверка:**
```bash
unzip -l SecToolTarget.ipa | grep -E "\.sh$"
unzip -p SecToolTarget.ipa Payload/SecToolTarget.app/build.sh | head -1   # → #!/bin/sh
```
**Фикс:** build/CI-скрипты не копировать в бандл; держать вне Copy Bundle Resources.

---

## VULN-5 — Хранение sensitive-информации в KeyChain в открытом виде

**Где:** `Payload/SecToolTarget.app/SecToolTarget`.
**Источник:** `src/main.m`, функция `storePlaintextSecretInKeychain()` — `SecItemAdd` кладёт значение **как есть** (без прикладного шифрования) с **слабым** классом доступности `kSecAttrAccessibleAlways` (нет гейта по паролю/биометрии; элемент попадает в iCloud Keychain / резервную копию). Описание риска полностью соответствует ТЗ: значение в Keychain извлекаемо при доступе к устройству/облачной копии.

**На что реагирует инструмент (импортируемые символы + значение):**
```
_SecItemAdd
_kSecValueData
_kSecAttrAccessible
_kSecAttrAccessibleAlways          ← слабый класс доступности (а не ...ThisDeviceOnly / ...WhenPasscodeSet)
_kSecClassGenericPassword
```
плюс строка-значение в бинаре:
```
session_token=eyJhbGciOiJIUzI1NiJ9.eyJ1IjoicHJvZCJ9.PLAINTEXT_SECRET_DO_NOT_SHIP
```

**Проверка:**
```bash
nm -u Payload/SecToolTarget.app/SecToolTarget | grep -E "SecItemAdd|kSecValueData|kSecAttrAccessible"
strings -a Payload/SecToolTarget.app/SecToolTarget | grep "session_token="
```
**Фикс:** не хранить секрет в открытом виде; класс доступности `kSecAttrAccessibleWhenUnlockedThisDeviceOnly` (или `…WhenPasscodeSetThisDeviceOnly`), `kSecAttrSynchronizable = false`, привязка к Secure Enclave / `SecAccessControl` (biometryCurrentSet); чувствительные данные шифровать ключом из Keychain/Enclave.

---

## Чего в таргете НЕТ (контроль «ничего лишнего»)

Сознательно не заложено, чтобы исключить посторонние сработки:

- **PIE, NX, ARC — присутствуют** (норма) → не должно быть находок «no PIE / no NX / no ARC».
- **Символы вырезаны** (`strip`) → не должно быть «symbols not stripped».
- **`get-task-allow` / debuggable — нет** (ad-hoc подпись без entitlements, нет provisioning profile).
- **ATS не трогали** (ключа `NSAppTransportSecurity` нет → ATS включён по умолчанию) → нет «ATS misconfig / cleartext».
- **Нет URL-схем, WebView, deeplink, логирования, небезопасных libc-функций** (`printf/strcpy/memcpy/...` — отсутствуют в импортируемых символах).
- **Секретов в `Info.plist` нет** (пункт 1 — только в исполняемом файле, как требует ТЗ).

**Неустранимые артефакты (вне 5 проверяемых пунктов):**
- `cryptid = 0` («not encrypted») — у любого не-App-Store `.ipa` это неизбежно (FairPlay даёт только App Store). Если инструмент это метит — трактовать как фоновый артефакт сборки, не как одну из 5 целевых находок.
- Подпись **ad-hoc** (не distribution-сертификат) — следствие сборки без аккаунта; на 5 целевых проверок не влияет.

## Пересборка

```bash
sh make_ipa.sh        # → SecToolTarget.ipa
```
Требуется: macOS + Xcode (CLT) с iPhoneOS SDK. Скрипт компилирует `src/main.m` (`-fobjc-arc -fno-stack-protector`), strip-ает, собирает `.app`, кладёт `Package.resolved` + `build.sh`, ad-hoc-подписывает и пакует в `.ipa`.

## Карта файлов проекта

```
iOS-VulnTarget/
├── README.md           ← этот файл
├── make_ipa.sh         ← воспроизводимый сборщик (НЕ попадает в бандл)
├── src/main.m          ← исходник: секреты (#1) + Keychain plaintext (#5); сборка без canary (#2)
├── Info.plist          ← кладётся в .app
├── Package.resolved    ← кладётся в .app  (#3)
├── build.sh            ← кладётся в .app  (#4)
├── Payload/            ← выход сборки (.app)
└── SecToolTarget.ipa   ← готовый артефакт для прогона инструментом
```
