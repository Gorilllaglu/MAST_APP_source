#pragma once

// VULN-IPA-02 (C++): чувствительная информация в user-preferences.
//
// NSUserDefaults — Objective-C класс, на чистом C++ недоступен. Его
// C-уровневый эквивалент — CFPreferences (CoreFoundation): пишет в ТОТ ЖЕ
// незашифрованный plist ~/Library/Preferences/<bundle>.plist. Поэтому
// уязвимая логика — чистый C++ (этот файл + .cpp), UI — ObjC++.
namespace UserDefaultsOps {
void runAll();
}
