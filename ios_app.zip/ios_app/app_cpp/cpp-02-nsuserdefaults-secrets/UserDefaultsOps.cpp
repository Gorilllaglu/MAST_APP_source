#include "UserDefaultsOps.hpp"

#include <CoreFoundation/CoreFoundation.h>

namespace UserDefaultsOps {

void runAll() {
    // CFPreferencesSetAppValue с kCFPreferencesCurrentApplication пишет в
    // стандартный домен приложения — тот же plist, что и NSUserDefaults.standard.
    // Каждый вызов — отдельный sink; ключи очевидные для grep-сканера.
    CFPreferencesSetAppValue(CFSTR("auth_token"),
                             CFSTR("eyJhbGciOiJIUzI1NiJ9.userdefaults.fake"),
                             kCFPreferencesCurrentApplication);  // <-- VULN sink
    CFPreferencesSetAppValue(CFSTR("user_password"),
                             CFSTR("hunter2-prod"),
                             kCFPreferencesCurrentApplication);  // <-- VULN sink
    CFPreferencesSetAppValue(CFSTR("google_api_key"),
                             CFSTR("AIzaSyA_INTENTIONALLY_FAKE_FOR_TESTING"),
                             kCFPreferencesCurrentApplication);  // <-- VULN sink
    CFPreferencesSetAppValue(CFSTR("unlock_pin"),
                             CFSTR("1234"),
                             kCFPreferencesCurrentApplication);  // <-- VULN sink

    // Дополнительно — словарь с creditCard данными.
    const void *keys[] = {CFSTR("pan"), CFSTR("cvv"), CFSTR("exp")};
    const void *vals[] = {CFSTR("4242424242424242"), CFSTR("123"), CFSTR("12/29")};
    CFDictionaryRef card = CFDictionaryCreate(
        nullptr, keys, vals, 3, &kCFTypeDictionaryKeyCallBacks, &kCFTypeDictionaryValueCallBacks);
    CFPreferencesSetAppValue(CFSTR("saved_card"), card,
                             kCFPreferencesCurrentApplication);  // <-- VULN sink
    CFRelease(card);

    // Принудительный flush на диск (аналог deprecated -[NSUserDefaults synchronize]).
    CFPreferencesAppSynchronize(kCFPreferencesCurrentApplication);
}

}  // namespace UserDefaultsOps
