# CPP-02 (C++) — Чувствительная информация в user-preferences

C++ аналог Swift-приложения
[`app_swift/ipa-02-nsuserdefaults-secrets`](../../app_swift/ipa-02-nsuserdefaults-secrets).

## Архитектура «C++ iOS-апп»

- **Уязвимая логика — чистый C++** ([UserDefaultsOps.hpp](UserDefaultsOps.hpp) +
  [UserDefaultsOps.cpp](UserDefaultsOps.cpp)): `NSUserDefaults` — это
  Objective-C класс, недоступный из C++. Его **C-уровневый эквивалент —
  `CFPreferences`** (CoreFoundation), который пишет в **тот же
  незашифрованный plist** `~/Library/Preferences/<bundle>.plist`.
- **UI-оболочка — ObjC++** (`AppDelegate.mm`/`ViewController.mm`).

## Что заложено (идентично Swift/ObjC версиям)

`CFPreferencesSetAppValue(key, value, kCFPreferencesCurrentApplication)` ×5:

| Ключ | Класс данных | Категория |
|---|---|---|
| `auth_token` | bearer / JWT | R075 |
| `user_password` | password | R075 |
| `google_api_key` | API key | R075 + R030 |
| `unlock_pin` | PIN | R075 |
| `saved_card` | PII карты (CFDictionary) | R075 |

+ `CFPreferencesAppSynchronize` (аналог `-[NSUserDefaults synchronize]`).
Литералы → в Mach-O `__TEXT,__cstring`.

## Раскладка файлов

```
cpp-02-nsuserdefaults-secrets/   (C++)
├── README.md
├── Info.plist
├── UserDefaultsOps.hpp
├── UserDefaultsOps.cpp   ← sink'и: CFPreferencesSetAppValue (чистый C++)
├── ViewController.mm     ← ObjC++ UI
└── AppDelegate.mm        ← ObjC++ bootstrap + main()
```

## C++ ↔ Swift/ObjC

- **Sink меняет API:** `CFPreferencesSetAppValue` вместо
  `-[NSUserDefaults setObject:forKey:]` — но пишет в тот же plist, тот же
  класс утечки. Хороший сканер должен ловить **оба** API.
- `CFPreferencesSetAppValue` — C-функция; в безымянном/strip-нутом C++ нет
  ObjC-метаданных → `class-dump` пуст, реверс через символ импорта
  `_CFPreferencesSetAppValue` + строковые ключи.

## Форма

Src-снапшот без `.xcodeproj`. Линковать `CoreFoundation.framework` + UIKit.
