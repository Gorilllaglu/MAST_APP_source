#!/bin/sh
# Xcode build-phase / CI build script.
# НЕ должен попадать внутрь .app — здесь он включён намеренно (заложенный дефект №4).
set -eu

SCHEME="SecToolTarget"
CONFIG="Release"
SDK="iphoneos"
ARCHIVE="build/${SCHEME}.xcarchive"

echo "[build] clean…"
xcodebuild clean -scheme "$SCHEME" -configuration "$CONFIG"

echo "[build] archive…"
xcodebuild archive \
  -scheme "$SCHEME" \
  -configuration "$CONFIG" \
  -sdk "$SDK" \
  -archivePath "$ARCHIVE" \
  CODE_SIGN_IDENTITY="iPhone Distribution" \
  PROVISIONING_PROFILE_SPECIFIER="SecToolTarget-Dist"

echo "[build] export .ipa…"
xcodebuild -exportArchive \
  -archivePath "$ARCHIVE" \
  -exportOptionsPlist "ExportOptions.plist" \
  -exportPath "build/ipa"

echo "[build] done."
