//
//  main.cpp
//  SecToolTarget (C++) — намеренно уязвимый iOS-таргет для проверки сработок
//  MAST-инструмента. Ровно 5 заложенных дефектов (см. README.md).
//
//  Этот таргет НЕ использует UIKit (минимальный main()-бинарь), поэтому в
//  отличие от cpp-01/02/05 здесь не нужна ObjC++ оболочка — весь код на
//  ЧИСТОМ C++ через C-API CoreFoundation + Security. ObjC/ARC не задействованы.
//

#include <CoreFoundation/CoreFoundation.h>
#include <Security/Security.h>
#include <cstring>

// ===== [VULN-1] Чувствительная информация в исполняемом файле =====
// C-строковые литералы → секция __TEXT,__cstring → видны в `strings`.
// __attribute__((used)) удерживает их в бинаре даже без рантайм-использования.
__attribute__((used)) static const char *const kHardcodedSecrets[] = {
    "API_KEY=sk_live_51PvulnTOOLtarget9aZ3bQ7c1dE5fG8hJ0kL2mN",       // Stripe-style secret key
    "AWS_ACCESS_KEY_ID=AKIAIOSFODNN7VULNTOOL",                        // AWS access key id
    "AWS_SECRET_ACCESS_KEY=wJalrXUtnFEMI/K7MDENG/bPxRfiCEYSECRETKEY", // AWS secret access key
    "DB_PASSWORD=Sup3rS3cr3t!Prod#2024",                              // database password
    "PRIVATE_KEY=-----BEGIN RSA PRIVATE KEY-----MIIBVAIBADANBgkqhkiG9w0BAQEFAASCATEST-----END RSA PRIVATE KEY-----",
};

// ===== [VULN-5] Хранение sensitive-данных в KeyChain в открытом виде =====
static void storePlaintextSecretInKeychain() {
    // Значение кладётся как есть, со «слабым» классом доступности
    // kSecAttrAccessibleAlways (нет гейта по паролю/биометрии; элемент
    // попадает в iCloud Keychain / резервную копию). Keychain — C API
    // Security.framework, поэтому всё на чистом C++.
    const char *sessionToken =
        "session_token=eyJhbGciOiJIUzI1NiJ9.eyJ1IjoicHJvZCJ9.PLAINTEXT_SECRET_DO_NOT_SHIP";

    CFDataRef value = CFDataCreate(nullptr,
                                   reinterpret_cast<const UInt8 *>(sessionToken),
                                   static_cast<CFIndex>(std::strlen(sessionToken)));

    CFMutableDictionaryRef item = CFDictionaryCreateMutable(
        nullptr, 0, &kCFTypeDictionaryKeyCallBacks, &kCFTypeDictionaryValueCallBacks);
    CFDictionarySetValue(item, kSecClass, kSecClassGenericPassword);
    CFDictionarySetValue(item, kSecAttrService, CFSTR("com.appsec.sectooltarget.credentials"));
    CFDictionarySetValue(item, kSecAttrAccount, CFSTR("prod_user"));
    CFDictionarySetValue(item, kSecValueData, value);
    CFDictionarySetValue(item, kSecAttrAccessible, kSecAttrAccessibleAlways);   // <-- VULN sink

    SecItemDelete(item);
    SecItemAdd(item, nullptr);                                                  // <-- VULN sink

    CFRelease(item);
    CFRelease(value);
}

int main(int argc, char *argv[]) {
    (void)argc;
    (void)argv;
    storePlaintextSecretInKeychain();
    return 0;
}
