# CPP-SecToolTarget (C++) — эталонный уязвимый iOS-таргет

C++ версия SecToolTarget — минимального device-`.ipa` с **ровно 5 заложенными
дефектами**. Источник — [`iOS-VulnTarget`](../../../iOS-VulnTarget) (`src/main.m`,
ObjC); здесь логика переписана на **чистый C++**.

## Архитектура

В отличие от cpp-01/02/05 здесь **нет UIKit** (минимальный `main()`-бинарь),
поэтому **ObjC++ оболочка не нужна** — весь код на чистом C++:
- секреты — C-массив строк;
- Keychain — C API Security.framework (`SecItemAdd`) + CoreFoundation
  (`CFDictionary`, `CFData`).

Objective-C/ARC не задействованы вообще.

## 5 заложенных дефектов

| # | Уязвимость | Где | Триггер |
|---|---|---|---|
| 1 | Секреты в исполняемом файле | [main.cpp](main.cpp) `kHardcodedSecrets[]` | строки `sk_live_…`/`AKIA…`/`AWS_SECRET…`/`DB_PASSWORD=`/`BEGIN … PRIVATE KEY` в `strings` |
| 2 | Нет stack-canary | [make_ipa.sh](make_ipa.sh) `-fno-stack-protector` | отсутствие `___stack_chk_guard/_fail` |
| 3 | Файл зависимостей в бандле | [Package.resolved](Package.resolved) | SwiftPM lock в `.app` |
| 4 | Build-скрипт в бандле | [build.sh](build.sh) | `*.sh` в `.app` |
| 5 | Keychain plaintext | [main.cpp](main.cpp) `storePlaintextSecretInKeychain()` | `SecItemAdd` + `kSecAttrAccessibleAlways` + `kSecValueData` |

## Раскладка файлов

```
cpp-sectooltarget/   (C++)
├── README.md
├── main.cpp            ← VULN-1 (секреты) + VULN-5 (Keychain plaintext), чистый C++
├── make_ipa.sh         ← VULN-2 (-fno-stack-protector); clang++; собирает .ipa
├── Info.plist          ← кладётся в .app
├── Package.resolved    ← кладётся в .app  (VULN-3)
└── build.sh            ← кладётся в .app  (VULN-4)
```

## C++ ↔ ObjC: что меняется для анализа

- **Sink тот же** (`SecItemAdd` + `kSecAttrAccessibleAlways`), но построен на
  `CFDictionaryCreateMutable`/`CFDictionarySetValue` вместо `NSDictionary`.
- **Нет ObjC-метаданных и ARC.** Бинарь чисто C++/C → `class-dump` пуст;
  реверс через символы импортов (`_SecItemAdd`, `_kSecAttrAccessibleAlways`) +
  `strings`.

## Важно про артефакт «no ARC»

ARC — фича Objective-C; в чисто C++-бинаре её нет **by design**, поэтому
символов `_objc_release`/`_objc_retainAutoreleasedReturnValue` не будет и
сканер может пометить «no ARC». Это **языковой артефакт C++-таргета, а не
один из 5 заложенных дефектов** — трактовать как фоновый сигнал (в ObjC-версии
ARC намеренно оставлен в норме, чтобы этой сработки не было).

## Сборка

```bash
sh make_ipa.sh   # → SecToolTarget.ipa  (нужен macOS + Xcode CLT, iPhoneOS SDK)
```
