#include "KeychainOps.hpp"

#include <CoreFoundation/CoreFoundation.h>
#include <Security/Security.h>
#include <cstring>

namespace {

// Hardcoded literals — попадают в Mach-O (__TEXT,__cstring) как plaintext.
const char *kService      = "com.masttest.stingapp";
const char *kAuthToken    = "eyJhbGciOiJIUzI1NiJ9.fake.fake";
const char *kApiPassword  = "P@ssw0rd-2024";
const char *kSessionToken = "sess_live_4eC39HqLyjWDarjtT1zdp7dc";

// Строит базовый query-словарь { class, service, account, value } для
// generic password. Вызывающий добавляет accessibility/synchronizable.
CFMutableDictionaryRef makeBaseQuery(CFStringRef account, const char *secret) {
    CFStringRef service = CFStringCreateWithCString(nullptr, kService, kCFStringEncodingUTF8);
    CFDataRef value =
        CFDataCreate(nullptr, reinterpret_cast<const UInt8 *>(secret),
                     static_cast<CFIndex>(std::strlen(secret)));

    CFMutableDictionaryRef q = CFDictionaryCreateMutable(
        nullptr, 0, &kCFTypeDictionaryKeyCallBacks, &kCFTypeDictionaryValueCallBacks);
    CFDictionarySetValue(q, kSecClass, kSecClassGenericPassword);
    CFDictionarySetValue(q, kSecAttrService, service);
    CFDictionarySetValue(q, kSecAttrAccount, account);
    CFDictionarySetValue(q, kSecValueData, value);

    CFRelease(service);
    CFRelease(value);
    return q;
}

// Худшая категория: kSecAttrAccessibleAlways — токен читается даже когда
// устройство залочено.
OSStatus saveTokenAccessibleAlways() {
    CFMutableDictionaryRef q = makeBaseQuery(CFSTR("auth_token"), kAuthToken);
    CFDictionarySetValue(q, kSecAttrAccessible, kSecAttrAccessibleAlways);  // <-- VULN sink
    SecItemDelete(q);
    OSStatus st = SecItemAdd(q, nullptr);
    CFRelease(q);
    return st;
}

// kSecAttrAccessibleAfterFirstUnlock без kSecAttrAccessControl —
// фоновый доступ после первой разблокировки, без user-presence.
OSStatus savePasswordAfterFirstUnlock() {
    CFMutableDictionaryRef q = makeBaseQuery(CFSTR("api_password"), kApiPassword);
    CFDictionarySetValue(q, kSecAttrAccessible, kSecAttrAccessibleAfterFirstUnlock);  // <-- VULN sink
    SecItemDelete(q);
    OSStatus st = SecItemAdd(q, nullptr);
    CFRelease(q);
    return st;
}

// kSecAttrSynchronizable = true → токен уезжает в iCloud Keychain.
OSStatus saveSessionSynced() {
    CFMutableDictionaryRef q = makeBaseQuery(CFSTR("session_token"), kSessionToken);
    CFDictionarySetValue(q, kSecAttrAccessible, kSecAttrAccessibleWhenUnlocked);
    CFDictionarySetValue(q, kSecAttrSynchronizable, kCFBooleanTrue);  // <-- VULN sink
    SecItemDelete(q);
    OSStatus st = SecItemAdd(q, nullptr);
    CFRelease(q);
    return st;
}

}  // namespace

namespace KeychainOps {

void runAll() {
    saveTokenAccessibleAlways();
    savePasswordAfterFirstUnlock();
    saveSessionSynced();
}

}  // namespace KeychainOps
