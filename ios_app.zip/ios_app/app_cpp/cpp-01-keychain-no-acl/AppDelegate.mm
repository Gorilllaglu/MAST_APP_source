// ObjC++ оболочка приложения. Вся уязвимая логика — в чистом C++
// (KeychainOps.cpp); здесь только bootstrap UIKit + вызов C++.
#import <UIKit/UIKit.h>

#include "KeychainOps.hpp"

@interface ViewController : UIViewController
@end

@interface AppDelegate : UIResponder <UIApplicationDelegate>
@property (strong, nonatomic) UIWindow *window;
@end

@implementation AppDelegate

- (BOOL)application:(UIApplication *)application
    didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    self.window = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
    self.window.rootViewController = [ViewController new];
    [self.window makeKeyAndVisible];
    // Заложенные уязвимости — на чистом C++ (Security C API).
    KeychainOps::runAll();
    return YES;
}

@end

int main(int argc, char *argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
