#pragma once

// VULN-IPA-01 (C++): Keychain item записан с самым слабым access-control'ом.
//
// Keychain — это Security.framework, у которого C API (SecItemAdd,
// kSecClass*, kSecAttrAccessible*). Поэтому вся уязвимая логика —
// чистый C++ (этот файл + KeychainOps.cpp), без Objective-C. UI-оболочка
// (AppDelegate.mm/ViewController.mm) — Objective-C++, т.к. UIKit на чистом
// C++ недоступен.
namespace KeychainOps {
// Записывает три Keychain-item'а со слабыми атрибутами доступности.
void runAll();
}
