# IPA-01 (C++) — Keychain item без access control

C++ аналог Swift-приложения
[`app_swift/ipa-01-keychain-no-acl`](../../app_swift/ipa-01-keychain-no-acl).
Та же уязвимость и те же sink'и — но логика на **чистом C++**.

## Архитектура «C++ iOS-апп»

Чистый C++ не умеет UIKit (это Objective-C фреймворк), поэтому:

- **Уязвимая логика — чистый C++** ([KeychainOps.hpp](KeychainOps.hpp) +
  [KeychainOps.cpp](KeychainOps.cpp)): Keychain пишется через C API
  Security.framework (`SecItemAdd`, `kSecClass*`, `kSecAttrAccessible*`) и
  CoreFoundation (`CFDictionary`, `CFData`). Никакого Objective-C.
- **UI-оболочка — Objective-C++** (`.mm`): минимальный
  `AppDelegate`/`ViewController` поднимают UIKit и вызывают `KeychainOps::runAll()`.

## Что заложено (идентично Swift/ObjC версиям)

| Запись | Атрибут | Sink (C++) |
|---|---|---|
| `auth_token` | `kSecAttrAccessibleAlways` | `SecItemAdd` + `CFDictionarySetValue(q, kSecAttrAccessible, kSecAttrAccessibleAlways)` (R151) |
| `api_password` | `kSecAttrAccessibleAfterFirstUnlock` без access-control | `SecItemAdd` (R151) |
| `session_token` | `kSecAttrSynchronizable = kCFBooleanTrue` | `SecItemAdd` (R151 / R031) |

Hardcoded-литералы (`const char* kAuthToken`/`kApiPassword`/`kSessionToken`) →
в Mach-O `__TEXT,__cstring`, видны `strings`.

## Раскладка файлов

```
cpp-01-keychain-no-acl/   (C++)
├── README.md
├── Info.plist            ← идентичен Swift-версии
├── KeychainOps.hpp       ← интерфейс C++
├── KeychainOps.cpp       ← sink'и: SecItemAdd + kSecAttrAccessible* (чистый C++)
├── ViewController.mm     ← ObjC++ UI
└── AppDelegate.mm        ← ObjC++ bootstrap + main(); зовёт KeychainOps::runAll()
```

## C++ ↔ Swift/ObjC: что меняется для анализа

- **Sink тот же** (`SecItemAdd` + слабый `kSecAttrAccessible`), но в C++ он
  построен на CoreFoundation (`CFDictionaryCreateMutable` + `CFDictionarySetValue`)
  вместо `NSDictionary`-литерала.
- **Меньше метаданных.** C++-функции (`saveTokenAccessibleAlways` и т.д.)
  лежат в безымянном namespace и `strip`-аются/манглятся — `class-dump` их
  НЕ покажет (в отличие от ObjC-версии). Реверс — через символы импортов
  (`_SecItemAdd`, `_kSecAttrAccessibleAlways`) + xref в Ghidra/IDA. Это
  ближе к «нативному» C/C++-таргету (как `SecToolTarget`/`main.m`).

## Форма

Src-снапшот: `.hpp/.cpp/.mm` + `Info.plist`, без `.xcodeproj`. Для сборки —
xcodegen/Xcode-таргет; компилировать `.mm` как Objective-C++, `.cpp` как C++,
линковать `Security.framework` + `CoreFoundation.framework` + `UIKit.framework`.
