#pragma once

// VULN-IPA-05 (C++): HTTP-запрос с bearer-токеном.
//
// NSURLSession — Objective-C; его C-уровневый аналог — CFNetwork
// (CFHTTPMessage + CFReadStream). Поэтому сетевая логика — чистый C++.
// Работает в паре с ослаблениями ATS в Info.plist (он копируется 1:1
// со Swift-версии).
namespace NetworkOps {
void fetchInsecure();
}
