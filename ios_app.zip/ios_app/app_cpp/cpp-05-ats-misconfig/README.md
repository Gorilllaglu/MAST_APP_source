# CPP-05 (C++) — Небезопасная конфигурация ATS

C++ аналог Swift-приложения
[`app_swift/ipa-05-ats-misconfig`](../../app_swift/ipa-05-ats-misconfig).
Двойной сигнал: **манифест** (Info.plist) **+ код** (реальный HTTP на C++).

## Архитектура «C++ iOS-апп»

- **Сетевая логика — чистый C++** ([NetworkOps.hpp](NetworkOps.hpp) +
  [NetworkOps.cpp](NetworkOps.cpp)): `NSURLSession` — Objective-C; его
  C-уровневый аналог — **CFNetwork** (`CFHTTPMessageCreateRequest`,
  `CFReadStreamCreateForHTTPRequest`).
- **UI-оболочка — ObjC++** (`AppDelegate.mm`/`ViewController.mm`).

## Что заложено (идентично Swift/ObjC версиям)

**Info.plist** (скопирован 1:1) — `NSAppTransportSecurity` с максимальным
набором ослаблений (R012): `NSAllowsArbitraryLoads`, `…ForMedia`,
`…InWebContent`, `NSAllowsLocalNetworking`, + `NSExceptionDomains` для
`insecure.example.com` (insecure HTTP, TLSv1.0, no forward secrecy).

**Код** — CFNetwork-запрос:
| Sink (C++) | Что |
|---|---|
| `CFURLCreateWithString(… CFSTR("http://insecure.example.com/..."))` | cleartext HTTP (R092) |
| `CFHTTPMessageSetHeaderFieldValue(req, "Authorization", "Bearer …")` | токен в HTTP (R087) |
| `CFReadStreamCreateForHTTPRequest` | выполнение запроса |

## Раскладка файлов

```
cpp-05-ats-misconfig/   (C++)
├── README.md
├── Info.plist          ← VULN: NSAppTransportSecurity ослаблен (R012)
├── NetworkOps.hpp
├── NetworkOps.cpp      ← sink'и: CFNetwork + http:// + Authorization (чистый C++)
├── ViewController.mm   ← ObjC++ UI
└── AppDelegate.mm      ← ObjC++ bootstrap + main()
```

## C++ ↔ Swift/ObjC

- **Манифест-часть идентична** (тот же Info.plist) — language-agnostic.
- **Код-часть:** CFNetwork (C API) вместо NSURLSession — `http://`-литерал
  и Bearer-токен в `__TEXT,__cstring`; реверс через символы импортов
  CFNetwork + строки. ObjC-метаданных у C++-части нет.

## Форма

Src-снапшот без `.xcodeproj`. Линковать `CFNetwork.framework` +
`CoreFoundation.framework` + UIKit.
