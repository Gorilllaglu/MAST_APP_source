#include "NetworkOps.hpp"

#include <CFNetwork/CFNetwork.h>
#include <CoreFoundation/CoreFoundation.h>

namespace NetworkOps {

void fetchInsecure() {
    // <-- VULN: http:// (а не https). Использует ATS-послабление из Info.plist.
    CFURLRef url = CFURLCreateWithString(
        nullptr, CFSTR("http://insecure.example.com/v1/profile"), nullptr);
    if (url == nullptr) {
        return;
    }
    CFHTTPMessageRef req =
        CFHTTPMessageCreateRequest(nullptr, CFSTR("GET"), url, kCFHTTPVersion1_1);
    // <-- VULN: bearer-токен в HTTP-запросе.
    CFHTTPMessageSetHeaderFieldValue(req, CFSTR("Authorization"),
                                     CFSTR("Bearer eyJhbGciOiJIUzI1NiJ9.fake.fake"));

    CFReadStreamRef stream = CFReadStreamCreateForHTTPRequest(nullptr, req);
    CFReadStreamOpen(stream);
    // намеренно ничего не читаем из ответа
    CFReadStreamClose(stream);

    CFRelease(stream);
    CFRelease(req);
    CFRelease(url);
}

}  // namespace NetworkOps
