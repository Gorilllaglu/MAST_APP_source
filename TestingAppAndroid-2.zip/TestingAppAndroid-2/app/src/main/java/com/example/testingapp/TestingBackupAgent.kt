package com.example.testingapp

import android.app.backup.BackupAgent
import android.app.backup.BackupDataInput
import android.app.backup.BackupDataOutput
import android.app.backup.FullBackupDataOutput
import android.os.ParcelFileDescriptor
import android.util.Log

/**
 * Testing Backup Agent - Configured for full backup (insecure)
 * M9: Insecure Data Storage - MSTG-STORAGE-8
 */
class TestingBackupAgent : BackupAgent() {

    companion object {
        private const val TAG = "TestingBackupAgent"
    }

    override fun onCreate() {
        super.onCreate()
        Log.d(TAG, "Backup agent created")
    }

    override fun onBackup(
        oldState: ParcelFileDescriptor?,
        data: BackupDataOutput,
        newState: ParcelFileDescriptor
    ) {
        Log.d(TAG, "Performing backup")
        
        // Backing up all application data including sensitive information
        backupSharedPreferences(data)
        backupDatabase(data)
        backupFiles(data)
    }

    override fun onRestore(
        data: BackupDataInput,
        appVersionCode: Int,
        newState: ParcelFileDescriptor
    ) {
        Log.d(TAG, "Performing restore")
        
        // Restoring data without integrity verification
        while (data.readNextHeader()) {
            val key = data.key
            Log.d(TAG, "Restoring key: $key")
            
            // Reading and restoring data
            val dataSize = data.dataSize()
            val buffer = ByteArray(dataSize)
            data.readEntityData(buffer, 0, dataSize)
            
            Log.d(TAG, "Restored ${buffer.size} bytes for key: $key")
            data.skipEntityPadding()
        }
    }

    override fun onFullBackup(data: FullBackupDataOutput) {
        Log.d(TAG, "Performing full backup")
        
        // Full backup includes all app data - vulnerability
        super.onFullBackup(data)
    }

    private fun backupSharedPreferences(data: BackupDataOutput) {
        Log.d(TAG, "Backing up SharedPreferences")
        
        // This backs up all shared preferences including credentials
        val prefs = listOf(
            "app_data",
            "credentials",
            "app_settings"
        )
        
        prefs.forEach { prefName ->
            Log.d(TAG, "Backing up preference: $prefName")
        }
    }

    private fun backupDatabase(data: BackupDataOutput) {
        Log.d(TAG, "Backing up databases")
        
        // Backing up all databases
        context?.databaseList()?.forEach { dbName ->
            Log.d(TAG, "Backing up database: $dbName")
        }
    }

    private fun backupFiles(data: BackupDataOutput) {
        Log.d(TAG, "Backing up files")
        
        // Backing up all files including potentially sensitive ones
        context?.filesDir?.listFiles()?.forEach { file ->
            Log.d(TAG, "Backing up file: ${file.name}")
        }
    }
}
