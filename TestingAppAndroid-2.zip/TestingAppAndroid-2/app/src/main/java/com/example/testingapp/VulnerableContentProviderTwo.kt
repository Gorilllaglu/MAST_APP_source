package com.example.testingapp

import android.content.ContentProvider
import android.content.ContentValues
import android.database.Cursor
import android.database.MatrixCursor
import android.net.Uri
import android.util.Log
import java.io.File

/**
 * Vulnerable Content Provider Two - Exported with grantUriPermissions
 * M9: Insecure Data Storage / M8: Security Misconfiguration - MSTG-PLATFORM-4
 */
class VulnerableContentProviderTwo : ContentProvider() {

    companion object {
        private const val TAG = "VulnerableCPTwo"
        const val AUTHORITY = "com.example.testingapp.vulnerable.provider.two"
    }

    override fun onCreate(): Boolean {
        Log.d(TAG, "Content Provider Two created")
        return true
    }

    override fun query(
        uri: Uri,
        projection: Array<String>?,
        selection: String?,
        selectionArgs: Array<String>?,
        sortOrder: String?
    ): Cursor? {
        Log.d(TAG, "Query received for URI: $uri")
        
        // Exposing file paths through content provider
        val cursor = MatrixCursor(arrayOf("file_path", "file_name", "size"))
        
        // Listing sensitive files - vulnerability
        context?.filesDir?.listFiles()?.forEach { file ->
            cursor.addRow(arrayOf(file.absolutePath, file.name, file.length()))
        }
        
        // Also exposing cache directory
        context?.cacheDir?.listFiles()?.forEach { file ->
            cursor.addRow(arrayOf(file.absolutePath, file.name, file.length()))
        }
        
        return cursor
    }

    override fun getType(uri: Uri): String? {
        return "vnd.android.cursor.item/file"
    }

    override fun insert(uri: Uri, values: ContentValues?): Uri? {
        Log.d(TAG, "Insert received for URI: $uri")
        
        // Allowing arbitrary file writes
        val filePath = values?.getAsString("file_path")
        Log.d(TAG, "File path for insert: $filePath")
        
        return uri
    }

    override fun delete(uri: Uri, selection: String?, selectionArgs: Array<String>?): Int {
        Log.d(TAG, "Delete received for URI: $uri")
        
        // Allowing deletion of arbitrary files
        val pathSegments = uri.pathSegments
        if (pathSegments.isNotEmpty()) {
            val fileName = pathSegments.last()
            val file = File(context?.filesDir, fileName)
            if (file.exists()) {
                Log.d(TAG, "Would delete file: ${file.absolutePath}")
                // file.delete() - commented for safety
            }
        }
        
        return 0
    }

    override fun update(
        uri: Uri,
        values: ContentValues?,
        selection: String?,
        selectionArgs: Array<String>?
    ): Int {
        Log.d(TAG, "Update received for URI: $uri")
        return 0
    }

    override fun openFile(uri: Uri, mode: String): android.os.ParcelFileDescriptor? {
        // Allowing arbitrary file access - critical vulnerability
        Log.d(TAG, "Open file requested: $uri with mode: $mode")
        
        // This could allow access to any file in the app's directory
        return null
    }
}
