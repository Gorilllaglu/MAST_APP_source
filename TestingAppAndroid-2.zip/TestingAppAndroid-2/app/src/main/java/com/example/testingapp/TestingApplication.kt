package com.example.testingapp

import android.app.Application
import android.content.Context
import android.util.Log

/**
 * Application class for TestingAppAndroid-2
 * Contains intentionally vulnerable code for security testing purposes
 */
class TestingApplication : Application() {

    companion object {
        private const val TAG = "TestingApplication"
        
        // Hardcoded sensitive data - vulnerability for testing
        const val HARDCODED_API_KEY = "sk_test_1234567890abcdef"
        const val HARDCODED_SECRET = "super_secret_key_do_not_use_in_production"
        
        @Volatile
        private var instance: TestingApplication? = null
        
        fun getInstance(): TestingApplication {
            return instance ?: throw IllegalStateException("Application not initialized")
        }
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        Log.d(TAG, "Application created with debug mode enabled")
        
        // Insecure logging of sensitive data
        Log.d(TAG, "API Key loaded: $HARDCODED_API_KEY")
    }

    override fun attachBaseContext(base: Context) {
        super.attachBaseContext(base)
        // No additional security measures - intentional vulnerability
    }
}
