package com.example.testingapp

import android.app.IntentService
import android.content.Intent
import android.util.Log

/**
 * Vulnerable Service One - Exported without permission protection
 * M8: Security Misconfiguration - MSTG-PLATFORM-4
 */
class VulnerableServiceOne : IntentService("VulnerableServiceOne") {

    companion object {
        private const val TAG = "VulnerableServiceOne"
    }

    override fun onHandleIntent(intent: Intent?) {
        intent?.let {
            val command = it.getStringExtra("command")
            val data = it.getStringExtra("data")
            val action = it.getStringExtra("action")

            Log.d(TAG, "Service received command: $command")
            Log.d(TAG, "Service received data: $data")
            Log.d(TAG, "Service received action: $action")

            // Processing commands without validation
            when (command) {
                "delete_data" -> deleteDataInsecurely(data)
                "update_config" -> updateConfigInsecurely(data)
                "execute" -> executeCommandInsecurely(action)
                else -> Log.d(TAG, "Unknown command: $command")
            }
        }
    }

    private fun deleteDataInsecurely(data: String?) {
        // Insecure deletion without authorization
        Log.d(TAG, "Deleting data without authorization: $data")
    }

    private fun updateConfigInsecurely(data: String?) {
        // Updating configuration without validation
        Log.d(TAG, "Updating config without validation: $data")
    }

    private fun executeCommandInsecurely(action: String?) {
        // Executing arbitrary commands - critical vulnerability
        Log.d(TAG, "Executing command without validation: $action")
    }
}
