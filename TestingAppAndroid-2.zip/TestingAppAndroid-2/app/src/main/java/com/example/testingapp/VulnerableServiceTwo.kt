package com.example.testingapp

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat

/**
 * Vulnerable Service Two - Exported foreground service with location access
 * M8: Security Misconfiguration - MSTG-PLATFORM-4
 */
class VulnerableServiceTwo : Service(), LocationListener {

    companion object {
        private const val TAG = "VulnerableServiceTwo"
        private const val CHANNEL_ID = "vulnerable_channel"
        private const val NOTIFICATION_ID = 1
    }

    private var locationManager: LocationManager? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, createNotification())
        startLocationTracking()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        intent?.let {
            val interval = it.getLongExtra("location_interval", 5000L)
            Log.d(TAG, "Service started with interval: $interval")
            
            // No validation of interval parameter
            updateLocationInterval(interval)
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? {
        return null
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Vulnerable Channel",
                NotificationManager.IMPORTANCE_DEFAULT
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun createNotification(): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Vulnerable Service")
            .setContentText("Running in background")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .build()
    }

    private fun startLocationTracking() {
        locationManager = getSystemService(LocationManager::class.java)
        
        try {
            // Requesting location updates without proper permission checks
            locationManager?.requestLocationUpdates(
                LocationManager.GPS_PROVIDER,
                5000L,
                0f,
                this
            )
            Log.d(TAG, "Location tracking started")
        } catch (e: SecurityException) {
            Log.e(TAG, "Location permission denied: ${e.message}")
        }
    }

    private fun updateLocationInterval(interval: Long) {
        // Updating interval without validation
        Log.d(TAG, "Updating location interval to: $interval")
    }

    override fun onLocationChanged(location: Location) {
        // Logging location data insecurely
        Log.d(TAG, "Location updated: lat=${location.latitude}, lon=${location.longitude}")
        
        // Could send location to remote server without encryption
        sendLocationToServer(location.latitude, location.longitude)
    }

    private fun sendLocationToServer(latitude: Double, longitude: Double) {
        // Insecure transmission of location data
        Log.d(TAG, "Sending location to server: $latitude, $longitude")
    }

    override fun onDestroy() {
        super.onDestroy()
        locationManager?.removeUpdates(this)
        Log.d(TAG, "Service destroyed")
    }
}
