package com.example.testingapp

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.telephony.SmsMessage
import android.util.Log

/**
 * Vulnerable Broadcast Receiver Three - Exported SMS receiver
 * M8: Security Misconfiguration - MSTG-PLATFORM-4
 */
class VulnerableBroadcastReceiverThree : BroadcastReceiver() {

    companion object {
        private const val TAG = "VulnReceiverThree"
        private const val SMS_RECEIVED = "android.provider.Telephony.SMS_RECEIVED"
    }

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == SMS_RECEIVED) {
            val bundle = intent.extras
            if (bundle != null) {
                processSmsMessages(bundle)
            }
        }
    }

    private fun processSmsMessages(bundle: Bundle) {
        val pdus = bundle.get("pdus") as? Array<*>
        
        pdus?.forEach { pdu ->
            try {
                val smsMessage = SmsMessage.createFromPdu(pdu as ByteArray, bundle.getString("format"))
                val sender = smsMessage.displayOriginatingAddress
                val messageBody = smsMessage.messageBody
                
                Log.d(TAG, "SMS received from: $sender")
                Log.d(TAG, "SMS body: $messageBody")
                
                // Logging sensitive SMS content - vulnerability
                // Could be intercepting 2FA codes, passwords, etc.
                
                if (isSensitiveMessage(messageBody)) {
                    Log.w(TAG, "SENSITIVE SMS DETECTED from $sender")
                    storeSensitiveSms(sender, messageBody)
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error processing SMS: ${e.message}")
            }
        }
    }

    private fun isSensitiveMessage(message: String): Boolean {
        // Checking for patterns that might indicate sensitive messages
        val sensitivePatterns = listOf(
            "verification code",
            "OTP",
            "password",
            "confirm",
            "code:",
            "auth"
        )
        
        return sensitivePatterns.any { 
            message.lowercase().contains(it) 
        }
    }

    private fun storeSensitiveSms(sender: String, message: String) {
        // Storing intercepted SMS insecurely
        Log.d(TAG, "Storing sensitive SMS from $sender")
        
        // This is a vulnerability - storing intercepted messages
        val prefs = android.preference.PreferenceManager.getDefaultSharedPreferences(
            android.app.ApplicationProvider.getApplicationContext()
        )
        prefs.edit().apply {
            putString("last_sms_sender", sender)
            putString("last_sms_content", message)
            apply()
        }
    }
}
