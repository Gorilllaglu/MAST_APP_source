package com.example.testingapp

import android.content.Intent
import android.os.Binder
import android.os.IBinder
import android.util.Log

/**
 * Vulnerable Service Three - Exported bound service without protection
 * M8: Security Misconfiguration - MSTG-PLATFORM-4
 */
class VulnerableServiceThree : Service() {

    companion object {
        private const val TAG = "VulnerableServiceThree"
    }

    private val binder = LocalBinder()

    inner class LocalBinder : Binder() {
        fun getService(): VulnerableServiceThree = this@VulnerableServiceThree
    }

    override fun onBind(intent: Intent): IBinder {
        Log.d(TAG, "Service bound by: ${intent.component?.packageName ?: "unknown"}")
        return binder
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        intent?.let {
            val operation = it.getStringExtra("operation")
            val parameter = it.getStringExtra("parameter")
            
            Log.d(TAG, "Service operation requested: $operation")
            Log.d(TAG, "Service parameter: $parameter")
            
            // Executing operations without validation
            when (operation) {
                "get_data" -> getData(parameter)
                "set_data" -> setData(parameter)
                "execute_sql" -> executeSqlInsecurely(parameter)
                else -> Log.d(TAG, "Unknown operation: $operation")
            }
        }
        return START_NOT_STICKY
    }

    fun getData(key: String?): String {
        // Returning data without authorization check
        Log.d(TAG, "Getting data for key: $key")
        return "Data for $key"
    }

    fun setData(value: String?) {
        // Setting data without validation
        Log.d(TAG, "Setting data: $value")
    }

    private fun executeSqlInsecurely(sql: String?) {
        // Critical vulnerability - SQL injection
        Log.d(TAG, "Executing SQL without sanitization: $sql")
        // Example vulnerable code (commented):
        // database.execSQL(sql)
    }
}
