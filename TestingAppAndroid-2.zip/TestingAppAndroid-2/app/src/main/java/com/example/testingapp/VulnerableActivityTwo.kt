package com.example.testingapp

import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

/**
 * Vulnerable Activity Two - Exported with implicit intent and deep link
 * M8: Security Misconfiguration - MSTG-PLATFORM-4, MSTG-PLATFORM-2
 */
class VulnerableActivityTwo : AppCompatActivity() {

    companion object {
        private const val TAG = "VulnerableActivityTwo"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_vulnerable_two)

        // Handling deep link without proper validation
        val data: Uri? = intent.data
        Log.d(TAG, "Deep link received: $data")

        val tvDeepLink: TextView = findViewById(R.id.tvDeepLink)
        tvDeepLink.text = "Deep Link: ${data?.toString() ?: "None"}"

        // Extracting parameters from deep link without validation
        data?.let { uri ->
            val token = uri.getQueryParameter("token")
            val action = uri.getQueryParameter("action")
            
            Log.d(TAG, "Token from deep link: $token")
            Log.d(TAG, "Action from deep link: $action")
            
            // Insecure handling of deep link parameters
            processDeepLinkParams(token, action)
        }
    }

    private fun processDeepLinkParams(token: String?, action: String?) {
        // No validation of token or action - vulnerability
        if (token != null) {
            // Using token directly without verification
            Log.d(TAG, "Processing unverified token: $token")
        }
        
        if (action != null) {
            // Executing action without authorization check
            Log.d(TAG, "Executing unverified action: $action")
        }
    }
}
