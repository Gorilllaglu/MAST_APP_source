package com.example.testingapp

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.net.URL
import javax.net.ssl.HttpsURLConnection

/**
 * Main Activity - Entry point of the application
 * Contains intentionally vulnerable code for security testing
 */
class MainActivity : AppCompatActivity() {

    companion object {
        private const val TAG = "MainActivity"
        // Hardcoded credentials - vulnerability M9
        private const val HARDCODED_PASSWORD = "admin123"
        private const val API_ENDPOINT = "http://api.example.com/data"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        Log.d(TAG, "MainActivity created - Debug mode: ${applicationInfo.flags and android.content.pm.ApplicationInfo.FLAG_DEBUGGABLE != 0}")

        setupUI()
        performInsecureNetworkRequest()
    }

    private fun setupUI() {
        val btnOpenVulnerableActivity: Button = findViewById(R.id.btnOpenVulnerableActivity)
        val btnSendBroadcast: Button = findViewById(R.id.btnSendBroadcast)
        val btnStartService: Button = findViewById(R.id.btnStartService)
        val btnStoreData: Button = findViewById(R.id.btnStoreData)
        val etInput: EditText = findViewById(R.id.etInput)
        val tvOutput: TextView = findViewById(R.id.tvOutput)

        btnOpenVulnerableActivity.setOnClickListener {
            val intent = Intent(this, VulnerableActivityOne::class.java)
            intent.putExtra("sensitive_data", etInput.text.toString())
            startActivity(intent)
        }

        btnSendBroadcast.setOnClickListener {
            val broadcastIntent = Intent("com.example.testingapp.CUSTOM_BROADCAST")
            broadcastIntent.putExtra("data", etInput.text.toString())
            sendBroadcast(broadcastIntent)
            Toast.makeText(this, "Broadcast sent", Toast.LENGTH_SHORT).show()
        }

        btnStartService.setOnClickListener {
            val serviceIntent = Intent(this, VulnerableServiceOne::class.java)
            serviceIntent.putExtra("command", etInput.text.toString())
            startService(serviceIntent)
            Toast.makeText(this, "Service started", Toast.LENGTH_SHORT).show()
        }

        btnStoreData.setOnClickListener {
            val data = etInput.text.toString()
            storeDataInsecurely(data)
            tvOutput.text = "Data stored: $data"
        }
    }

    private fun storeDataInsecurely(data: String) {
        // Insecure storage - plaintext SharedPreferences
        val prefs = getSharedPreferences("app_data", MODE_WORLD_READABLE)
        prefs.edit().apply {
            putString("user_input", data)
            putString("password", HARDCODED_PASSWORD)
            apply()
        }
        Log.d(TAG, "Data stored insecurely: $data")
    }

    private fun performInsecureNetworkRequest() {
        Thread {
            try {
                // Insecure HTTP connection - no TLS
                val url = URL(API_ENDPOINT)
                val connection = url.openConnection() as HttpsURLConnection
                connection.requestMethod = "GET"
                
                // Weak TLS configuration - accepting all certificates
                connection.hostnameVerifier = { _, _ -> true }
                
                val responseCode = connection.responseCode
                Log.d(TAG, "Insecure request response: $responseCode")
            } catch (e: Exception) {
                Log.e(TAG, "Network error: ${e.message}")
            }
        }.start()
    }
}
