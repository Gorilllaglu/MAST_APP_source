package com.example.testingapp

import android.os.Bundle
import android.util.Log
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

/**
 * Vulnerable Activity One - Exported without proper protection
 * M8: Security Misconfiguration - MSTG-PLATFORM-4
 */
class VulnerableActivityOne : AppCompatActivity() {

    companion object {
        private const val TAG = "VulnerableActivityOne"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_vulnerable_one)

        // Receiving sensitive data via intent without validation
        val sensitiveData = intent.getStringExtra("sensitive_data")
        Log.d(TAG, "Received sensitive data: $sensitiveData")

        val tvData: TextView = findViewById(R.id.tvVulnerableData)
        tvData.text = "Received: $sensitiveData"

        // No input validation - potential injection vulnerability
        processUserData(sensitiveData)
    }

    private fun processUserData(data: String?) {
        // Insecure processing - no sanitization
        Log.d(TAG, "Processing user data without validation: $data")
        
        // Potential SQL injection if used with database
        // Example vulnerable code (commented for safety):
        // val query = "SELECT * FROM users WHERE name = '$data'"
    }
}
