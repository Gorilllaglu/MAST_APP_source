package com.example.testingapp

import android.content.ContentProvider
import android.content.ContentValues
import android.database.Cursor
import android.database.MatrixCursor
import android.net.Uri
import android.util.Log

/**
 * Vulnerable Content Provider One - Exported with read/write access
 * M9: Insecure Data Storage / M8: Security Misconfiguration - MSTG-PLATFORM-4
 */
class VulnerableContentProviderOne : ContentProvider() {

    companion object {
        private const val TAG = "VulnerableCPOne"
        const val AUTHORITY = "com.example.testingapp.vulnerable.provider.one"
        const val TABLE_NAME = "sensitive_data"
    }

    override fun onCreate(): Boolean {
        Log.d(TAG, "Content Provider One created")
        return true
    }

    override fun query(
        uri: Uri,
        projection: Array<String>?,
        selection: String?,
        selectionArgs: Array<String>?,
        sortOrder: String?
    ): Cursor? {
        Log.d(TAG, "Query received - selection: $selection, selectionArgs: ${selectionArgs?.joinToString()}")
        
        // No input validation - SQL injection vulnerability
        val cursor = MatrixCursor(arrayOf("id", "name", "value", "secret"))
        cursor.addRow(arrayOf(1, "test_name", "test_value", "secret_key_123"))
        cursor.addRow(arrayOf(2, "api_key", "sk_live_abcdef", "production_key"))
        cursor.addRow(arrayOf(3, "password", "admin123", "user_password"))
        
        return cursor
    }

    override fun getType(uri: Uri): String? {
        return "vnd.android.cursor.dir/$TABLE_NAME"
    }

    override fun insert(uri: Uri, values: ContentValues?): Uri? {
        Log.d(TAG, "Insert received - values: $values")
        
        // No validation of inserted data
        // Could lead to SQL injection or data corruption
        
        return uri
    }

    override fun delete(uri: Uri, selection: String?, selectionArgs: Array<String>?): Int {
        Log.d(TAG, "Delete received - selection: $selection")
        
        // No authorization check for deletion
        return 0
    }

    override fun update(
        uri: Uri,
        values: ContentValues?,
        selection: String?,
        selectionArgs: Array<String>?
    ): Int {
        Log.d(TAG, "Update received - selection: $selection, values: $values")
        
        // No authorization check for updates
        return 0
    }
}
