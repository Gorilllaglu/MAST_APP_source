package com.example.testingapp

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log

/**
 * Vulnerable Broadcast Receiver One - Exported boot completed receiver
 * M8: Security Misconfiguration - MSTG-PLATFORM-4
 */
class VulnerableBroadcastReceiverOne : BroadcastReceiver() {

    companion object {
        private const val TAG = "VulnReceiverOne"
    }

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action
        Log.d(TAG, "Broadcast received with action: $action")

        when (action) {
            Intent.ACTION_BOOT_COMPLETED -> {
                Log.d(TAG, "Device boot completed - starting services")
                // Starting services automatically after boot without user consent
                startVulnerableServices(context)
            }
            "android.intent.action.QUICKBOOT_POWERON" -> {
                Log.d(TAG, "Quick boot detected")
                startVulnerableServices(context)
            }
        }
    }

    private fun startVulnerableServices(context: Context) {
        // Starting service without proper checks
        val serviceIntent = Intent(context, VulnerableServiceOne::class.java)
        context.startService(serviceIntent)
        
        Log.d(TAG, "Vulnerable services started")
    }
}
