package com.example.testingapp

import android.content.ContentProvider
import android.content.ContentValues
import android.database.Cursor
import android.database.MatrixCursor
import android.net.Uri
import android.util.Log

/**
 * Vulnerable Content Provider Three - Exported file provider variant
 * M9: Insecure Data Storage / M8: Security Misconfiguration - MSTG-PLATFORM-4
 */
class VulnerableContentProviderThree : ContentProvider() {

    companion object {
        private const val TAG = "VulnerableCPThree"
        const val AUTHORITY = "com.example.testingapp.vulnerable.provider.three"
    }

    override fun onCreate(): Boolean {
        Log.d(TAG, "Content Provider Three created")
        return true
    }

    override fun query(
        uri: Uri,
        projection: Array<String>?,
        selection: String?,
        selectionArgs: Array<String>?,
        sortOrder: String?
    ): Cursor? {
        Log.d(TAG, "Query received - path: ${uri.path}")
        
        // Exposing database records without authentication
        val cursor = MatrixCursor(arrayOf("id", "username", "email", "password_hash"))
        cursor.addRow(arrayOf(1, "admin", "admin@example.com", "5f4dcc3b5aa765d61d8327deb882cf99"))
        cursor.addRow(arrayOf(2, "user1", "user1@example.com", "password123_hash"))
        cursor.addRow(arrayOf(3, "user2", "user2@example.com", "qwerty_hash"))
        
        return cursor
    }

    override fun getType(uri: Uri): String? {
        return "vnd.android.cursor.dir/vnd.$AUTHORITY"
    }

    override fun insert(uri: Uri, values: ContentValues?): Uri? {
        Log.d(TAG, "Insert received - values: $values")
        
        // Inserting data without validation
        return uri
    }

    override fun delete(uri: Uri, selection: String?, selectionArgs: Array<String>?): Int {
        Log.d(TAG, "Delete received - selection: $selection")
        
        // Deleting without authorization
        return 0
    }

    override fun update(
        uri: Uri,
        values: ContentValues?,
        selection: String?,
        selectionArgs: Array<String>?
    ): Int {
        Log.d(TAG, "Update received - selection: $selection")
        
        // Updating without authorization
        return 0
    }

    fun getSensitiveData(): String {
        // Method to retrieve sensitive data - vulnerability
        return "Sensitive data exposed"
    }
}
