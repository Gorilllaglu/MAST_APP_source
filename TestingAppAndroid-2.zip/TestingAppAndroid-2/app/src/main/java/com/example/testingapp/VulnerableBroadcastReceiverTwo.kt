package com.example.testingapp

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log

/**
 * Vulnerable Broadcast Receiver Two - Exported custom action receiver
 * M8: Security Misconfiguration - MSTG-PLATFORM-4
 */
class VulnerableBroadcastReceiverTwo : BroadcastReceiver() {

    companion object {
        private const val TAG = "VulnReceiverTwo"
    }

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action
        val data = intent.getStringExtra("data")
        val command = intent.getStringExtra("command")
        val extras = intent.extras

        Log.d(TAG, "Broadcast received - action: $action")
        Log.d(TAG, "Data: $data")
        Log.d(TAG, "Command: $command")
        Log.d(TAG, "All extras: $extras")

        // Processing broadcast without validation - vulnerability
        when (command) {
            "update_settings" -> updateSettingsInsecurely(context, data)
            "clear_data" -> clearDataInsecurely(context)
            "send_data" -> sendDataToExternalServer(data)
            else -> Log.d(TAG, "Unknown command received")
        }
    }

    private fun updateSettingsInsecurely(context: Context, data: String?) {
        // Updating app settings without authorization
        Log.d(TAG, "Updating settings with data: $data")
        
        val prefs = context.getSharedPreferences("app_settings", Context.MODE_WORLD_READABLE)
        prefs.edit().apply {
            putString("last_command", data)
            apply()
        }
    }

    private fun clearDataInsecurely(context: Context) {
        // Clearing application data without user confirmation
        Log.d(TAG, "Clearing application data")
        
        context.getSharedPreferences("app_data", Context.MODE_PRIVATE).edit().clear().apply()
    }

    private fun sendDataToExternalServer(data: String?) {
        // Sending data to external server without encryption
        Log.d(TAG, "Sending data to external server: $data")
    }
}
