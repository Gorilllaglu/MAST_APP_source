package com.example.testingapp

import android.os.Bundle
import android.util.Log
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

/**
 * Vulnerable Activity Three - Exported receiving sensitive data
 * M8: Security Misconfiguration - MSTG-PLATFORM-4
 */
class VulnerableActivityThree : AppCompatActivity() {

    companion object {
        private const val TAG = "VulnerableActivityThree"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_vulnerable_three)

        // Receiving potentially sensitive extras without validation
        val username = intent.getStringExtra("username")
        val password = intent.getStringExtra("password")
        val authToken = intent.getStringExtra("auth_token")
        val apiKey = intent.getStringExtra("api_key")

        Log.d(TAG, "Received username: $username")
        Log.d(TAG, "Received password: $password")
        Log.d(TAG, "Received auth_token: $authToken")
        Log.d(TAG, "Received api_key: $apiKey")

        val tvCredentials: TextView = findViewById(R.id.tvCredentials)
        tvCredentials.text = buildString {
            appendLine("Username: ${username ?: "N/A"}")
            appendLine("Password: ${password ?: "N/A"}")
            appendLine("Auth Token: ${authToken ?: "N/A"}")
            appendLine("API Key: ${apiKey ?: "N/A"}")
        }

        // Storing received credentials insecurely
        storeCredentialsInsecurely(username, password, authToken, apiKey)
    }

    private fun storeCredentialsInsecurely(
        username: String?,
        password: String?,
        authToken: String?,
        apiKey: String?
    ) {
        // Insecure storage in SharedPreferences
        val prefs = getSharedPreferences("credentials", MODE_WORLD_READABLE)
        prefs.edit().apply {
            putString("username", username)
            putString("password", password)
            putString("auth_token", authToken)
            putString("api_key", apiKey)
            apply()
        }
        Log.d(TAG, "Credentials stored insecurely")
    }
}
