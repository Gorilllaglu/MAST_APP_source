package ru.corp.app

import android.content.ClipData
import android.widget.TextView

/** S08 text-drag-and-drop. Правило безусловное, стороны TN у него нет. */

class DragSources {

    /** S08-TP-1. Программный источник перетаскивания, флаги нулевые. */
    fun startLocalDrag(view: TextView, data: ClipData) {
        view.startDragAndDrop(data, null, null, 0)
    }

    /** S08-TP-2. Устаревшая форма того же вызова. */
    fun startLegacyDrag(view: TextView, data: ClipData) {
        view.startDrag(data, null, null, 0)
    }

    /**
     * S08-PROBE-1. Перетаскивание выделения, которое начинает сама платформа:
     * выделение включено, пользователь тянет текст, а startDragAndDrop
     * вызывается внутри TextView. Ожидается молчание правила по перетаскиванию
     * и срабатывание правила S07 — канал закрывается только через выделение.
     */
    fun enableSelectionOnly(view: TextView) {
        view.setTextIsSelectable(true)
    }

    /**
     * S02-PROBE-2. ClipData собрана для перетаскивания, а не для буфера обмена.
     * Ожидается СРАБАТЫВАНИЕ правила по буферу: якорь на ClipData.newPlainText
     * не различает назначение. Известное ложное, клетка измеряет его.
     */
    fun buildDragPayload(text: String): ClipData {
        return ClipData.newPlainText("drag", text)
    }
}
