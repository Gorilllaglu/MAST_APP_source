package ru.corp.app

import android.webkit.WebSettings
import android.webkit.WebView

/** S11 webview-selection-unrestricted, S05-TP-2 печать из WebView. */

class WebScreens {

    /** S11-TP-1. Содержимое загружено, меню выделения не ограничено. */
    fun openDocument(view: WebView, url: String) {
        view.settings.javaScriptEnabled = true
        view.loadUrl(url)
    }

    /** S11-TP-2. Та же картина для загрузки данных строкой. */
    fun openInlineHtml(view: WebView, html: String) {
        view.loadData(html, "text/html", "utf-8")
    }

    /** S11-TN-1. Маска меню выставлена через свойство. */
    fun openRestrictedProperty(view: WebView, url: String) {
        view.settings.disabledActionModeMenuItems =
            WebSettings.MENU_ITEM_SHARE or WebSettings.MENU_ITEM_WEB_SEARCH or WebSettings.MENU_ITEM_PROCESS_TEXT
        view.loadUrl(url)
    }

    /** S11-TN-2. Маска меню выставлена через сеттер. */
    fun openRestrictedSetter(view: WebView, url: String) {
        view.settings.setDisabledActionModeMenuItems(WebSettings.MENU_ITEM_PROCESS_TEXT)
        view.loadUrl(url)
    }

    /** S11-TN-3. Выделение снято целиком свойством. */
    fun openNoSelection(view: WebView, url: String) {
        view.isLongClickable = false
        view.loadUrl(url)
    }

    /** S11-TN-4. Выделение снято перехватом долгого нажатия. */
    fun openSwallowLongClick(view: WebView, url: String) {
        view.setOnLongClickListener { true }
        view.loadUrl(url)
    }

    /** S05-TP-2. Печать из WebView. */
    fun printPage(view: WebView) {
        view.createPrintDocumentAdapter("document")
    }
}
