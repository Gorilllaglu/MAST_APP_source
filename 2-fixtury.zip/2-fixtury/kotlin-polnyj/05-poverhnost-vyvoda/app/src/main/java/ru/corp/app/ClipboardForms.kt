package ru.corp.app

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.TextView
import ru.sberbank.cerbersdk.AllowedTextActionsCallBack
import ru.sberbank.cerbersdk.CerberCopyPasteBuffer
import ru.sberbank.cerbersdk.CerberSDKApplicationDelegate
import ru.sberbank.cerbersdk.WriteResult
import ru.corp.stubs.OutputStreamStub

/** S01 clipboard-write-result-ignored, S02 host-clipboard-bypass, S03 insecure-clipboard-disabled. */

class ClipboardUsage {

    /** S01-TP-1. Результат write нигде не читается. */
    fun copyIgnored(text: String) {
        CerberCopyPasteBuffer.write(text)
    }

    /** S01-TN-1. Результат связан и разобран. */
    fun copyHandled(text: String) {
        val result = CerberCopyPasteBuffer.write(text)
        when (result) {
            WriteResult.SUCCESS -> show("ok")
            WriteResult.TRUNCATED -> show("truncated")
            WriteResult.FAILURE -> show("failed")
        }
    }

    /** S01-TN-2. Результат разобран прямо в when. */
    fun copyInlineWhen(text: String) {
        when (CerberCopyPasteBuffer.write(text)) {
            WriteResult.SUCCESS -> show("ok")
            else -> show("not ok")
        }
    }

    /** S01-TN-3. Результат возвращён вызывающему. */
    fun copyReturning(text: String): WriteResult {
        return CerberCopyPasteBuffer.write(text)
    }

    /**
     * S01-TN-4. Регрессия на сужение якоря. Прежний якорь был $BUF.write(...)
     * и ловил любой write: потоки, сокеты, логгеры. Здесь правило обязано молчать.
     */
    fun writeToStream(stream: OutputStreamStub, bytes: ByteArray) {
        stream.write(bytes)
    }

    /**
     * S01-PROBE-1. Результат связан и больше не используется.
     * Ожидается молчание: ветка на неиспользуемую переменную убрана намеренно,
     * движок не умеет доказывать, что локальная переменная не читается.
     */
    fun copyBoundUnused(text: String) {
        val unusedResult = CerberCopyPasteBuffer.write(text)
        show("copied")
    }

    /** S02-TP-1. Системный буфер напрямую, обе формы в одном месте. */
    fun copyToSystemClipboard(ctx: Any, text: String) {
        val manager = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        manager.setPrimaryClip(ClipData.newPlainText("label", text))
    }

    /**
     * S02-PROBE-1. Форма через литерал класса. Ожидается молчание:
     * литерал класса в этом движке тип не ограничивает, альтернатива убрана
     * намеренно, иначе правило срабатывало на чужих сервисах.
     */
    fun copyViaClassLiteral(text: String) {
        val manager = getSystemService(ClipboardManager::class.java)
        manager.setPrimaryClip(ClipData.newPlainText("label", text))
    }

    private fun getSystemService(name: String): Any = ClipboardManager()
    private fun <T> getSystemService(cls: Class<T>): ClipboardManager = ClipboardManager()
    private fun show(message: String) {}
}

/** S03-TP-1. Защита буфера выключена литералом. */
class ClipboardOffApp {
    val delegate = CerberSDKApplicationDelegate(
        secureInitialCheck = true,
        secureScreen = true,
        secureClipboard = false
    )
}

/** S03-TN-1. Защита буфера включена. */
class ClipboardOnApp {
    val delegate = CerberSDKApplicationDelegate(
        secureInitialCheck = true,
        secureScreen = true,
        secureClipboard = true
    )
}

/**
 * S03-PROBE-1. Динамическое значение под каноническим именем.
 * Ожидается СРАБАТЫВАНИЕ: это латентное ложное, то же, что было в правиле
 * secureInitialCheck до правки. Клетка измеряет его, а не корректность.
 */
val secureChecks = true

class ClipboardDynamicApp {
    val delegate = CerberSDKApplicationDelegate(
        secureInitialCheck = true,
        secureScreen = true,
        secureClipboard = secureChecks
    )
}
