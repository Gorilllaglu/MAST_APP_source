package ru.corp.app

import android.content.Context
import android.content.Intent
import java.io.File
import ru.corp.stubs.Environment
import ru.corp.stubs.PrintHelper
import ru.corp.stubs.ShareCompat

/** S04 system-share-channel, S05 print-channel, S06 external-storage-export. */

class OutputChannels {

    /** S04-TP-1. Шаринг через константу действия. */
    fun shareByConstant(text: String): Intent {
        val intent = Intent(Intent.ACTION_SEND)
        return intent.putExtra("android.intent.extra.TEXT", text)
    }

    /** S04-TP-2. Шаринг через строковый литерал: форма добавлена в правило. */
    fun shareByLiteral(text: String): Intent {
        val intent = Intent("android.intent.action.SEND")
        return intent.putExtra("android.intent.extra.TEXT", text)
    }

    /** S04-TP-3. Присваивание действия литералом. */
    fun shareByAssignment(text: String): Intent {
        val intent = Intent()
        intent.action = "android.intent.action.SEND"
        return intent
    }

    /** S04-TP-4. Построитель из androidx. */
    fun shareByBuilder(activity: Any): Any {
        return ShareCompat.IntentBuilder(activity)
    }

    /** S04-TN-1. Открытие ссылки, не шаринг. */
    fun openLink(): Intent {
        return Intent(Intent.ACTION_VIEW)
    }

    /** S05-TP-1. Печать картинки. */
    fun printReceipt(ctx: Any, bitmap: Any) {
        PrintHelper(ctx).printBitmap("receipt", bitmap)
    }

    /** S05-TP-3. Служба печати через константу. */
    fun printService(): Any {
        return getSystemService(Context.PRINT_SERVICE)
    }

    /** S06-TP-1. Каталог приложения во внешней памяти. */
    fun exportToExternal(ctx: ContextStub): Any? {
        return ctx.getExternalFilesDir(null)
    }

    /** S06-TP-2. Литеральный путь в общую память. */
    fun exportToSdcard(): File {
        return File("/sdcard/statement.pdf")
    }

    /** S06-TP-3. Корень внешней памяти. */
    fun exportToRoot(): Any {
        return Environment.getExternalStorageDirectory()
    }

    /** S06-TN-1. Запись в песочницу приложения. */
    fun saveInSandbox(ctx: ContextStub): Any {
        return ctx.filesDir
    }

    private fun getSystemService(name: String): Any = Any()
}

class ContextStub {
    val filesDir: Any = Any()
    fun getExternalFilesDir(type: String?): Any? = null
}
