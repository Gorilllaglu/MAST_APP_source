package ru.corp.app

/** S09 compose-text-selection, S02-TP-2 буфер Compose, S08-TP-3 источник перетаскивания Compose. */

object Modifier {
    fun dragAndDropSource(block: () -> Unit): Modifier = this
    fun fillMaxWidth(): Modifier = this
}

object LocalClipboardManager {
    val current: ClipboardHandle = ClipboardHandle()
}

class ClipboardHandle {
    fun setText(value: String) {}
}

fun SelectionContainer(content: () -> Unit) {}

fun Text(value: String) {}

fun TextField(value: String, onValueChange: (String) -> Unit, readOnly: Boolean = false) {}

/** S09-TP-1. Выделение включено в области Compose. */
fun AccountScreen(number: String) {
    SelectionContainer {
        Text(number)
    }
}

/**
 * S09-PROBE-1. Поле ввода только для чтения: выделяется по умолчанию,
 * SelectionContainer не нужен. Ожидается молчание — это записанная граница
 * покрытия, а не корректность.
 */
fun AccountFieldScreen(number: String) {
    TextField(value = number, onValueChange = {}, readOnly = true)
}

/** S02-TP-2. Буфер Compose: системный буфер в обход буфера SDK. */
fun CopyButtonScreen(number: String) {
    LocalClipboardManager.current.setText(number)
}

/** S08-TP-3. Источник перетаскивания в Compose. */
fun DraggableScreen() {
    Modifier.dragAndDropSource {
        Text("payload")
    }
}
