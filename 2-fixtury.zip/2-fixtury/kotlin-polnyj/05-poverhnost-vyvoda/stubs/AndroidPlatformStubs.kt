package android.content

object Context {
    const val CLIPBOARD_SERVICE = "clipboard"
    const val PRINT_SERVICE = "print"
}

class ClipboardManager {
    fun setPrimaryClip(clip: Any?) {}
}

class ClipData {
    companion object {
        fun newPlainText(label: String, text: String): ClipData = ClipData()
        fun newUri(resolver: Any?, label: String, uri: Any?): ClipData = ClipData()
        fun newIntent(label: String, intent: Any?): ClipData = ClipData()
        fun newRawUri(label: String, uri: Any?): ClipData = ClipData()
    }
}

class Intent(action: String? = null) {
    var action: String? = null
    fun setAction(a: String?): Intent = this
    fun putExtra(name: String, value: Any?): Intent = this

    companion object {
        const val ACTION_SEND = "android.intent.action.SEND"
        const val ACTION_SEND_MULTIPLE = "android.intent.action.SEND_MULTIPLE"
        const val ACTION_VIEW = "android.intent.action.VIEW"
        const val EXTRA_STREAM = "android.intent.extra.STREAM"
        fun createChooser(target: Intent, title: String?): Intent = target
    }
}
