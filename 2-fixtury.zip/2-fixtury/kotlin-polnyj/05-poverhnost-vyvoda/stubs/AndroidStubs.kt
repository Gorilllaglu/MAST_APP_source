package android.widget

open class TextView {
    var isTextSelectable: Boolean = false
    var customSelectionActionModeCallback: Any? = null
    var customInsertionActionModeCallback: Any? = null
    var isLongClickable: Boolean = true
    fun setTextIsSelectable(value: Boolean) {}
    fun setCustomSelectionActionModeCallback(cb: Any?) {}
    fun setCustomInsertionActionModeCallback(cb: Any?) {}
    fun setLongClickable(value: Boolean) {}
    fun setOnLongClickListener(l: (Any) -> Boolean) {}
    fun startDragAndDrop(data: Any?, shadow: Any?, state: Any?, flags: Int): Boolean = true
    fun startDrag(data: Any?, shadow: Any?, state: Any?, flags: Int): Boolean = true
}

open class EditText : TextView()
