package android.webkit

class WebSettings {
    var javaScriptEnabled: Boolean = false
    var disabledActionModeMenuItems: Int = MENU_ITEM_NONE
    fun setDisabledActionModeMenuItems(items: Int) {}

    companion object {
        const val MENU_ITEM_NONE = 0
        const val MENU_ITEM_SHARE = 1
        const val MENU_ITEM_WEB_SEARCH = 2
        const val MENU_ITEM_PROCESS_TEXT = 4
    }
}

class WebView {
    val settings = WebSettings()
    var isLongClickable: Boolean = true
    fun loadUrl(url: String) {}
    fun loadData(data: String, mime: String?, encoding: String?) {}
    fun loadDataWithBaseURL(base: String?, data: String, mime: String?, encoding: String?, history: String?) {}
    fun createPrintDocumentAdapter(name: String): Any = Any()
    fun setLongClickable(value: Boolean) {}
    fun setOnLongClickListener(l: (Any) -> Boolean) {}
}
