package ru.corp.stubs

object ShareCompat {
    class IntentBuilder(ctx: Any?) {
        companion object {
            fun from(activity: Any?): IntentBuilder = IntentBuilder(activity)
        }
    }
}

class PrintHelper(ctx: Any?) {
    fun printBitmap(name: String, bitmap: Any?) {}
}

object MediaStore {
    object Images {
        object Media {
            const val EXTERNAL_CONTENT_URI = "content://media/external/images/media"
        }
    }
}

object Environment {
    fun getExternalStorageDirectory(): Any = Any()
}

class OutputStreamStub {
    fun write(bytes: ByteArray) {}
}
