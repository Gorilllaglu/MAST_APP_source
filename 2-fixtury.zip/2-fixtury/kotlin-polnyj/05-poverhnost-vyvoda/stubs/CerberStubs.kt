package ru.sberbank.cerbersdk

enum class WriteResult { SUCCESS, TRUNCATED, FAILURE }

object CerberCopyPasteBuffer {
    fun write(data: String): WriteResult = WriteResult.SUCCESS
    fun read(): String = ""
}

object AllowedTextActionsCallBack

class CerberSDKApplicationDelegate(
    val secureInitialCheck: Boolean = false,
    val secureScreen: Boolean = false,
    val secureClipboard: Boolean = false
)

fun android.widget.EditText.disableSharing() {}
