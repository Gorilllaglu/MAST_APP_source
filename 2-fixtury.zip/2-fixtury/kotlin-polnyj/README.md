# Фикстуры на блок Kotlin: 49 правил

Собрано 2026-11-05. В `rules/` лежат все 49 правил блока — 43 котлиновских и 6 на XML.
Фикстуры разложены по девяти наборам, у каждого свои заглушки, поэтому объявления классов
между наборами не сталкиваются.

## Как запускать

Сквозным прогоном по корню архива: `--config rules/` по всему дереву. Так видно и
перекрёстные сработки между наборами, а они есть и они штатные — см. раздел «Пересечения».
Если нужен разбор одного правила, прогоняйте его набор отдельно: имя каталога указано в
матрице.

## Наборы

| Каталог | Чем занят | Клеток |
|---|---|---|
| `01-delegate-i-auth` | делегат, режимы авторизации, флаги сборки, экраны | 61 |
| `02-ipc-i-vyvod` | IPC, экспортированные компоненты, файлы, ресурсы и манифест | 96 |
| `03-pinning` | пиннинг и прямые клиенты OkHttp | 26 |
| `04-initial-check` | динамический secureInitialCheck | 10 |
| `05-poverhnost-vyvoda` | выделение, буфер, поделиться, печать, WebView, Compose | 51 |
| `06-celostnost` | проверка целостности приложения | 12 |
| `07-zhiznennyj-cikl` | жизненный цикл, колбэки, разбор результата проверок | 50 |
| `08-rasp-markery` | отладочный обход, FLAG_SECURE, маркер trustedComponents | 36 |
| `09-anomaliya-identichnosti` | аномалия текстовой идентичности, вне матрицы правил | 2 |

У каждого набора свой `README.md` с построчными ожиданиями по клеткам. Это и есть эталон
для сверки: отклонением считается расхождение с таблицей своего набора.

## Матрица: правило в клетки

| # | Правило | Критичность | Язык | Набор | Префикс | TP | TN | PROBE |
|---|---|---|---|---|---|---|---|---|
| 1 | `cerber-activity-missing-auth-onresume` | ERROR+MEDIUM | kotlin | `01-delegate-i-auth` | `K01` | 2 | 1 | 1 |
| 2 | `cerber-activity-no-lifecycle-override` | WARNING+INFO | kotlin | `07-zhiznennyj-cikl` | `L01` | 3 | 2 | 4 |
| 3 | `cerber-app-integrity-check-marker` | WARNING+INFO | kotlin | `06-celostnost` | `I01` | 7 | 2 | 3 |
| 4 | `cerber-auth-requested-but-not-observed` | WARNING+INFO | kotlin | `01-delegate-i-auth` | `K02` | 1 | 1 | 1 |
| 5 | `cerber-clipboard-write-result-ignored` | WARNING+MEDIUM | kotlin | `05-poverhnost-vyvoda` | `S01` | 1 | 4 | 1 |
| 6 | `cerber-compose-text-selection` | ERROR+HIGH | kotlin | `05-poverhnost-vyvoda` | `S09` | 1 | 0 | 1 |
| 7 | `cerber-debug-bypass-checker-present` | ERROR+HIGH | kotlin | `08-rasp-markery` | `R1` | 2 | 6 | 2 |
| 8 | `cerber-default-constructor-used` | ERROR+HIGH | kotlin | `01-delegate-i-auth` | `K04` | 1 | 2 | 0 |
| 9 | `cerber-direct-okhttp-client` | WARNING+MEDIUM | kotlin | `03-pinning` | `OK` | 12 | 8 | 6 |
| 10 | `cerber-exported-component-no-permission` | WARNING+MEDIUM | xml | `02-ipc-i-vyvod` | `E02` | 5 | 4 | 0 |
| 11 | `cerber-external-storage-export` | WARNING+INFO | kotlin | `05-poverhnost-vyvoda` | `S06` | 3 | 1 | 0 |
| 12 | `cerber-file-received-callback-empty` | WARNING+INFO | kotlin | `07-zhiznennyj-cikl` | `L02` | 2 | 1 | 2 |
| 13 | `cerber-file-received-no-caller-check` | WARNING+INFO | kotlin | `01-delegate-i-auth` | `K05` | 2 | 4 | 0 |
| 14 | `cerber-flag-secure-cleared` | ERROR+HIGH | kotlin | `08-rasp-markery` | `R2` | 2 | 5 | 3 |
| 15 | `cerber-host-clipboard-bypass` | ERROR+HIGH | kotlin | `05-poverhnost-vyvoda` | `S02` | 2 | 0 | 2 |
| 16 | `cerber-host-pin-screen` | WARNING+INFO | kotlin | `02-ipc-i-vyvod` | `E10` | 4 | 1 | 1 |
| 17 | `cerber-host-pin-screen-layout` | WARNING+MEDIUM | xml | `02-ipc-i-vyvod` | `E16` | 3 | 3 | 0 |
| 18 | `cerber-insecure-auth-mode` | ERROR+HIGH | kotlin | `01-delegate-i-auth` | `K06` | 5 | 3 | 0 |
| 19 | `cerber-insecure-auth-mode-variable` | ERROR+MEDIUM | kotlin | `01-delegate-i-auth` | `K07` | 3 | 1 | 1 |
| 20 | `cerber-insecure-clipboard-disabled` | ERROR+HIGH | kotlin | `05-poverhnost-vyvoda` | `S03` | 1 | 1 | 1 |
| 21 | `cerber-insecure-screen-disabled` | ERROR+HIGH | kotlin | `01-delegate-i-auth` | `K09` | 1 | 1 | 0 |
| 22 | `cerber-ipc-identity-fallback-open` | ERROR+MEDIUM | kotlin | `02-ipc-i-vyvod` | `E03` | 4 | 3 | 0 |
| 23 | `cerber-ipc-identity-from-payload` | WARNING+INFO | kotlin | `02-ipc-i-vyvod` | `E04` | 2 | 1 | 1 |
| 24 | `cerber-isolated-service-not-isolated` | ERROR+HIGH | xml | `01-delegate-i-auth` | `K10` | 2 | 2 | 1 |
| 25 | `cerber-logout-callback-empty` | WARNING+MEDIUM | kotlin | `07-zhiznennyj-cikl` | `L03` | 2 | 1 | 1 |
| 26 | `cerber-missing-delegate-creation` | WARNING+INFO | kotlin | `01-delegate-i-auth` | `K11` | 4 | 2 | 0 |
| 27 | `cerber-missing-sdk-application-interface` | ERROR+HIGH | kotlin | `01-delegate-i-auth` | `K12` | 1 | 1 | 1 |
| 28 | `cerber-multiprocess-ipc-exported` | ERROR+HIGH | xml | `02-ipc-i-vyvod` | `E05` | 1 | 3 | 0 |
| 29 | `cerber-no-auth-detected-ignored` | ERROR+MEDIUM | kotlin | `07-zhiznennyj-cikl` | `L05` | 2 | 1 | 1 |
| 30 | `cerber-non-production-build-type` | WARNING+INFO | kotlin | `01-delegate-i-auth` | `K13` | 2 | 1 | 0 |
| 31 | `cerber-non-production-build-type-variable` | WARNING+INFO | kotlin | `01-delegate-i-auth` | `K14` | 3 | 1 | 1 |
| 32 | `cerber-own-certificate-expiry-logic` | WARNING+LOW | kotlin | `02-ipc-i-vyvod` | `E13` | 4 | 1 | 0 |
| 33 | `cerber-passwordless-auth-disabled` | WARNING+MEDIUM | kotlin | `01-delegate-i-auth` | `K15` | 1 | 1 | 0 |
| 34 | `cerber-print-channel` | WARNING+INFO | kotlin | `05-poverhnost-vyvoda` | `S05` | 3 | 0 | 0 |
| 35 | `cerber-received-file-not-copied` | WARNING+MEDIUM | kotlin | `02-ipc-i-vyvod` | `E11` | 2 | 2 | 0 |
| 36 | `cerber-root-detected-no-termination` | WARNING+LOW | kotlin | `07-zhiznennyj-cikl` | `L07` | 1 | 6 | 3 |
| 37 | `cerber-root-detection-bypass-attempt` | ERROR+MEDIUM | kotlin | `07-zhiznennyj-cikl` | `L06` | 4 | 0 | 1 |
| 38 | `cerber-secure-check-wrong-state-comparison` | ERROR+HIGH | kotlin | `07-zhiznennyj-cikl` | `L08` | 3 | 2 | 4 |
| 39 | `cerber-secure-initial-check-disabled` | ERROR+MEDIUM | kotlin | `04-initial-check` | `K16` | 4 | 3 | 1 |
| 40 | `cerber-selection-callback-not-sdk` | ERROR+HIGH | kotlin | `05-poverhnost-vyvoda` | `S10` | 4 | 2 | 0 |
| 41 | `cerber-signature-whitelist-plaintext` | WARNING+MEDIUM | xml | `02-ipc-i-vyvod` | `E12` | 3 | 3 | 0 |
| 42 | `cerber-system-share-channel` | WARNING+INFO | kotlin | `05-poverhnost-vyvoda` | `S04` | 4 | 1 | 0 |
| 43 | `cerber-text-drag-and-drop` | ERROR+HIGH | kotlin | `05-poverhnost-vyvoda` | `S08` | 3 | 0 | 1 |
| 44 | `cerber-text-selection-enabled-layout` | WARNING+INFO | xml | `05-poverhnost-vyvoda` | `S12` | 2 | 1 | 0 |
| 45 | `cerber-text-selection-without-sdk-actions` | WARNING+MEDIUM | kotlin | `05-poverhnost-vyvoda` | `S07` | 2 | 2 | 1 |
| 46 | `cerber-transfer-temp-file-not-deleted` | WARNING+LOW | kotlin | `02-ipc-i-vyvod` | `E14` | 1 | 2 | 0 |
| 47 | `cerber-trusted-components-usage-marker` | WARNING+INFO | kotlin | `08-rasp-markery` | `R4` | 2 | 0 | 2 |
| 48 | `cerber-user-changed-callback-empty` | WARNING+MEDIUM | kotlin | `07-zhiznennyj-cikl` | `L04` | 3 | 1 | 0 |
| 49 | `cerber-webview-selection-unrestricted` | WARNING+MEDIUM | kotlin | `05-poverhnost-vyvoda` | `S11` | 2 | 4 | 0 |

Итого клеток: 134 TP, 98 TN, 48 PROBE.

## Что измерялось, а что нет

Наборы 01-05 и 08 прогонялись и сверялись, их ожидания — факт, а не расчёт. Наборы 06 и 07
собраны 2026-11-05 и не прогонялись ни разу: там ожидания выведены из текста шаблонов, и
именно там отклонения вероятнее всего. Набор 09 не прогонялся никогда — он не про правило,
а про поведение движка.

## Пересечения наборов

Пять правил покрыты дважды: клетки для них есть и в наборе 02, собранном на четвёртом
этапе, и в наборе 05, собранном под поверхность вывода. При сквозном прогоне сработки
придут из обоих мест, и это не дубль-ошибка.

| Правило | Клетки в 02 | Клетки в 05 |
|---|---|---|
| `cerber-host-clipboard-bypass` | E01 | S02 |
| `cerber-system-share-channel` | E07 | S04 |
| `cerber-external-storage-export` | E08 | S06 |
| `cerber-print-channel` | E09 | S05 |
| `cerber-text-selection-enabled-layout` | E15 | S12 |

Отдельно стоит набор 09: его клетки `X01-TP-1` и `X01-TP-2` — две байт-идентичные строки на
`cerber-host-clipboard-bypass`, собранные под вопрос к движку, а не под правило. Ожидание там
одно: либо срабатывают обе, либо ни одна. Любой другой исход и есть сам ответ.

Ещё три правила имеют старые клетки в наборе 01 и новые в 05: `clipboard-write-result-ignored`
(`K03` и `S01`), `insecure-clipboard-disabled` (`K08` и `S03`), `file-received-no-caller-check`
(`K05`, плюс попутные сработки в наборе 03). Якорь первого правила 2026-11-05 сужен, поэтому
часть старых клеток `K03` теперь молчит намеренно.

## Клетки не из набора правил

Три группы клеток в архиве не относятся ни к одному из 49 правил. Находок по ним быть не
должно, и их отсутствие — не пропуск.

| Клетки | Где | Почему |
|---|---|---|
| `E06-*` | набор 02 | `cerber-text-selection-enabled` удалено 2026-11-05, на его место сделаны пять правил поверхности вывода |
| `R3-*` | набор 08 | `cerber-secure-check-result-ignored` заменено на `cerber-secure-check-wrong-state-comparison`; его клетки — `L08` в наборе 07 |
| `K17-*` | набор 04 | предложенное второе правило на саму динамику флага, в состав не входит |

## Известные отклонения, которые отклонениями не считаются

Это измеренные ложные и пропуски, записанные в своих README. Их не нужно заявлять заново.

| Клетка | Правило | Что происходит |
|---|---|---|
| `K12-PROBE-1` | `missing-sdk-application-interface` | класс Application без тела даёт сработку: положительный шаблон с `{ ... }` видит класс без тела, исключение — нет |
| `K16-TP-2` | `secure-initial-check-disabled` | сработка на `val secureChecks = true` в том же файле: свёртка констант файл-локальна |
| `S02-PROBE-2` | `host-clipboard-bypass` | известное ложное |
| `S03-PROBE-1` | `insecure-clipboard-disabled` | латентное ложное; клетка написана на компильной константе, поэтому мерит свёртку, а не само ложное |
| `S07-PROBE-1` | `text-selection-without-sdk-actions` | сработка при выносе установки колбэка в другую функцию: `pattern-not-inside` в обёртке `fun` не ограничен этой функцией |
| `S01-TN-4` | `clipboard-write-result-ignored` | молчит: сужение якоря сработало как задумано |

## На что смотреть в первую очередь

1. Набор 07, клетки `L03-PROBE-1` и `L05-PROBE-1` против `L04-TP-3`: три правила-близнеца
   с разными наборами форм. Если расхождение подтвердится, двум из трёх надо добавить
   форму `{ return }`.
2. Набор 07, `L08-PROBE-3` и `L08-PROBE-4`: в перечислении `SecureCheck` декомпилированного
   SDK шесть небезопасных состояний, правило сравнивает с тремя. Молчание этих клеток —
   основание дописать остальные.
3. Набор 07, `L07-PROBE-2` и `L07-PROBE-3`: завершение внутри `if` и внутри лямбды.
   Меряют, доходит ли многоточие исключения внутрь вложенного блока.
4. Набор 06, `I01-PROBE-1`: флаг в локальной переменной. Та же свёртка констант, что
   дала `K16-TP-2`, но в другой позиции.
5. Набор 07, `L01-PROBE-4`: класс без тела. Если сработает, ложное из `K12` воспроизводится
   на втором правиле, и это уже не частный случай.
