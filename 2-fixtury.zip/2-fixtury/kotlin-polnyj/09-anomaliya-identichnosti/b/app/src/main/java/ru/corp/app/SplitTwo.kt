package ru.corp.app

import android.content.ClipData
import android.content.ClipboardManager

/**
 * J-2. Та же конструкция, что в SplitOne.kt, побайтово. Разные файлы.
 * Ожидается СРАБОТКА.
 */
object SplitTwo {
    fun copy(cm: ClipboardManager, text: String) {
        cm.setPrimaryClip(ClipData.newPlainText("label", text))
    }
}
