package ru.corp.app

import android.content.ClipData
import android.content.ClipboardManager

/**
 * J-1. Та же конструкция, что в SplitTwo.kt, побайтово. Разные файлы.
 * Ожидается СРАБОТКА. Проверяет, действует ли эффект за границей файла.
 */
object SplitOne {
    fun copy(cm: ClipboardManager, text: String) {
        cm.setPrimaryClip(ClipData.newPlainText("label", text))
    }
}
