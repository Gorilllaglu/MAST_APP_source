package ru.corp.app

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context

/**
 * Один файл, три функции. Отличается ровно одно: текст строкового литерала.
 *
 * Все три содержат одну и ту же конструкцию cm.setPrimaryClip(ClipData.newPlainText(...)),
 * то есть каждая подходит сразу под два шаблона правила: $CM.setPrimaryClip(...)
 * и ClipData.newPlainText(...). Сработать обязаны все три.
 *
 * Основание для теста: в прогоне 2026-10-28 клетки X01-TP-1 и X01-TP-2 имели
 * побайтово одинаковую строку cm.setPrimaryClip(ClipData.newPlainText("label", text)),
 * лежали в одном файле в соседних функциях — и первая дала находки, а вторая
 * промолчала.
 *
 * Клетки I-1 и I-2 совпадают побайтово. Клетка I-3 отличается только текстом
 * литерала. Если I-1 сработает, I-2 промолчит, а I-3 сработает — значит
 * различитель именно текстовая идентичность совпадения, и это объясняет всю
 * серию аномалий проекта: в них совпадающий текст тоже всегда был одинаков.
 */
object Identical {

    /** I-1. Ожидается СРАБОТКА. */
    fun first(cm: ClipboardManager, text: String) {
        cm.setPrimaryClip(ClipData.newPlainText("label", text))
    }

    /** I-2. Побайтово то же, что I-1. Ожидается СРАБОТКА. */
    fun second(cm: ClipboardManager, text: String) {
        cm.setPrimaryClip(ClipData.newPlainText("label", text))
    }

    /** I-3. Та же конструкция, другой текст литерала. Ожидается СРАБОТКА. */
    fun third(cm: ClipboardManager, text: String) {
        cm.setPrimaryClip(ClipData.newPlainText("clip", text))
    }
}
