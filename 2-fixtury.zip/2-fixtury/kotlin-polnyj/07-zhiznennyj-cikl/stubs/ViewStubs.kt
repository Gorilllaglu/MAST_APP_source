package android.view

class View {
    interface OnClickListener { fun onClick(view: View?) }
    interface OnLongClickListener { fun onLongClick(view: View?): Boolean }
    interface OnFocusChangeListener { fun onFocusChange(view: View?, hasFocus: Boolean) }
}
