package android.app

open class Activity {
    open fun onResume() {}
    open fun onPause() {}
    fun finish() {}
    fun finishAffinity() {}
    fun finishAndRemoveTask() {}
}
