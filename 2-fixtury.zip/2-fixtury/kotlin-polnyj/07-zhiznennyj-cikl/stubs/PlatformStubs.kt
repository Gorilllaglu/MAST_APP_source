package android.os

object Process {
    fun myPid(): Int = 0
    fun killProcess(pid: Int) {}
}
