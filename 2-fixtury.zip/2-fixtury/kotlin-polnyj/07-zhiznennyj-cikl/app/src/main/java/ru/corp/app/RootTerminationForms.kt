package ru.corp.app

import android.os.Process
import ru.sberbank.cerbersdk.CerberCallbacks
import kotlin.system.exitProcess

/** L07 cerber-root-detected-no-termination. */

private fun report(event: String) {
    event.length
}

/** L07-TP-1. Тело есть, завершения нет: только журнал. */
class RootLogOnly : CerberCallbacks {
    override fun onRootDetected() {
        report("root detected")
    }
}

/** L07-TN-1. exitProcess. */
class RootExitProcess : CerberCallbacks {
    override fun onRootDetected() {
        report("root detected")
        exitProcess(1)
    }
}

/** L07-TN-2. System.exit. */
class RootSystemExit : CerberCallbacks {
    override fun onRootDetected() {
        report("root detected")
        System.exit(1)
    }
}

/** L07-TN-3. killProcess. */
class RootKillProcess : CerberCallbacks {
    override fun onRootDetected() {
        report("root detected")
        Process.killProcess(Process.myPid())
    }
}

/** L07-TN-4. finish. */
class RootFinish : android.app.Activity(), CerberCallbacks {
    override fun onRootDetected() {
        report("root detected")
        finish()
    }
}

/** L07-TN-5. finishAffinity. */
class RootFinishAffinity : android.app.Activity(), CerberCallbacks {
    override fun onRootDetected() {
        report("root detected")
        finishAffinity()
    }
}

/** L07-TN-6. finishAndRemoveTask. */
class RootFinishAndRemoveTask : android.app.Activity(), CerberCallbacks {
    override fun onRootDetected() {
        report("root detected")
        finishAndRemoveTask()
    }
}

/**
 * L07-PROBE-1. Завершение вынесено в свой метод. Ожидается сработка:
 * исключения правила перечисляют вызовы по имени, своё имя в список не входит.
 * Это ложное на корректном коде, и обвязка такого вида встречается часто.
 */
class RootTerminateHelper : CerberCallbacks {
    override fun onRootDetected() {
        report("root detected")
        terminate()
    }

    private fun terminate() {
        exitProcess(1)
    }
}

/**
 * L07-PROBE-2. Завершение внутри условия. Измеряет, доходит ли многоточие
 * исключения внутрь вложенного блока: если нет - ложное на корректном коде.
 */
class RootConditionalExit : CerberCallbacks {
    override fun onRootDetected() {
        report("root detected")
        if (System.currentTimeMillis() > 0) {
            exitProcess(1)
        }
    }
}

/**
 * L07-PROBE-3. Завершение в лямбде обработчика. Та же проверка глубины,
 * но вложение другого вида.
 */
class RootExitInLambda : CerberCallbacks {
    override fun onRootDetected() {
        report("root detected")
        runCatching { exitProcess(1) }
    }
}
