package ru.corp.app

import android.net.Uri
import ru.sberbank.cerbersdk.CerberCallbacks
import kotlin.system.exitProcess

/**
 * L02 file-received-callback-empty, L03 logout-callback-empty,
 * L04 user-changed-callback-empty, L05 no-auth-detected-ignored,
 * L06 root-detection-bypass-attempt.
 *
 * В классах, где клетка не про onRootDetected, этот колбэк завершает процесс:
 * иначе его увидит L07 root-detected-no-termination и даст свою сработку.
 */

private fun handle(message: String) {
    message.length
}

/** L02-TP-1. Пустое тело. */
class FileSinkEmpty : CerberCallbacks {
    override fun onFileReceived(uri: Uri, pkg: String) { }
    override fun onRootDetected() { exitProcess(1) }
}

/** L02-TP-2. Форма через Unit. */
class FileSinkUnit : CerberCallbacks {
    override fun onFileReceived(uri: Uri, pkg: String) = Unit
    override fun onRootDetected() { exitProcess(1) }
}

/** L02-TN-1. Файл обрабатывается. */
class FileSinkReal : CerberCallbacks {
    override fun onFileReceived(uri: Uri, pkg: String) {
        handle(pkg)
    }
    override fun onRootDetected() { exitProcess(1) }
}

/**
 * L02-PROBE-1. Тело из одного комментария. Ожидание неизвестно: если шаблон
 * { } видит только пустые скобки, пропуск; если комментарий выбрасывается
 * лексером, сработка. Это самая частая форма заглушки в живом коде.
 */
class FileSinkComment : CerberCallbacks {
    override fun onFileReceived(uri: Uri, pkg: String) {
        // приём файлов пока не нужен
    }
    override fun onRootDetected() { exitProcess(1) }
}

/**
 * L02-PROBE-2. Тип параметра с вопросительным знаком. Ожидается пропуск:
 * в шаблоне тип записан как Uri без знака.
 */
class FileSinkNullable {
    fun onFileReceived(uri: Uri?, pkg: String) { }
}

/** L03-TP-1. Пустое тело. */
class LogoutEmpty : CerberCallbacks {
    override fun onLogout() { }
    override fun onRootDetected() { exitProcess(1) }
}

/** L03-TP-2. Форма через Unit. */
class LogoutUnit : CerberCallbacks {
    override fun onLogout() = Unit
    override fun onRootDetected() { exitProcess(1) }
}

/** L03-TN-1. Выход обрабатывается. */
class LogoutReal : CerberCallbacks {
    override fun onLogout() {
        handle("clear")
    }
    override fun onRootDetected() { exitProcess(1) }
}

/**
 * L03-PROBE-1. Тело из одного return. Ожидается пропуск: у onLogout такая
 * форма в правиле не перечислена, а у onUserChanged перечислена. Клетка
 * измеряет расхождение между правилами-близнецами.
 */
class LogoutReturn : CerberCallbacks {
    override fun onLogout() {
        return
    }
    override fun onRootDetected() { exitProcess(1) }
}

/** L04-TP-1. Пустое тело. */
class UserChangedEmpty : CerberCallbacks {
    override fun onUserChanged() { }
    override fun onRootDetected() { exitProcess(1) }
}

/** L04-TP-2. Форма через Unit. */
class UserChangedUnit : CerberCallbacks {
    override fun onUserChanged() = Unit
    override fun onRootDetected() { exitProcess(1) }
}

/** L04-TP-3. Тело из одного return. */
class UserChangedReturn : CerberCallbacks {
    override fun onUserChanged() {
        return
    }
    override fun onRootDetected() { exitProcess(1) }
}

/** L04-TN-1. Смена пользователя обрабатывается. */
class UserChangedReal : CerberCallbacks {
    override fun onUserChanged() {
        handle("reset")
    }
    override fun onRootDetected() { exitProcess(1) }
}

/** L05-TP-1. Пустое тело. */
class NoAuthEmpty : CerberCallbacks {
    override fun onNoAuthDetected() { }
    override fun onRootDetected() { exitProcess(1) }
}

/** L05-TP-2. Форма через Unit. */
class NoAuthUnit : CerberCallbacks {
    override fun onNoAuthDetected() = Unit
    override fun onRootDetected() { exitProcess(1) }
}

/** L05-TN-1. Отсутствие авторизации обрабатывается. */
class NoAuthReal : CerberCallbacks {
    override fun onNoAuthDetected() {
        handle("login")
    }
    override fun onRootDetected() { exitProcess(1) }
}

/**
 * L05-PROBE-1. Тело из одного return. Ожидается пропуск: форма в правиле
 * не перечислена. То же расхождение, что в L03-PROBE-1.
 */
class NoAuthReturn : CerberCallbacks {
    override fun onNoAuthDetected() {
        return
    }
    override fun onRootDetected() { exitProcess(1) }
}

/** L06-TP-1. Пустое тело. Сработают оба правила по onRootDetected. */
class RootEmpty : CerberCallbacks {
    override fun onRootDetected() { }
}

/** L06-TP-2. Форма через Unit. Сработает только L06: у L07 положительный шаблон с телом. */
class RootUnit : CerberCallbacks {
    override fun onRootDetected() = Unit
}

/** L06-TP-3. Тело из одного return. */
class RootReturn : CerberCallbacks {
    override fun onRootDetected() {
        return
    }
}

/** L06-TP-4. Тело из одного Unit. */
class RootUnitBody : CerberCallbacks {
    override fun onRootDetected() {
        Unit
    }
}

/**
 * L06-PROBE-1. Объявления в интерфейсе без тела. Измерено ранее: шаблон с
 * пустым телом совпадает с абстрактным объявлением. Клетка держит этот ложный
 * на виду; сработки ожидаются на всех пяти строках.
 */
interface HostCallbacksDeclaration {
    fun onLogout()
    fun onUserChanged()
    fun onNoAuthDetected()
    fun onRootDetected()
    fun onFileReceived(uri: Uri, pkg: String)
}
