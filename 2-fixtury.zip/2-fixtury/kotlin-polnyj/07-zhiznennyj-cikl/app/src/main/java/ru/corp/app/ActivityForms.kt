package ru.corp.app

import android.view.View
import androidx.appcompat.app.AppCompatActivity

/** L01 cerber-activity-no-lifecycle-override. */

/** L01-TP-1. Экран без onResume. */
class ProfileActivity : AppCompatActivity() {
    fun load() {
        val unused = 1
    }
}

/** L01-TP-2. Экран с одним интерфейсом, без onResume. */
class OrdersActivity : AppCompatActivity(), View.OnClickListener {
    override fun onClick(view: View?) {}
}

/** L01-TP-3. Экран с двумя интерфейсами, без onResume. */
class HistoryActivity : AppCompatActivity(), View.OnClickListener, View.OnLongClickListener {
    override fun onClick(view: View?) {}
    override fun onLongClick(view: View?): Boolean = true
}

/** L01-TN-1. onResume переопределён. */
class PaymentActivity : AppCompatActivity() {
    override fun onResume() {
        super.onResume()
    }
}

/** L01-TN-2. Два интерфейса и onResume. */
class CardsActivity : AppCompatActivity(), View.OnClickListener, View.OnLongClickListener {
    override fun onClick(view: View?) {}
    override fun onLongClick(view: View?): Boolean = true
    override fun onResume() {
        super.onResume()
    }
}

/**
 * L01-PROBE-1. Имя класса без подстроки Activity. Ожидается пропуск:
 * metavariable-regex на $ACT требует .*Activity.*, а экраны часто называют
 * Screen, Fragment, Page. Клетка измеряет размер пропуска.
 */
class Dashboard : AppCompatActivity() {
    fun load() {
        val unused = 1
    }
}

/**
 * L01-PROBE-2. Базовый класс приложения без подстроки Activity в имени.
 * Ожидается пропуск: regex на $BASE не совпадает. Так выглядит вынос в свою базу.
 */
open class BaseScreen : AppCompatActivity()

class ReportsActivity : BaseScreen() {
    fun load() {
        val unused = 1
    }
}

/**
 * L01-PROBE-3. Три интерфейса. Ожидается пропуск: в правиле перечислены
 * формы до двух интерфейсов включительно.
 */
class SettingsActivity : AppCompatActivity(), View.OnClickListener, View.OnLongClickListener, View.OnFocusChangeListener {
    override fun onClick(view: View?) {}
    override fun onLongClick(view: View?): Boolean = true
    override fun onFocusChange(view: View?, hasFocus: Boolean) {}
}

/**
 * L01-PROBE-4. Класс без тела. Измерено 2026-11-05 на правиле
 * missing-sdk-application-interface: положительный шаблон с { ... }
 * совпадает с классом без тела, а исключение с тем же { ... } - нет.
 * Если тут сработка, тот же ложный есть и здесь.
 */
class EmptyActivity : AppCompatActivity()
