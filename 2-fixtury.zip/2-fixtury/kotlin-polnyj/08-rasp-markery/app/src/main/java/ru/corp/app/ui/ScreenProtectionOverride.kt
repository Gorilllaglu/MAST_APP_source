package ru.corp.app.ui

import android.app.Activity
import android.os.Bundle
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity

/** Правило cerber-flag-secure-cleared, сторона TP. */
class ReceiptPreviewActivity : AppCompatActivity() {

    /** R2-TP-1. Именованная константа. Прогон 2026-10-22: сработка, верно. */
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
    }
}

/** R2-TP-2. Числовой литерал, составной получатель. Прогон: сработка, верно. */
fun allowScreenshotsForOnboarding(activity: Activity) {
    activity.window.clearFlags(8192)
}

/** R2-PROBE-1. Шестнадцатеричная запись. Прогон: сработка — константная подстановка работает. */
fun allowScreenshotsHex(activity: Activity) {
    activity.window.clearFlags(0x2000)
}

/** R2-PROBE-2. Снятие флага без clearFlags. v0: находки нет. v4: СРАБОТКА через setFlags(0, FLAG_SECURE). */
fun dropSecureFlagWithoutClearFlags(activity: Activity) {
    activity.window.setFlags(0, WindowManager.LayoutParams.FLAG_SECURE)
    val attrs = activity.window.attributes
    attrs.flags = attrs.flags and WindowManager.LayoutParams.FLAG_SECURE.inv()
    activity.window.attributes = attrs
}
