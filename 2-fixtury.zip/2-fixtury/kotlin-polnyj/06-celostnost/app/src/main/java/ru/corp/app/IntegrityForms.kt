package ru.corp.app

import android.content.pm.PackageManager
import android.content.pm.PackageManager.Companion.GET_SIGNATURES
import android.content.pm.PackageManager.Companion.GET_SIGNING_CERTIFICATES
import ru.sberbank.cerbersdk.CerberStoreHolder
import ru.sberbank.cerbersdk.CerberStoreRepository

/** I01 cerber-app-integrity-check-marker. */

private const val TRUSTED_PKG = "ru.sberbank.sberapps"

class IntegrityGates(private val pm: PackageManager) {

    /** I01-TP-1. Проверка Цербера через хранилище. */
    fun cerberCheckWithReceiver(store: CerberStoreRepository, callingPackage: String): Boolean {
        return store.checkOtherAppSignature(callingPackage)
    }

    /** I01-TP-2. Проверка Цербера без получателя: вызов изнутри обвязки. */
    fun cerberCheckReceiverless(callingPackage: String): Boolean {
        return with(CerberStoreHolder) { checkOtherAppSignature(callingPackage) }
    }

    /** I01-TP-3. Платформенная проверка по отпечатку, современная форма. */
    fun platformHasCertificate(callingPackage: String, expected: ByteArray): Boolean {
        return pm.hasSigningCertificate(callingPackage, expected, PackageManager.CERT_INPUT_SHA256)
    }

    /** I01-TP-4. Платформенное сравнение подписей двух пакетов. */
    fun platformCompare(callingPackage: String, ownPackage: String): Boolean {
        return pm.checkSignatures(callingPackage, ownPackage) == PackageManager.SIGNATURE_MATCH
    }

    /** I01-TP-5. Чтение подписи с флагом, квалифицированная константа. */
    fun platformReadModern(callingPackage: String): Int {
        val info = pm.getPackageInfo(callingPackage, PackageManager.GET_SIGNING_CERTIFICATES)
        return info.signingInfo?.signingCertificateHistory?.size ?: 0
    }

    /** I01-TP-6. Чтение подписи устаревшим флагом. */
    fun platformReadLegacy(callingPackage: String): Int {
        val info = pm.getPackageInfo(callingPackage, PackageManager.GET_SIGNATURES)
        return info.signatures.size
    }

    /** I01-TP-7. Тот же флаг импортирован, обращение без квалификатора. */
    fun platformReadImportedConstant(callingPackage: String): Int {
        val info = pm.getPackageInfo(callingPackage, GET_SIGNING_CERTIFICATES)
        return info.signingInfo?.signingCertificateHistory?.size ?: 0
    }

    /** I01-TN-1. Пакет читается без флага подписи: это не проверка целостности. */
    fun readVersionOnly(callingPackage: String): String? {
        return pm.getPackageInfo(callingPackage, 0).versionName
    }

    /** I01-TN-2. Доверие по имени пакета. Ровно то, что правило не должно принимать за проверку. */
    fun trustByName(callingPackage: String?): Boolean {
        return callingPackage == TRUSTED_PKG
    }

    /**
     * I01-PROBE-1. Флаг положен в локальную переменную в этом же файле.
     * Проверяет, доходит ли сюда свёртка констант: если да, сработка будет,
     * если нет - это пропуск, и его надо знать по месту.
     */
    fun flagsInVariable(callingPackage: String): Int {
        val flags = PackageManager.GET_SIGNING_CERTIFICATES
        val info = pm.getPackageInfo(callingPackage, flags)
        return info.signatures.size
    }

    /**
     * I01-PROBE-2. Форма API 33: флаг обёрнут в PackageInfoFlags.of.
     * Ожидается пропуск: перечислять обёртку целиком нельзя, внутрь of()
     * может попасть любой флаг.
     */
    fun flagsApi33(callingPackage: String): Int {
        val flags = PackageManager.PackageInfoFlags.of(GET_SIGNING_CERTIFICATES.toLong())
        val info = pm.getPackageInfo(callingPackage, flags)
        return info.signatures.size
    }
}

/**
 * I01-PROBE-3. Свой метод с именем checkSignatures на постороннем объекте.
 * Измеряет цену ветки без получателя: сработка здесь - ложная.
 */
class DocumentValidator {
    fun checkSignatures(documentId: String): Boolean = documentId.isNotEmpty()

    fun validate(documentId: String): Boolean {
        return checkSignatures(documentId)
    }
}
