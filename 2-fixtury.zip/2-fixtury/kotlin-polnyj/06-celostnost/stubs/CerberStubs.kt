package ru.sberbank.cerbersdk

interface CerberStore {
    fun checkAvailability(): Boolean
}

interface CerberStoreRepository : CerberStore {
    fun checkOtherAppSignature(bundleId: String): Boolean
}

object CerberStoreHolder : CerberStoreRepository {
    override fun checkAvailability(): Boolean = true
    override fun checkOtherAppSignature(bundleId: String): Boolean = true
}
