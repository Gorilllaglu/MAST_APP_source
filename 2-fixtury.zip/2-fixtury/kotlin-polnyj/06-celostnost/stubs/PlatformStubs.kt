package android.content.pm

class Signature(val raw: ByteArray = ByteArray(0))

class SigningInfo {
    val signingCertificateHistory: Array<Signature> = emptyArray()
    fun hasMultipleSigners(): Boolean = false
}

class PackageInfo {
    var versionName: String? = null
    var signatures: Array<Signature> = emptyArray()
    var signingInfo: SigningInfo? = null
}

class PackageManager {
    companion object {
        const val GET_SIGNATURES = 0x40
        const val GET_SIGNING_CERTIFICATES = 0x8000000
        const val CERT_INPUT_SHA256 = 1
        const val SIGNATURE_MATCH = 0
    }

    class PackageInfoFlags private constructor(val value: Long) {
        companion object { fun of(value: Long): PackageInfoFlags = PackageInfoFlags(value) }
    }

    fun getPackageInfo(packageName: String, flags: Int): PackageInfo = PackageInfo()
    fun getPackageInfo(packageName: String, flags: PackageInfoFlags): PackageInfo = PackageInfo()
    fun hasSigningCertificate(packageName: String, certificate: ByteArray, type: Int): Boolean = false
    fun checkSignatures(packageOne: String, packageTwo: String): Int = SIGNATURE_MATCH
}
