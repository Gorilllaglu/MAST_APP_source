package ru.sberbank.cerbersdk.sdk_framework;

public enum WriteResult { SUCCESS, TRUNCATED, FAILURE }
