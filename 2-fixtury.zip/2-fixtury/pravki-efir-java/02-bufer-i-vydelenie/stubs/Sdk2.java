package ru.sberbank.cerbersdk.sdk_framework;

public class CerberCopyPasteBuffer {
    public static WriteResult write(String data) { return WriteResult.SUCCESS; }
    public static String read() { return ""; }
}

class CerberBuffer {
    WriteResult write(String data) { return WriteResult.SUCCESS; }
}

class DelegateWithBuffer {
    private final CerberBuffer buffer = new CerberBuffer();

    CerberBuffer getBuffer() { return buffer; }
}

class ActionModeCallback { }

class TextInputEditText {
    public void setCustomSelectionActionModeCallback(ActionModeCallback cb) { }
    public void disableSharing() { }
}

class AllowedTextActionsCallBack {
    public static final ActionModeCallback INSTANCE = new ActionModeCallback();
}

class OutputBuffer {
    void write(byte[] bytes) { }
}

class Host {
    static void show(String message) { }
}
