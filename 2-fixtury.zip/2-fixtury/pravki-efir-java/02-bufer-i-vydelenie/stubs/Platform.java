package android.content;

public class ClipData {
    public static ClipData newPlainText(String label, String text) { return new ClipData(); }
    public static ClipData newUri(Object resolver, String label, Object uri) { return new ClipData(); }
    public static ClipData newIntent(String label, Object intent) { return new ClipData(); }
    public static ClipData newRawUri(String label, Object uri) { return new ClipData(); }
}

class ClipboardManager {
    public void setPrimaryClip(ClipData clip) { }
    public void clearPrimaryClip() { }
}

class Context {
    public static final String CLIPBOARD_SERVICE = "clipboard";
    public Object getSystemService(String name) { return new ClipboardManager(); }
    public Object getSystemService(Class<?> type) { return new ClipboardManager(); }
}
