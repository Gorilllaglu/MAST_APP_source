package ru.corp.app;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import ru.sberbank.cerbersdk.sdk_framework.ActionModeCallback;
import ru.sberbank.cerbersdk.sdk_framework.AllowedTextActionsCallBack;
import ru.sberbank.cerbersdk.sdk_framework.CerberCopyPasteBuffer;
import ru.sberbank.cerbersdk.sdk_framework.DelegateWithBuffer;
import ru.sberbank.cerbersdk.sdk_framework.Host;
import ru.sberbank.cerbersdk.sdk_framework.OutputBuffer;
import ru.sberbank.cerbersdk.sdk_framework.TextInputEditText;
import ru.sberbank.cerbersdk.sdk_framework.WriteResult;

/** JA-CW write-result-ignored, JA-CL host-clipboard-bypass, JA-SB selection-callback-not-sdk. */
public class BufferForms {

    private final DelegateWithBuffer delegate = new DelegateWithBuffer();
    private final Context context = new Context();

    /** JA-CW-TP-1. Запись литералом типа, результат отброшен. */
    void copyLiteral(String text) {
        CerberCopyPasteBuffer.write(text);
        Host.show("copied");
    }

    /** JA-CW-TP-2. Запись через буфер делегата, результат отброшен. Форма из приложения. */
    void copyViaDelegate(String value) {
        delegate.getBuffer().write(value);
        Host.show("stored");
    }

    /**
     * JA-CW-TN-3. Поток с именем buffer. Молчание обязательно: форма
     * this.buffer.write встречается в okio и spongycastle десятками.
     */
    void dumpBytes(OutputBuffer outputBuffer, byte[] bytes) {
        outputBuffer.write(bytes);
    }

    /** JA-CW-TN-1. Результат записи литералом разобран. Молчание. */
    void copyLiteralHandled(String text) {
        WriteResult result = CerberCopyPasteBuffer.write(text);
        Host.show(result.name());
    }

    /** JA-CW-TN-2. Результат записи через делегат разобран. Молчание. */
    void copyViaDelegateHandled(String value) {
        WriteResult outcome = delegate.getBuffer().write(value);
        Host.show(outcome.name());
    }

    /** JA-CL-TP-1. Получение системного менеджера буфера. */
    Object grabManager() {
        return context.getSystemService(Context.CLIPBOARD_SERVICE);
    }

    /** JA-CL-TP-2. Получение менеджера литералом класса. */
    Object grabManagerByClass() {
        return context.getSystemService(ClipboardManager.class);
    }

    /** JA-CL-TP-3. Очистка системного буфера. */
    void clearSystem(ClipboardManager manager) {
        manager.clearPrimaryClip();
    }

    /** JA-CL-TP-4. Запись в системный буфер. */
    void copyToSystem(ClipboardManager manager, ClipData clip) {
        manager.setPrimaryClip(clip);
    }

    /**
     * JA-CL-TN-1. Сборка ClipData без записи в системный буфер. После сужения
     * правила здесь молчание.
     */
    ClipData buildPayload(String text) {
        return ClipData.newPlainText("label", text);
    }

    /** JA-SB-TP-1. Поставлен свой колбэк выделения. */
    void setOwnCallback(TextInputEditText field) {
        field.setCustomSelectionActionModeCallback(new ActionModeCallback());
    }

    /** JA-SB-TN-1. Поставлен штатный объект SDK. Молчание. */
    void setSdkCallback(TextInputEditText field) {
        field.setCustomSelectionActionModeCallback(AllowedTextActionsCallBack.INSTANCE);
    }

    /**
     * JA-SB-TN-2. Вызван штатный защитный хелпер SDK. Молчание обязательно:
     * до правки шаблон на disableSharing стоял в положительных.
     */
    void disableSharingOnField(TextInputEditText field) {
        field.disableSharing();
    }
}
