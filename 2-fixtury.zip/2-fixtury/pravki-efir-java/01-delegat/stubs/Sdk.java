package ru.sberbank.cerbersdk.sdk_framework;

import java.util.List;

public enum AuthorizationMode { CERBER, NONE, EXTERNAL, LEGACY }
