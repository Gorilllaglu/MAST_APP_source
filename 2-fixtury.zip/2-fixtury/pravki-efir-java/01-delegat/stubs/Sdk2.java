package ru.sberbank.cerbersdk.sdk_framework;

import java.util.List;

public class CerberSDKApplicationDelegate {
    public CerberSDKApplicationDelegate(AuthorizationMode mode, BuildType buildType, boolean isolated,
            boolean secureInitialCheck, boolean secureScreen, boolean secureClipboard,
            boolean enableTestServerPinning, SberMagOptions sberMagOptions,
            WhiteListOptions whiteListOptions, boolean disablePasswordlessAuth) { }

    public CerberSDKApplicationDelegate(AuthorizationMode mode, BuildType buildType, boolean isolated,
            boolean secureInitialCheck, boolean secureScreen, boolean secureClipboard,
            boolean enableTestServerPinning, SberMagOptions sberMagOptions,
            WhiteListOptions whiteListOptions, boolean disablePasswordlessAuth,
            boolean observeAuthStateWithoutActivity) { }
}

enum BuildType { PROM, DEV1, DEV2, IFT, PSI }

class SberMagOptions { }

class WhiteListOptions {
    WhiteListOptions(List<String> packages) { }
}
