package ru.corp.app;

import java.util.Collections;
import ru.sberbank.cerbersdk.sdk_framework.AuthorizationMode;
import ru.sberbank.cerbersdk.sdk_framework.BuildType;
import ru.sberbank.cerbersdk.sdk_framework.CerberSDKApplicationDelegate;
import ru.sberbank.cerbersdk.sdk_framework.WhiteListOptions;

/** JA-PD passwordless-auth-disabled: позиция десятого аргумента. */
public class PositionalForms {

    private static final WhiteListOptions EMPTY = new WhiteListOptions(Collections.emptyList());

    /** JA-PD-TP-1. disablePasswordlessAuth true десятым аргументом, всего одиннадцать. */
    CerberSDKApplicationDelegate passwordlessDisabled() {
        return new CerberSDKApplicationDelegate(AuthorizationMode.CERBER, BuildType.PROM, false,
                true, true, true, false, null, EMPTY, true, false);
    }

    /** JA-PD-TP-2. То же на десяти аргументах. */
    CerberSDKApplicationDelegate passwordlessDisabledShort() {
        return new CerberSDKApplicationDelegate(AuthorizationMode.CERBER, BuildType.PROM, false,
                true, true, true, false, null, EMPTY, true);
    }

    /**
     * JA-PD-TN-1. Одиннадцать аргументов: десятый false, одиннадцатый true.
     * Молчание обязательно. До правки шаблон читал последний аргумент и здесь
     * давал ложную.
     */
    CerberSDKApplicationDelegate elevenArgs() {
        return new CerberSDKApplicationDelegate(AuthorizationMode.CERBER, BuildType.PROM, false,
                true, true, true, false, null, EMPTY, false, true);
    }

    /** JA-PD-TN-2. Десять аргументов, десятый false. Молчание. */
    CerberSDKApplicationDelegate tenArgs() {
        return new CerberSDKApplicationDelegate(AuthorizationMode.CERBER, BuildType.PROM, false,
                true, true, true, false, null, EMPTY, false);
    }
}
