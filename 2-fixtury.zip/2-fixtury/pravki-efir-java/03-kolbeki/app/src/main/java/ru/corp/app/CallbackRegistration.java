package ru.corp.app;

import java.util.Collections;
import java.util.List;
import ru.sberbank.cerbersdk.sdk_framework.CerberCallbacks;
import ru.sberbank.cerbersdk.sdk_framework.CerberSDKApplicationDelegate;
import ru.sberbank.cerbersdk.sdk_framework.Uri;

/** JA-CB callbacks-not-set. Правило обратной логики: ценность в молчании. */
public class CallbackRegistration {

    private final CerberSDKApplicationDelegate delegate = new CerberSDKApplicationDelegate();

    /** JA-CB-TP-1. Регистрация через сеттер на делегате. */
    void registerViaSetter() {
        delegate.setCerberCallbacks(new RealCallbacks());
    }

    /**
     * JA-CB-TN-1. Объявление реализации без регистрации. Молчание: правило
     * отмечает регистрацию, а не наличие класса-реализации.
     */
    static class RealCallbacks implements CerberCallbacks {
        @Override public void onFileReceived(Uri uri, String callingPackage) { }
        @Override public void onLogout() { }
        @Override public void onNoAuthDetected() { }
        @Override public void onRootDetected() { }
        @Override public void onSuccessPaoAuth() { }
        @Override public void onSuccessPaoEnter() { }
        @Override public void onUserChanged() { }
        @Override public List<String> provideSpaceIds() { return Collections.emptyList(); }
    }
}
