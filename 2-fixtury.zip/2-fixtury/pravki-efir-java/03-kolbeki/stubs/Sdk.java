package ru.sberbank.cerbersdk.sdk_framework;

import java.util.List;

public interface CerberCallbacks {
    void onFileReceived(Uri uri, String callingPackage);
    void onLogout();
    void onNoAuthDetected();
    void onRootDetected();
    void onSuccessPaoAuth();
    void onSuccessPaoEnter();
    void onUserChanged();
    List<String> provideSpaceIds();
}

class Uri { }

class CerberSDKApplicationDelegate {
    private CerberCallbacks cerberCallbacks;

    void setCerberCallbacks(CerberCallbacks callbacks) { this.cerberCallbacks = callbacks; }
}
