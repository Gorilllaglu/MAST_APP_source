package android.net;

public class Uri {
    public String getPath() { return ""; }
}
