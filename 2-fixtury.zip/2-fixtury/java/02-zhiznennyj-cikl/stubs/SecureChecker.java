package ru.sberbank.cerbersdk.sdk_framework;

public class SecureChecker {
    public SecureCheck performChecks() {
        return SecureCheck.DEVICE_COMPLIANT;
    }
}
