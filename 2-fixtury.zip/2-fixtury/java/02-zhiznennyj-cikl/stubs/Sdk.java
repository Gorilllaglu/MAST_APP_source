package ru.sberbank.cerbersdk.sdk_framework;

import android.net.Uri;

public interface CerberCallbacks {
    void onLogout();
    void onUserChanged();
    void onNoAuthDetected();
    void onRootDetected();
    void onFileReceived(Uri uri, String callingPackage);
}
