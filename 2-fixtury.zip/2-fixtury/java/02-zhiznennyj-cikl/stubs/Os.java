package android.os;

public class Process {
    public static int myPid() { return 0; }
    public static void killProcess(int pid) { }
}
