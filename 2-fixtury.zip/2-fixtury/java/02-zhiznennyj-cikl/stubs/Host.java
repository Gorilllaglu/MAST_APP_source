package ru.corp.app;

import java.io.FileOutputStream;
import java.io.InputStream;

public class Host {
    public static void log(String tag, String msg) { }
}

class ContentResolver {
    InputStream openInputStream(Object uri) { return null; }
}
