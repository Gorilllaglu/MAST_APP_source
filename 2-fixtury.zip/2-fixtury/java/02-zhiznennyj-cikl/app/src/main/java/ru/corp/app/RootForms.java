package ru.corp.app;

import android.net.Uri;
import android.os.Process;
import ru.sberbank.cerbersdk.sdk_framework.CerberCallbacks;

/** JA-RT root-detected-no-termination. Шесть форм завершения и уровни вложенности. */

abstract class RootBase implements CerberCallbacks {
    @Override public void onLogout() {
        Host.log("app", "logout");
    }

    @Override public void onUserChanged() {
        Host.log("app", "user changed");
    }

    @Override public void onNoAuthDetected() {
        Host.log("app", "no auth");
    }

    @Override public void onFileReceived(Uri uri, String callingPackage) {
        Host.log("app", "file from " + callingPackage);
    }

    void finish() { }

    void finishAffinity() { }

    void finishAndRemoveTask() { }
}

/** JA-RT-TP-1. Только запись в журнал. Сработка обязательна. */
class RootLogOnly extends RootBase {
    @Override public void onRootDetected() {
        Host.log("app", "root detected, continuing anyway");
    }
}

/** JA-RT-TN-1. System.exit прямо в теле. */
class RootSystemExit extends RootBase {
    @Override public void onRootDetected() {
        System.exit(1);
    }
}

/** JA-RT-TN-2. Runtime.getRuntime().exit. */
class RootRuntimeExit extends RootBase {
    @Override public void onRootDetected() {
        Runtime.getRuntime().exit(1);
    }
}

/** JA-RT-TN-3. Process.killProcess. */
class RootKillProcess extends RootBase {
    @Override public void onRootDetected() {
        Process.killProcess(Process.myPid());
    }
}

/** JA-RT-TN-4. finish. */
class RootFinish extends RootBase {
    @Override public void onRootDetected() {
        finish();
    }
}

/** JA-RT-TN-5. finishAffinity. */
class RootFinishAffinity extends RootBase {
    @Override public void onRootDetected() {
        finishAffinity();
    }
}

/** JA-RT-TN-6. finishAndRemoveTask. */
class RootFinishAndRemove extends RootBase {
    @Override public void onRootDetected() {
        finishAndRemoveTask();
    }
}

/** JA-RT-TN-7. Завершение внутри if с блоком. */
class RootNestedIf extends RootBase {
    @Override public void onRootDetected() {
        Host.log("app", "root detected");
        if (System.currentTimeMillis() > 0) {
            System.exit(1);
        }
    }
}

/** JA-RT-TN-8. Завершение в ветви else. */
class RootNestedElse extends RootBase {
    @Override public void onRootDetected() {
        if (System.currentTimeMillis() < 0) {
            Host.log("app", "clock skew");
        } else {
            System.exit(1);
        }
    }
}

/** JA-RT-TN-9. Завершение под условием без фигурных скобок. */
class RootBraceless extends RootBase {
    @Override public void onRootDetected() {
        if (System.currentTimeMillis() > 0) System.exit(1);
    }
}

/**
 * JA-RT-PROBE-2. Завершение вынесено в свой метод. Ожидается сработка:
 * правило видит только тело колбэка.
 */
class RootHelper extends RootBase {
    @Override public void onRootDetected() {
        terminate();
    }

    private void terminate() {
        System.exit(1);
    }
}

/**
 * JA-RT-PROBE-3. Завершение на два уровня вложенности. Ожидается молчание:
 * на джава-фронтенде многоточие проходит сквозь вложенные блоки, поэтому
 * исключение на один уровень снимает и эту форму. В котлиновском блоке
 * та же клетка (DL07-TP-1) даёт сработку - там многоточие так не ходит.
 */
class RootDoubleNested extends RootBase {
    @Override public void onRootDetected() {
        if (System.currentTimeMillis() > 0) {
            if (System.nanoTime() > 0) {
                System.exit(1);
            }
        }
    }
}
