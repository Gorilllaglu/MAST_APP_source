package ru.corp.app;

import android.net.Uri;
import android.os.Process;
import ru.sberbank.cerbersdk.sdk_framework.CerberCallbacks;

import java.io.FileOutputStream;
import java.io.InputStream;

/**
 * JA-LG logout-callback-empty
 * JA-NA no-auth-detected-ignored
 * JA-UC user-changed-callback-empty
 * JA-FE file-received-callback-empty
 * JA-FM file-received-no-caller-check (маркер наличия приёмника)
 * JA-FC received-file-not-copied
 * JA-RB root-detection-bypass-attempt
 * JA-RT root-detected-no-termination
 */

/** JA-LG-TP-1, JA-NA-TP-1, JA-UC-TP-1, JA-FE-TP-1, JA-FM-TP-1, JA-RB-TP-1. Все колбэки пусты. */
class EmptyCallbacks implements CerberCallbacks {
    @Override public void onLogout() { }

    @Override public void onUserChanged() { }

    @Override public void onNoAuthDetected() { }

    @Override public void onRootDetected() { }

    @Override public void onFileReceived(Uri uri, String callingPackage) { }
}

/** JA-LG-TP-2, JA-NA-TP-2, JA-UC-TP-2, JA-FE-TP-2. Тело из одного return. */
class ReturnOnlyCallbacks implements CerberCallbacks {
    @Override public void onLogout() {
        return;
    }

    @Override public void onUserChanged() {
        return;
    }

    @Override public void onNoAuthDetected() {
        return;
    }

    @Override public void onRootDetected() {
        Process.killProcess(Process.myPid());
    }

    @Override public void onFileReceived(Uri uri, String callingPackage) {
        return;
    }
}

/**
 * JA-LG-TN-1, JA-NA-TN-1, JA-UC-TN-1, JA-FE-TN-1. Все колбэки с настоящим телом.
 * Молчание по правилам пустоты. По маркеру JA-FM сработка обязательна.
 * JA-FC-TN-1: файл копируется в песочницу.
 */
class RealCallbacks implements CerberCallbacks {
    private String token = "t";
    private final ContentResolver resolver = new ContentResolver();

    @Override public void onLogout() {
        token = null;
    }

    @Override public void onUserChanged() {
        token = null;
        Host.log("app", "user changed");
    }

    @Override public void onNoAuthDetected() {
        Host.log("app", "redirect to login");
    }

    @Override public void onRootDetected() {
        Process.killProcess(Process.myPid());
    }

    @Override public void onFileReceived(Uri uri, String callingPackage) {
        InputStream in = resolver.openInputStream(uri);
        Host.log("app", "copied from " + callingPackage);
    }
}

/** JA-FC-TP-1. Приёмник работает по чужому Uri, копии нет. JA-FM-TP-2. */
class NoCopyReceiver implements CerberCallbacks {
    @Override public void onLogout() {
        Host.log("app", "logout");
    }

    @Override public void onUserChanged() {
        Host.log("app", "user changed");
    }

    @Override public void onNoAuthDetected() {
        Host.log("app", "no auth");
    }

    @Override public void onRootDetected() {
        Process.killProcess(Process.myPid());
    }

    @Override public void onFileReceived(Uri uri, String callingPackage) {
        Host.log("app", uri.getPath());
    }
}

/** JA-FC-TN-2. Копирование через FileOutputStream. */
class OutStreamReceiver implements CerberCallbacks {
    @Override public void onLogout() {
        Host.log("app", "logout");
    }

    @Override public void onUserChanged() {
        Host.log("app", "user changed");
    }

    @Override public void onNoAuthDetected() {
        Host.log("app", "no auth");
    }

    @Override public void onRootDetected() {
        Process.killProcess(Process.myPid());
    }

    @Override public void onFileReceived(Uri uri, String callingPackage) {
        FileOutputStream out = new FileOutputStream("/data/data/ru.corp.app/files/payload");
        Host.log("app", "stored");
    }
}

/**
 * JA-RB-PROBE-1, JA-RT-PROBE-1, JA-FM-TN-1. Объявления в интерфейсе без тела.
 * Исключение pattern-not-inside на interface должно их снять, ожидается
 * молчание по всем трём. Маркер JA-FM до правки давал здесь сработку.
 */
interface HostCallbacksDeclaration {
    void onLogout();

    void onUserChanged();

    void onNoAuthDetected();

    void onRootDetected();

    void onFileReceived(Uri uri, String callingPackage);
}
