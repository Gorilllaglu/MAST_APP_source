package ru.sberbank.cerbersdk.domain.repository;

public interface CerberStoreRepository {
    boolean checkOtherAppSignature(String bundleId);
}
