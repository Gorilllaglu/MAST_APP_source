package android.content.pm;

public class PackageManager {
    public static final int GET_SIGNATURES = 64;
    public static final int GET_SIGNING_CERTIFICATES = 134217728;
    public static final int CERT_INPUT_SHA256 = 1;
    public static final int SIGNATURE_MATCH = 0;

    public PackageInfo getPackageInfo(String pkg, int flags) { return new PackageInfo(); }

    public boolean hasSigningCertificate(String pkg, byte[] cert, int type) { return false; }

    public int checkSignatures(String a, String b) { return SIGNATURE_MATCH; }
}

class PackageInfo {
    public SigningInfo signingInfo;
    public Signature[] signatures;
    public String versionName;
}

class SigningInfo {
    public Signature[] getSigningCertificateHistory() { return new Signature[0]; }
    public Signature[] getApkContentsSigners() { return new Signature[0]; }
    public boolean hasMultipleSigners() { return false; }
}

class Signature {
    public byte[] toByteArray() { return new byte[0]; }
}
