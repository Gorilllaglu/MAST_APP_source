package ru.corp.app;

import android.content.pm.PackageManager;
import ru.sberbank.cerbersdk.domain.repository.CerberStoreRepository;

/** JA-IG app-integrity-check-marker. Обратная логика: ценность в молчании. */

class IntegrityGates {
    private static final String TRUSTED_PKG = "ru.sberbank.sberapps";

    private final PackageManager pm;

    IntegrityGates(PackageManager pm) {
        this.pm = pm;
    }

    /** JA-IG-TP-1. Проверка Цербера через хранилище. */
    boolean cerberCheck(CerberStoreRepository store, String callingPackage) {
        return store.checkOtherAppSignature(callingPackage);
    }

    /** JA-IG-TP-2. Платформенная проверка по отпечатку. */
    boolean platformHasCertificate(String callingPackage, byte[] expected) {
        return pm.hasSigningCertificate(callingPackage, expected, PackageManager.CERT_INPUT_SHA256);
    }

    /** JA-IG-TP-3. Платформенное сравнение подписей двух пакетов. */
    boolean platformCompare(String callingPackage, String ownPackage) {
        return pm.checkSignatures(callingPackage, ownPackage) == PackageManager.SIGNATURE_MATCH;
    }

    /** JA-IG-TP-4. Чтение подписи современным флагом. */
    int platformReadModern(String callingPackage) {
        return pm.getPackageInfo(callingPackage, PackageManager.GET_SIGNING_CERTIFICATES)
                .signingInfo.getSigningCertificateHistory().length;
    }

    /** JA-IG-TP-5. Чтение подписи устаревшим флагом. */
    int platformReadLegacy(String callingPackage) {
        return pm.getPackageInfo(callingPackage, PackageManager.GET_SIGNATURES).signatures.length;
    }

    /**
     * JA-IG-TP-6. Многострочная запись вызова. Форма снята с исходников
     * SignatureRepository из SberApps.
     */
    int platformReadMultiline(String callingPackage) {
        return pm.getPackageInfo(
                callingPackage,
                PackageManager.GET_SIGNING_CERTIFICATES
        ).signingInfo.getApkContentsSigners().length;
    }

    /** JA-IG-TN-1. Пакет читается без флага подписи: это не проверка целостности. */
    String readVersionOnly(String callingPackage) {
        return pm.getPackageInfo(callingPackage, 0).versionName;
    }

    /** JA-IG-TN-2. Доверие по имени пакета. Ровно то, что правило не должно принимать за проверку. */
    boolean trustByName(String callingPackage) {
        return TRUSTED_PKG.equals(callingPackage);
    }

    /**
     * JA-IG-PROBE-1. Свой метод с именем checkSignatures на постороннем объекте.
     * Ожидается сработка, ложная. Это цена формы без получателя.
     */
    boolean ownCheckSignatures(DocumentValidator validator, String a, String b) {
        return validator.checkSignatures(a, b) == 0;
    }
}

class DocumentValidator {
    int checkSignatures(String a, String b) { return 0; }
}
