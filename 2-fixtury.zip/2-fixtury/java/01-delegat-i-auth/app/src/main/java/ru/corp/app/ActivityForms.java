package ru.corp.app;

/**
 * JA-AR activity-missing-auth-onresume
 * JA-LC activity-no-lifecycle-override
 * JA-OB auth-requested-but-not-observed
 */

/** JA-AR-TP-1. onResume переопределён, авторизация не запрашивается. */
class ProfileActivity extends AppCompatActivity {
    @Override public void onResume() {
        super.onResume();
        Host.log("profile", "resumed");
    }
}

/** JA-AR-TP-2. То же на фрагменте. */
class SettingsFragment extends AppCompatActivity {
    @Override public void onResume() {
        super.onResume();
    }
}

/** JA-AR-TN-1. Авторизация запрашивается в onResume. Молчание. */
class PaymentActivity extends AppCompatActivity {
    @Override public void onResume() {
        super.onResume();
        Host.requestCerberAuth(PaymentActivity.this);
    }
}

/** JA-LC-TP-1. onResume не переопределён вовсе. */
class ReportsActivity extends AppCompatActivity {
    void load() {
        Host.log("reports", "load");
    }
}

/** JA-LC-TP-2. Экран без тела метода жизненного цикла, с интерфейсом. */
class OrdersActivity extends AppCompatActivity implements AnalyticsHost {
    @Override public void trackScreen(String name) { }
}

/** JA-LC-TN-1. onResume переопределён. Молчание по этому правилу. */
class CardsActivity extends AppCompatActivity {
    @Override public void onResume() {
        super.onResume();
        Host.requestCerberAuth(this);
    }
}

/**
 * JA-OB-TP-1. Авторизация запрошена, за состоянием никто не следит.
 * Получатель записан как HistoryActivity.this, чтобы текст оператора не
 * совпал с клеткой JA-LC-TN-1: находки с одинаковым текстом внутри файла
 * движок схлопывает в одну.
 */
class HistoryActivity extends AppCompatActivity {
    @Override public void onResume() {
        super.onResume();
        Host.requestCerberAuth(HistoryActivity.this);
    }
}

/** JA-OB-TN-1. Запрос и наблюдение в одном классе. Молчание. */
class StatementActivity extends AppCompatActivity {
    @Override public void onResume() {
        super.onResume();
        Host.requestCerberAuth(StatementActivity.this);
        Host.observeAuthState(StatementActivity.this);
    }
}
