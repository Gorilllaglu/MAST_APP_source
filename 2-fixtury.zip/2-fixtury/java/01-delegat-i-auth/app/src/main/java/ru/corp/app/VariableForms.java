package ru.corp.app;

import ru.sberbank.cerbersdk.sdk_framework.CerberSDKApplication;
import ru.sberbank.cerbersdk.sdk_framework.CerberSDKApplicationDelegate;
import ru.sberbank.cerbersdk.sdk_framework.CerberSdk.AuthorizationMode;
import ru.sberbank.cerbersdk.sdk_framework.CerberSdk.BuildType;

/**
 * JA-AV insecure-auth-mode-variable
 * JA-BV non-production-build-type-variable
 * JA-M  missing-delegate-creation
 */

/** JA-AV-TP-1. Режим авторизации объявлен переменной. */
class AuthModeHolder {
    static AuthorizationMode mode = AuthorizationMode.NONE;
}

/** JA-AV-TP-2. Режим приходит возвратом метода. */
class AuthModeFactory {
    static AuthorizationMode resolve() {
        return AuthorizationMode.LEGACY;
    }
}

/** JA-AV-TP-3. Режим выбирается условием. */
class AuthModeChooser {
    static AuthorizationMode pick(boolean prom) {
        return prom ? AuthorizationMode.CERBER : AuthorizationMode.NONE;
    }
}

/** JA-AV-TN-1. Режим всегда CERBER, объявлен константой. Молчание. */
class AuthModeConstant {
    static final AuthorizationMode MODE = AuthorizationMode.CERBER;
}

/** JA-BV-TP-1. Тип сборки объявлен переменной. */
class BuildTypeHolder {
    static BuildType type = BuildType.DEV2;
}

/** JA-BV-TP-2. Тип сборки возвратом метода. */
class BuildTypeFactory {
    static BuildType resolve() {
        return BuildType.PSI;
    }
}

/** JA-BV-TN-1. Тип сборки всегда PROM. Молчание. */
class BuildTypeConstant {
    static final BuildType TYPE = BuildType.PROM;
}

/** JA-M-TP-1. Делегат получен из внешнего источника, не создан на месте. */
class InjectedDelegateApplication extends Application implements CerberSDKApplication {
    CerberSDKApplicationDelegate delegate = DelegateVault.INSTANCE;

    @Override public void initializeSdk() { }
}

/** JA-M-TP-2. Делегат из статической фабрики. */
class FactoryDelegateApplication extends Application implements CerberSDKApplication {
    CerberSDKApplicationDelegate delegate = DelegateVault.provide();

    @Override public void initializeSdk() { }
}

/** JA-M-TP-3. Делегат из геттера поля другого класса. */
class HolderDelegateApplication extends Application implements CerberSDKApplication {
    CerberSDKApplicationDelegate delegate = DelegateVault.getShared();

    @Override public void initializeSdk() { }
}

/** JA-M-TN-1. Делегат создан на месте с явными параметрами. Молчание. */
class FreshDelegateApplication extends Application implements CerberSDKApplication {
    CerberSDKApplicationDelegate delegate = new CerberSDKApplicationDelegate(
            AuthorizationMode.CERBER, BuildType.PROM, false, true, true, true, false,
            null, null, false);

    @Override public void initializeSdk() { }
}

class DelegateVault {
    static final CerberSDKApplicationDelegate INSTANCE = new CerberSDKApplicationDelegate(
            AuthorizationMode.CERBER, BuildType.PROM, false, true, true, true, false,
            null, null, false);

    static CerberSDKApplicationDelegate provide() {
        return INSTANCE;
    }

    static CerberSDKApplicationDelegate getShared() {
        return INSTANCE;
    }
}
