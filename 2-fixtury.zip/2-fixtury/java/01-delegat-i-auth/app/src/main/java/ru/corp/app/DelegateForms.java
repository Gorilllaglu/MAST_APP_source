package ru.corp.app;

import ru.sberbank.cerbersdk.sdk_framework.CerberSDKApplication;
import ru.sberbank.cerbersdk.sdk_framework.CerberSDKApplicationDelegate;
import ru.sberbank.cerbersdk.sdk_framework.CerberSdk.AuthorizationMode;
import ru.sberbank.cerbersdk.sdk_framework.CerberSdk.BuildType;

/**
 * Конструктор делегата. Порядок аргументов:
 * (mode, buildType, isolated, secureInitialCheck, secureScreen, secureClipboard,
 *  testPinning, sberMagOptions, whiteListOptions, disablePasswordlessAuth)
 *
 * JA-D  default-constructor-used
 * JA-IC secure-initial-check-disabled
 * JA-SC insecure-screen-disabled
 * JA-CB insecure-clipboard-disabled
 * JA-PW passwordless-auth-disabled
 * JA-AM insecure-auth-mode
 * JA-BT non-production-build-type
 * JA-I  missing-sdk-application-interface
 */

/** JA-D-TP-1. Конструктор без аргументов: все защиты выключены по умолчанию. */
class DefaultCtorApplication extends Application implements CerberSDKApplication {
    CerberSDKApplicationDelegate delegate = new CerberSDKApplicationDelegate();

    @Override public void initializeSdk() { }
}

/** JA-IC-TP-1. secureInitialCheck=false литералом. */
class InitialCheckOffApplication extends Application implements CerberSDKApplication {
    CerberSDKApplicationDelegate delegate = new CerberSDKApplicationDelegate(
            AuthorizationMode.CERBER, BuildType.PROM, false, false, true, true, false,
            null, null, false);

    @Override public void initializeSdk() { }
}

/** JA-SC-TP-1. secureScreen=false литералом. */
class ScreenOffApplication extends Application implements CerberSDKApplication {
    CerberSDKApplicationDelegate delegate = new CerberSDKApplicationDelegate(
            AuthorizationMode.CERBER, BuildType.PROM, false, true, false, true, false,
            null, null, false);

    @Override public void initializeSdk() { }
}

/** JA-CB-TP-1. secureClipboard=false литералом. */
class ClipboardOffApplication extends Application implements CerberSDKApplication {
    CerberSDKApplicationDelegate delegate = new CerberSDKApplicationDelegate(
            AuthorizationMode.CERBER, BuildType.PROM, false, true, true, false, false,
            null, null, false);

    @Override public void initializeSdk() { }
}

/** JA-PW-TP-1. disablePasswordlessAuth=true, последний аргумент. */
class PasswordlessOffApplication extends Application implements CerberSDKApplication {
    CerberSDKApplicationDelegate delegate = new CerberSDKApplicationDelegate(
            AuthorizationMode.CERBER, BuildType.PROM, false, true, true, true, false,
            null, null, true);

    @Override public void initializeSdk() { }
}

/** JA-AM-TP-1. Режим авторизации не CERBER. */
class AuthModeNoneApplication extends Application implements CerberSDKApplication {
    CerberSDKApplicationDelegate delegate = new CerberSDKApplicationDelegate(
            AuthorizationMode.NONE, BuildType.PROM, false, true, true, true, false,
            null, null, false);

    @Override public void initializeSdk() { }
}

/** JA-AM-TP-2. Режим EXTERNAL. */
class AuthModeExternalApplication extends Application implements CerberSDKApplication {
    CerberSDKApplicationDelegate delegate = new CerberSDKApplicationDelegate(
            AuthorizationMode.EXTERNAL, BuildType.PROM, false, true, true, true, false,
            null, null, false);

    @Override public void initializeSdk() { }
}

/** JA-BT-TP-1. Непродуктовый тип сборки DEV1. */
class Dev1Application extends Application implements CerberSDKApplication {
    CerberSDKApplicationDelegate delegate = new CerberSDKApplicationDelegate(
            AuthorizationMode.CERBER, BuildType.DEV1, false, true, true, true, false,
            null, null, false);

    @Override public void initializeSdk() { }
}

/** JA-BT-TP-2. Непродуктовый тип сборки IFT. */
class IftApplication extends Application implements CerberSDKApplication {
    CerberSDKApplicationDelegate delegate = new CerberSDKApplicationDelegate(
            AuthorizationMode.CERBER, BuildType.IFT, false, true, true, true, false,
            null, null, false);

    @Override public void initializeSdk() { }
}

/**
 * Эталон. Все защиты включены, режим и тип сборки продуктовые.
 * JA-IC-TN-1, JA-SC-TN-1, JA-CB-TN-1, JA-PW-TN-1, JA-AM-TN-1, JA-BT-TN-1, JA-D-TN-1.
 * Молчание по всем семи правилам.
 */
class SecureApplication extends Application implements CerberSDKApplication {
    CerberSDKApplicationDelegate delegate = new CerberSDKApplicationDelegate(
            AuthorizationMode.CERBER, BuildType.PROM, false, true, true, true, false,
            null, null, false);

    @Override public void initializeSdk() { }
}

/** JA-I-TP-1. Наследует Application, интерфейс SDK не реализует. */
class PlainApplication extends Application {
    void onCreateStub() {
        Host.log("app", "no cerber");
    }
}

/** JA-I-TP-2. Интерфейс есть, но не церберовский. */
class AnalyticsOnlyApplication extends Application implements AnalyticsHost {
    @Override public void trackScreen(String name) { }
}

/** JA-I-TN-1. Интерфейс реализован напрямую. Молчание. */
class IntegratedApplication extends Application implements CerberSDKApplication {
    CerberSDKApplicationDelegate delegate = new CerberSDKApplicationDelegate(
            AuthorizationMode.CERBER, BuildType.PROM, false, true, true, true, false,
            null, null, false);

    @Override public void initializeSdk() { }
}

/** JA-I-TN-2. Два интерфейса, церберовский второй. Молчание. */
class MixedApplication extends Application implements AnalyticsHost, CerberSDKApplication {
    @Override public void trackScreen(String name) { }

    @Override public void initializeSdk() { }
}

/**
 * JA-I-PROBE-1. Класс не наследует Application. Ожидается молчание:
 * правило построено на наследовании.
 */
class NotAnApplication {
    void doWork() {
        Host.log("app", "plain class");
    }
}

interface AnalyticsHost {
    void trackScreen(String name);
}
