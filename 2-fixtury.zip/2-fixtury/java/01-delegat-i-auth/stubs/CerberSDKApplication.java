package ru.sberbank.cerbersdk.sdk_framework;

public interface CerberSDKApplication {
    void initializeSdk();
}
