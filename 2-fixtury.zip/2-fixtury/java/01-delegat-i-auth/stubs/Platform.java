package ru.corp.app;

public class Platform {
    public static class Application { }
    public static class AppCompatActivity {
        public void onResume() { }
        public void onPause() { }
        public void onCreate(Object state) { }
    }
}
