package ru.sberbank.cerbersdk.sdk_framework;

import ru.sberbank.cerbersdk.sdk_framework.CerberSdk.AuthorizationMode;
import ru.sberbank.cerbersdk.sdk_framework.CerberSdk.BuildType;

/**
 * Порядок аргументов снят с декомпиляции SDK:
 * (authorizationMode, buildType, isolated, secureInitialCheck, secureScreen,
 *  secureClipboard, enableTestServerPinning, sberMagOptions, whiteListOptions,
 *  disablePasswordlessAuth)
 */
public class CerberSDKApplicationDelegate implements CerberSDKApplication {
    public CerberSDKApplicationDelegate() { }

    public CerberSDKApplicationDelegate(AuthorizationMode mode, BuildType buildType,
            boolean isolated, boolean secureInitialCheck, boolean secureScreen,
            boolean secureClipboard, boolean enableTestServerPinning,
            Object sberMagOptions, Object whiteListOptions, boolean disablePasswordlessAuth) { }

    @Override public void initializeSdk() { }
}
