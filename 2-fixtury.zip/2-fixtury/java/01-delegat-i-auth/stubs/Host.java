package ru.corp.app;

public class Host {
    public static void requestCerberAuth(Object target) { }
    public static void observeAuthState(Object cb) { }
    public static void log(String tag, String msg) { }
}

class Application { }

class AppCompatActivity {
    public void onResume() { }
    public void onPause() { }
    public void onCreate(Object state) { }
    public void finish() { }
}

class BuildConfig {
    public static final boolean DEBUG = false;
    public static final String FLAVOR = "promDef";
}
