package ru.sberbank.cerbersdk.sdk_framework;

public final class CerberSdk {
    public enum AuthorizationMode { CERBER, NONE, EXTERNAL, LEGACY }
    public enum BuildType { PROM, DEV1, DEV2, IFT, PSI }
}
