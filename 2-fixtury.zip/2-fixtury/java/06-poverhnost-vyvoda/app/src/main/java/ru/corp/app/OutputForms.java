package ru.corp.app;

import android.content.Context;
import android.content.Intent;
import android.widget.TextView;
import ru.corp.stubs.Environment;
import ru.corp.stubs.InputType;
import ru.corp.stubs.MediaStore;
import ru.corp.stubs.PasswordTransformationMethod;
import ru.corp.stubs.PrintHelper;
import ru.corp.stubs.ShareCompat;
import ru.corp.stubs.WebView;

import java.io.File;

/**
 * JA-SH system-share-channel
 * JA-ES external-storage-export
 * JA-PR print-channel
 * JA-PN host-pin-screen
 * JA-WV webview-selection-unrestricted
 */

class OutputChannels {
    private final Context ctx = new Context();

    /** JA-SH-TP-1. Шаринг через константу действия. */
    Intent share() {
        return new Intent(Intent.ACTION_SEND);
    }

    /** JA-SH-TP-2. Шаринг строковым литералом действия. */
    Intent shareLiteral() {
        return new Intent("android.intent.action.SEND");
    }

    /** JA-SH-TP-3. Диалог выбора. */
    Intent chooser(Intent target) {
        return Intent.createChooser(target, "Share");
    }

    /** JA-SH-TP-4. Установка действия сеттером. */
    void setShareAction(Intent intent) {
        intent.setAction(Intent.ACTION_SEND);
    }

    /** JA-SH-TP-5. Вложение через EXTRA_STREAM. */
    void attach(Intent intent, Object uri) {
        intent.putExtra(Intent.EXTRA_STREAM, uri);
    }

    /** JA-SH-TP-6. Сборка через ShareCompat. */
    Object shareCompat() {
        return ShareCompat.IntentBuilder.from(this);
    }

    /** JA-SH-TN-1. Просмотр, а не отправка. Молчание. */
    Intent view() {
        return new Intent(Intent.ACTION_VIEW);
    }

    /** JA-ES-TP-1. Каталог приложения во внешней памяти. */
    File externalAppDir() {
        return ctx.getExternalFilesDir(null);
    }

    /** JA-ES-TP-2. Общая память. */
    File sharedStorage() {
        return Environment.getExternalStorageDirectory();
    }

    /** JA-ES-TP-3. Медиа-коллекция. */
    Object mediaCollection() {
        return MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
    }

    /** JA-ES-TP-4. Литеральный путь в общую память. */
    File sdcardPath() {
        return new File("/sdcard/statement.pdf");
    }

    /** JA-ES-TP-5. Выбор места пользователем через SAF. */
    Intent createDocument() {
        return new Intent(Intent.ACTION_CREATE_DOCUMENT);
    }

    /** JA-ES-TN-1. Внутренний каталог приложения. Молчание. */
    File internalDir() {
        return new File("/data/data/ru.corp.app/files");
    }

    /** JA-PR-TP-1. Печать картинки. */
    void printReceipt(Object bitmap) {
        new PrintHelper(ctx).printBitmap("receipt", bitmap);
    }

    /** JA-PR-TP-2. Печать из WebView. */
    Object printWebView(WebView view) {
        return view.createPrintDocumentAdapter("document");
    }

    /** JA-PR-TP-3. Служба печати по константе, с получателем. */
    Object printService() {
        return ctx.getSystemService(Context.PRINT_SERVICE);
    }

    /** JA-PN-TP-1. Числовой пароль установкой типа ввода. */
    void setupPin(TextView view) {
        view.setInputType(InputType.TYPE_NUMBER_VARIATION_PASSWORD);
    }

    /** JA-PN-TP-2. Маскирование ввода методом преобразования. */
    void maskInput(TextView view) {
        view.setTransformationMethod(PasswordTransformationMethod.getInstance());
    }

    /** JA-PN-TN-1. Обычный числовой ввод без маскирования. Молчание. */
    void setupAmount(TextView view) {
        view.setInputType(InputType.TYPE_CLASS_NUMBER);
    }

    /** JA-WV-TP-1. Загрузка по адресу, меню выделения не ограничено. */
    void loadStatement(WebView view, String url) {
        view.loadUrl(url);
    }

    /** JA-WV-TP-2. Загрузка готового содержимого. */
    void loadHtml(WebView view, String html) {
        view.loadData(html, "text/html", "utf-8");
    }

    /** JA-WV-TN-1. Маска пунктов меню выставлена. Молчание. */
    void loadRestricted(WebView view, String url) {
        view.getSettings().setDisabledActionModeMenuItems(7);
        view.loadUrl(url);
    }

    /** JA-WV-TN-2. Выделение снято через долгое нажатие. Молчание. */
    void loadNoLongClick(WebView view, String url) {
        view.setLongClickable(false);
        view.loadUrl(url);
    }
}
