package android.widget;

public class TextView {
    public void setTextIsSelectable(boolean value) { }
    public void setCustomSelectionActionModeCallback(Object cb) { }
    public void setCustomInsertionActionModeCallback(Object cb) { }
    public void setInputType(int type) { }
    public void setTransformationMethod(Object method) { }
    public void setLongClickable(boolean value) { }
    public void setOnLongClickListener(Object listener) { }
    public boolean startDragAndDrop(Object data, Object shadow, Object local, int flags) { return true; }
    public boolean startDrag(Object data, Object shadow, Object local, int flags) { return true; }
}
