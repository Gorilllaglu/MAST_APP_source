package ru.sberbank.cerbersdk.sdk_framework;

public class CerberCopyPasteBuffer {
    public enum WriteResult { SUCCESS, TRUNCATED, FAILURE }

    public static WriteResult write(String data) { return WriteResult.SUCCESS; }

    public static String read() { return ""; }
}

class AllowedTextActionsCallBack {
    public static final AllowedTextActionsCallBack INSTANCE = new AllowedTextActionsCallBack();
}
