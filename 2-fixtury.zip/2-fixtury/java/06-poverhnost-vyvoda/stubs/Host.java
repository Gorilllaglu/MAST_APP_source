package ru.corp.app;

public class Host {
    public static void log(String tag, String msg) { }

    public static void show(String message) { }
}
