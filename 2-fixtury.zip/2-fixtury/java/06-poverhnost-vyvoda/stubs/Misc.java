package ru.corp.stubs;

public class PrintHelper {
    public PrintHelper(Object ctx) { }

    public void printBitmap(String name, Object bitmap) { }
}

class PrintManager {
    public void print(String name, Object adapter, Object attrs) { }
}

class WebView {
    public void loadUrl(String url) { }
    public void loadData(String data, String mime, String encoding) { }
    public void loadDataWithBaseURL(String base, String data, String mime, String enc, String hist) { }
    public Object createPrintDocumentAdapter(String name) { return null; }
    public WebSettings getSettings() { return new WebSettings(); }
    public void setLongClickable(boolean value) { }
    public void setOnLongClickListener(Object listener) { }
}

class WebSettings {
    public void setDisabledActionModeMenuItems(int mask) { }
}

class MediaStore {
    public static class Images {
        public static class Media {
            public static final Object EXTERNAL_CONTENT_URI = new Object();
            public static Object insertImage(Object r, Object b, String t, String d) { return null; }
        }
    }

    public static class Downloads {
        public static final Object EXTERNAL_CONTENT_URI = new Object();
    }

    public static class Files {
        public static Object getContentUri(String volume) { return null; }
    }
}

class Environment {
    public static java.io.File getExternalStorageDirectory() { return null; }
    public static java.io.File getExternalStoragePublicDirectory(String type) { return null; }
}

class ShareCompat {
    public static class IntentBuilder {
        public static IntentBuilder from(Object activity) { return new IntentBuilder(); }

        public IntentBuilder(Object activity) { }

        public IntentBuilder() { }
    }
}

class InputType {
    public static final int TYPE_CLASS_NUMBER = 2;
    public static final int TYPE_NUMBER_VARIATION_PASSWORD = 16;
}

class PasswordTransformationMethod {
    public static PasswordTransformationMethod getInstance() { return new PasswordTransformationMethod(); }
}
