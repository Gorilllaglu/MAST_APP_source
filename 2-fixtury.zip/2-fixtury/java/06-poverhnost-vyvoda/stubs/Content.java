package android.content;

public class Context {
    public static final String CLIPBOARD_SERVICE = "clipboard";
    public static final String PRINT_SERVICE = "print";

    public Object getSystemService(String name) { return null; }
    public Object getSystemService(Class<?> cls) { return null; }
    public java.io.File getExternalFilesDir(String type) { return null; }
    public java.io.File getExternalCacheDir() { return null; }
    public java.io.File[] getExternalFilesDirs(String type) { return null; }
}

class ClipboardManager {
    public void setPrimaryClip(ClipData clip) { }
    public ClipData getPrimaryClip() { return null; }
}

class ClipData {
    public static ClipData newPlainText(CharSequence label, CharSequence text) { return null; }
    public static ClipData newUri(Object resolver, CharSequence label, Object uri) { return null; }
    public static ClipData newIntent(CharSequence label, Intent intent) { return null; }
    public static ClipData newRawUri(CharSequence label, Object uri) { return null; }
}

class Intent {
    public static final String ACTION_SEND = "android.intent.action.SEND";
    public static final String ACTION_SEND_MULTIPLE = "android.intent.action.SEND_MULTIPLE";
    public static final String ACTION_CREATE_DOCUMENT = "android.intent.action.CREATE_DOCUMENT";
    public static final String ACTION_VIEW = "android.intent.action.VIEW";
    public static final String EXTRA_STREAM = "android.intent.extra.STREAM";

    public Intent() { }
    public Intent(String action) { }

    public Intent setAction(String action) { return this; }
    public Intent putExtra(String key, Object value) { return this; }
    public static Intent createChooser(Intent target, CharSequence title) { return target; }
}
