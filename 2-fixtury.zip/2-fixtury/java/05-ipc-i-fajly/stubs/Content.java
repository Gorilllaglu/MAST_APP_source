package android.content;

import android.content.pm.PackageManager;

public class Intent {
    public String getStringExtra(String key) { return null; }
    public Bundle getExtras() { return new Bundle(); }
}

class Bundle {
    public String getString(String key) { return null; }
}

class Context {
    public String getCallingPackage() { return null; }
    public PackageManager getPackageManager() { return new PackageManager(); }
}
