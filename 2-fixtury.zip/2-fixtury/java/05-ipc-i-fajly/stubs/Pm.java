package android.content.pm;

public class PackageManager {
    public static final int GET_SIGNATURES = 64;
    public static final int GET_SIGNING_CERTIFICATES = 134217728;

    public Object getPackageInfo(String pkg, int flags) { return null; }
}
