package ru.corp.app;

import java.io.File;

public class Host {
    public static void log(String tag, String msg) { }
}

class FileProvider {
    static Object getUriForFile(Object ctx, String authority, File file) { return null; }
}

class X509Certificate {
    java.util.Date getNotAfter() { return null; }
    java.util.Date getNotBefore() { return null; }
    void checkValidity() { }
}
