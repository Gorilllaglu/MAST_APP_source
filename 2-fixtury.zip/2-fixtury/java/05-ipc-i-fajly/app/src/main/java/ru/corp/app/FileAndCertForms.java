package ru.corp.app;

import java.io.File;
import java.nio.file.Files;

/**
 * JA-TF transfer-temp-file-not-deleted
 * JA-CE own-certificate-expiry-logic
 */

class TransferFiles {

    /** JA-TF-TP-1. Файл выдан наружу и в той же функции не удалён. */
    Object shareReport() {
        File temp = new File("/data/data/ru.corp.app/cache/report.pdf");
        return FileProvider.getUriForFile(this, "ru.corp.app.files", temp);
    }

    /** JA-TF-TN-1. Файл удалён после выдачи. Молчание. */
    Object shareAndDelete() {
        File temp = new File("/data/data/ru.corp.app/cache/report.pdf");
        Object uri = FileProvider.getUriForFile(this, "ru.corp.app.files", temp);
        temp.delete();
        return uri;
    }

    /** JA-TF-TN-2. Удаление отложено до выхода. Молчание. */
    Object shareAndDeleteOnExit() {
        File temp = new File("/data/data/ru.corp.app/cache/report.pdf");
        Object uri = FileProvider.getUriForFile(this, "ru.corp.app.files", temp);
        temp.deleteOnExit();
        return uri;
    }

    /**
     * JA-TF-PROBE-1. Удаление вынесено в свой метод. Ожидается сработка:
     * правило видит только тело одной функции.
     */
    Object shareAndCleanupLater() {
        File temp = new File("/data/data/ru.corp.app/cache/report.pdf");
        Object uri = FileProvider.getUriForFile(this, "ru.corp.app.files", temp);
        cleanup(temp);
        return uri;
    }

    private void cleanup(File f) {
        f.delete();
    }
}

class CertificateLifecycle {

    /** JA-CE-TP-1. Чтение срока окончания. */
    boolean expired(X509Certificate cert) {
        return cert.getNotAfter().before(new java.util.Date());
    }

    /** JA-CE-TP-2. Чтение срока начала. */
    boolean notYetValid(X509Certificate cert) {
        return cert.getNotBefore().after(new java.util.Date());
    }

    /** JA-CE-TP-3. Проверка срока через checkValidity. */
    void validate(X509Certificate cert) {
        cert.checkValidity();
    }

    /** JA-CE-TN-1. К объекту сертификата обращения нет. Молчание. */
    boolean scheduleReissue(long issuedAt) {
        return System.currentTimeMillis() - issuedAt > 30L * 24 * 3600 * 1000;
    }
}
