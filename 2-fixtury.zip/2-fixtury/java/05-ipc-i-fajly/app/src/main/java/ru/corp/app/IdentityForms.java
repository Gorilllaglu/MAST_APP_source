package ru.corp.app;

import android.content.Bundle;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Binder;

/**
 * JA-IF ipc-identity-fallback-open
 * JA-IP ipc-identity-from-payload
 */

class IdentityChecks {

    /** JA-IF-TP-1. try/catch вокруг Binder.getCallingUid, обработчик не отвергает. */
    boolean trustByUid() {
        try {
            int uid = Binder.getCallingUid();
            return uid == 1000;
        } catch (SecurityException e) {
            Host.log("ipc", "cannot read uid");
            return true;
        }
    }

    /** JA-IF-TP-2. То же вокруг getCallingPackage. */
    boolean trustByPackage(Context ctx) {
        try {
            String pkg = ctx.getCallingPackage();
            return "ru.sberbank.sberapps".equals(pkg);
        } catch (SecurityException e) {
            Host.log("ipc", "cannot read package");
            return true;
        }
    }

    /** JA-IF-TP-3. То же вокруг чтения подписей вызывающего. */
    boolean trustByPackageInfo(Context ctx, String pkg) {
        try {
            Object info = ctx.getPackageManager().getPackageInfo(pkg, PackageManager.GET_SIGNATURES);
            return info != null;
        } catch (RuntimeException e) {
            Host.log("ipc", "cannot read info");
            return true;
        }
    }

    /**
     * JA-IF-TN-4. getPackageInfo с нулевыми флагами: это проверка версии, а не
     * опознание вызывающего. В джаве getPackageInfo бросает проверяемое
     * исключение, поэтому в try/catch он стоит в каждом приложении; правило
     * сужено до флагов чтения подписей именно поэтому. Молчание обязательно.
     */
    long appVersion(Context ctx, String pkg) {
        try {
            Object info = ctx.getPackageManager().getPackageInfo(pkg, 0);
            return info == null ? 0 : 1;
        } catch (RuntimeException e) {
            Host.log("app", "version unknown");
            return 0;
        }
    }

    /** JA-IF-TP-4. Вызов прямо в return, без промежуточной переменной. */
    boolean trustByUidInReturn() {
        try {
            return Binder.getCallingUid() == 1000;
        } catch (SecurityException e) {
            Host.log("ipc", "cannot read uid");
            return true;
        }
    }

    /** JA-IF-TP-5. Вызов в условии. */
    boolean trustByUidInCondition() {
        try {
            if (Binder.getCallingUid() == 1000) {
                return true;
            }
        } catch (SecurityException e) {
            Host.log("ipc", "cannot read uid");
        }
        return true;
    }

    /** JA-IF-TN-1. Исключение переброшено. Молчание. */
    boolean rethrow() {
        try {
            return Binder.getCallingUid() == 10123;
        } catch (SecurityException e) {
            throw e;
        }
    }

    /** JA-IF-TN-2. Отказ возвратом false. Молчание. */
    boolean denyOnError() {
        try {
            return Binder.getCallingUid() == 10234;
        } catch (SecurityException e) {
            return false;
        }
    }

    /** JA-IF-TN-3. Отказ возвратом null. Молчание. */
    String denyWithNull(Context ctx) {
        try {
            return ctx.getCallingPackage();
        } catch (SecurityException e) {
            return null;
        }
    }

    /** JA-IP-TP-1. Идентичность из полезной нагрузки по говорящему ключу. */
    String callerFromIntent(Intent intent) {
        return intent.getStringExtra("caller_package");
    }

    /** JA-IP-TP-2. То же из Bundle. */
    String callerFromBundle(Bundle bundle) {
        return bundle.getString("calling_package");
    }

    /** JA-IP-TP-3. То же через getExtras. */
    String senderFromExtras(Intent intent) {
        return intent.getExtras().getString("sender");
    }

    /** JA-IP-TN-1. Ключ не об идентификации. Молчание. */
    String documentId(Intent intent) {
        return intent.getStringExtra("document_id");
    }

    /**
     * JA-IP-PROBE-1. Нейтральное имя ключа. Ожидается пропуск:
     * правило опознаёт дефект по имени ключа, перечень имён конечен.
     */
    String callerUnderNeutralKey(Intent intent) {
        return intent.getStringExtra("x_origin");
    }
}
