package ru.sberbank.cerbersdk.sdk_framework;

import okhttp3.Interceptor;

public class CerberPinningRetryInterceptor implements Interceptor { }

class TrustedComponentsPinningInterceptor implements Interceptor { }

class NetworkSelectRepository {
    public Interceptor getPinningInterceptor() { return new CerberPinningRetryInterceptor(); }
}

class NetworkUtils {
    public static Object getDefaultOkHttpClient() { return null; }
}
