package okhttp3;

public class OkHttpClient {
    public OkHttpClient() { }

    public static class Builder {
        public Builder addInterceptor(Interceptor i) { return this; }
        public Builder addNetworkInterceptor(Interceptor i) { return this; }
        public Builder connectTimeout(long t, Object unit) { return this; }
        public OkHttpClient build() { return new OkHttpClient(); }
    }
}

interface Interceptor { }
