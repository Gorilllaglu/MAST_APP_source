package ru.corp.app;

import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import ru.sberbank.cerbersdk.sdk_framework.CerberPinningRetryInterceptor;
import ru.sberbank.cerbersdk.sdk_framework.NetworkSelectRepository;
import ru.sberbank.cerbersdk.sdk_framework.TrustedComponentsPinningInterceptor;

import java.util.concurrent.TimeUnit;

/** JA-OK direct-okhttp-client. */

class ClientFactory {
    private final NetworkSelectRepository repo = new NetworkSelectRepository();

    private Interceptor getPinningInterceptor() {
        return new CerberPinningRetryInterceptor();
    }

    /** JA-OK-TP-1. Клиент без пиннинга вовсе. */
    OkHttpClient plain() {
        return new OkHttpClient.Builder().build();
    }

    /** JA-OK-TP-2. Конструктор клиента напрямую. */
    OkHttpClient constructed() {
        return new OkHttpClient();
    }

    /** JA-OK-TP-3. Пиннинг прикладным интерцептором, а не сетевым. */
    OkHttpClient appInterceptor() {
        return new OkHttpClient.Builder()
                .addInterceptor(new CerberPinningRetryInterceptor())
                .build();
    }

    /**
     * JA-OK-TP-4. Прикладной интерцептор из репозитория. Сборка записана в
     * одну строку намеренно: при переносе первая строка совпадает с клеткой
     * JA-OK-TP-3, а находки с одинаковым текстом внутри файла движок
     * схлопывает в одну.
     */
    OkHttpClient appInterceptorFromRepo() {
        return new OkHttpClient.Builder().addInterceptor(repo.getPinningInterceptor()).build();
    }

    /** JA-OK-TP-5. Сетевой интерцептор, но аргумент переменная. */
    OkHttpClient networkWithVariable(Interceptor logging) {
        return new OkHttpClient.Builder().addNetworkInterceptor(logging).build();
    }

    /** JA-OK-TP-6. Корректный пиннинг в другой функции того же класса. */
    OkHttpClient unpinnedNeighbour() {
        return new OkHttpClient.Builder().connectTimeout(30, TimeUnit.SECONDS).build();
    }

    /** JA-OK-TN-1. Сетевой интерцептор с интерцептором SDK. Молчание. */
    OkHttpClient pinnedCerber() {
        return new OkHttpClient.Builder()
                .addNetworkInterceptor(new CerberPinningRetryInterceptor())
                .build();
    }

    /** JA-OK-TN-2. Сетевой интерцептор из репозитория. Молчание. */
    OkHttpClient pinnedFromRepo() {
        return new OkHttpClient.Builder()
                .addNetworkInterceptor(repo.getPinningInterceptor())
                .build();
    }

    /** JA-OK-TN-3. Сетевой интерцептор из своего метода. Молчание. */
    OkHttpClient pinnedFromMethod() {
        return new OkHttpClient.Builder()
                .addNetworkInterceptor(getPinningInterceptor())
                .build();
    }

    /** JA-OK-TN-4. Сетевой интерцептор доверенных компонентов. Молчание. */
    OkHttpClient pinnedTrusted() {
        return new OkHttpClient.Builder()
                .addNetworkInterceptor(new TrustedComponentsPinningInterceptor())
                .build();
    }

    /**
     * JA-OK-PROBE-1. Сборка разорвана на три оператора, пиннинг правильный.
     * Ожидается молчание: исключение привязано к функции.
     */
    OkHttpClient splitCorrect() {
        OkHttpClient.Builder builder = new OkHttpClient.Builder();
        builder.addNetworkInterceptor(new CerberPinningRetryInterceptor());
        return builder.build();
    }

    /** JA-OK-PROBE-2. Та же разорванная сборка без пиннинга. Контроль к PROBE-1. */
    OkHttpClient splitUnpinned() {
        OkHttpClient.Builder builder = new OkHttpClient.Builder();
        builder.connectTimeout(30, TimeUnit.SECONDS);
        return builder.build();
    }
}
