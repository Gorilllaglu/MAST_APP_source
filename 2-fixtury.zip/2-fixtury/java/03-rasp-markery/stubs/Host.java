package ru.corp.app;

import android.view.Window;

public class Host {
    public static void log(String tag, String msg) { }
}

class Activity {
    public Window getWindow() { return new Window(); }
}

class TrustedComponents {
    Object getFromCache() { return null; }

    void download() { }
}

class Delegate {
    TrustedComponents trustedComponents = new TrustedComponents();

    TrustedComponents getTrustedComponents() { return trustedComponents; }
}
