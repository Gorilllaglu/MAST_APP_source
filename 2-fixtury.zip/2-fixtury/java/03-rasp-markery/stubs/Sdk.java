package ru.sberbank.cerbersdk.sdk_framework;

public class DebugBypassChecker {
    public static boolean shouldBypassRootEmulatorCheck() { return false; }
    public static boolean shouldBypassSecureScreen() { return false; }
}

interface TrustedComponents {
    Object getFromCache();
    void download();
}
