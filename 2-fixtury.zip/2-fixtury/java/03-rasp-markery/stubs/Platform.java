package android.view;

public class WindowManager {
    public static class LayoutParams {
        public static final int FLAG_SECURE = 8192;
        public static final int FLAG_KEEP_SCREEN_ON = 128;
    }
}

class Window {
    public void addFlags(int flags) { }
    public void clearFlags(int flags) { }
    public void setFlags(int flags, int mask) { }
}
