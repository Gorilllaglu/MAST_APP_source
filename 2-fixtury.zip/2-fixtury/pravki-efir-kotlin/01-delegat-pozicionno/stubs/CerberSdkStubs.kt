package ru.sberbank.cerbersdk.sdk_framework

enum class AuthorizationMode { CERBER, NONE, EXTERNAL, LEGACY }

enum class BuildType { PROM, DEV1, DEV2, IFT, PSI }

enum class DestinationAction { BYPASS, BLOCK }

enum class PolicyFailedAction { BYPASS, BLOCK }

class SberMagOptions(val destination: DestinationAction, val policyFailed: PolicyFailedAction)

class WhiteListOptions(val packages: List<String>)

interface CerberSDKApplication {
    fun initializeSdk()
}

class CerberSDKApplicationDelegate(
    val authorizationMode: AuthorizationMode = AuthorizationMode.CERBER,
    val buildType: BuildType = BuildType.PROM,
    val isolated: Boolean = false,
    val secureInitialCheck: Boolean = false,
    val secureScreen: Boolean = false,
    val secureClipboard: Boolean = false,
    val enableTestServerPinning: Boolean = false,
    val sberMagOptions: SberMagOptions? = null,
    val whiteListOptions: WhiteListOptions = WhiteListOptions(emptyList()),
    val disablePasswordlessAuth: Boolean = false,
    val observeAuthStateWithoutActivity: Boolean = false
) : CerberSDKApplication {
    override fun initializeSdk() {}
}
