package ru.corp.app

import ru.sberbank.cerbersdk.sdk_framework.AuthorizationMode
import ru.sberbank.cerbersdk.sdk_framework.BuildType
import ru.sberbank.cerbersdk.sdk_framework.CerberSDKApplicationDelegate
import ru.sberbank.cerbersdk.sdk_framework.DestinationAction
import ru.sberbank.cerbersdk.sdk_framework.PolicyFailedAction
import ru.sberbank.cerbersdk.sdk_framework.SberMagOptions
import ru.sberbank.cerbersdk.sdk_framework.WhiteListOptions

/**
 * Позиционная форма конструктора делегата. Порядок параметров сверен с метаданными
 * SDK: authorizationMode, buildType, isolated, secureInitialCheck, secureScreen,
 * secureClipboard, enableTestServerPinning, sberMagOptions, whiteListOptions,
 * disablePasswordlessAuth, observeAuthStateWithoutActivity.
 *
 * Параметр isolated стоит третьим и в нормальной интеграции равен false. Шаблоны
 * обязаны не путать его с четвёртым.
 */

private val emptyWhiteList = WhiteListOptions(emptyList())

/** PD-TP-1. secureInitialCheck выключен, четвёртым аргументом. */
fun buildInitCheckOff() = CerberSDKApplicationDelegate(
    AuthorizationMode.CERBER, BuildType.PROM, false, false, true, true, false, null, emptyWhiteList, false
)

/** PD-TP-2. secureScreen выключен, пятым аргументом. */
fun buildScreenOff() = CerberSDKApplicationDelegate(
    AuthorizationMode.CERBER, BuildType.PROM, false, true, false, true, false, null, emptyWhiteList, false
)

/** PD-TP-3. secureClipboard выключен, шестым аргументом. */
fun buildClipboardOff() = CerberSDKApplicationDelegate(
    AuthorizationMode.CERBER, BuildType.PROM, false, true, true, false, false, null, emptyWhiteList, false
)

/** PD-TP-4. disablePasswordlessAuth включён, десятым аргументом. */
fun buildPasswordlessDisabled() = CerberSDKApplicationDelegate(
    AuthorizationMode.CERBER, BuildType.PROM, false, true, true, true, false, null, emptyWhiteList, true
)

/**
 * PD-TP-5. Форма из реального приложения: dev-стенд, выключено всё.
 * Ожидается три сработки: initCheck, screen, clipboard. Плюс сработка правила
 * на нерабочий тип сборки по BuildType.IFT.
 */
fun buildDevDelegate() = CerberSDKApplicationDelegate(
    AuthorizationMode.CERBER, BuildType.IFT, false, false, false, false, false,
    SberMagOptions(DestinationAction.BYPASS, PolicyFailedAction.BYPASS), emptyWhiteList, false
)

/** PD-TN-1. Позиционно, все защиты включены, isolated false. Молчание по всем четырём. */
fun buildPromDelegate() = CerberSDKApplicationDelegate(
    AuthorizationMode.CERBER, BuildType.PROM, false, true, true, true, false, null, emptyWhiteList, false
)

/** PD-TN-2. Именованная форма, всё включено. Молчание. */
fun buildNamedDelegate() = CerberSDKApplicationDelegate(
    authorizationMode = AuthorizationMode.CERBER,
    buildType = BuildType.PROM,
    isolated = false,
    secureInitialCheck = true,
    secureScreen = true,
    secureClipboard = true,
    enableTestServerPinning = false,
    whiteListOptions = emptyWhiteList,
    disablePasswordlessAuth = false
)

/**
 * PD-TN-3. Одиннадцать аргументов: disablePasswordlessAuth false десятым,
 * observeAuthStateWithoutActivity true одиннадцатым. Правило по беспарольному
 * входу обязано молчать: до правки оно читало последний аргумент и здесь
 * ошибалось.
 */
fun buildElevenArgs() = CerberSDKApplicationDelegate(
    AuthorizationMode.CERBER, BuildType.PROM, false, true, true, true, false, null, emptyWhiteList, false, true
)

/**
 * PD-PROBE-1. Пятым аргументом переменная, значение шаблоном не читается.
 * Ожидается сработка ветви «значение не прочитано» у правила по secureScreen.
 */
fun buildScreenFromFlag(screenFlag: Boolean) = CerberSDKApplicationDelegate(
    AuthorizationMode.CERBER, BuildType.PROM, false, true, screenFlag, true, false, null, emptyWhiteList, false
)
