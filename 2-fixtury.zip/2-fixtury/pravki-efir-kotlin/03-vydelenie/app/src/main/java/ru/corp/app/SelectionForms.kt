package ru.corp.app

import android.view.ActionModeCallback
import android.view.AllowedTextActionsCallBack
import android.view.LocalTextToolbar
import android.view.SelectionContainer
import android.view.TextInputEditText
import android.view.TextToolbar

/** SB selection-callback-not-sdk, TT compose-text-selection. */

class SelectionForms {

    /** SB-TP-1. Поставлен свой колбэк выделения. */
    fun setOwnCallback(field: TextInputEditText) {
        field.setCustomSelectionActionModeCallback(ActionModeCallback())
    }

    /** SB-TN-1. Поставлен штатный объект SDK. Молчание. */
    fun setSdkCallback(field: TextInputEditText) {
        field.setCustomSelectionActionModeCallback(AllowedTextActionsCallBack.INSTANCE)
    }

    /**
     * SB-TN-2. Вызван штатный защитный хелпер SDK. Молчание обязательно: до
     * правки disableSharing стоял в положительных шаблонах, и приложение,
     * вызвавшее предписанную защиту, получало находку высокой критичности.
     */
    fun disableSharingOnField(field: TextInputEditText) {
        field.disableSharing()
    }

    /** TT-TP-1. Выделение включено в области Compose. */
    fun selectableScope() {
        SelectionContainer {
            renderText()
        }
    }

    /**
     * TT-TP-2. Подмена панели текста Compose. Сработка по делу: подмена может
     * и убирать пункт копирования, и возвращать его, и что именно - видно
     * только в месте подмены.
     */
    fun installToolbar(own: TextToolbar): Any = LocalTextToolbar provides own

    /** TT-TN-1. Чтение панели без подмены. Молчание. */
    fun readToolbar(): TextToolbar = LocalTextToolbar.current

    private fun renderText() {}
}
