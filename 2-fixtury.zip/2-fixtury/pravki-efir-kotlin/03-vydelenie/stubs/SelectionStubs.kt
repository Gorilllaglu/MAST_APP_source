package android.view

class ActionModeCallback

class TextInputEditText {
    var customSelectionActionModeCallback: ActionModeCallback? = null
    var customInsertionActionModeCallback: ActionModeCallback? = null
    fun setCustomSelectionActionModeCallback(cb: ActionModeCallback?) {}
    fun setCustomInsertionActionModeCallback(cb: ActionModeCallback?) {}
    fun disableSharing() {}
}

object AllowedTextActionsCallBack {
    val INSTANCE = ActionModeCallback()
}

class TextToolbar

object LocalTextToolbar {
    val current = TextToolbar()
    infix fun provides(value: TextToolbar): Any = value
}

fun SelectionContainer(content: () -> Unit) {}
