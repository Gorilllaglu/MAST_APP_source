package ru.sberbank.cerbersdk.sdk_framework

import android.net.Uri

interface CerberCallbacks {
    fun onFileReceived(uri: Uri, callingPackage: String)
    fun onLogout()
    fun onNoAuthDetected()
    fun onRootDetected()
    fun onSuccessPaoAuth()
    fun onSuccessPaoEnter()
    fun onUserChanged()
    fun provideSpaceIds(): List<String>
}

class Uri

class CerberSDKApplicationDelegate {
    var cerberCallbacks: CerberCallbacks? = null
    fun setCerberCallbacks(callbacks: CerberCallbacks) { cerberCallbacks = callbacks }
}
