package ru.corp.app

import ru.sberbank.cerbersdk.sdk_framework.CerberCallbacks
import ru.sberbank.cerbersdk.sdk_framework.CerberSDKApplicationDelegate
import ru.sberbank.cerbersdk.sdk_framework.Uri

/**
 * CB callbacks-not-set. Правило обратной логики: ценность в молчании.
 * Ноль находок на приложении означает, что колбэки не подключены вовсе,
 * и четыре события безопасности теряются молча. Здесь регистрация есть,
 * поэтому находки обязаны быть.
 */

private val delegate = CerberSDKApplicationDelegate()

private val callbacks = object : CerberCallbacks {
    override fun onFileReceived(uri: Uri, callingPackage: String) {}
    override fun onLogout() { clearSession() }
    override fun onNoAuthDetected() { restrictScreens() }
    override fun onRootDetected() { terminate() }
    override fun onSuccessPaoAuth() {}
    override fun onSuccessPaoEnter() {}
    override fun onUserChanged() { clearSession() }
    override fun provideSpaceIds(): List<String> = emptyList()
}

/** CB-TP-1. Регистрация через сеттер. */
fun registerViaSetter() {
    delegate.setCerberCallbacks(callbacks)
}

/** CB-TP-2. Регистрация присваиванием свойства. */
fun registerViaProperty() {
    delegate.cerberCallbacks = callbacks
}

/**
 * CB-TN-1. Объявление реализации колбэков без регистрации. Молчание:
 * правило отмечает именно регистрацию, а не наличие класса-реализации.
 * Приложение с таким кодом и без регистрации событий не получит.
 */
object UnregisteredCallbacks : CerberCallbacks {
    override fun onFileReceived(uri: Uri, callingPackage: String) {}
    override fun onLogout() {}
    override fun onNoAuthDetected() {}
    override fun onRootDetected() {}
    override fun onSuccessPaoAuth() {}
    override fun onSuccessPaoEnter() {}
    override fun onUserChanged() {}
    override fun provideSpaceIds(): List<String> = emptyList()
}

private fun clearSession() {}
private fun restrictScreens() {}
private fun terminate() {}
