package ru.corp.app

import android.content.ClipData
import android.content.ClipEntry
import android.content.Clipboard
import android.content.ClipboardManager
import android.content.Context
import android.content.Host
import android.content.LocalClipboard
import android.content.LocalClipboardManager
import android.content.OutputBuffer
import ru.sberbank.cerbersdk.sdk_framework.CerberCopyPasteBuffer
import ru.sberbank.cerbersdk.sdk_framework.DelegateWithBuffer

/**
 * CW clipboard-write-result-ignored, CL host-clipboard-bypass,
 * CS compose-clipboard-surface.
 */

private val delegate = DelegateWithBuffer()
private val manager = Host.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
private val buffer = OutputBuffer()

class BufferForms {

    /** CW-TP-1. Запись в буфер SDK литералом типа, результат отброшен. */
    fun copyLiteral(text: String) {
        CerberCopyPasteBuffer.write(text)
        Host.show("copied")
    }

    /**
     * CW-TP-2. Запись через буфер делегата, результат отброшен. Это форма из
     * реального приложения: до правки якорь был литеральным и такую запись
     * правило не видело.
     */
    fun copyViaDelegate(value: String) {
        delegate.buffer.write(value)
        Host.show("stored")
    }

    /** CW-TN-1. Результат записи литералом разобран. Молчание. */
    fun copyLiteralHandled(text: String) {
        val result = CerberCopyPasteBuffer.write(text)
        Host.show(result.name)
    }

    /** CW-TN-2. Результат записи через делегат разобран. Молчание. */
    fun copyViaDelegateHandled(value: String) {
        val outcome = delegate.buffer.write(value)
        Host.show(outcome.name)
    }

    /**
     * CW-TN-3. Свой поток с именем, кончающимся на Buffer. Молчание
     * обязательно: форма this.buffer.write и sink.buffer.write встречается
     * в okio, spongycastle и в своём коде приложений десятками, поэтому
     * получатель опознаётся только через delegate.
     */
    fun dumpBytes(outputBuffer: OutputBuffer, bytes: ByteArray) {
        outputBuffer.write(bytes)
    }

    /** CW-TN-4. Поле с именем buffer. Молчание. */
    fun dumpField(bytes: ByteArray) {
        buffer.write(bytes)
    }

    /** CL-TP-1. Получение системного менеджера буфера. */
    fun grabManager(): Any = Host.getSystemService(Context.CLIPBOARD_SERVICE)

    /** CL-TP-2. Запись в системный буфер. */
    fun copyToSystem(clip: ClipData) {
        manager.setPrimaryClip(clip)
    }

    /**
     * CL-TP-3. Очистка системного буфера. Сработка по делу, но в приложении
     * это может быть защитной мерой, о чём сказано в сообщении правила.
     */
    fun clearSystem() {
        manager.clearPrimaryClip()
    }

    /**
     * CL-TN-1. Сборка ClipData без записи в системный буфер. После сужения
     * правила по обходу буфера здесь молчание: это полезная нагрузка любого
     * из двух маршрутов, и сама по себе обходом не является. Клетка должна
     * попасть в правило compose-clipboard-surface.
     */
    fun buildPayload(text: String): ClipData = ClipData.newPlainText("label", text)

    /** CS-TP-1. Подмена локали буфера на свою реализацию. */
    fun installClipboard(own: Clipboard): Any = LocalClipboard provides own

    /** CS-TP-2. Подмена локали менеджера буфера. */
    fun installManager(own: Clipboard): Any = LocalClipboardManager provides own

    /** CS-TP-3. Запись через Compose-локаль. */
    fun copyCompose(clipboard: Clipboard, text: String) {
        clipboard.setClipEntry(ClipEntry(ClipData.newPlainText("label", text)))
    }

    /**
     * CS-TN-1. Чтение локали без записи. После пересборки правил чтение
     * локали якорем не является: куда она ведёт, в точке чтения не видно.
     */
    fun readCurrent(): Clipboard = LocalClipboard.current
}
