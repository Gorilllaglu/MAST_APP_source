package ru.sberbank.cerbersdk.sdk_framework

enum class WriteResult { SUCCESS, TRUNCATED, FAILURE }

object CerberCopyPasteBuffer {
    fun write(data: String): WriteResult = WriteResult.SUCCESS
    fun read(): String = ""
}

class CerberBuffer {
    fun write(data: String): WriteResult = WriteResult.SUCCESS
    fun read(): String = ""
}

class DelegateWithBuffer {
    val buffer = CerberBuffer()
}
