package android.content

class ClipData {
    companion object {
        fun newPlainText(label: String, text: String): ClipData = ClipData()
        fun newUri(resolver: Any?, label: String, uri: Any?): ClipData = ClipData()
        fun newIntent(label: String, intent: Any?): ClipData = ClipData()
        fun newRawUri(label: String, uri: Any?): ClipData = ClipData()
    }
}

class ClipboardManager {
    fun setPrimaryClip(clip: ClipData) {}
    fun clearPrimaryClip() {}
}

object Context {
    const val CLIPBOARD_SERVICE = "clipboard"
}

class ClipEntry(val clipData: ClipData)

class Clipboard {
    fun setClipEntry(entry: ClipEntry?) {}
}

object LocalClipboard {
    val current = Clipboard()
    infix fun provides(value: Clipboard): Any = value
}

object LocalClipboardManager {
    val current = Clipboard()
    infix fun provides(value: Clipboard): Any = value
}

class OutputBuffer {
    fun write(bytes: ByteArray) {}
}

object Host {
    fun show(message: String) {}
    fun getSystemService(name: String): Any = ClipboardManager()
}
