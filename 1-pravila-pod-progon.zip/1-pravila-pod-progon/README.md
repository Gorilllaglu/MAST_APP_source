# 21 правило под прогон

Заменить в составе и прогнать по фикстурам из папки `2-fixtury`. Раскладка: `rules/kotlin` 12, `rules/java` 8, `rules/xml` 1.

| Правило | Что изменилось |
|---|---|
| `secure-initial-check-disabled` | позиционная форма конструктора |
| `insecure-screen-disabled` | позиционная форма |
| `insecure-clipboard-disabled` + джава | позиционная форма; полка ERROR+HIGH → WARNING+INFO |
| `passwordless-auth-disabled` | позиционная форма |
| `cerber-java-passwordless-auth-disabled` | читал последний аргумент конструктора вместо десятого |
| `clipboard-write-result-ignored` + джава | получатель буфера опознаётся через `delegate` |
| `host-clipboard-bypass` + джава | ERROR+HIGH | платформенные якоря плюс четыре формы сборки `ClipData`; исключены инлайновая сборка внутри `setPrimaryClip` и формы, завёрнутые в `ClipEntry` для буфера Compose | `cerber-compose-clipboard-surface` | **новое правило**, WARNING+INFO |
| `selection-callback-not-sdk` + джава | убран `disableSharing` — защитный хелпер SDK |
| `compose-text-selection` | якоря на `LocalTextToolbar`; полка → WARNING+MEDIUM |
| `activity-missing-auth-onresume` + джава | полка → WARNING+LOW |
| `exported-component-no-permission` | в исключения добавлены три компонента SDK |
| `secure-check-wrong-state-comparison` + джава | добавлены состояния `APPS_UNAUTHORIZED` и `WRONG_THUMBPRINT` |
| `cerber-callbacks-not-set` + джава | **новое правило-маркер**, WARNING+INFO |

## Два правила обратной логики в этой партии

`cerber-callbacks-not-set` и `cerber-compose-clipboard-surface` устроены по-разному, хотя полка у них одна.

Маркер колбэков — обратная логика: ноль находок означает дефект, и в CI гейт должен срабатывать на нуле (`expected_ci_logic: fail_if_zero_findings`). На пяти разобранных приложениях два — SberCost и SberTransport — колбэки не регистрируют вовсе.

Поверхность буфера Compose — не маркер, а сигнал: находки перечисляют поверхность, а решение принимается один раз, в месте подмены локали.

## Поправка к первой сборке этой партии

В первой сборке сборка `ClipData` была вынесена из `host-clipboard-bypass` в новое котлиновское правило по буферу Compose. Это оставило джавовский блок без покрытия: `ClipData.newPlainText` в джаве не ловил никто, кроме правила по перетаскиванию. Разделение было неверным и по существу — буфер SDK принимает `String`, поэтому `ClipData` в коде приложения собирается для платформенного буфера либо для перетаскивания, но никогда для SDK, и к неразрешимой маршрутизации Compose отношения не имеет.

Сборка `ClipData` возвращена в `host-clipboard-bypass` в обоих языках. В котлиновском варианте добавлены исключения на формы, завёрнутые в `ClipEntry` или приведённые через `toClipEntry()`: такая `ClipData` уходит в подменённую локаль и разбирается правилом по поверхности Compose. В правиле по Compose остались подмена локали и `setClipEntry`.
