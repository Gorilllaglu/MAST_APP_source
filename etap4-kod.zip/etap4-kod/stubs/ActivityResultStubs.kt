@file:Suppress("UNUSED_PARAMETER", "unused")

package androidx.activity.result.contract

object ActivityResultContracts {
    class CreateDocument(mimeType: String)
    class OpenDocumentTree
}
