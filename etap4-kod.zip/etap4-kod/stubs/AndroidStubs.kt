@file:Suppress("UNUSED_PARAMETER", "unused")

package android.content

object Context {
    const val CLIPBOARD_SERVICE = "clipboard"
    const val PRINT_SERVICE = "print"
    fun getSystemService(name: String): Any = TODO("stub")
    fun getSystemService(cls: Class<*>): Any = TODO("stub")
    fun getExternalFilesDir(type: String?): java.io.File = TODO("stub")
    fun getExternalCacheDir(): java.io.File = TODO("stub")
    val externalCacheDir: java.io.File get() = TODO("stub")
    fun getCacheDir(): java.io.File = TODO("stub")
    val cacheDir: java.io.File get() = TODO("stub")
    val contentResolver: ContentResolver = TODO("stub")
    val packageManager: Any = TODO("stub")
    fun startActivity(intent: Intent) { TODO("stub") }
}

class ClipboardManager {
    fun setPrimaryClip(clip: ClipData) { TODO("stub") }
}

class ClipData {
    companion object {
        fun newPlainText(label: CharSequence, text: CharSequence): ClipData = TODO("stub")
        fun newUri(resolver: ContentResolver, label: CharSequence, uri: android.net.Uri): ClipData = TODO("stub")
        fun newIntent(label: CharSequence, intent: Intent): ClipData = TODO("stub")
        fun newRawUri(label: CharSequence, uri: android.net.Uri): ClipData = TODO("stub")
    }
}

class ContentResolver {
    fun openInputStream(uri: android.net.Uri): java.io.InputStream? = TODO("stub")
    fun insert(uri: android.net.Uri, values: Any?): android.net.Uri? = TODO("stub")
}

class Intent {
    var action: String? = null
    val extras: Bundle? get() = TODO("stub")

    constructor()
    constructor(action: String)

    fun setAction(action: String): Intent = TODO("stub")
    fun putExtra(name: String, value: Any?): Intent = TODO("stub")
    fun getStringExtra(name: String): String? = TODO("stub")
    fun setType(type: String): Intent = TODO("stub")

    companion object {
        const val ACTION_SEND = "android.intent.action.SEND"
        const val ACTION_SEND_MULTIPLE = "android.intent.action.SEND_MULTIPLE"
        const val EXTRA_STREAM = "android.intent.extra.STREAM"
        const val EXTRA_TEXT = "android.intent.extra.TEXT"
        fun createChooser(target: Intent, title: CharSequence?): Intent = TODO("stub")
    }
}
