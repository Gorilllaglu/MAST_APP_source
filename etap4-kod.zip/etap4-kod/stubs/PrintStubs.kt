@file:Suppress("UNUSED_PARAMETER", "unused")

package androidx.print

class PrintHelper(context: Any) {
    var scaleMode: Int = 0
    fun printBitmap(jobName: String, bitmap: Any?) { TODO("stub") }
}
