@file:Suppress("unused")

package android.text

object InputType {
    const val TYPE_CLASS_NUMBER = 2
    const val TYPE_NUMBER_VARIATION_PASSWORD = 16
    const val TYPE_TEXT_VARIATION_PASSWORD = 128
}
