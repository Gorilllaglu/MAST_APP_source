@file:Suppress("UNUSED_PARAMETER", "unused")

package android.webkit

class WebView {
    fun createPrintDocumentAdapter(documentName: String): Any = TODO("stub")
    fun loadUrl(url: String) { TODO("stub") }
}
