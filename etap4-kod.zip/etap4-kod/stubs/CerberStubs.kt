@file:Suppress("UNUSED_PARAMETER", "unused")

package ru.sberbank.cerbersdk.sdk_framework

enum class WriteResult { SUCCESS, TRUNCATED, FAILURE }

object CerberCopyPasteBuffer {
    fun write(value: String): WriteResult = TODO("stub")
    fun read(): String = TODO("stub")
}

interface CerberFileReceiver {
    fun onFileReceived(uri: android.net.Uri, callingPackage: String)
}
