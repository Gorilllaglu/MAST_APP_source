@file:Suppress("UNUSED_PARAMETER", "unused")

package android.widget

open class TextView {
    var isTextSelectable: Boolean = false
    var inputType: Int = 0
    fun setTextIsSelectable(selectable: Boolean) { TODO("stub") }
    fun setInputType(type: Int) { TODO("stub") }
    fun startDragAndDrop(data: Any?, shadow: Any?, local: Any?, flags: Int): Boolean = TODO("stub")
    fun startDrag(data: Any?, shadow: Any?, local: Any?, flags: Int): Boolean = TODO("stub")
}

class EditText : TextView()
