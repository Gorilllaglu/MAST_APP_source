@file:Suppress("UNUSED_PARAMETER", "unused")

package android.os

class Bundle {
    fun getString(key: String): String? = TODO("stub")
}

object Binder {
    fun getCallingUid(): Int = TODO("stub")
    fun getCallingPid(): Int = TODO("stub")
}

object Environment {
    fun getExternalStorageDirectory(): java.io.File = TODO("stub")
    fun getExternalStoragePublicDirectory(type: String): java.io.File = TODO("stub")
}
