@file:Suppress("UNUSED_PARAMETER", "unused")

package androidx.core.app

object ShareCompat {
    class IntentBuilder(context: Any) {
        fun setType(type: String): IntentBuilder = TODO("stub")
        fun setText(text: CharSequence): IntentBuilder = TODO("stub")
        fun startChooser() { TODO("stub") }
        fun createChooserIntent(): android.content.Intent = TODO("stub")

        companion object {
            fun from(context: Any): IntentBuilder = TODO("stub")
        }
    }
}
