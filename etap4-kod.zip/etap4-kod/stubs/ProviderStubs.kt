@file:Suppress("UNUSED_PARAMETER", "unused")

package android.provider

object MediaStore {
    fun createWriteRequest(resolver: android.content.ContentResolver, uris: List<android.net.Uri>): Any = TODO("stub")

    object Images {
        object Media {
            val EXTERNAL_CONTENT_URI: android.net.Uri = TODO("stub")
            fun insertImage(
                resolver: android.content.ContentResolver,
                bitmap: Any?,
                title: String?,
                description: String?
            ): String = TODO("stub")
        }
    }

    object Downloads {
        val EXTERNAL_CONTENT_URI: android.net.Uri = TODO("stub")
    }

    object Files {
        fun getContentUri(volumeName: String): android.net.Uri = TODO("stub")
    }
}
