@file:Suppress("UNUSED_PARAMETER", "unused")

package androidx.core.content

object FileProvider {
    fun getUriForFile(context: Any, authority: String, file: java.io.File): android.net.Uri = TODO("stub")
}
