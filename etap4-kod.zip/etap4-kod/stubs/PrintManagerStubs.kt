@file:Suppress("UNUSED_PARAMETER", "unused")

package android.print

class PrintManager {
    fun print(jobName: String, adapter: Any?, attributes: Any?): Any = TODO("stub")
}
