@file:Suppress("UNUSED_PARAMETER", "unused")

package androidx.compose.foundation.text

object KeyboardType {
    val Text = 0
    val Number = 1
    val Password = 2
    val NumberPassword = 3
}

class KeyboardOptions(val keyboardType: Int = KeyboardType.Text)

interface VisualTransformation

class PasswordVisualTransformation : VisualTransformation

interface TextToolbar

val LocalTextToolbar: ProvidableKey<TextToolbar> = TODO("stub")

class ProvidableKey<T> {
    infix fun provides(value: T): Any = TODO("stub")
}

fun SelectionContainer(content: () -> Unit) { TODO("stub") }

fun BasicText(text: String) { TODO("stub") }
