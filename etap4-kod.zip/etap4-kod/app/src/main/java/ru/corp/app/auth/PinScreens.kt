package ru.corp.app.auth

import android.text.InputType
import android.widget.EditText
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.KeyboardType
import androidx.compose.foundation.text.PasswordVisualTransformation

/** E10: приложение реализует свой экран ввода PIN. */
object PinScreens {

    /** E10-TP-1. Клавиатура числового пароля в Compose. */
    fun pinKeyboard(): Int = KeyboardType.NumberPassword

    /** E10-TP-2. Маскирование ввода. */
    fun pinTransformation(): PasswordVisualTransformation = PasswordVisualTransformation()

    /** E10-TP-3. Параметры клавиатуры с числовым паролем. */
    fun pinOptions(): KeyboardOptions =
        KeyboardOptions(keyboardType = KeyboardType.NumberPassword)

    /** E10-TP-4. Числовой пароль на View. */
    fun pinField(field: EditText) {
        field.inputType = InputType.TYPE_NUMBER_VARIATION_PASSWORD
    }

    /** E10-TN-1. Обычное текстовое поле. */
    fun searchOptions(): KeyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text)

    /**
     * E10-PROBE-1. Числовая клавиатура без маскирования: это поле суммы,
     * а не PIN. Правило построено на NumberPassword, ожидается молчание.
     */
    fun amountOptions(): KeyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
}
