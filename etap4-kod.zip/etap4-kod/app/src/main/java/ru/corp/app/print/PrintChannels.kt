package ru.corp.app.print

import android.content.Context
import android.print.PrintManager
import android.webkit.WebView
import androidx.print.PrintHelper

/** E09: канал печати открыт. */
object PrintChannels {

    /** E09-TP-1. Печать картинки через PrintHelper. */
    fun printScreenshot(bitmap: Any?) {
        PrintHelper(Context).printBitmap("statement", bitmap)
    }

    /** E09-TP-2. Печать содержимого WebView. */
    fun printWebContent(webView: WebView): Any =
        webView.createPrintDocumentAdapter("statement")

    /** E09-TP-3. Служба печати получена напрямую. */
    fun printService(): PrintManager =
        Context.getSystemService(Context.PRINT_SERVICE) as PrintManager

    /** E09-TN-1. WebView без печати. */
    fun showWebContent(webView: WebView) {
        webView.loadUrl("https://corp.example/statement")
    }
}
