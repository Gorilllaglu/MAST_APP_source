package ru.corp.app.ui

import android.widget.TextView
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.text.LocalTextToolbar
import androidx.compose.foundation.text.SelectionContainer
import androidx.compose.foundation.text.TextToolbar

/** E06: выделение текста и перетаскивание включены приложением. */
object SelectionScreens {

    /** E06-TP-1. Выделение включено контейнером. */
    fun selectableBalance() {
        SelectionContainer {
            BasicText("1 234 567,89")
        }
    }

    /** E06-TP-2. Выделение включено на View. */
    fun selectableView(view: TextView) {
        view.isTextSelectable = true
    }

    /** E06-TP-3. Выделение включено сеттером. */
    fun selectableViaSetter(view: TextView) {
        view.setTextIsSelectable(true)
    }

    /** E06-TP-4. Перетаскивание запущено приложением. */
    fun startDrag(view: TextView) {
        view.startDragAndDrop(null, null, null, 0)
    }

    /** E06-TP-5. Своя панель инструментов текста. */
    fun customToolbar(toolbar: TextToolbar): Any = LocalTextToolbar provides toolbar

    /** E06-TN-1. Текст без выделения, как по умолчанию в Compose. */
    fun plainBalance() {
        BasicText("1 234 567,89")
    }

    /** E06-TN-2. Выделение выключено явно. */
    fun nonSelectableView(view: TextView) {
        view.isTextSelectable = false
    }
}
