package ru.corp.app.share

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.app.ShareCompat

/** E07: данные уходят в системный диалог «Поделиться». */
object ShareChannels {

    /** E07-TP-1. Intent создан с ACTION_SEND. */
    fun shareText(text: String) {
        val intent = Intent(Intent.ACTION_SEND)
        intent.putExtra(Intent.EXTRA_TEXT, text)
        Context.startActivity(intent)
    }

    /** E07-TP-2. Диалог выбора получателя. */
    fun shareViaChooser(text: String) {
        val base = Intent()
        base.setAction("android.intent.action.SEND")
        Context.startActivity(Intent.createChooser(base, "Share"))
    }

    /** E07-TP-3. Несколько вложений. */
    fun shareMultiple() {
        val intent = Intent(Intent.ACTION_SEND_MULTIPLE)
        Context.startActivity(intent)
    }

    /** E07-TP-4. Действие присвоено свойством. */
    fun shareViaProperty(uri: Uri) {
        val intent = Intent()
        intent.action = Intent.ACTION_SEND
        intent.putExtra(Intent.EXTRA_STREAM, uri)
        Context.startActivity(intent)
    }

    /** E07-TP-5. Идиома androidx: точка входа цепочки ShareCompat. */
    fun shareViaShareCompat(text: String) {
        ShareCompat.IntentBuilder.from(Context)
            .setType("text/plain")
            .setText(text)
            .startChooser()
    }

    /** E07-TN-1. Явный получатель, без системного диалога. */
    fun openInternally(uri: Uri) {
        val intent = Intent("ru.corp.app.VIEW_DOCUMENT")
        intent.putExtra("uri", uri.toString())
        Context.startActivity(intent)
    }
}
