package ru.corp.app.clipboard

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import ru.sberbank.cerbersdk.sdk_framework.CerberCopyPasteBuffer
import ru.sberbank.cerbersdk.sdk_framework.WriteResult

/** E01: платформенный буфер обмена в обход SDK. */
object ClipboardUsage {

    /** E01-TP-1. Менеджер буфера получен через getSystemService. */
    fun copyViaSystemService(text: String) {
        val cm = Context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("label", text))
    }

    /** E01-TP-2. Менеджер получен по классу. */
    fun copyViaClass(text: String) {
        val cm = Context.getSystemService(ClipboardManager::class.java) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("label", text))
    }

    /**
     * E01-PROBE-1. Менеджер получен литералом класса и больше ничего.
     *
     * Шаблон с литералом класса из правила убран 2026-10-28: он матчил любой
     * литерал класса, и правило печати из-за этого сработало на клетке
     * E01-TP-2. Здесь форма осталась в одиночку, без setPrimaryClip и без
     * ClipData рядом, то есть зацепиться правилу больше не за что.
     * Ожидается молчание — это измерение созданного пробела, а не дефект.
     */
    fun managerOnly(): ClipboardManager =
        Context.getSystemService(ClipboardManager::class.java) as ClipboardManager

    /** E01-TP-3. Только сборка ClipData, без записи. */
    fun buildClip(text: String): ClipData = ClipData.newPlainText("label", text)

    /** E01-TP-4. ClipData из URI. */
    fun buildUriClip(uri: android.net.Uri): ClipData =
        ClipData.newRawUri("label", uri)

    /** E01-TN-1. Запись через буфер SDK, результат сверен. */
    fun copyViaSdk(text: String): Boolean {
        val result = CerberCopyPasteBuffer.write(text)
        return result == WriteResult.SUCCESS
    }
}
