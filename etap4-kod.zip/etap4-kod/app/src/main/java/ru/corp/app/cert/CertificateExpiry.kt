package ru.corp.app.cert

import java.security.cert.X509Certificate
import java.util.Calendar

/** E13: приложение само считает срок сертификата. */
object CertificateExpiry {

    /** E13-TP-1. Чтение notAfter. */
    fun expiresAt(cert: X509Certificate): java.util.Date = cert.notAfter

    /** E13-TP-2. Проверка срока своими руками. */
    fun isStillValid(cert: X509Certificate): Boolean {
        cert.checkValidity()
        return true
    }

    /** E13-TP-3. Начало срока. */
    fun issuedAt(cert: X509Certificate): java.util.Date = cert.notBefore

    /** E13-TP-4. Своя арифметика по дате перевыпуска. */
    fun renewAfter(cert: X509Certificate): java.util.Date {
        val cal = Calendar.getInstance()
        cal.time = cert.notAfter
        cal.add(Calendar.DAY_OF_YEAR, -30)
        return cal.time
    }

    /** E13-TN-1. Срок не считается, решение за SDK. */
    fun subject(cert: X509Certificate): String = cert.subjectX500Principal.name
}
