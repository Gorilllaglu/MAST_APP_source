package ru.corp.app.transfer

import android.content.Context
import android.net.Uri
import androidx.core.content.FileProvider
import java.io.File

/** E14: временный файл передачи не удаляется. */
object FileSender {

    private const val AUTHORITY = "ru.corp.app.fileprovider"

    /** E14-TP-1. URI отдан наружу, файл остался. */
    fun shareDocument(name: String): Uri {
        val file = File(Context.cacheDir, "transfer/$name")
        return FileProvider.getUriForFile(Context, AUTHORITY, file)
    }

    /** E14-TN-1. Файл удалён после выдачи URI. */
    fun shareAndCleanup(name: String): Uri {
        val file = File(Context.cacheDir, "transfer/$name")
        val uri = FileProvider.getUriForFile(Context, AUTHORITY, file)
        file.delete()
        return uri
    }

    /** E14-TN-2. Удаление отложено на выход процесса. */
    fun shareDeferred(name: String): Uri {
        val file = File(Context.cacheDir, "transfer/$name")
        val uri = FileProvider.getUriForFile(Context, AUTHORITY, file)
        file.deleteOnExit()
        return uri
    }
}
