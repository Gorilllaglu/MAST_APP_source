package ru.corp.app.storage

import android.content.Context
import android.os.Environment
import android.provider.MediaStore
import java.io.File

/** E08: запись за пределы песочницы приложения. */
object ExternalStorage {

    /** E08-TP-1. Каталог внешних файлов приложения. */
    fun externalDir(): File = Context.getExternalFilesDir(null)

    /** E08-TP-2. Внешний кеш свойством. */
    fun externalCache(): File = Context.externalCacheDir

    /** E08-TP-3. Корень внешнего хранилища. */
    fun storageRoot(): File = Environment.getExternalStorageDirectory()

    /** E08-TP-4. Публичный каталог. */
    fun publicDownloads(): File = Environment.getExternalStoragePublicDirectory("Download")

    /** E08-TP-5. Запись в галерею. */
    fun saveToGallery(bitmap: Any?): String =
        MediaStore.Images.Media.insertImage(Context.contentResolver, bitmap, "doc", null)

    /** E08-TP-6. Коллекция загрузок. */
    fun downloadsCollection(): android.net.Uri = MediaStore.Downloads.EXTERNAL_CONTENT_URI

    /** E08-TN-1. Приватный кеш приложения. */
    fun privateCache(): File = Context.cacheDir

    /** E08-TN-2. Файл в приватном кеше. */
    fun transferTemp(name: String): File = File(Context.cacheDir, "transfer/$name")
}
