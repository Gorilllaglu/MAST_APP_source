package ru.corp.app.ipc

import android.content.Intent
import android.os.Binder
import android.os.Bundle

/**
 * E03: проверка вызывающего обёрнута в try/catch, который не отвергает запрос.
 * E04: идентификация берётся из payload вместо системного источника.
 */
object IdentityChecks {

    private val allowed = setOf(1000, 10123)

    /** E03-TP-1. catch проглатывает исключение, запрос продолжается. */
    fun checkSwallowing(): Boolean {
        try {
            val uid = Binder.getCallingUid()
            return uid in allowed
        } catch (e: Exception) {
            android.util.Log.w("ipc", "uid not resolved")
        }
        return true
    }

    /** E03-TP-2. catch логирует и возвращает управление дальше. */
    fun checkLoggingOnly(pm: android.content.ContentResolver): Int {
        try {
            val uid = Binder.getCallingUid()
            return uid
        } catch (e: SecurityException) {
            android.util.Log.w("ipc", "ignored")
        }
        return 0
    }

    /** E03-TN-1. catch бросает SecurityException. */
    fun checkThrowing(): Int {
        try {
            return Binder.getCallingUid()
        } catch (e: Exception) {
            throw SecurityException("caller identity unavailable")
        }
    }

    /** E03-TN-2. catch возвращает отказ. */
    fun checkReturningFalse(): Boolean {
        try {
            return Binder.getCallingUid() in allowed
        } catch (e: Exception) {
            return false
        }
    }

    /** E04-TP-1. Имя вызывающего взято из extra интента. */
    fun identityFromExtra(intent: Intent): Boolean {
        val caller = intent.getStringExtra("caller_package")
        return caller == "ru.sberbank.sberapps"
    }

    /** E04-TP-2. То же из Bundle. */
    fun identityFromBundle(bundle: Bundle): Boolean {
        val caller = bundle.getString("calling_package")
        return caller == "ru.sberbank.sberapps"
    }

    /**
     * E04-PROBE-1. Ключ не похож на идентификацию по имени.
     * Правило ограничено регексом по имени ключа, ожидается молчание,
     * хотя значение используется точно так же.
     */
    fun identityFromOpaqueKey(intent: Intent): Boolean {
        val who = intent.getStringExtra("x_origin")
        return who == "ru.sberbank.sberapps"
    }

    /** E04-TN-1. Идентификация из системного источника. */
    fun identityFromBinder(): Boolean = Binder.getCallingUid() in allowed
}
