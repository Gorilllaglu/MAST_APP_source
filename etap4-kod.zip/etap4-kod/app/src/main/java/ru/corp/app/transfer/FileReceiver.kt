package ru.corp.app.transfer

import android.content.Context
import android.net.Uri
import ru.sberbank.cerbersdk.sdk_framework.CerberFileReceiver
import java.io.File
import java.io.FileOutputStream

/**
 * E11: полученный файл не скопирован в песочницу приложения.
 *
 * Во всех четырёх клетках callingPackage сверяется с белым списком. Это не
 * предмет E11, а необходимость: без сверки на те же функции срабатывает
 * правило cerber-file-received-no-caller-check с прошлых этапов, и в прогоне
 * 2026-10-27 оно дало по находке на каждую из четырёх, зашумив триаж E11.
 * Сверка здесь нужна только чтобы оставить в находках одно правило.
 */
object FileReceiver {

    private val allowedSenders = setOf("ru.sberbank.sberapps", "ru.sberbank.sbermail")

    /** E11-TP-1. Работа напрямую по чужому URI. */
    class DirectReceiver : CerberFileReceiver {
        override fun onFileReceived(uri: Uri, callingPackage: String) {
            if (!allowedSenders.contains(callingPackage)) {
                return
            }
            android.util.Log.d("transfer", "opening $uri from $callingPackage")
        }
    }

    /** E11-TP-2. URI передан дальше без копии. */
    class ForwardingReceiver : CerberFileReceiver {
        override fun onFileReceived(uri: Uri, callingPackage: String) {
            if (!allowedSenders.contains(callingPackage)) {
                return
            }
            val intent = android.content.Intent("ru.corp.app.VIEW_DOCUMENT")
            intent.putExtra("uri", uri.toString())
            Context.startActivity(intent)
        }
    }

    /** E11-TN-1. Поток скопирован в приватный файл. */
    class CopyingReceiver : CerberFileReceiver {
        override fun onFileReceived(uri: Uri, callingPackage: String) {
            if (!allowedSenders.contains(callingPackage)) {
                return
            }
            val target = File(Context.cacheDir, "inbox/doc.bin")
            val input = Context.contentResolver.openInputStream(uri)
            FileOutputStream(target).use { out ->
                input?.copyTo(out)
            }
        }
    }

    /** E11-TN-2. Содержимое прочитано в память до работы с ним. */
    class ReadingReceiver : CerberFileReceiver {
        override fun onFileReceived(uri: Uri, callingPackage: String) {
            if (!allowedSenders.contains(callingPackage)) {
                return
            }
            val bytes = File(uri.toString()).readBytes()
            android.util.Log.d("transfer", "read ${bytes.size} bytes")
        }
    }
}
