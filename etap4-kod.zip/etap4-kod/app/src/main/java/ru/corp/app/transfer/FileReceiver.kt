package ru.corp.app.transfer

import android.content.Context
import android.net.Uri
import ru.sberbank.cerbersdk.sdk_framework.CerberFileReceiver
import java.io.File
import java.io.FileOutputStream

/** E11: полученный файл не скопирован в песочницу приложения. */
object FileReceiver {

    /** E11-TP-1. Работа напрямую по чужому URI. */
    class DirectReceiver : CerberFileReceiver {
        override fun onFileReceived(uri: Uri, callingPackage: String) {
            android.util.Log.d("transfer", "opening $uri from $callingPackage")
        }
    }

    /** E11-TP-2. URI передан дальше без копии. */
    class ForwardingReceiver : CerberFileReceiver {
        override fun onFileReceived(uri: Uri, callingPackage: String) {
            val intent = android.content.Intent("ru.corp.app.VIEW_DOCUMENT")
            intent.putExtra("uri", uri.toString())
            Context.startActivity(intent)
        }
    }

    /** E11-TN-1. Поток скопирован в приватный файл. */
    class CopyingReceiver : CerberFileReceiver {
        override fun onFileReceived(uri: Uri, callingPackage: String) {
            val target = File(Context.cacheDir, "inbox/doc.bin")
            val input = Context.contentResolver.openInputStream(uri)
            FileOutputStream(target).use { out ->
                input?.copyTo(out)
            }
        }
    }

    /** E11-TN-2. Содержимое прочитано в память до работы с ним. */
    class ReadingReceiver : CerberFileReceiver {
        override fun onFileReceived(uri: Uri, callingPackage: String) {
            val bytes = File(uri.toString()).readBytes()
            android.util.Log.d("transfer", "read ${bytes.size} bytes")
        }
    }
}
