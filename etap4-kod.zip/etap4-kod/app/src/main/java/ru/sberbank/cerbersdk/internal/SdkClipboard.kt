package ru.sberbank.cerbersdk.internal

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context

/**
 * E01-TN-SDK-1. Файл лежит под путём /cerbersdk/ и обязан попасть в
 * paths.exclude всех правил этапа. Платформенный буфер здесь используется
 * напрямую и по делу: это код самой библиотеки, она его и подменяет
 * заглушкой при сворачивании приложения.
 */
internal object SdkClipboard {
    fun writeThrough(text: String) {
        val cm = Context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("cerber", text))
    }
}
