import React from 'react';
import {WebView} from 'react-native-webview';

/**
 * VULN-25: token injection в WebView без проверки origin.
 *
 * URL приходит снаружи; сразу после загрузки страницы приложение через
 * `injectJavaScript` инжектит auth-token в DOM (авто-логин), НЕ сверяя
 * host'а. Атакующий хостит свою страницу и читает `window.__authToken`.
 */
const AUTH_TOKEN = 'eyJhbGciOiJIUzI1NiJ9.fake.fake';

export function Vuln25TokenInjection({url}: {url: string}): React.JSX.Element {
  const webRef = React.useRef<WebView>(null);
  return (
    <WebView
      ref={webRef}
      source={{uri: url}}
      javaScriptEnabled={true}
      onLoadEnd={() => {
        // <-- VULN sink: инжектим токен в любой только что загруженный
        // URL, не сверяя host'а.
        webRef.current?.injectJavaScript(
          `window.__authToken='${AUTH_TOKEN}'; ` +
            "window.dispatchEvent(new Event('app-token-ready')); true;");
      }}
    />
  );
}
