import React, {useState} from 'react';
import {SafeAreaView, ScrollView, Button, Text, View} from 'react-native';

import {Vuln23JsBridge} from './Vuln23JsBridge';
import {Vuln24ArbitraryUrl} from './Vuln24ArbitraryUrl';
import {Vuln25TokenInjection} from './Vuln25TokenInjection';
import {Vuln26FileAccess} from './Vuln26FileAccess';

type Screen = 'menu' | 'v23' | 'v24' | 'v25' | 'v26';

function Back({onBack, children}: {onBack: () => void; children: React.ReactNode}): React.JSX.Element {
  return (
    <SafeAreaView style={{flex: 1}}>
      <Button title="← back" onPress={onBack} />
      <View style={{flex: 1}}>{children}</View>
    </SafeAreaView>
  );
}

export default function App(): React.JSX.Element {
  const [screen, setScreen] = useState<Screen>('menu');
  const back = () => setScreen('menu');

  if (screen === 'v23') {
    return <Back onBack={back}><Vuln23JsBridge /></Back>;
  }
  if (screen === 'v24') {
    // URL извне (аналог intent extra / deeplink) — без allowlist.
    return <Back onBack={back}><Vuln24ArbitraryUrl url="https://attacker.example/phish.html" /></Back>;
  }
  if (screen === 'v25') {
    return <Back onBack={back}><Vuln25TokenInjection url="https://attacker.example/grab.html" /></Back>;
  }
  if (screen === 'v26') {
    return <Back onBack={back}><Vuln26FileAccess url="file:///android_asset/index.html" /></Back>;
  }

  return (
    <SafeAreaView>
      <ScrollView contentContainerStyle={{padding: 16}}>
        <Text>VULN: WebView misuse</Text>
        <View style={{height: 12}} />
        <Button title="VULN-23: JS bridge without origin check" onPress={() => setScreen('v23')} />
        <View style={{height: 8}} />
        <Button title="VULN-24: arbitrary URL from external source" onPress={() => setScreen('v24')} />
        <View style={{height: 8}} />
        <Button title="VULN-25: token injection on any origin" onPress={() => setScreen('v25')} />
        <View style={{height: 8}} />
        <Button title="VULN-26: WebView file access enabled" onPress={() => setScreen('v26')} />
      </ScrollView>
    </SafeAreaView>
  );
}
