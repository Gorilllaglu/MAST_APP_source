import React from 'react';
import {WebView} from 'react-native-webview';

/**
 * VULN-26: WebView с включёнными file-access настройками.
 *
 * react-native-webview пробрасывает опасные настройки как props:
 *   allowFileAccess, allowFileAccessFromFileURLs,
 *   allowUniversalAccessFromFileURLs.
 * В сочетании с произвольным URL (как vuln24) это даёт чтение приватных
 * файлов приложения через file://-схему и XHR на любой origin.
 *
 * (В Flutter эти настройки недоступны через плагин — RN здесь выразительнее.)
 */
export function Vuln26FileAccess({url}: {url: string}): React.JSX.Element {
  return (
    <WebView
      source={{uri: url}}
      javaScriptEnabled={true}
      allowFileAccess={true}                       // <-- VULN
      allowFileAccessFromFileURLs={true}           // <-- VULN
      allowUniversalAccessFromFileURLs={true}      // <-- VULN
    />
  );
}
