import React from 'react';
import {WebView, WebViewMessageEvent} from 'react-native-webview';
import AsyncStorage from '@react-native-async-storage/async-storage';

/**
 * VULN-23: JavaScript bridge без проверки origin.
 *
 * `onMessage` обрабатывает `window.ReactNativeWebView.postMessage(...)` с
 * ЛЮБОЙ страницы, загруженной в WebView (включая редирект на сторонний
 * домен). Никакой проверки текущего URL перед sensitive-операциями нет —
 * любая страница может вызвать нативную сторону.
 *
 * Безопасный паттерн (НЕ реализован): сверять источник перед ответом,
 * например через onNavigationStateChange и allowlist доменов.
 */
export function Vuln23JsBridge(): React.JSX.Element {
  const webRef = React.useRef<WebView>(null);

  const onMessage = async (e: WebViewMessageEvent) => {
    const msg = e.nativeEvent.data;
    // Без проверки origin — выполняем команды любого caller-а.
    if (msg === 'getAuthToken') {
      // <-- VULN sink: отдаём токен обратно в DOM любому caller-у
      webRef.current?.injectJavaScript(
        "window.__nativeToken='eyJhbGciOiJIUzI1NiJ9.fakejwt.fakesig'; true;");
    } else if (msg.startsWith('save:')) {
      // <-- VULN sink: пишем произвольные данные в AsyncStorage
      await AsyncStorage.setItem('bridge_data', msg.substring(5));
    }
  };

  return (
    <WebView
      ref={webRef}
      source={{uri: 'https://app.example.com/profile'}}
      javaScriptEnabled={true}
      onMessage={onMessage}  // <-- VULN: bridge доступен любой загруженной странице
    />
  );
}
