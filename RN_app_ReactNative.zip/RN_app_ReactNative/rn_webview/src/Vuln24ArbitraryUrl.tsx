import React from 'react';
import {WebView} from 'react-native-webview';

/**
 * VULN-24: WebView грузит произвольный URL из внешнего источника
 * без allowlist'а доменов.
 *
 * `url` приходит снаружи — аналог `intent.getStringExtra("url")` в
 * нативе (в RN это deeplink-параметр / prop экрана). Любой, кто умеет
 * открыть этот экран с подконтрольным URL, показывает свою страницу
 * внутри нашего приложения (phishing: чрома/логотип наши).
 */
export function Vuln24ArbitraryUrl({url}: {url: string}): React.JSX.Element {
  return (
    <WebView
      source={{uri: url}}        // <-- VULN sink: URL без проверки домена
      javaScriptEnabled={true}
    />
  );
}
