# rn_webview — React Native порт (WebView misuse)

Консолидирует **4** уязвимых приложения нативного стенда. WebView в RN —
пакет `react-native-webview` (обёртка над `android.webkit.WebView`).

## Что объединено

| Оригинал | TS-файл | Класс уязвимости | Sink |
|---|---|---|---|
| `23-webview-jsbridge-no-origin` | [src/Vuln23JsBridge.tsx](src/Vuln23JsBridge.tsx) | JS bridge без origin-check | `onMessage` (window.ReactNativeWebView.postMessage) + `injectJavaScript` ответ |
| `24-webview-arbitrary-url` | [src/Vuln24ArbitraryUrl.tsx](src/Vuln24ArbitraryUrl.tsx) | Arbitrary URL | `source={{uri: externalUrl}}` без allowlist |
| `25-webview-token-injection` | [src/Vuln25TokenInjection.tsx](src/Vuln25TokenInjection.tsx) | Token injection без origin-check | `onLoadEnd → injectJavaScript("window.__authToken=…")` |
| `26-webview-file-access` | [src/Vuln26FileAccess.tsx](src/Vuln26FileAccess.tsx) | WebView file access | `allowFileAccess` / `allowFileAccessFromFileURLs` / `allowUniversalAccessFromFileURLs` props |

## Маппинг нативных API → react-native-webview

| Натив (Kotlin/Java) | RN (react-native-webview) |
|---|---|
| `addJavascriptInterface(obj, "Native")` | `onMessage` + `window.ReactNativeWebView.postMessage` |
| `settings.javaScriptEnabled = true` | `javaScriptEnabled={true}` |
| `loadUrl(url)` | `source={{uri: url}}` |
| `evaluateJavascript(js, null)` | `injectJavaScript(js)` |
| `setAllowFileAccess*(true)` | `allowFileAccess*` props ✅ (в Flutter недоступно) |

## Раскладка файлов

```
rn_webview/
├── README.md · package.json · tsconfig.json · app.json · index.js
└── src/
    ├── App.tsx                 ← меню (state-switch на 4 экрана + back)
    ├── Vuln23JsBridge.tsx
    ├── Vuln24ArbitraryUrl.tsx
    ├── Vuln25TokenInjection.tsx
    └── Vuln26FileAccess.tsx
```

## Особенности RN-порта

- **JS-bridge семантика:** `react-native-webview` использует
  `window.ReactNativeWebView.postMessage(...)` → `onMessage` (JS→native).
  «Возврат токена» смоделирован ответным `injectJavaScript(...)`. Суть
  (нативная функция доступна любой странице без origin-check) сохранена.
- **VULN-26 выразительнее, чем в Flutter:** file-access настройки доступны
  как props компонента (в Flutter-плагине их нет).
- Экраны достижимы через state-switch в `App.tsx` (без react-navigation,
  чтобы не тянуть лишнюю зависимость).

## Форма

Src-снапшот: `src/` + конфиги. Манифест-уязвимостей нет.
