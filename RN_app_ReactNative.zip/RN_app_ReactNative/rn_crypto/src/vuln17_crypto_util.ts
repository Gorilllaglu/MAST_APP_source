import CryptoJS from 'crypto-js';

/**
 * VULN-17: сборная солянка криптографических ошибок (через crypto-js).
 *
 * 1. HARDCODED_KEY — ключ зашит как строковая константа.
 * 2. aesEcb — AES/ECB: раскрывает паттерны (одинаковые блоки → одинаковый ct).
 * 3. aesStaticIv — AES/CBC с константным нулевым IV → детерминированный ct.
 * 4. weakDes — DES: 56-битный ключ, brute-force за дни.
 * 5. md5Hash — MD5: коллизии, непригоден.
 * 6. sha1Hash — SHA-1: коллизии, deprecated.
 * 7. weakPbkdf — PBKDF2 с iterations=1000 (OWASP: ≥600000) + слабая соль.
 */
const HARDCODED_KEY = 'ThisIsTheKey1234';
const STATIC_IV = CryptoJS.enc.Hex.parse('00000000000000000000000000000000'); // нулевой IV
const WEAK_SALT = CryptoJS.enc.Utf8.parse('saltsalt');

export const CryptoUtil = {
  aesEcb(plaintext: string): string {
    const key = CryptoJS.enc.Utf8.parse(HARDCODED_KEY);
    return CryptoJS.AES.encrypt(plaintext, key, {
      mode: CryptoJS.mode.ECB, // <-- VULN: ECB
      padding: CryptoJS.pad.Pkcs7,
    }).toString();
  },

  aesStaticIv(plaintext: string): string {
    const key = CryptoJS.enc.Utf8.parse(HARDCODED_KEY);
    return CryptoJS.AES.encrypt(plaintext, key, {
      iv: STATIC_IV, // <-- VULN: static IV
      mode: CryptoJS.mode.CBC,
      padding: CryptoJS.pad.Pkcs7,
    }).toString();
  },

  weakDes(plaintext: string): string {
    const key = CryptoJS.enc.Utf8.parse('8byteKey');
    const iv = CryptoJS.enc.Hex.parse('0101010101010101');
    return CryptoJS.DES.encrypt(plaintext, key, {
      iv, // <-- VULN: weak cipher (DES)
      mode: CryptoJS.mode.CBC,
      padding: CryptoJS.pad.Pkcs7,
    }).toString();
  },

  md5Hash(input: string): string {
    return CryptoJS.MD5(input).toString(); // <-- VULN: weak hash
  },

  sha1Hash(input: string): string {
    return CryptoJS.SHA1(input).toString(); // <-- VULN: weak hash
  },

  weakPbkdf(password: string): string {
    return CryptoJS.PBKDF2(password, WEAK_SALT, {
      keySize: 128 / 32,
      iterations: 1000, // <-- VULN: low iter + weak salt
      hasher: CryptoJS.algo.SHA1,
    }).toString();
  },
};
