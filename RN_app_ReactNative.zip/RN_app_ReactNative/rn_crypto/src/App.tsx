import React, {useEffect} from 'react';
import {SafeAreaView, ScrollView, Button, Text, View} from 'react-native';

import {CryptoUtil} from './vuln17_crypto_util';

function runAll(): void {
  try {
    console.log(`ecb=${CryptoUtil.aesEcb('hello').length}`);
    console.log(`iv =${CryptoUtil.aesStaticIv('hello').length}`);
    console.log(`des=${CryptoUtil.weakDes('hello').length}`);
    console.log(`md5=${CryptoUtil.md5Hash('password')}`);
    console.log(`sha1=${CryptoUtil.sha1Hash('password')}`);
    console.log(`pbkdf=${CryptoUtil.weakPbkdf('password').length}`);
  } catch (_) {}
}

export default function App(): React.JSX.Element {
  useEffect(() => {
    runAll();
  }, []);

  return (
    <SafeAreaView>
      <ScrollView contentContainerStyle={{padding: 16}}>
        <Text>VULN-17: crypto misuse</Text>
        <View style={{height: 12}} />
        <Button title="Re-run all crypto sinks" onPress={runAll} />
        <View style={{height: 12}} />
        <Text>Sinks: hardcoded key · AES/ECB · static IV · DES · MD5 · SHA-1 · weak PBKDF</Text>
      </ScrollView>
    </SafeAreaView>
  );
}
