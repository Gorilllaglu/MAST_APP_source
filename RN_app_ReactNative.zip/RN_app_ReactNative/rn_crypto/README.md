# rn_crypto — React Native порт (crypto misuse)

Содержит **1** уязвимое приложение. Оставлено отдельным аппом — crypto-misuse
крупный самостоятельный класс с 7 sink'ами (каждому соответствует отдельное
правило сканера).

## Что объединено

| Оригинал | TS-файл | Класс уязвимости | Sinks |
|---|---|---|---|
| `17-crypto-misuse-grabbag` | [src/vuln17_crypto_util.ts](src/vuln17_crypto_util.ts) | Crypto misuse grab-bag | hardcoded key · AES/ECB · AES/CBC static IV · DES · MD5 · SHA-1 · PBKDF2 1000 iter + weak salt |

## Маппинг на crypto-js

| Sink | crypto-js |
|---|---|
| AES/ECB | `CryptoJS.AES.encrypt(pt, key, {mode: mode.ECB, padding: pad.Pkcs7})` |
| AES/CBC static IV | `{iv: STATIC_IV=0, mode: mode.CBC}` |
| DES | `CryptoJS.DES.encrypt(...)` |
| MD5 / SHA-1 | `CryptoJS.MD5(...)` / `CryptoJS.SHA1(...)` |
| weak PBKDF2 | `CryptoJS.PBKDF2(pwd, salt, {iterations: 1000, hasher: algo.SHA1})` |
| hardcoded key / salt / IV | строковые/Hex-литералы |

## Раскладка файлов

```
rn_crypto/
├── README.md · package.json · tsconfig.json · app.json · index.js
└── src/
    ├── App.tsx                 ← меню; useEffect дёргает все 7 sink'ов
    └── vuln17_crypto_util.ts
```

## Особенности RN-порта

- `crypto-js` — чистый JS, поддерживает MD5/SHA-1/AES(ECB,CBC)/DES/PBKDF2
  из коробки (в отличие от Flutter, где для DES/ECB нужен pointycastle).
- Все литералы и выбор слабых алгоритмов попадают в `index.android.bundle`
  (JSC ≈ исходный JS, Hermes → `.hbc`).

## Форма

Src-снапшот: `src/` + конфиги. Манифест-уязвимостей нет.
