import RNFS from 'react-native-fs';

/**
 * VULN-16 (часть 1): hardcoded секреты прямо в JS/TS-константах.
 *
 * В RN эти литералы попадают в JS-бандл `index.android.bundle`. С JSC
 * это почти исходный JS, с Hermes — байткод `.hbc` (достаётся
 * hermes-dec/hbctool). В любом случае секрет извлекается заметно проще,
 * чем из нативного DEX или Flutter AOT.
 */
export const SecretsHolder = {
  // подпись JWT, которую сервер использует для верификации
  jwtSigningKey: 's3cr3t-jwt-signing-key-do-not-share',
  // ключ AWS (формат намеренно похож на настоящий)
  awsAccessKeyId: 'AKIAIOSFODNN7EXAMPLE',
  awsSecretAccessKey: 'wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY',
  // токен админа на staging (часто забывают убрать)
  adminBearerToken: 'eyJhbGciOiJIUzI1NiJ9.eyJyb2xlIjoiYWRtaW4ifQ.fakeFakeFake',
  // VULN-16 (часть 2): аналог секретов из strings.xml — в RN это
  // обычные константы или значения react-native-config (.env → BuildConfig).
  apiSecretToken: 'sk_live_4eC39HqLyjWDarjtT1zdp7dc',
  hardcodedAdminPassword: 'P@ssw0rd-Admin-2024',
} as const;

export async function touchSecrets(): Promise<void> {
  // Используем секреты, чтобы их не вырезал minifier/dead-code-elim.
  console.log(`loaded ${SecretsHolder.jwtSigningKey.length} chars`);
  console.log(`admin pwd len=${SecretsHolder.hardcodedAdminPassword.length}`);

  // VULN-16 (часть 3): секретный материал, отгруженный в android assets.
  // Лежит в APK дословно (assets/), читается RNFS.readFileAssets.
  try {
    const creds = await RNFS.readFileAssets('api_credentials.txt'); // <-- VULN: shipped creds
    const cert = await RNFS.readFileAssets('server_cert.pem');      // <-- VULN: shipped private key/cert
    console.log(`api_credentials=${creds.length}B server_cert=${cert.length}B`);
  } catch (_) {}
}
