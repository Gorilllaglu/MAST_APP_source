import AsyncStorage from '@react-native-async-storage/async-storage';
import RNFS from 'react-native-fs';
import SQLite from 'react-native-sqlite-storage';

/**
 * VULN-20: storage grab-bag.
 *   (1) SQLite без шифрования с password в открытом виде.
 *   (2) Чувствительные данные (cookie/token) в AsyncStorage.
 *   (3) Секрет в external storage — читается другими приложениями.
 *
 * Нативный `MODE_WORLD_READABLE` (openFileOutput) из JS в RN недоступен —
 * эта часть оригинала опущена (она требует нативного модуля).
 */
export async function runStorageGrabbag(): Promise<void> {
  // (1) SQLite plaintext: password лежит в
  //     /data/data/<pkg>/databases/secrets.db без шифрования
  //     (никакого SQLCipher).
  try {
    const db = await SQLite.openDatabase({name: 'secrets.db', location: 'default'});
    await db.executeSql(
      'CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, login TEXT, password TEXT)');
    await db.executeSql(
      'INSERT INTO users (login, password) VALUES (?, ?)', ['alice', 'hunter2']); // <-- VULN: plaintext password
  } catch (_) {}

  // (2) sensitive token/cookie в AsyncStorage (без шифрования).
  try {
    await AsyncStorage.setItem(
      'auth_cookie', 'auth=eyJhbGciOiJIUzI1NiJ9.fake.fake; Path=/; Secure'); // <-- VULN
  } catch (_) {}

  // (3) секрет в external storage — где его прочитает любое приложение
  //     с READ_EXTERNAL_STORAGE.
  try {
    const path = `${RNFS.ExternalStorageDirectoryPath}/MAST_APP_BACKUP/secret_token.txt`;
    await RNFS.mkdir(`${RNFS.ExternalStorageDirectoryPath}/MAST_APP_BACKUP`);
    await RNFS.writeFile(path, 'eyJhbGciOiJIUzI1NiJ9.exfil-target.fake', 'utf8'); // <-- VULN: external storage
  } catch (_) {}
}
