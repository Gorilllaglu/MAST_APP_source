import AsyncStorage from '@react-native-async-storage/async-storage';

/**
 * VULN-01: Plaintext credentials in AsyncStorage (MASVS-STORAGE-1, CWE-312).
 *
 * AsyncStorage на Android хранит данные БЕЗ шифрования — в SQLite
 * (RKStorage) в /data/data/<pkg>/databases/. Значения тривиально
 * достаются с rooted-устройства, через `adb backup` или любым кодом,
 * читающим приватное хранилище приложения. Никакого слоя шифрования
 * (в отличие от react-native-encrypted-storage / Keychain) нет.
 */
export async function savePlaintextCreds(): Promise<void> {
  await AsyncStorage.setItem('password', 'hunter2');                                   // <-- VULN sink
  await AsyncStorage.setItem('auth_token', 'eyJhbGciOiJIUzI1NiJ9.fakepayload.fakesig'); // <-- VULN sink
}
