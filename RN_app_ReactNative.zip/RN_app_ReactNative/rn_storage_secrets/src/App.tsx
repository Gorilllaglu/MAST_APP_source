import React, {useEffect} from 'react';
import {SafeAreaView, ScrollView, Button, Text, View} from 'react-native';

import {savePlaintextCreds} from './vuln01_plaintext_async_storage';
import {touchSecrets} from './vuln16_hardcoded_secrets';
import {loadAllKeyMaterial} from './vuln37_keys_in_assets';
import {runStorageGrabbag} from './vuln20_storage_grabbag';

export default function App(): React.JSX.Element {
  useEffect(() => {
    // Безусловный запуск всех модулей (аналог нативного onCreate) —
    // чтобы sink'и были reachable и попали в JS-бандл.
    savePlaintextCreds();
    touchSecrets();
    loadAllKeyMaterial();
    runStorageGrabbag();
  }, []);

  return (
    <SafeAreaView>
      <ScrollView contentContainerStyle={{padding: 16}}>
        <Text>VULN: storage &amp; secrets</Text>
        <View style={{height: 12}} />
        <Button title="VULN-01: plaintext AsyncStorage" onPress={savePlaintextCreds} />
        <View style={{height: 8}} />
        <Button title="VULN-16: hardcoded secrets shipped" onPress={touchSecrets} />
        <View style={{height: 8}} />
        <Button title="VULN-37: key material in assets" onPress={loadAllKeyMaterial} />
        <View style={{height: 8}} />
        <Button title="VULN-20: SQLite plaintext / external storage" onPress={runStorageGrabbag} />
      </ScrollView>
    </SafeAreaView>
  );
}
