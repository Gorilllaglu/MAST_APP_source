import RNFS from 'react-native-fs';

/**
 * VULN-37: ключевой/сертификатный материал, зашитый в android assets
 * (R026–R029).
 *
 * Восемь файлов реально читаются из бандла (RNFS.readFileAssets), чтобы
 * у сканера была видна связка «файл в assets» ↔ «использование в коде».
 * Содержимое — placeholder'ы; нативного KeyStore/CertificateFactory в JS
 * нет, поэтому в RN-порте мы ограничиваемся чтением + использованием
 * hardcoded-паролей к зашифрованным контейнерам.
 */
export const KeyMaterialUsage = {
  // Hardcoded passwords к зашифрованным контейнерам — typical defaults.
  encryptedPemPassword: 'changeit',
  pkcs12Password: 'changeit',
  bksPassword: 'android',
} as const;

export async function loadAllKeyMaterial(): Promise<void> {
  // === R026: публичные ключи / сертификаты ===
  await readText('public_cert_x509.pem', 'X.509 cert');
  await readText('public_key_rsa.pem', 'RSA public key');

  // === R027: приватные ключи БЕЗ пароля ===
  await readText('private_unencrypted_pkcs8.pem', 'unencrypted PKCS#8 priv');
  await readText('private_unencrypted_rsa.pem', 'legacy RSA priv');

  // === R028: приватные ключи / keystore'ы С паролем ===
  await readText('private_encrypted_pkcs8.pem',
    `encrypted PEM (pwd=${KeyMaterialUsage.encryptedPemPassword})`);
  await readBin('client_pkcs12.p12', `PKCS#12 (pwd=${KeyMaterialUsage.pkcs12Password})`);
  await readBin('client_bouncy.bks', `BKS (pwd=${KeyMaterialUsage.bksPassword})`);

  // === R029: «общая категория» — generic key blob ===
  await readBin('mystery_key.bin', 'mystery key blob');
}

async function readText(name: string, label: string): Promise<void> {
  try {
    const data = await RNFS.readFileAssets(name); // <-- VULN: shipped key material
    console.log(`${label} loaded: ${data.length} chars from ${name}`);
  } catch (_) {}
}

async function readBin(name: string, label: string): Promise<void> {
  try {
    const data = await RNFS.readFileAssets(name, 'base64'); // <-- VULN: shipped key material
    console.log(`${label} loaded: ${data.length}B (base64) from ${name}`);
  } catch (_) {}
}
