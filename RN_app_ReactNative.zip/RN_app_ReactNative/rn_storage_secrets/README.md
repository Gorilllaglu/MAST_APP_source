# rn_storage_secrets — React Native порт (storage & secrets)

Консолидирует **4** уязвимых приложения нативного MAST-стенда в одно
RN-приложение (на RN, как и на Flutter, объединяем тематически — RN-апп
это одна `MainActivity` + JS-логика).

## Что объединено

| Оригинал | TS-файл | Класс уязвимости | Sink |
|---|---|---|---|
| `01-storage-plaintext-prefs` | [src/vuln01_plaintext_async_storage.ts](src/vuln01_plaintext_async_storage.ts) | Plaintext creds (MASVS-STORAGE-1, CWE-312) | `AsyncStorage.setItem('password'/'auth_token', …)` |
| `16-creds-and-keys-shipped` | [src/vuln16_hardcoded_secrets.ts](src/vuln16_hardcoded_secrets.ts) | Hardcoded secrets shipped | JS `const` (JWT/AWS/admin) + `RNFS.readFileAssets(...)` |
| `37-keys-and-certs-in-resources` | [src/vuln37_keys_in_assets.ts](src/vuln37_keys_in_assets.ts) | Key/cert material в assets (R026–R029) | `RNFS.readFileAssets(*.pem/.p12/.bks/.bin)` + hardcoded container passwords |
| `20-storage-grabbag` | [src/vuln20_storage_grabbag.ts](src/vuln20_storage_grabbag.ts) | Storage grab-bag | SQLite plaintext password · AsyncStorage cookie · external storage write |

## Раскладка файлов

```
rn_storage_secrets/
├── README.md
├── package.json                    ← deps: async-storage, sqlite-storage, react-native-fs
├── tsconfig.json
├── app.json / index.js             ← RN entry
├── src/
│   ├── App.tsx                     ← меню; useEffect дёргает все 4 модуля
│   ├── vuln01_plaintext_async_storage.ts
│   ├── vuln16_hardcoded_secrets.ts
│   ├── vuln37_keys_in_assets.ts
│   └── vuln20_storage_grabbag.ts
└── android/app/src/main/assets/    ← реальный секретный/ключевой материал (1:1 из оригиналов)
    ├── api_credentials.txt, server_cert.pem            (vuln16)
    └── *.pem / client_pkcs12.p12 / client_bouncy.bks / mystery_key.bin  (vuln37)
```

## Особенности RN-порта (важно для анализа)

- **JS-логика → `index.android.bundle`.** Sink'и и секреты лежат в бандле:
  JSC ≈ исходный JS, Hermes → `.hbc` байткод (`hermes-dec`/`hbctool`). Это
  **проще для восстановления**, чем нативный DEX/jadx или Flutter `libapp.so`.
- **Assets — нативный путь:** в RN бандлить произвольный файл идиоматично
  через `android/app/src/main/assets/` + `RNFS.readFileAssets(name)`. Файлы
  лежат в APK дословно — стандартный «shipped material»-сигнал.
- **AsyncStorage не шифрует** (SQLite RKStorage) — прямой аналог нативного
  plaintext SharedPreferences.
- **Опущено:** нативный `MODE_WORLD_READABLE` из vuln20 (требует нативного
  модуля, из JS недоступен) — отмечено в коде.

## Форма

Src-снапшот: `src/` + `package.json`/`tsconfig.json` + `android/.../assets`,
без полного RN-скаффолда (`android/`/`ios/` gradle-обвязка). Для сборки —
обернуть в `npx react-native init` каркас и `npm i && react-native run-android`.
