# rn_auth_resilience — React Native порт (auth & resilience)

Консолидирует **2** уязвимых приложения нативного стенда.

## Что объединено

| Оригинал | TS-файл | Класс уязвимости | Sink |
|---|---|---|---|
| `31-auth-misconfig-grabbag` | [src/vuln31_auth_misconfig.ts](src/vuln31_auth_misconfig.ts) | Biometric без crypto-binding · OAuth без PKCE/state · hardcoded backdoor | `ReactNativeBiometrics.simplePrompt()` (bool) → unlock-флаг · OAuth-URL без `code_challenge`/`state` · сравнение с `admin:debugbypass` |
| `32-no-protections-baseline` | [src/vuln32_no_protections.ts](src/vuln32_no_protections.ts) | Отсутствие RASP-проверок | (нет root/emu/debugger/Frida/integrity/screen-lock — sink = absence) |

## Раскладка файлов

```
rn_auth_resilience/
├── README.md · package.json · tsconfig.json · app.json · index.js
└── src/
    ├── App.tsx                 ← меню; useEffect дёргает OAuth/backdoor/baseline
    ├── vuln31_auth_misconfig.ts
    └── vuln32_no_protections.ts
```

## Особенности RN-порта

- **Биометрия без crypto-binding:** `react-native-biometrics.simplePrompt()`
  возвращает только `{success}`. Безопасный путь той же библиотеки —
  `createSignature(...)` с ключом из keystore — НЕ используется. То есть
  «биометрия как yes/no-флаг» — уязвимость по построению (как и в Flutter).
- **VULN-32** — чистое «отсутствие защит»: сканер репортит по факту
  ненахождения jail-monkey / device-info / нативных проверок.
- Dart-аналог: см. `dart_auth_resilience`. Логика (OAuth-URL, backdoor) —
  в `index.android.bundle`.

## Форма

Src-снапшот: `src/` + конфиги. Манифест-уязвимостей нет.
