/**
 * VULN-32: «vanilla» приложение БЕЗ каких-либо защитных проверок.
 *
 * Намеренно НЕ содержит:
 *   - root detection (нет jail-monkey / нативных проверок su/Magisk);
 *   - emulator detection (нет проверок Build.* через react-native-device-info);
 *   - debugger detection;
 *   - Frida detection (нет поиска /data/local/tmp/frida-server);
 *   - app integrity check (нет сверки подписи APK);
 *   - screen-lock check.
 *
 * Сканер должен сообщить, что эти защиты ОТСУТСТВУЮТ. Проверка делается
 * по факту отсутствия в проекте соответствующих вызовов/зависимостей —
 * поэтому код тривиален.
 */
export const NoProtectionsBaseline = {
  noop(): void {
    // намеренно пусто — отсутствие проверок и есть «уязвимость»
  },
};
