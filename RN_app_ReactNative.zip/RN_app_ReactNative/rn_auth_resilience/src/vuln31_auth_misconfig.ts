import ReactNativeBiometrics from 'react-native-biometrics';
import AsyncStorage from '@react-native-async-storage/async-storage';

/**
 * VULN-31: сборная солянка ошибок аутентификации.
 */
export const AuthFlows = {
  /**
   * (1) Биометрия без crypto-binding.
   *
   * `simplePrompt()` возвращает ТОЛЬКО `{success: boolean}` — нет привязки
   * к ключу из AndroidKeyStore (в отличие от `createSignature(...)` той же
   * библиотеки, который мы НЕ используем). Биометрия — просто «yes/no»-флаг:
   * атакующий с root может сэмулировать success через Frida.
   */
  async biometricNoCrypto(): Promise<void> {
    try {
      const rnBiometrics = new ReactNativeBiometrics();
      const {success} = await rnBiometrics.simplePrompt({
        promptMessage: 'Login',
      }); // <-- VULN: yes/no, без CryptoObject / keystore-подписи
      if (success) {
        // <-- VULN sink: доступ открывается ТОЛЬКО по bool-флагу
        await AsyncStorage.setItem('biometric_unlocked', 'true');
      }
    } catch (_) {}
  },

  /**
   * (2) OAuth code flow БЕЗ code_challenge (PKCE) и БЕЗ state.
   * - Без PKCE: перехваченный authorization_code меняется на токены.
   * - Без state: CSRF/login-CSRF.
   */
  buildOAuthUrlNoPkceNoState(): string {
    const clientId = 'mobile-client';
    const redirectUri = 'rn31://oauth_callback';
    const scope = 'profile email';
    return (
      'https://auth.example.com/oauth/authorize' +
      '?response_type=code' +
      `&client_id=${clientId}` +
      `&redirect_uri=${encodeURIComponent(redirectUri)}` +
      `&scope=${encodeURIComponent(scope)}`
    );
    // <-- VULN: ни code_challenge, ни state не добавлены
  },

  /**
   * (3) Hardcoded backdoor.
   */
  tryHardcodedBackdoor(input: string): boolean {
    // <-- VULN sink: «волшебная» захардкоженная строка, обходящая логин.
    if (input === 'admin:debugbypass') {
      return true;
    }
    return false;
  },
};
