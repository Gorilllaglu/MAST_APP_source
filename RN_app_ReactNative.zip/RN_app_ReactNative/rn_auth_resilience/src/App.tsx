import React, {useEffect} from 'react';
import {SafeAreaView, ScrollView, Button, Text, View} from 'react-native';

import {AuthFlows} from './vuln31_auth_misconfig';
import {NoProtectionsBaseline} from './vuln32_no_protections';

export default function App(): React.JSX.Element {
  useEffect(() => {
    // (2) OAuth-URL без PKCE/state.
    const url = AuthFlows.buildOAuthUrlNoPkceNoState();
    console.log(`oauth url len=${url.length}`);
    // (3) Hardcoded backdoor.
    AuthFlows.tryHardcodedBackdoor('admin:debugbypass');
    // (4) Отсутствие RASP-проверок (baseline).
    NoProtectionsBaseline.noop();
  }, []);

  return (
    <SafeAreaView>
      <ScrollView contentContainerStyle={{padding: 16}}>
        <Text>VULN: auth &amp; resilience</Text>
        <View style={{height: 12}} />
        <Button
          title="VULN-31: biometric without crypto binding"
          onPress={AuthFlows.biometricNoCrypto}
        />
        <View style={{height: 8}} />
        <Button
          title="VULN-31: OAuth no-PKCE / hardcoded backdoor"
          onPress={() => AuthFlows.tryHardcodedBackdoor('admin:debugbypass')}
        />
        <View style={{height: 12}} />
        <Text>
          VULN-32: no root/emulator/debugger/Frida/integrity/screen-lock checks
          (absence is the finding)
        </Text>
      </ScrollView>
    </SafeAreaView>
  );
}
