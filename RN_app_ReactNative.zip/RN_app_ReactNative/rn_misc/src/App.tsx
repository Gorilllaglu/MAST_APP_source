import React, {useEffect} from 'react';
import {SafeAreaView, ScrollView, Text, View} from 'react-native';
import RNFS from 'react-native-fs';

import {unzip} from './vuln14_zip_slip';
import {readUserFile} from './vuln15_path_traversal';
import {leakViaLogs, buildLoggingClient} from './vuln21_logging';

export default function App(): React.JSX.Element {
  useEffect(() => {
    // VULN-14: имитируем «скачали zip и распаковываем». Несуществующий
    // файл просто приведёт к ошибке (поглощается внутри unzip).
    const tmp = RNFS.CachesDirectoryPath;
    unzip(`${tmp}/downloaded.zip`, `${tmp}/unpacked`);

    // VULN-15: имя файла из «внешнего источника» с traversal.
    readUserFile('../../databases/secrets.db');

    // VULN-21: логирование секретов + клиент с logging-interceptor.
    leakViaLogs();
    buildLoggingClient();
  }, []);

  return (
    <SafeAreaView>
      <ScrollView contentContainerStyle={{padding: 16}}>
        <Text>VULN: misc</Text>
        <View style={{height: 8}} />
        <Text>VULN-14: zip-slip (unzip без проверки "../")</Text>
        <Text>VULN-15: path traversal (filename из внешнего источника)</Text>
        <Text>VULN-21: secrets в console.* + axios logging interceptor</Text>
        <Text>VULN-10: manifest flags — android/app/src/main/AndroidManifest.xml</Text>
        <Text>VULN-11: NSC — android/.../res/xml/network_security_config.xml</Text>
      </ScrollView>
    </SafeAreaView>
  );
}
