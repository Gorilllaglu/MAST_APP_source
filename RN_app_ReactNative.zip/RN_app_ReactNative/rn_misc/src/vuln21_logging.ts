import axios, {AxiosInstance} from 'axios';

/**
 * VULN-21: логирование чувствительных данных.
 */
export function leakViaLogs(): void {
  const username = 'alice';
  const password = 'hunter2';
  const authToken = 'eyJhbGciOiJIUzI1NiJ9.fakepayload.fakesig';

  // (1) console.* со чувствительными данными — на Android уходит в logcat
  //     (ReactNativeJS tag).
  console.log(`user=${username} pass=${password}`);          // <-- VULN: password в логе
  console.warn(`issued token=${authToken}`);                 // <-- VULN: токен в логе
  console.log('credit_card=4242 4242 4242 4242 cvv=123');    // <-- VULN: PII в логе
}

/**
 * (2) axios-интерсептор, логирующий ВСЁ тело и заголовки запроса/ответа
 * (включая Authorization и тело логина с password). Аналог OkHttp
 * HttpLoggingInterceptor.Level.BODY.
 */
export function buildLoggingClient(): AxiosInstance {
  const client = axios.create();
  client.interceptors.request.use(config => {
    // <-- VULN: тело + заголовки запроса в логе
    console.log('REQ', config.method, config.url,
      JSON.stringify(config.headers), JSON.stringify(config.data));
    return config;
  });
  client.interceptors.response.use(resp => {
    // <-- VULN: тело ответа в логе
    console.log('RESP', resp.status, JSON.stringify(resp.data));
    return resp;
  });
  return client;
}
