import RNFS from 'react-native-fs';

/**
 * VULN-15: Path Traversal через File I/O.
 *
 * Имя файла приходит из внешнего источника (deeplink-параметр / аргумент)
 * и конкатенируется к базовой директории БЕЗ нормализации и проверки по
 * whitelist. Передав `../../databases/secrets.db`, вызывающий читает чужой
 * приватный файл приложения.
 *
 * Безопасный паттерн (НЕ реализован): нормализовать итоговый путь и
 * проверить `startsWith(base + '/')`.
 */
export async function readUserFile(filename: string): Promise<string | null> {
  try {
    const base = `${RNFS.DocumentDirectoryPath}/user_files`;
    const target = `${base}/${filename}`; // <-- VULN sink: filename может содержать '../'
    const text = await RNFS.readFile(target, 'utf8');
    console.log(`read ${text.length} chars from ${target}`);
    return text;
  } catch (_) {
    return null;
  }
}
