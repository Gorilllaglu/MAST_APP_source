import JSZip from 'jszip';
import RNFS from 'react-native-fs';

/**
 * VULN-14: zip-slip — распаковка zip без проверки имён entries.
 *
 * Имена записей в архиве могут содержать `../` и приводить к записи файла
 * за пределы целевой директории (Zip-Slip, CVE-2018-1002200). Здесь путь
 * строится как `${targetDir}/${entry.name}` без нормализации/проверки, что
 * результат остаётся внутри targetDir.
 *
 * Безопасный вариант (НЕ реализован): нормализовать путь и проверить, что
 * он начинается с `targetDir + '/'`, иначе бросить ошибку.
 */
export async function unzip(zipPath: string, targetDir: string): Promise<void> {
  try {
    const base64 = await RNFS.readFile(zipPath, 'base64');
    const zip = await JSZip.loadAsync(base64, {base64: true});
    for (const name of Object.keys(zip.files)) {
      const entry = zip.files[name];
      const outPath = `${targetDir}/${name}`; // <-- VULN sink: нет проверки '..'
      if (entry.dir) {
        await RNFS.mkdir(outPath);
      } else {
        const content = await entry.async('base64');
        const parent = outPath.substring(0, outPath.lastIndexOf('/'));
        await RNFS.mkdir(parent);
        await RNFS.writeFile(outPath, content, 'base64'); // <-- VULN: запись за пределы targetDir
      }
    }
  } catch (_) {}
}
