# rn_misc — React Native порт (misc: zip-slip · path-traversal · logging · manifest · NSC)

Консолидирует **5** уязвимых приложений нативного стенда: три на уровне
JS-кода (14, 15, 21) и две на уровне манифеста/ресурсов (10, 11).

## Что объединено

| Оригинал | Где | Класс уязвимости | Sink |
|---|---|---|---|
| `14-zip-slip` | [src/vuln14_zip_slip.ts](src/vuln14_zip_slip.ts) | Zip-Slip (CWE-22) | `'${targetDir}/${entry.name}'` + `RNFS.writeFile` без проверки `..` |
| `15-path-traversal-fileio` | [src/vuln15_path_traversal.ts](src/vuln15_path_traversal.ts) | Path traversal | `${base}/${filename}` + `RNFS.readFile`, filename из внешнего источника |
| `21-logging-grabbag` | [src/vuln21_logging.ts](src/vuln21_logging.ts) | Sensitive data in logs | `console.log/warn` с password/token/PII · axios interceptor (тело+заголовки) |
| `10-manifest-flags-grabbag` | [android/.../AndroidManifest.xml](android/app/src/main/AndroidManifest.xml) | Опасные манифест-флаги | `debuggable` · `allowBackup` · `hasFragileUserData` · `requestLegacyExternalStorage` |
| `11-nsc-misconfig` | [android/.../res/xml/network_security_config.xml](android/app/src/main/res/xml/network_security_config.xml) | NSC misconfig | trust `user` CA + `cleartextTrafficPermitted="true"` |

## Раскладка файлов

```
rn_misc/
├── README.md · package.json · tsconfig.json · app.json · index.js
├── src/
│   ├── App.tsx                 ← меню; useEffect дёргает zip-slip + path-traversal + logging
│   ├── vuln14_zip_slip.ts
│   ├── vuln15_path_traversal.ts
│   └── vuln21_logging.ts
└── android/app/src/main/
    ├── AndroidManifest.xml     ← VULN-10: 4 флага + ссылка на NSC
    └── res/xml/network_security_config.xml   ← VULN-11
```

## Особенности RN-порта

- **14 / 15 / 21 — на уровне JS** (в `index.android.bundle`): zip-slip через
  `jszip` + `react-native-fs` (пер-entry путь строится в JS, поэтому zip-slip
  выражается явно — нативный `react-native-zip-archive` это бы спрятал);
  path-traversal через `RNFS.readFile`; логирование через `console.*` +
  axios interceptor (аналог `HttpLoggingInterceptor.BODY`).
- **10 / 11 — манифест/ресурсный уровень** (нативная обёртка RN-проекта),
  ловятся сканером обычным путём.

## Форма

Src-снапшот: `src/` + конфиги + те части `android/`, где живут манифест/NSC.
