# rn_network_tls — React Native порт (network & TLS)

Консолидирует **3** уязвимых приложения нативного стенда.

## Что объединено

| Оригинал | Где | Класс уязвимости | Sink |
|---|---|---|---|
| `06-network-cleartext-http` | [src/vuln06_cleartext_http.ts](src/vuln06_cleartext_http.ts) | Cleartext HTTP (MASVS-NETWORK-1, CWE-319) | `fetch('http://…')` + Authorization Bearer **+ манифест** `usesCleartextTraffic="true"` |
| `33-sensitive-transit-grabbag` | [src/vuln33_sensitive_transit.ts](src/vuln33_sensitive_transit.ts) | Sensitive data in transit | токен в query-URL · JWT в `WebSocket.send(...)` · password в URL POST |
| `19-tls-misconfig-grabbag` | [src/vuln19_tls_misconfig.ts](src/vuln19_tls_misconfig.ts) + [NSC](android/app/src/main/res/xml/network_security_config.xml) | TLS misconfig | no-pinning (дефолт RN, plain `fetch`) + **NSC** trust user-CA (MITM) |

## Раскладка файлов

```
rn_network_tls/
├── README.md · package.json · tsconfig.json · app.json · index.js
├── src/
│   ├── App.tsx                     ← меню; useEffect дёргает все 3 модуля
│   ├── vuln06_cleartext_http.ts
│   ├── vuln19_tls_misconfig.ts
│   └── vuln33_sensitive_transit.ts
└── android/app/src/main/
    ├── AndroidManifest.xml         ← VULN-06 usesCleartextTraffic + VULN-19 NSC ref
    └── res/xml/network_security_config.xml   ← VULN-19 (trust user CA)
```

## Особенности RN-порта

- **Сеть — на built-in `fetch`/`WebSocket`** (через нативный OkHttp), без
  доп. пакетов.
- **VULN-19 — главное отличие от Flutter-порта.** В Dart trust-all делался
  одной строкой (`badCertificateCallback`), а в RN из JS это невозможно:
  - **no-pinning** — дефолт RN (нет `react-native-ssl-pinning`), показан
    обычным `fetch`;
  - **trust-all** — вынесен в `network_security_config.xml` (доверие user-CA);
  - **hostname-only pinning** — требует нативного кода, опущен.
- **VULN-06 / VULN-19 манифест-часть** ловится сканером обычным путём
  (манифест/`res/xml`), в отличие от JS-логики (она в `index.android.bundle`).

## Форма

Src-снапшот: `src/` + конфиги + те части `android/`, где живут манифест/NSC.
