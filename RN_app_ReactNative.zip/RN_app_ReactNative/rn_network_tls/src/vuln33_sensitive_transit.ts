/**
 * VULN-33: чувствительные данные в транзите.
 */
const authToken = 'eyJhbGciOiJIUzI1NiJ9.fake.fake';
const username = 'alice';

export async function sensitiveTransit(): Promise<void> {
  // (1) HTTPS-запрос с токеном В query-параметрах URL.
  //     Серверы/proxy логируют URL целиком (access.log) + Referer.
  try {
    const url =
      `https://api.example.com/profile?token=${encodeURIComponent(authToken)}` + // <-- VULN sink
      `&user=${encodeURIComponent(username)}`;
    await fetch(url);
  } catch (_) {}

  // (2) WebSocket-сообщение с JWT прямо в payload.
  try {
    const ws = new WebSocket('wss://realtime.example.com/socket');
    ws.onopen = () => {
      ws.send(`{"action":"auth","jwt":"${authToken}","user":"${username}"}`); // <-- VULN sink
      ws.close();
    };
  } catch (_) {}

  // (3) POST с password в URL.
  try {
    await fetch('https://api.example.com/legacy_login?password=hunter2', {       // <-- VULN: password в URL
      method: 'POST',
    });
  } catch (_) {}
}
