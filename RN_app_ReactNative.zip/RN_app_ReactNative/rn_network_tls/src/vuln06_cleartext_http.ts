/**
 * VULN-06: Cleartext HTTP traffic (MASVS-NETWORK-1, CWE-319).
 *
 * Два усиливающих фактора:
 *   1. AndroidManifest: android:usesCleartextTraffic="true"
 *      (см. android/app/src/main/AndroidManifest.xml). Без него Android
 *      (target API 28+) блокирует http:// по умолчанию.
 *   2. Реальный HTTP (не HTTPS) fetch на hardcoded URL с Authorization
 *      Bearer — пользователь предполагается авторизованным.
 */
export async function fetchInsecure(): Promise<void> {
  try {
    const resp = await fetch('http://api.example.com/v1/profile', {     // <-- VULN sink: plain HTTP
      method: 'GET',
      headers: {Authorization: 'Bearer eyJhbGciOiJIUzI1NiJ9.fake.fake'},
    });
    const body = await resp.text();
    console.log(`got ${body.length} bytes`);
  } catch (_) {}
}
