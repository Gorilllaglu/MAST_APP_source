/**
 * VULN-19: TLS misconfig.
 *
 * В RN проверку TLS из JS отключить нельзя — fetch/XHR ходят через
 * нативный OkHttp. Поэтому три исходных под-уязвимости маппятся так:
 *   - **no-pinning** (отсутствие certificate pinning) — это ДЕФОЛТ RN:
 *     здесь нет ни react-native-ssl-pinning, ни нативного CertificatePinner.
 *     Обычный fetch ниже это и демонстрирует.
 *   - **trust-all / trust-user-CA** — смоделировано на уровне
 *     res/xml/network_security_config.xml: доверие user-CA → MITM через
 *     прокси с подсунутым «корпоративным» сертификатом.
 *   - **hostname-only "pinning"** в чистом JS не выражается (нужен native).
 */
export async function noPinningRequest(): Promise<void> {
  try {
    // <-- VULN: обычный fetch без какого-либо certificate pinning'а
    const resp = await fetch('https://api.example.com/profile');
    console.log(`status ${resp.status}`);
  } catch (_) {}
}
