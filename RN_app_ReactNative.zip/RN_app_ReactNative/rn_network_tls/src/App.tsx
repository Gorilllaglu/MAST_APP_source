import React, {useEffect} from 'react';
import {SafeAreaView, ScrollView, Button, Text, View} from 'react-native';

import {fetchInsecure} from './vuln06_cleartext_http';
import {noPinningRequest} from './vuln19_tls_misconfig';
import {sensitiveTransit} from './vuln33_sensitive_transit';

export default function App(): React.JSX.Element {
  useEffect(() => {
    fetchInsecure();
    noPinningRequest();
    sensitiveTransit();
  }, []);

  return (
    <SafeAreaView>
      <ScrollView contentContainerStyle={{padding: 16}}>
        <Text>VULN: network &amp; TLS</Text>
        <View style={{height: 12}} />
        <Button title="VULN-06: cleartext HTTP + Bearer" onPress={fetchInsecure} />
        <View style={{height: 8}} />
        <Button title="VULN-19: no certificate pinning" onPress={noPinningRequest} />
        <View style={{height: 8}} />
        <Button title="VULN-33: token in URL / JWT in WebSocket" onPress={sensitiveTransit} />
      </ScrollView>
    </SafeAreaView>
  );
}
