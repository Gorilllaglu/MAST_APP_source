package ru.corp.app.security;

import ru.sberbank.cerbersdk.sdk_framework.DebugBypassChecker;

/**
 * Изоляция: в файле ровно один целевой вызов, и он в первом методе класса,
 * внутри условия. Это та же форма, что не сработала на строке 20
 * файла DebugBypassUsage.java, при том что идентичные строки 36 и 44 сработали.
 *
 * J1-ISO-1. Сработка обязательна. Если её нет — у движка особенность
 * с первым методом класса либо с вызовом в условии на верхнем уровне.
 */
public final class IsoFirstMethod {

    public static boolean isDeviceTrusted() {
        if (DebugBypassChecker.shouldBypassRootEmulatorCheck()) {
            return true;
        }
        return false;
    }
}
