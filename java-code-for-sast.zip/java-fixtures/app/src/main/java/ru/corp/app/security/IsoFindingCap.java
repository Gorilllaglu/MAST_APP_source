package ru.corp.app.security;

import ru.sberbank.cerbersdk.sdk_framework.DebugBypassChecker;

/**
 * Проверка предела числа находок на файл. Двенадцать одинаковых целевых
 * вызовов, по одному в методе, строки заранее известны.
 *
 * J1-CAP. Ожидается двенадцать сработок. Если их меньше — у движка есть
 * предел на файл, и тогда в реальном коде файл с множеством нарушений
 * покажет только часть, а остальные будут невидимы для гейта.
 * Это объяснило бы, почему в DebugBypassUsage.java из семи вызовов
 * сработали пять.
 */
public final class IsoFindingCap {

    private IsoFindingCap() { }

    public static boolean c01() { return DebugBypassChecker.shouldBypassRootEmulatorCheck(); }
    public static boolean c02() { return DebugBypassChecker.shouldBypassRootEmulatorCheck(); }
    public static boolean c03() { return DebugBypassChecker.shouldBypassRootEmulatorCheck(); }
    public static boolean c04() { return DebugBypassChecker.shouldBypassRootEmulatorCheck(); }
    public static boolean c05() { return DebugBypassChecker.shouldBypassRootEmulatorCheck(); }
    public static boolean c06() { return DebugBypassChecker.shouldBypassRootEmulatorCheck(); }
    public static boolean c07() { return DebugBypassChecker.shouldBypassRootEmulatorCheck(); }
    public static boolean c08() { return DebugBypassChecker.shouldBypassRootEmulatorCheck(); }
    public static boolean c09() { return DebugBypassChecker.shouldBypassRootEmulatorCheck(); }
    public static boolean c10() { return DebugBypassChecker.shouldBypassRootEmulatorCheck(); }
    public static boolean c11() { return DebugBypassChecker.shouldBypassRootEmulatorCheck(); }
    public static boolean c12() { return DebugBypassChecker.shouldBypassRootEmulatorCheck(); }
}
