package ru.corp.app.security;

import ru.sberbank.cerbersdk.sdk_framework.DebugBypassChecker;

/**
 * Изоляция пропуска лямбды. Три формы тела, по одному вызову в каждой,
 * чтобы отделить блочную лямбду от лямбды-выражения и от ссылки на метод.
 */
public final class IsoLambdaBody {

    private IsoLambdaBody() { }

    /** J1-ISO-2. Лямбда с блочным телом. На строке 54 исходного файла не сработала. */
    public static Runnable blockLambda() {
        return () -> {
            if (DebugBypassChecker.shouldBypassRootEmulatorCheck()) {
                System.out.println("relaxed");
            }
        };
    }

    /** J1-ISO-3. Лямбда с телом-выражением, без фигурных скобок. */
    public static java.util.function.Supplier<Boolean> expressionLambda() {
        return () -> DebugBypassChecker.shouldBypassRootEmulatorCheck();
    }

    /** J1-ISO-4. Ссылка на метод: вызова как выражения нет вообще. */
    public static java.util.function.Supplier<Boolean> methodRef() {
        return DebugBypassChecker::shouldBypassRootEmulatorCheck;
    }

    /** J1-ISO-5. Контроль: тот же вызов в обычном методе рядом. Обязан сработать. */
    public static boolean plainMethod() {
        return DebugBypassChecker.shouldBypassRootEmulatorCheck();
    }
}
