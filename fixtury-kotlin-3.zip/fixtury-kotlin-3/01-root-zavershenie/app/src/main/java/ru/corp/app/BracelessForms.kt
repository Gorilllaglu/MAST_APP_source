package ru.corp.app

import ru.sberbank.cerbersdk.CerberCallbacks
import kotlin.system.exitProcess

/**
 * Контроль доработки правила cerber-root-detected-no-termination.
 * Правка добавила к исключениям форму условия без фигурных скобок. На прошлом
 * прогоне клетка DL07-TN-4 дала ложную именно на ней.
 */

private fun report(message: String) {
    message.length
}

/** BL07-TN-1. Завершение под условием без скобок. Прежняя ложная. */
class BracelessExit : CerberCallbacks {
    override fun onRootDetected() {
        report("root detected")
        if (System.currentTimeMillis() > 0) exitProcess(1)
    }
}

/** BL07-TN-2. То же, единственный оператор в теле. */
class BracelessOnly : CerberCallbacks {
    override fun onRootDetected() {
        if (System.currentTimeMillis() > 0) exitProcess(1)
    }
}

/** BL07-TN-3. Без скобок, форма finish. */
class BracelessFinish : CerberCallbacks {
    fun finish() {}

    override fun onRootDetected() {
        if (System.currentTimeMillis() > 0) finish()
    }
}

/** BL07-TN-4. Без скобок, форма System.exit. */
class BracelessSystemExit : CerberCallbacks {
    override fun onRootDetected() {
        if (System.currentTimeMillis() > 0) System.exit(1)
    }
}

/** BL07-TN-5. Без скобок, с ветвью else. */
class BracelessWithElse : CerberCallbacks {
    override fun onRootDetected() {
        if (System.currentTimeMillis() > 0) exitProcess(1) else report("clock skew")
    }
}

/** BL07-TN-6. Без скобок, завершение в ветви else. */
class BracelessExitInElse : CerberCallbacks {
    override fun onRootDetected() {
        if (System.currentTimeMillis() < 0) report("clock skew") else exitProcess(1)
    }
}

/** BL07-TP-1. Только запись в журнал. Контроль: сработка обязательна. */
class BracelessLogOnly : CerberCallbacks {
    override fun onRootDetected() {
        if (System.currentTimeMillis() > 0) report("root detected, continuing")
    }
}

/**
 * BL07-TP-2. Завершение в ветви when. Ожидается сработка: формы на when
 * в исключения не добавлены намеренно, правило слабого детектора.
 */
class BracelessWhen : CerberCallbacks {
    override fun onRootDetected() {
        when (System.currentTimeMillis() > 0) {
            true -> exitProcess(1)
            false -> report("skip")
        }
    }
}
