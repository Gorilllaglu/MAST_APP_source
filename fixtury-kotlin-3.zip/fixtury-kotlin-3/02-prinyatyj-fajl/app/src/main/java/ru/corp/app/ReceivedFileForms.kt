package ru.corp.app

import android.net.Uri
import ru.sberbank.cerbersdk.CerberCallbacks
import ru.sberbank.cerbersdk.CerberCallbacksNullableBoth
import ru.sberbank.cerbersdk.CerberCallbacksNullablePkg
import ru.sberbank.cerbersdk.CerberCallbacksNullableUri
import java.io.File
import java.io.FileOutputStream

/**
 * Контроль доработки правила cerber-received-file-not-copied.
 * Правка добавила все четыре написания типов параметров: Uri и Uri?,
 * String и String?. В SDK колбэк объявлен в Java без аннотаций обнуляемости,
 * поэтому законны все четыре. На прошлом прогоне правило брало только
 * необнуляемую пару и молчало на остальных трёх.
 */

private val sandbox = File("/data/data/ru.corp.app/files")

class ReceivedFiles(private val resolver: ContentResolverStub) {

    /** RF-TP-1. Необнуляемая пара, копии нет. */
    inner class PlainNoCopy : CerberCallbacks {
        override fun onFileReceived(uri: Uri, pkg: String) {
            open(uri)
        }
    }

    /** RF-TP-2. Uri обнуляемый, копии нет. */
    inner class NullableUriNoCopy : CerberCallbacksNullableUri {
        override fun onFileReceived(uri: Uri?, pkg: String) {
            if (uri != null) open(uri)
        }
    }

    /** RF-TP-3. Обнуляемый пакет, копии нет. */
    inner class NullablePkgNoCopy : CerberCallbacksNullablePkg {
        override fun onFileReceived(uri: Uri, pkg: String?) {
            open(uri)
        }
    }

    /** RF-TP-4. Оба обнуляемые, копии нет. */
    inner class NullableBothNoCopy : CerberCallbacksNullableBoth {
        override fun onFileReceived(uri: Uri?, pkg: String?) {
            if (uri != null) open(uri)
        }
    }

    /** RF-TN-1. Необнуляемая пара, копирование через copyTo. */
    inner class PlainCopyTo : CerberCallbacks {
        override fun onFileReceived(uri: Uri, pkg: String) {
            val source = File(uri.path)
            source.copyTo(File(sandbox, "payload"))
        }
    }

    /** RF-TN-2. Uri обнуляемый, копирование через openInputStream. */
    inner class NullableUriStream : CerberCallbacksNullableUri {
        override fun onFileReceived(uri: Uri?, pkg: String) {
            val input = resolver.openInputStream(uri)
            input.close()
        }
    }

    /** RF-TN-3. Обнуляемый пакет, копирование через FileOutputStream. */
    inner class NullablePkgOutStream : CerberCallbacksNullablePkg {
        override fun onFileReceived(uri: Uri, pkg: String?) {
            val out = FileOutputStream(File(sandbox, "payload"))
            out.close()
        }
    }

    /** RF-TN-4. Оба обнуляемые, чтение через readBytes. */
    inner class NullableBothReadBytes : CerberCallbacksNullableBoth {
        override fun onFileReceived(uri: Uri?, pkg: String?) {
            val source = File("/tmp/in")
            val bytes = source.readBytes()
            bytes.size
        }
    }

    /** RF-TN-5. Необнуляемая пара, запись через writeBytes. */
    inner class PlainWriteBytes : CerberCallbacks {
        override fun onFileReceived(uri: Uri, pkg: String) {
            val target = File(sandbox, "payload")
            target.writeBytes(ByteArray(0))
        }
    }

    /**
     * RF-PROBE-1. Копирование вынесено в свой метод. Ожидается сработка:
     * правило видит только тело колбэка и пройти по вызову не может.
     */
    inner class CopyInHelper : CerberCallbacks {
        override fun onFileReceived(uri: Uri, pkg: String) {
            persist(uri)
        }
    }

    /**
     * RF-PROBE-2. Тело-выражение. Ожидается пропуск: шаблоны требуют
     * блочного тела, это известная граница.
     */
    inner class ExpressionBody : CerberCallbacks {
        override fun onFileReceived(uri: Uri, pkg: String) = open(uri)
    }

    private fun open(uri: Uri) {
        uri.toString()
    }

    private fun persist(uri: Uri) {
        val source = File(uri.path)
        source.copyTo(File(sandbox, "payload"))
    }
}

class ContentResolverStub {
    fun openInputStream(uri: Uri?): InputStreamStub = InputStreamStub()
}

class InputStreamStub {
    fun close() {}
}
