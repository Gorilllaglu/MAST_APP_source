package ru.corp.app

import ru.sberbank.cerbersdk.sdk_framework.CerberSDKApplication
import ru.sberbank.cerbersdk.sdk_framework.CerberSDKApplicationDelegate

/**
 * Контроль доработки правила cerber-missing-delegate-creation.
 * Правка добавила к положительным шаблонам формы без тела класса: прежние
 * четыре требовали фигурных скобок, и класс без тела правило не видело.
 * Это та же асимметрия движка, что давала одиннадцать ложных в правиле
 * по интерфейсу Application.
 */

private val sharedDelegate = CerberSDKApplicationDelegate(secureInitialCheck = true)

object DelegateVault {
    val instance = CerberSDKApplicationDelegate(secureInitialCheck = true)
}

interface AnalyticsHost {
    fun trackScreen(name: String)
}

/** DB-TP-1. Делегат из свойства файла, класс без тела. Прежний пропуск. */
class SharedNoBodyApp : Application(), CerberSDKApplication by sharedDelegate

/** DB-TP-2. Делегат из свойства объекта, класс без тела. */
class VaultNoBodyApp : Application(), CerberSDKApplication by DelegateVault.instance

/** DB-TP-3. Без базового класса, без тела. */
class BarelessApp : CerberSDKApplication by sharedDelegate

/** DB-TP-4. Два интерфейса, церберовский первый, без тела. */
class MixedFirstNoBodyApp : CerberSDKApplication by sharedDelegate, AnalyticsHost {
    override fun trackScreen(name: String) {
        Log.d("app", name)
    }
}

/** DB-TP-5. Делегат из свойства файла, класс с телом. Работало и раньше. */
class SharedBodyApp : Application(), CerberSDKApplication by sharedDelegate {
    fun onCreateStub() {
        Log.d("app", "shared delegate with body")
    }
}

/** DB-TN-1. Делегат создан на месте, класс без тела. Молчание. */
class InlineNoBodyApp : Application(), CerberSDKApplication by CerberSDKApplicationDelegate(
    secureInitialCheck = true,
    secureScreen = true,
    secureClipboard = true
)

/** DB-TN-2. Делегат создан на месте в одну строку, без тела. Молчание. */
class InlineShortNoBodyApp : Application(), CerberSDKApplication by CerberSDKApplicationDelegate(secureInitialCheck = true)

/** DB-TN-3. Делегат создан на месте, класс с телом. Молчание. */
class InlineBodyApp : Application(), CerberSDKApplication by CerberSDKApplicationDelegate(
    secureInitialCheck = true,
    secureScreen = true,
    secureClipboard = true
) {
    fun onCreateStub() {
        Log.d("app", "inline delegate with body")
    }
}

/** DB-TN-4. Интерфейс реализован напрямую, делегат в свойстве. Не зона правила. */
class DirectApp : Application(), CerberSDKApplication {
    override val delegate = CerberSDKApplicationDelegate(
        secureInitialCheck = true,
        secureScreen = true,
        secureClipboard = true
    )

    override fun initializeSdk() {}
}

/**
 * DB-PROBE-1. Делегат получен геттером свойства, класс без тела.
 * Ожидается сработка по самому факту делегирования на выражение, отличное
 * от конструктора: тело геттера правилу читать не нужно.
 */
private val lazyDelegate: CerberSDKApplicationDelegate
    get() = CerberSDKApplicationDelegate(secureInitialCheck = true)

class GetterDelegateApp : Application(), CerberSDKApplication by lazyDelegate
