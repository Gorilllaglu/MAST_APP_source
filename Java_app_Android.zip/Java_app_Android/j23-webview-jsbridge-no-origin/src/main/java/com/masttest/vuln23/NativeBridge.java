package com.masttest.vuln23;

import android.content.Context;
import android.util.Log;
import android.webkit.JavascriptInterface;

/**
 * VULN-23: JavaScript bridge без проверки origin.
 *
 * @JavascriptInterface-методы будут вызываться JS с любой страницы,
 * загруженной в этот WebView. Никакой `getUrl()`/`origin`-проверки
 * перед выполнением sensitive операций нет.
 *
 * Безопасный паттерн (НЕ реализован):
 *
 *   @JavascriptInterface
 *   public String getAuthToken() {
 *       String origin = webView.getUrl();
 *       if (origin == null || !origin.startsWith("https://app.example.com/")) {
 *           throw new IllegalStateException("JS bridge called from unauthorized origin: " + origin);
 *       }
 *       return token;
 *   }
 */
public class NativeBridge {

    private final Context ctx;

    public NativeBridge(Context ctx) {
        this.ctx = ctx;
    }

    @JavascriptInterface
    public String getAuthToken() {
        // <-- VULN sink: возвращает токен любому caller-у
        return "eyJhbGciOiJIUzI1NiJ9.fakejwt.fakesig";
    }

    @JavascriptInterface
    public void saveData(String key, String value) {
        // <-- VULN sink: пишет произвольные данные в SharedPrefs
        ctx.getSharedPreferences("bridge", Context.MODE_PRIVATE)
                .edit()
                .putString(key, value)
                .apply();
        Log.w("NativeBridge", "saveData(" + key + ", " + value + ")");
    }

    @JavascriptInterface
    public void openExternal(String url) {
        // <-- VULN sink: запускает Intent VIEW с произвольным URL
        // (это путь к scheme://intent injection)
        Log.w("NativeBridge", "openExternal(" + url + ")");
    }
}
