package com.masttest.vuln16;

import android.os.Bundle;
import android.util.Log;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // Используем секреты, чтобы они не были dead-code-eliminated
        Log.d("Vuln16", "loaded " + SecretsHolder.JWT_SIGNING_KEY.length() + " chars");
        String apiKey = BuildConfig.API_KEY;
        Log.d("Vuln16", "buildconfig api_key="
                + apiKey.substring(0, Math.min(8, apiKey.length())) + "...");
    }
}
