package com.masttest.vuln16;

/**
 * VULN-16 (часть 1): hardcoded секреты прямо в .java константах.
 * Любой, кто декомпилирует APK через jadx — увидит эти значения.
 */
final class SecretsHolder {

    private SecretsHolder() {
    }

    // подпись JWT, которую сервер использует для верификации
    static final String JWT_SIGNING_KEY = "s3cr3t-jwt-signing-key-do-not-share";

    // ключ AWS (формат намеренно похож на настоящий)
    static final String AWS_ACCESS_KEY_ID = "AKIAIOSFODNN7EXAMPLE";
    static final String AWS_SECRET_ACCESS_KEY = "wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY";

    // токен админа на staging (часто забывают убрать)
    static final String ADMIN_BEARER_TOKEN =
            "eyJhbGciOiJIUzI1NiJ9.eyJyb2xlIjoiYWRtaW4ifQ.fakeFakeFake";
}
