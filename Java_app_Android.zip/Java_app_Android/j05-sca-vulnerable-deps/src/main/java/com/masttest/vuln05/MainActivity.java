package com.masttest.vuln05;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // Touch на каждую уязвимую библиотеку — чтобы её классы реально
        // попали в DEX/APK (без вызова R8/DCE может выкинуть unused libs).
        VulnerableLibsTouch.touchAll();
    }
}
