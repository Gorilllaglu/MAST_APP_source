package com.masttest.vuln05;

import android.util.Log;
import java.util.Collections;

/**
 * VULN-05 (SCA fixture): touch-вызовы на каждую из заведомо уязвимых
 * зависимостей. Цель — гарантировать, что классы соответствующих
 * библиотек попадут в финальный DEX, чтобы SCA-сканер их видел.
 *
 * Сами CVE-номера задокументированы в README и в комментариях
 * build.gradle.
 */
final class VulnerableLibsTouch {

    private static final String TAG = "Vuln05-SCA";

    private VulnerableLibsTouch() {
    }

    static void touchAll() {
        try { touchOkHttp(); } catch (Throwable ignored) {}
        try { touchGson(); } catch (Throwable ignored) {}
        try { touchJackson(); } catch (Throwable ignored) {}
        try { touchCommonsCollections(); } catch (Throwable ignored) {}
        try { touchBouncyCastle(); } catch (Throwable ignored) {}
        try { touchCommonsCodec(); } catch (Throwable ignored) {}
    }

    private static void touchOkHttp() {
        // com.squareup.okhttp3:okhttp:3.12.0 (CVE-2021-0341)
        okhttp3.OkHttpClient client = new okhttp3.OkHttpClient.Builder().build();
        Log.d(TAG, "OkHttp loaded: " + client.getClass().getName());
    }

    private static void touchGson() {
        // com.google.code.gson:gson:2.8.5 (CVE-2022-25647)
        com.google.gson.Gson gson = new com.google.gson.Gson();
        String json = gson.toJson(Collections.singletonMap("k", "v"));
        Log.d(TAG, "Gson loaded, sample: " + json);
    }

    private static void touchJackson() throws Exception {
        // com.fasterxml.jackson.core:jackson-databind:2.9.10 (CVE-2020-36518, ...)
        com.fasterxml.jackson.databind.ObjectMapper mapper =
                new com.fasterxml.jackson.databind.ObjectMapper();
        String s = mapper.writeValueAsString(Collections.singletonMap("k", "v"));
        Log.d(TAG, "Jackson loaded, sample: " + s);
    }

    private static void touchCommonsCollections() {
        // commons-collections:3.2.1 (CVE-2015-7501)
        // Touch на класс из gadget chain — InvokerTransformer.
        org.apache.commons.collections.Transformer xform =
                org.apache.commons.collections.functors.InvokerTransformer.getInstance(
                        "toString",
                        new Class<?>[0],
                        new Object[0]);
        Log.d(TAG, "Commons-Collections loaded: " + xform.getClass().getName());
    }

    private static void touchBouncyCastle() {
        // org.bouncycastle:bcprov-jdk15on:1.55 (multiple CVEs)
        org.bouncycastle.jce.provider.BouncyCastleProvider provider =
                new org.bouncycastle.jce.provider.BouncyCastleProvider();
        Log.d(TAG, "BouncyCastle loaded: " + provider.getName() + "/" + provider.getVersion());
    }

    private static void touchCommonsCodec() {
        // commons-codec:1.10 (старая версия)
        String md5 = org.apache.commons.codec.digest.DigestUtils.md5Hex("hello");
        String b64 = org.apache.commons.codec.binary.Base64.encodeBase64String("hello".getBytes());
        Log.d(TAG, "Commons-Codec loaded: md5=" + md5 + " b64=" + b64);
    }
}
