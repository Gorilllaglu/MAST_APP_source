package com.masttest.vuln07;

import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.fragment.app.Fragment;
import java.util.Arrays;
import java.util.List;

/**
 * VULN: «защищённый» admin-экран. В нормальной архитектуре он
 * должен быть доступен только после успешного login. Здесь же
 * — deeplink `vuln07://app/admin` в nav_graph даёт прямой
 * доступ извне.
 *
 * Атака:
 *   adb shell am start -W -a android.intent.action.VIEW \
 *     -d "vuln07://app/admin"
 *
 * → NavHostFragment автоматически переходит на AdminFragment
 *   минуя LoginFragment.
 */
public class AdminFragment extends Fragment {
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        Log.w("Vuln07-Admin", "AdminFragment entered — exposing admin features without auth");
        // Эмуляция чувствительной операции: «выгружаем» список пользователей
        List<String> sensitive = Arrays.asList("alice (admin)", "bob (admin)", "carol (admin)");
        TextView tv = new TextView(requireContext());
        tv.setText("ADMIN PANEL\n\nUsers:\n" + TextUtils.join("\n", sensitive));
        tv.setTextSize(16f);
        tv.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT));
        return tv;
    }
}
