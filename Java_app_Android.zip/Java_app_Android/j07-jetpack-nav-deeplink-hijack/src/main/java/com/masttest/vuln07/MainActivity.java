package com.masttest.vuln07;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // Сам NavHostFragment объявлен в layout/activity_main.xml,
        // он автоматически читает nav_graph.xml и handles deeplinks
        // из incoming Intent.
    }
}
