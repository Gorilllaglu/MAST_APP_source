package com.masttest.vuln17;

import java.security.MessageDigest;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

/**
 * Сборная солянка криптографических ошибок. Каждый метод — отдельный
 * класс уязвимости, по нему сканер должен иметь отдельное правило.
 *
 * 1. HARDCODED_KEY — ключ зашит как String-константа в коде.
 *    Видно в jadx и в `strings dex.dex | grep`.
 *
 * 2. aesEcb — Cipher.getInstance("AES/ECB/PKCS5Padding"). ECB
 *    раскрывает паттерны во входных данных (повторяющиеся блоки
 *    одинаковы в шифротексте).
 *
 * 3. aesWithStaticIv — AES/CBC/PKCS5Padding с константным IV (нули).
 *    При повторном шифровании одного и того же plaintext'а получается
 *    одинаковый ciphertext, что ломает семантическую безопасность CBC.
 *
 * 4. weakDes — Cipher.getInstance("DES"). 56-битный ключ, brute-force
 *    за дни на современном железе. Категория «слабый/устаревший шифр».
 *
 * 5. md5Hash — MessageDigest.getInstance("MD5"). MD5 уязвим к коллизиям,
 *    непригоден ни для подписей, ни для паролей.
 *
 * 6. sha1Hash — MessageDigest.getInstance("SHA-1"). Тоже уязвим к
 *    коллизиям, объявлен deprecated.
 *
 * 7. weakPbkdf — PBKDF2 с iterationCount=1000. OWASP рекомендует
 *    минимум 600 000 для SHA-256 (2024). 1000 — пережиток нулевых.
 *    Плюс соль "saltsalt" — short, low-entropy, dictionary-word.
 */
final class CryptoUtil {

    // (1) hardcoded key
    private static final String HARDCODED_KEY = "ThisIsTheKey1234";

    // (3) static IV
    private static final byte[] STATIC_IV = new byte[16];

    // (7) weak salt
    private static final byte[] WEAK_SALT = "saltsalt".getBytes();

    private CryptoUtil() {
    }

    static byte[] aesEcb(String plaintext) throws Exception {
        SecretKeySpec key = new SecretKeySpec(HARDCODED_KEY.getBytes(), "AES");
        Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");           // <-- VULN: ECB
        cipher.init(Cipher.ENCRYPT_MODE, key);
        return cipher.doFinal(plaintext.getBytes());
    }

    static byte[] aesWithStaticIv(String plaintext) throws Exception {
        SecretKeySpec key = new SecretKeySpec(HARDCODED_KEY.getBytes(), "AES");
        Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
        cipher.init(Cipher.ENCRYPT_MODE, key, new IvParameterSpec(STATIC_IV)); // <-- VULN: static IV
        return cipher.doFinal(plaintext.getBytes());
    }

    static byte[] weakDes(String plaintext) throws Exception {
        SecretKeySpec key = new SecretKeySpec("8byteKey".getBytes(), "DES");
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");           // <-- VULN: weak cipher
        byte[] iv = new byte[8];
        java.util.Arrays.fill(iv, (byte) 1);
        cipher.init(Cipher.ENCRYPT_MODE, key, new IvParameterSpec(iv));
        return cipher.doFinal(plaintext.getBytes());
    }

    static String md5Hash(String input) throws Exception {
        MessageDigest md = MessageDigest.getInstance("MD5");                  // <-- VULN: weak hash
        return toHex(md.digest(input.getBytes()));
    }

    static String sha1Hash(String input) throws Exception {
        MessageDigest md = MessageDigest.getInstance("SHA-1");                // <-- VULN: weak hash
        return toHex(md.digest(input.getBytes()));
    }

    static byte[] weakPbkdf(String password) throws Exception {
        PBEKeySpec spec = new PBEKeySpec(password.toCharArray(), WEAK_SALT, 1000, 128); // <-- VULN: low iter + weak salt
        SecretKeyFactory skf = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1");
        return skf.generateSecret(spec).getEncoded();
    }

    private static String toHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder();
        for (byte b : bytes) {
            sb.append(String.format("%02x", b));
        }
        return sb.toString();
    }
}
