package com.masttest.vuln26;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import androidx.appcompat.app.AppCompatActivity;

/**
 * VULN-26: WebView с включёнными file-access настройками.
 *
 * Опасные настройки:
 *   setAllowFileAccess(true)             — разрешает file:// URL
 *   setAllowFileAccessFromFileURLs(true) — file:// страница может
 *                                           через XHR читать другие
 *                                           file:// файлы
 *   setAllowUniversalAccessFromFileURLs(true) — file:// страница может
 *                                                делать XHR на ЛЮБОЙ
 *                                                origin (включая https)
 *   setAllowContentAccess(true)          — разрешает content:// URI
 *
 * В сочетании с произвольным URL из Intent extras (как в app 24) это
 * даёт чтение приватных файлов приложения через file://-схему.
 */
public class WebViewActivity extends AppCompatActivity {
    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_webview);

        WebView web = findViewById(R.id.web);
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setAllowFileAccess(true);                       // <-- VULN
        settings.setAllowFileAccessFromFileURLs(true);           // <-- VULN
        settings.setAllowUniversalAccessFromFileURLs(true);      // <-- VULN
        settings.setAllowContentAccess(true);                    // <-- VULN

        // URL берётся из Intent extras без проверки — позволяет
        // загрузить file://… или content://… со стороны атакующего
        String url = getIntent().getStringExtra("url");
        if (url == null) url = "about:blank";
        web.loadUrl(url);                                         // <-- VULN sink (вместе)
    }
}
