package com.masttest.vuln18;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // Реально вызываем все три проблемных генератора, чтобы у сканера
        // с reachability-анализом был полный call graph до уязвимостей.
        // try/catch вокруг — на устройствах без TEE/StrongBox AndroidKeyStore
        // может бросить exception (`java.security.KeyStoreException`), что
        // нам в тесте не нужно.
        try { KeyManager.generateKeyWithoutAuth("alias-noauth"); } catch (Exception ignored) {}
        try { KeyManager.generateKeyWithoutHwBackingCheck("alias-nohwcheck"); } catch (Exception ignored) {}
        try { KeyManager.generateKeyWithoutBiometricInvalidation("alias-nobio"); } catch (Exception ignored) {}
    }
}
