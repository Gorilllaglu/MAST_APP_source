package com.masttest.vuln11;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

/**
 * Уязвимость живёт в res/xml/network_security_config.xml.
 * Сам код Activity тривиален.
 */
public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}
