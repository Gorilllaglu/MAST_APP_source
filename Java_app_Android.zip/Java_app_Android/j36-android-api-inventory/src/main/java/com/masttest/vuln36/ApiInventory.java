package com.masttest.vuln36;

import android.accounts.Account;
import android.accounts.AccountManager;
import android.app.AlarmManager;
import android.app.DownloadManager;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.usage.UsageStatsManager;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.database.Cursor;
import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.hardware.camera2.CameraManager;
import android.hardware.fingerprint.FingerprintManager;
import android.location.Location;
import android.location.LocationManager;
import android.media.AudioManager;
import android.media.MediaRecorder;
import android.net.ConnectivityManager;
import android.net.Uri;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.nfc.NfcAdapter;
import android.os.Build;
import android.os.PowerManager;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.os.VibratorManager;
import android.provider.CalendarContract;
import android.provider.CallLog;
import android.provider.ContactsContract;
import android.provider.Settings;
import android.provider.Telephony;
import android.telephony.SmsManager;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityManager;
import android.view.inputmethod.InputMethodManager;
import androidx.core.content.ContextCompat;
import java.util.List;

/**
 * VULN-36 (R049 / R050): инвентарь чувствительных Android API.
 *
 * Каждый метод этого класса — один touch-point на один sensitive
 * API. Цель — дать сканеру с discovery-функцией материал для отчёта
 * «приложение использует: Camera, Location, Bluetooth, NFC, SMS, ...».
 *
 * Вся реальная функциональность обёрнута в try/catch, чтобы:
 *   - не падать на runtime если permission не выдан,
 *   - не падать на эмуляторе без железа (Bluetooth/NFC/Camera),
 *   - не делать deprecated API hard crash на новых SDK.
 *
 * Сам факт вызова API остаётся в DEX. Это и есть то, что должен
 * собрать в свой отчёт discovery-модуль сканера.
 */
final class ApiInventory {

    private static final String TAG = "ApiInventory";

    private ApiInventory() {
    }

    static void touchAll(Context ctx) {
        camera(ctx);
        location(ctx);
        bluetooth(ctx);
        nfc(ctx);
        sensors(ctx);
        telephony(ctx);
        smsRead(ctx);
        smsSend();
        contacts(ctx);
        calendar(ctx);
        callLog(ctx);
        accounts(ctx);
        wifi(ctx);
        connectivity(ctx);
        clipboard(ctx);
        installedPackages(ctx);
        usageStats(ctx);
        audio(ctx);
        mediaRecorder();
        vibrator(ctx);
        notifications(ctx);
        downloadManager(ctx);
        accessibility(ctx);
        inputMethod(ctx);
        fingerprintLegacy(ctx);
        powerWakeLock(ctx);
        deviceIdentifiers(ctx);
        windowSecureFlag(ctx);  // touch FLAG_SECURE — связано c privacy
        alarmManager(ctx);
    }

    // ---------- Камера ----------
    private static void camera(Context ctx) {
        try {
            CameraManager cm = (CameraManager) ctx.getSystemService(Context.CAMERA_SERVICE);
            String[] ids = cm.getCameraIdList();
            Log.d(TAG, "cameraIdList.size=" + ids.length);
        } catch (Throwable ignored) {}
    }

    // ---------- Локация ----------
    private static void location(Context ctx) {
        try {
            LocationManager lm = (LocationManager) ctx.getSystemService(Context.LOCATION_SERVICE);
            Location loc = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            Log.d(TAG, "lastKnownLocation=" + loc);
            // Также Network provider — отдельный сигнал для сканера.
            lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
        } catch (Throwable ignored) {}
    }

    // ---------- Bluetooth ----------
    private static void bluetooth(Context ctx) {
        try {
            BluetoothManager bm = (BluetoothManager) ctx.getSystemService(Context.BLUETOOTH_SERVICE);
            BluetoothAdapter adapter = bm.getAdapter();
            if (adapter != null) {
                adapter.startDiscovery();
                adapter.getBondedDevices();
            }
        } catch (Throwable ignored) {}
    }

    // ---------- NFC ----------
    private static void nfc(Context ctx) {
        try {
            NfcAdapter nfc = NfcAdapter.getDefaultAdapter(ctx);
            Log.d(TAG, "nfc=" + nfc + " isEnabled=" + (nfc != null ? nfc.isEnabled() : null));
        } catch (Throwable ignored) {}
    }

    // ---------- Sensors ----------
    private static void sensors(Context ctx) {
        try {
            SensorManager sm = (SensorManager) ctx.getSystemService(Context.SENSOR_SERVICE);
            sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
            sm.getDefaultSensor(Sensor.TYPE_GYROSCOPE);
            sm.getDefaultSensor(Sensor.TYPE_PROXIMITY);
            sm.getDefaultSensor(Sensor.TYPE_LIGHT);
        } catch (Throwable ignored) {}
    }

    // ---------- Telephony: device id / sim / номер ----------
    private static void telephony(Context ctx) {
        try {
            TelephonyManager tm = (TelephonyManager) ctx.getSystemService(Context.TELEPHONY_SERVICE);
            // Эти API возвращают IMEI / IMSI / phone number / SIM serial —
            // классические «hardware ids», сканеры их специально ловят.
            String imei = tm.getDeviceId();         // R: hardware id
            String imsi = tm.getSubscriberId();     // R: hardware id
            String sim = tm.getSimSerialNumber();   // R: hardware id
            String line = tm.getLine1Number();      // R: phone number
            Log.d(TAG, "imei=" + imei + " imsi=" + imsi + " sim=" + sim + " line=" + line);
        } catch (Throwable ignored) {}
    }

    // ---------- SMS чтение ----------
    private static void smsRead(Context ctx) {
        try {
            Cursor cursor = ctx.getContentResolver().query(
                    Telephony.Sms.CONTENT_URI,
                    new String[]{Telephony.Sms.BODY, Telephony.Sms.ADDRESS},
                    null, null, null);
            if (cursor != null) cursor.close();
        } catch (Throwable ignored) {}
    }

    // ---------- SMS отправка ----------
    private static void smsSend() {
        try {
            SmsManager sm = SmsManager.getDefault();
            sm.sendTextMessage("+10000000000", null, "ping", null, null);
        } catch (Throwable ignored) {}
    }

    // ---------- Контакты ----------
    private static void contacts(Context ctx) {
        try {
            Cursor c = ctx.getContentResolver().query(
                    ContactsContract.Contacts.CONTENT_URI,
                    new String[]{ContactsContract.Contacts.DISPLAY_NAME},
                    null, null, null);
            if (c != null) c.close();
        } catch (Throwable ignored) {}
    }

    // ---------- Календарь ----------
    private static void calendar(Context ctx) {
        try {
            Cursor c = ctx.getContentResolver().query(
                    CalendarContract.Events.CONTENT_URI,
                    new String[]{CalendarContract.Events.TITLE},
                    null, null, null);
            if (c != null) c.close();
        } catch (Throwable ignored) {}
    }

    // ---------- Журнал звонков ----------
    private static void callLog(Context ctx) {
        try {
            Cursor c = ctx.getContentResolver().query(
                    CallLog.Calls.CONTENT_URI,
                    new String[]{CallLog.Calls.NUMBER},
                    null, null, null);
            if (c != null) c.close();
        } catch (Throwable ignored) {}
    }

    // ---------- Аккаунты ----------
    private static void accounts(Context ctx) {
        try {
            AccountManager am = AccountManager.get(ctx);
            Account[] a = am.getAccounts();          // GET_ACCOUNTS
            Log.d(TAG, "accounts.size=" + a.length);
        } catch (Throwable ignored) {}
    }

    // ---------- Wi-Fi ----------
    private static void wifi(Context ctx) {
        try {
            WifiManager wm = (WifiManager) ctx.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            WifiInfo info = wm.getConnectionInfo();  // SSID, BSSID — sensitive
            List<ScanResult> scan = wm.getScanResults(); // список сетей рядом — sensitive
            Log.d(TAG, "wifi ssid=" + (info != null ? info.getSSID() : null)
                    + " scans=" + (scan != null ? scan.size() : null));
        } catch (Throwable ignored) {}
    }

    // ---------- Connectivity ----------
    private static void connectivity(Context ctx) {
        try {
            ConnectivityManager cm = (ConnectivityManager) ctx.getSystemService(Context.CONNECTIVITY_SERVICE);
            cm.getActiveNetworkInfo();
            cm.getActiveNetwork();
        } catch (Throwable ignored) {}
    }

    // ---------- Clipboard ----------
    private static void clipboard(Context ctx) {
        try {
            ClipboardManager cb = (ClipboardManager) ctx.getSystemService(Context.CLIPBOARD_SERVICE);
            cb.getPrimaryClip();                     // чтение clipboard
            cb.setPrimaryClip(ClipData.newPlainText("label", "value")); // запись clipboard
        } catch (Throwable ignored) {}
    }

    // ---------- PackageManager: список приложений ----------
    private static void installedPackages(Context ctx) {
        try {
            List<PackageInfo> pkgs = ctx.getPackageManager().getInstalledPackages(0);
            Log.d(TAG, "installed=" + pkgs.size());
            ctx.getPackageManager().queryIntentActivities(new Intent(Intent.ACTION_MAIN), 0);
        } catch (Throwable ignored) {}
    }

    // ---------- UsageStats ----------
    private static void usageStats(Context ctx) {
        try {
            UsageStatsManager us = (UsageStatsManager) ctx.getSystemService(Context.USAGE_STATS_SERVICE);
            long end = System.currentTimeMillis();
            long begin = end - 24L * 60 * 60 * 1000;
            us.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, begin, end);
        } catch (Throwable ignored) {}
    }

    // ---------- Audio / Microphone ----------
    private static void audio(Context ctx) {
        try {
            AudioManager am = (AudioManager) ctx.getSystemService(Context.AUDIO_SERVICE);
            am.setMode(AudioManager.MODE_NORMAL);
            am.setSpeakerphoneOn(false);
        } catch (Throwable ignored) {}
    }

    // ---------- MediaRecorder ----------
    private static void mediaRecorder() {
        try {
            MediaRecorder mr = new MediaRecorder();
            mr.setAudioSource(MediaRecorder.AudioSource.MIC);   // запись с микрофона
            mr.setVideoSource(MediaRecorder.VideoSource.CAMERA);
            mr.release();
        } catch (Throwable ignored) {}
    }

    // ---------- Vibrator ----------
    private static void vibrator(Context ctx) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                VibratorManager vm = (VibratorManager) ctx.getSystemService(Context.VIBRATOR_MANAGER_SERVICE);
                vm.getDefaultVibrator().vibrate(VibrationEffect.createOneShot(100, 255));
            } else {
                Vibrator v = (Vibrator) ctx.getSystemService(Context.VIBRATOR_SERVICE);
                v.vibrate(100);
            }
        } catch (Throwable ignored) {}
    }

    // ---------- Notifications ----------
    private static void notifications(Context ctx) {
        try {
            NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
            nm.getActiveNotifications();
            // PendingIntent — связан с возможностью intent-redirect, тоже sensitive
            PendingIntent.getActivity(ctx, 0, new Intent("noop"), PendingIntent.FLAG_IMMUTABLE);
        } catch (Throwable ignored) {}
    }

    // ---------- DownloadManager ----------
    private static void downloadManager(Context ctx) {
        try {
            DownloadManager dm = (DownloadManager) ctx.getSystemService(Context.DOWNLOAD_SERVICE);
            DownloadManager.Request req = new DownloadManager.Request(Uri.parse("https://example.com/file.bin"));
            dm.enqueue(req);
        } catch (Throwable ignored) {}
    }

    // ---------- AccessibilityManager ----------
    private static void accessibility(Context ctx) {
        try {
            AccessibilityManager am = (AccessibilityManager) ctx.getSystemService(Context.ACCESSIBILITY_SERVICE);
            am.isEnabled();
            am.isTouchExplorationEnabled();
        } catch (Throwable ignored) {}
    }

    // ---------- InputMethodManager ----------
    private static void inputMethod(Context ctx) {
        try {
            InputMethodManager im = (InputMethodManager) ctx.getSystemService(Context.INPUT_METHOD_SERVICE);
            im.getInputMethodList();
        } catch (Throwable ignored) {}
    }

    // ---------- FingerprintManager (deprecated) ----------
    private static void fingerprintLegacy(Context ctx) {
        try {
            FingerprintManager fm = (FingerprintManager) ctx.getSystemService(Context.FINGERPRINT_SERVICE);
            fm.hasEnrolledFingerprints();
            fm.isHardwareDetected();
        } catch (Throwable ignored) {}
    }

    // ---------- PowerManager / WakeLock ----------
    private static void powerWakeLock(Context ctx) {
        try {
            PowerManager pm = ContextCompat.getSystemService(ctx, PowerManager.class);
            PowerManager.WakeLock wl = pm != null
                    ? pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Vuln36:wl") : null;
            if (wl != null) {
                wl.acquire();
                wl.release();
            }
        } catch (Throwable ignored) {}
    }

    // ---------- Device identifiers через Settings.Secure ----------
    private static void deviceIdentifiers(Context ctx) {
        try {
            // ANDROID_ID — sticky device identifier (не сбрасывается при reset).
            String androidId = Settings.Secure.getString(ctx.getContentResolver(), Settings.Secure.ANDROID_ID);
            // Build.* fields — серийник, бренд, модель, FINGERPRINT
            Log.d(TAG, "androidId=" + androidId + " brand=" + Build.BRAND
                    + " model=" + Build.MODEL + " fp=" + Build.FINGERPRINT);
        } catch (Throwable ignored) {}
    }

    // ---------- WindowManager FLAG_SECURE ----------
    private static void windowSecureFlag(Context ctx) {
        try {
            // Только обращение к WindowManager.LayoutParams.FLAG_SECURE как
            // int-reference — для discovery достаточно.
            int flag = WindowManager.LayoutParams.FLAG_SECURE;
            Log.d(TAG, "flagSecure=" + flag);
        } catch (Throwable ignored) {}
    }

    // ---------- AlarmManager ----------
    private static void alarmManager(Context ctx) {
        try {
            AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
            // setExactAndAllowWhileIdle / setAndAllowWhileIdle — sensitive API,
            // ограничено на API 31+ через SCHEDULE_EXACT_ALARM permission.
            PendingIntent pi = PendingIntent.getBroadcast(ctx, 0, new Intent("noop"), PendingIntent.FLAG_IMMUTABLE);
            am.set(AlarmManager.RTC, System.currentTimeMillis() + 60_000L, pi);
        } catch (Throwable ignored) {}
    }
}
