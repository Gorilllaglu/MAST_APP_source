package com.masttest.vuln36;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // Один touch-call на каждый sensitive Android API.
        // Все вызовы внутри ApiInventory обёрнуты в try/catch, поэтому
        // отсутствие permission или железа не валит app — сканеру важно
        // лишь увидеть signatures в DEX.
        ApiInventory.touchAll(this);
    }
}
