package com.masttest.vuln09;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

/**
 * Launcher. Intentionally boring. The vulnerability lives in
 * InternalDebugActivity.java + AndroidManifest.xml.
 */
public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}
