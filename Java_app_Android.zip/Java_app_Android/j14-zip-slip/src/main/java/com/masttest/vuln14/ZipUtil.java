package com.masttest.vuln14;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * Распаковка zip-архива без проверки имён entries.
 *
 * Уязвимость:
 *   Имена записей в zip-архиве могут содержать '../' и приводить к
 *   записи файла за пределами целевой директории (Zip-Slip, CVE-2018-1002200).
 *   Здесь мы делаем буквально new File(targetDir, entry.getName()) и пишем туда —
 *   без вызова `getCanonicalPath` и проверки, что результирующий путь
 *   начинается с canonical path целевой директории.
 *
 * Безопасный вариант (для контраста, не используется тут):
 *
 *   File outFile = new File(targetDir, entry.getName());
 *   String canonicalDest = targetDir.getCanonicalPath() + File.separator;
 *   if (!outFile.getCanonicalPath().startsWith(canonicalDest)) {
 *       throw new SecurityException("zip-slip blocked: " + entry.getName());
 *   }
 */
final class ZipUtil {

    private ZipUtil() {
    }

    static void unzip(File zipFile, File targetDir) throws Exception {
        if (!targetDir.exists()) targetDir.mkdirs();
        try (ZipInputStream zin = new ZipInputStream(new FileInputStream(zipFile))) {
            ZipEntry entry = zin.getNextEntry();
            while (entry != null) {
                File outFile = new File(targetDir, entry.getName());     // <-- VULN sink
                if (entry.isDirectory()) {
                    outFile.mkdirs();
                } else {
                    if (outFile.getParentFile() != null) outFile.getParentFile().mkdirs();
                    try (FileOutputStream fos = new FileOutputStream(outFile)) {
                        byte[] buf = new byte[8192];
                        int n;
                        while ((n = zin.read(buf)) != -1) {
                            fos.write(buf, 0, n);
                        }
                    }
                }
                entry = zin.getNextEntry();
            }
        }
    }
}
