package com.masttest.vuln14;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import java.io.File;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Имитируем случай: приложение скачало zip и распаковывает его
        // в свой приватный каталог. Чтобы статический сканер с
        // reachability-анализом видел unzip() как реально достижимую,
        // безусловно вызываем его — пустой/несуществующий файл просто
        // приведёт к exception, который мы глотаем.
        File downloaded = new File(getCacheDir(), "downloaded.zip");
        File targetDir = new File(getFilesDir(), "unpacked");
        try {
            ZipUtil.unzip(downloaded, targetDir);
        } catch (Exception ignored) {}
    }
}
