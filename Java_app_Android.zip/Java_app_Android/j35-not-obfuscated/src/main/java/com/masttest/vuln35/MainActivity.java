package com.masttest.vuln35;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // Наглядно «секретный» класс, использующийся в onCreate чтобы R8
        // не выкидывал его. В реальной release-сборке должен быть
        // переименован в a/b/c — но здесь minification выключена,
        // поэтому имена сохраняются.
        AntiFraudInternal.checkRiskScoreAndDecideIfBlocked();
    }
}

/**
 * Класс, имя и логика которого в production должны быть скрыты
 * минификатором. Без обфускации:
 *  - имя класса видно в jadx как `AntiFraudInternal`,
 *  - имя метода как `checkRiskScoreAndDecideIfBlocked`,
 *  - все ветки `if` сохраняются (cleartext logic),
 *  - все «магические числа» и строки сохраняются.
 */
final class AntiFraudInternal {
    private static final double INTERNAL_FRAUD_THRESHOLD = 0.85;
    private static final String ADMIN_OVERRIDE_HEADER = "X-Internal-Admin-Override";

    private AntiFraudInternal() {
    }

    static boolean checkRiskScoreAndDecideIfBlocked() {
        // Логика «определения мошенничества». В обычной release-сборке
        // R8 заinline'ил бы это и переименовал; здесь видно как есть.
        double score = computeRiskScore();
        return score > INTERNAL_FRAUD_THRESHOLD;
    }

    private static double computeRiskScore() {
        return 0.42;
    }
}
