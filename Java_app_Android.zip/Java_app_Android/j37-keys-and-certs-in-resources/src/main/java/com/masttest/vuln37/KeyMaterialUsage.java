package com.masttest.vuln37;

import android.content.Context;
import android.util.Log;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.security.KeyFactory;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.cert.Certificate;
import java.security.cert.CertificateFactory;
import java.security.spec.EncodedKeySpec;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;

/**
 * VULN-37: четыре чистых случая «key material in APK resources/assets»,
 * по одному на каждое требование xlsx — R026, R027, R028, R029.
 *
 * Каждый файл-материал загружается реальным API из стандартной
 * библиотеки, чтобы у сканера была видна связка «файл в ресурсах»
 * ↔ «использование в коде».
 *
 * Все load'ы — внутри try/catch, потому что содержимое placeholder'ов
 * не парсится как валидный PEM/PKCS#12 (нам важна только сигнатура для
 * статика). На реальном устройстве каждое чтение бросит
 * `CertificateException` / `KeyStoreException`, но в DEX call-site
 * полностью присутствует.
 */
final class KeyMaterialUsage {

    private static final String TAG = "Vuln37";

    // Hardcoded passwords к зашифрованным контейнерам — typical defaults.
    // Это бонусный signal для семейства правил «слабый пароль keystore'а»
    // (R022/R023), но основная цель app — R026/R027/R028/R029.
    private static final String ENCRYPTED_PEM_PASSWORD = "changeit";
    private static final String PKCS12_PASSWORD = "changeit";
    private static final String BKS_PASSWORD = "android";

    private KeyMaterialUsage() {
    }

    static void loadAll(Context ctx) {
        // === R026: публичные ключи / сертификаты ===
        loadX509CertificateFromRaw(ctx);           // public_cert_x509.pem
        loadRsaPublicKeyFromRaw(ctx);              // public_key_rsa.pem

        // === R027: приватные ключи БЕЗ пароля ===
        loadUnencryptedPkcs8PrivateKey(ctx);       // private_unencrypted_pkcs8.pem
        loadLegacyRsaPrivateKey(ctx);              // private_unencrypted_rsa.pem

        // === R028: приватные ключи / keystore'ы С паролем ===
        loadEncryptedPemPrivateKey(ctx);           // private_encrypted_pkcs8.pem
        loadPkcs12KeyStore(ctx);                   // client_pkcs12.p12
        loadBksKeyStore(ctx);                      // assets/client_bouncy.bks

        // === R029: «общая категория» — generic key file без явного типа ===
        loadMysteryKeyBlob(ctx);                   // mystery_key.bin
    }

    // ---------------- R026 ----------------

    private static void loadX509CertificateFromRaw(Context ctx) {
        // BEGIN CERTIFICATE blob — обычный X.509-сертификат в директории
        // ресурсов приложения. Публичный материал; формально не утечка,
        // но всё равно «hardcoded trust anchor» — частая причина
        // certificate pinning bypass'ов, если ключ меняется.
        try (InputStream input = ctx.getResources().openRawResource(R.raw.public_cert_x509)) {
            Certificate cert = CertificateFactory.getInstance("X.509").generateCertificate(input);
            Log.d(TAG, "X.509 cert loaded: " + cert.getType());
        } catch (Throwable ignored) {}
    }

    private static void loadRsaPublicKeyFromRaw(Context ctx) {
        // BEGIN PUBLIC KEY (SubjectPublicKeyInfo). Используется,
        // например, для верификации подписей серверного API.
        try {
            String pem = readText(ctx.getResources().openRawResource(R.raw.public_key_rsa));
            byte[] encoded = pemBodyAsBase64(pem);
            EncodedKeySpec keySpec = new X509EncodedKeySpec(encoded);
            PublicKey pubKey = KeyFactory.getInstance("RSA").generatePublic(keySpec);
            Log.d(TAG, "RSA public key loaded: algorithm=" + pubKey.getAlgorithm());
        } catch (Throwable ignored) {}
    }

    // ---------------- R027 ----------------

    private static void loadUnencryptedPkcs8PrivateKey(Context ctx) {
        // BEGIN PRIVATE KEY — PKCS#8, БЕЗ пароля. Любой, кто извлекает
        // APK, получает приватный ключ целиком. Категория R027.
        try {
            String pem = readText(ctx.getResources().openRawResource(R.raw.private_unencrypted_pkcs8));
            byte[] encoded = pemBodyAsBase64(pem);
            PKCS8EncodedKeySpec spec = new PKCS8EncodedKeySpec(encoded);
            PrivateKey priv = KeyFactory.getInstance("RSA").generatePrivate(spec);
            Log.d(TAG, "Unencrypted PKCS#8 private key loaded: algorithm=" + priv.getAlgorithm());
        } catch (Throwable ignored) {}
    }

    private static void loadLegacyRsaPrivateKey(Context ctx) {
        // BEGIN RSA PRIVATE KEY — старый формат PKCS#1, тоже без пароля.
        // По смыслу то же R027, но другой rule_hint (другие сигнатуры
        // PEM-заголовков).
        try {
            String pem = readText(ctx.getResources().openRawResource(R.raw.private_unencrypted_rsa));
            // Реально парсить PKCS#1 в чистом Java неудобно — для целей
            // статика достаточно того, что мы прочитали байты файла.
            Log.d(TAG, "Legacy RSA private key bytes read: " + pem.length());
        } catch (Throwable ignored) {}
    }

    // ---------------- R028 ----------------

    private static void loadEncryptedPemPrivateKey(Context ctx) {
        // BEGIN ENCRYPTED PRIVATE KEY — PKCS#8 шифрованный. В коде рядом
        // hardcoded пароль `changeit` — типичный сильный сигнал для
        // сканера: «encrypted PEM + literal-password в исходниках».
        try {
            String pem = readText(ctx.getResources().openRawResource(R.raw.private_encrypted_pkcs8));
            Log.d(TAG, "Encrypted PEM read: " + pem.length()
                    + " chars, using password=" + ENCRYPTED_PEM_PASSWORD);
        } catch (Throwable ignored) {}
    }

    private static void loadPkcs12KeyStore(Context ctx) {
        // PKCS#12 — бинарный контейнер с приватным ключом, защищён
        // паролем `changeit` (default Java keystore). R028 + R022.
        try {
            KeyStore ks = KeyStore.getInstance("PKCS12");
            try (InputStream input = ctx.getResources().openRawResource(R.raw.client_pkcs12)) {
                ks.load(input, PKCS12_PASSWORD.toCharArray());
            }
            Log.d(TAG, "PKCS#12 keystore loaded: aliases=" + ks.size());
        } catch (Throwable ignored) {}
    }

    private static void loadBksKeyStore(Context ctx) {
        // BKS — Bouncy Castle keystore в assets. Пароль `android` —
        // ещё один типовой default.
        try {
            KeyStore ks = KeyStore.getInstance("BKS");
            try (InputStream input = ctx.getAssets().open("client_bouncy.bks")) {
                ks.load(input, BKS_PASSWORD.toCharArray());
            }
            Log.d(TAG, "BKS keystore loaded: aliases=" + ks.size());
        } catch (Throwable ignored) {}
    }

    // ---------------- R029 ----------------

    private static void loadMysteryKeyBlob(Context ctx) {
        // «Generic» key-файл с именем, в котором есть слово `key`,
        // но без явного PEM-заголовка / расширения keystore-формата.
        // Сканеру неочевидно, что это — приватный ключ или
        // зашифрованный blob — но имя файла + его entropy должны
        // флажить категорию R029 («сертификат/ключ в ресурсах»).
        try (InputStream input = ctx.getResources().openRawResource(R.raw.mystery_key)) {
            byte[] bytes = readAllBytes(input);
            Log.d(TAG, "Mystery key blob: " + bytes.length + " bytes");
        } catch (Throwable ignored) {}
    }

    // ---------- helpers ----------

    private static byte[] pemBodyAsBase64(String pem) {
        StringBuilder body = new StringBuilder();
        for (String line : pem.split("\n")) {
            if (!line.startsWith("-----")) body.append(line.trim());
        }
        // .decode упадёт на наших placeholder'ах — try/catch выше
        // это поглотит. Для статика важен факт вызова.
        return Base64.getDecoder().decode(body.toString().trim());
    }

    private static String readText(InputStream in) throws Exception {
        return new String(readAllBytes(in));
    }

    private static byte[] readAllBytes(InputStream in) throws Exception {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) != -1) {
            bos.write(buf, 0, n);
        }
        return bos.toByteArray();
    }
}
