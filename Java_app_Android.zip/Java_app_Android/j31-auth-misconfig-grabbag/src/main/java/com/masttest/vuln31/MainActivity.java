package com.masttest.vuln31;

import android.content.Context;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.biometric.BiometricPrompt;
import androidx.core.content.ContextCompat;
import java.net.URLEncoder;
import java.util.concurrent.Executor;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // (1) Biometric без CryptoObject (см. AuthFlows).
        AuthFlows.biometricPromptNoCryptoObject(this);

        // (2) OAuth без PKCE и state.
        try {
            String authUrl = AuthFlows.buildOAuthUrlNoPkceNoState();
        } catch (Exception ignored) {}

        // (3) Hardcoded backdoor — проверяем «волшебную» строку.
        String attemptedLogin = "admin:debugbypass";  // в реальности приходит из EditText
        AuthFlows.tryHardcodedBackdoor(attemptedLogin);
    }
}

final class AuthFlows {

    private AuthFlows() {
    }

    /**
     * (1) BiometricPrompt без CryptoObject.
     *
     * Биометрия используется только как «yes/no»-флаг: если палец /
     * лицо проходит — приложение считает пользователя авторизованным
     * и показывает sensitive UI. Привязки операции к ключу из
     * AndroidKeyStore нет — атакующий, имеющий root, может сэмулировать
     * onAuthenticationSucceeded() через Frida и пройти «биометрию».
     *
     * Безопасный паттерн:
     *   BiometricPrompt.CryptoObject crypto =
     *       new BiometricPrompt.CryptoObject(cipherInitializedWithKeystoreKey);
     *   prompt.authenticate(promptInfo, crypto);
     *   // onSucceeded { result -> result.getCryptoObject().getCipher().doFinal(...) }
     */
    static void biometricPromptNoCryptoObject(AppCompatActivity activity) {
        Executor executor = ContextCompat.getMainExecutor(activity);
        BiometricPrompt.AuthenticationCallback callback = new BiometricPrompt.AuthenticationCallback() {
            @Override
            public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result) {
                // <-- VULN sink: открываем профиль ТОЛЬКО на основании
                // того, что result пришёл; никаких проверок result.getCryptoObject().
                activity.getSharedPreferences("auth", Context.MODE_PRIVATE)
                        .edit()
                        .putBoolean("biometric_unlocked", true)
                        .apply();
            }
        };
        BiometricPrompt prompt = new BiometricPrompt(activity, executor, callback);
        BiometricPrompt.PromptInfo info = new BiometricPrompt.PromptInfo.Builder()
                .setTitle("Login")
                .setNegativeButtonText("Cancel")
                .build();
        // <-- VULN: authenticate() БЕЗ CryptoObject
        prompt.authenticate(info);
    }

    /**
     * (2) OAuth code flow БЕЗ code_challenge (PKCE) и БЕЗ state.
     *
     * - Без PKCE: атакующий, перехвативший authorization_code (через
     *   redirect_uri в виде custom URI scheme, который перехватывается
     *   как в app 30), может обменять его на токены, потому что нет
     *   привязки code_challenge ↔ code_verifier.
     * - Без state: уязвимость к CSRF/login-CSRF — нет проверки, что
     *   callback пришёл по запросу именно этой сессии.
     */
    static String buildOAuthUrlNoPkceNoState() throws Exception {
        String clientId = "mobile-client";
        String redirectUri = "vuln31://oauth_callback";
        String scope = "profile email";
        return "https://auth.example.com/oauth/authorize"
                + "?response_type=code"
                + "&client_id=" + clientId
                + "&redirect_uri=" + URLEncoder.encode(redirectUri, "UTF-8")
                + "&scope=" + URLEncoder.encode(scope, "UTF-8");
        // <-- VULN: ни code_challenge, ни state не добавлены
    }

    /**
     * (3) Hardcoded backdoor.
     */
    static boolean tryHardcodedBackdoor(String input) {
        // <-- VULN sink: проверка «волшебной» захардкоженной строки,
        // обходящей нормальный логин.
        if ("admin:debugbypass".equals(input)) {
            // Авторизуем как админа. В реальном приложении тут писали
            // бы admin-токен в SharedPreferences, выдавали бы дополнительные
            // permissions в UI, и т.д.
            return true;
        }
        return false;
    }
}
