package com.masttest.vuln27;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import java.io.File;

/**
 * VULN-27: ContentProvider, экспортированный без permission и без
 * валидации входных параметров. В одном CP — несколько разных
 * sink'ов, по которым у сканера должны срабатывать отдельные правила.
 */
public class UnsafeProvider extends ContentProvider {

    private DbHelper dbHelper;

    @Override
    public boolean onCreate() {
        dbHelper = new DbHelper(getContext());
        return true;
    }

    @Override
    public String getType(Uri uri) {
        return "vnd.android.cursor.dir/vnd.masttest.vuln27.row";
    }

    /**
     * (1) SQL injection через selection: вызывающий передаёт raw SQL,
     *     CP конкатенирует его в WHERE без parameterization.
     *     query("SELECT ... WHERE $selection")
     */
    @Override
    public Cursor query(Uri uri, String[] projection, String selection,
                        String[] selectionArgs, String sortOrder) {
        String rawSql = "SELECT id, login, password FROM users "
                + ((selection != null && !selection.trim().isEmpty()) ? "WHERE " + selection + " " : "")  // <-- VULN: SQLi
                + ((sortOrder != null && !sortOrder.trim().isEmpty()) ? "ORDER BY " + sortOrder : "");
        return dbHelper.getReadableDatabase().rawQuery(rawSql, selectionArgs);
    }

    /**
     * (2) Insert без проверки прав вызывающего и без проверки колонок.
     *     Любой может писать что угодно.
     */
    @Override
    public Uri insert(Uri uri, ContentValues values) {
        // <-- VULN sink: незащищённая запись
        long rowId = dbHelper.getWritableDatabase().insert("users", null, values);
        return Uri.withAppendedPath(uri, String.valueOf(rowId));
    }

    /**
     * (3) Update тоже передаёт selection как есть (SQLi).
     */
    @Override
    public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) {
        // <-- VULN sink: SQLi через selection + insecure update
        return dbHelper.getWritableDatabase().update("users", values, selection, selectionArgs);
    }

    /**
     * (4) Delete c selection без parameterization.
     */
    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {
        // <-- VULN sink: SQLi через selection + любой может удалить
        return dbHelper.getWritableDatabase().delete("users", selection, selectionArgs);
    }

    /**
     * (5) openFile отдаёт файл по path-сегменту URI без canonicalize.
     *     Атака: content://com.masttest.vuln27.unsafe/../shared_prefs/secrets.xml
     */
    @Override
    public ParcelFileDescriptor openFile(Uri uri, String mode) {
        String name = uri.getLastPathSegment();
        if (name == null) return null;
        File target = new File(getContext().getFilesDir(), name);     // <-- VULN: path traversal
        try {
            return ParcelFileDescriptor.open(target, ParcelFileDescriptor.MODE_READ_ONLY);
        } catch (Exception e) {
            return null;
        }
    }

    private static class DbHelper extends SQLiteOpenHelper {
        DbHelper(Context ctx) {
            super(ctx, "vuln27.db", null, 1);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {
            db.execSQL("CREATE TABLE users (id INTEGER PRIMARY KEY, login TEXT, password TEXT)");
            db.execSQL("INSERT INTO users (login, password) VALUES ('alice', 'hunter2')");
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        }
    }
}
