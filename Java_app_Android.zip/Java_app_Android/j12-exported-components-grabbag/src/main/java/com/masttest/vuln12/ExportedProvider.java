package com.masttest.vuln12;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.util.Log;
import java.util.Arrays;

/**
 * Content Provider, экспортированный без read/write permission.
 * Любое стороннее приложение может вызвать query/insert/update/delete.
 *
 * Здесь намеренно нет проверок calling UID/permission, нет path-permission,
 * вход parameters прокидывается в селекторы как есть. Это типичный
 * «небезопасный CP» — ground-truth уязвимость для семейства правил
 * вокруг exported provider'ов.
 */
public class ExportedProvider extends ContentProvider {
    @Override
    public boolean onCreate() {
        return true;
    }

    @Override
    public Cursor query(Uri uri, String[] projection, String selection,
                        String[] selectionArgs, String sortOrder) {
        Log.w("ExportedProvider", "query selection=" + selection
                + " args=" + Arrays.toString(selectionArgs));
        // Возвращаем фиктивный курсор. В реальном приложении тут был бы
        // запрос к SQLite с теми же неотфильтрованными `selection`/`selectionArgs`.
        MatrixCursor c = new MatrixCursor(new String[]{"id", "secret"});
        c.addRow(new Object[]{1, "hunter2"});
        return c;
    }

    @Override
    public String getType(Uri uri) {
        return "vnd.android.cursor.dir/vnd.masttest.vuln12.row";
    }

    @Override
    public Uri insert(Uri uri, ContentValues values) {
        Log.w("ExportedProvider", "insert values=" + values);
        return Uri.withAppendedPath(uri, "1");
    }

    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {
        Log.w("ExportedProvider", "delete selection=" + selection);
        return 1;
    }

    @Override
    public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) {
        Log.w("ExportedProvider", "update values=" + values + " selection=" + selection);
        return 1;
    }
}
