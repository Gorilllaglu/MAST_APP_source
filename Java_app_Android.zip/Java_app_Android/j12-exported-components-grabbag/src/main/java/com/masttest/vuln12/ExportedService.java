package com.masttest.vuln12;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;

/**
 * Service, экспортированный без permission. Любое стороннее приложение
 * на устройстве может вызвать его и заставить «отправить SMS» произвольному
 * номеру с произвольным текстом.
 */
public class ExportedService extends Service {
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String phone = (intent != null && intent.getStringExtra("phone") != null)
                ? intent.getStringExtra("phone") : "unknown";
        String text = (intent != null && intent.getStringExtra("text") != null)
                ? intent.getStringExtra("text") : "(empty)";
        // Привилегированное действие. В реальном приложении на этом месте
        // мог бы быть SmsManager.sendTextMessage(...).
        Log.w("ExportedService", "Sending SMS to " + phone + ": " + text);
        return START_NOT_STICKY;
    }
}
