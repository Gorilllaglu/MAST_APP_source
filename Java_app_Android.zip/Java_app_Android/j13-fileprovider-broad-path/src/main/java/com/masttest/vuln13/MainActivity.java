package com.masttest.vuln13;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;
import java.io.File;
import java.io.FileWriter;

/**
 * Шарит файл наружу через FileProvider. Сам этот код — обычный паттерн.
 * Реальная уязвимость в res/xml/file_paths.xml, который заявляет слишком
 * широкие корни.
 */
public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Создаём какой-нибудь файл и шарим его через FileProvider.
        File f = new File(getFilesDir(), "report.txt");
        try (FileWriter w = new FileWriter(f)) {
            w.write("hello, this is a shared report");
        } catch (Exception ignored) {}

        Uri uri = FileProvider.getUriForFile(
                this,
                "com.masttest.vuln13.fileprovider",
                f);
        Intent share = new Intent(Intent.ACTION_SEND);
        share.setType("text/plain");
        share.putExtra(Intent.EXTRA_STREAM, uri);
        share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        // Действительно дёргаем chooser, чтобы у сканера с
        // reachability-анализом был полный data-flow до startActivity.
        // try/catch глотает ActivityNotFound на устройствах без
        // обработчиков ACTION_SEND.
        try {
            startActivity(Intent.createChooser(share, "Share"));
        } catch (Exception ignored) {}
    }
}
