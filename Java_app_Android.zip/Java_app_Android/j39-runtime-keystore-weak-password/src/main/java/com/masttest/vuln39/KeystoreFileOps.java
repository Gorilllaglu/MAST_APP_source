package com.masttest.vuln39;

import android.content.Context;
import android.os.Environment;
import android.util.Log;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.security.KeyStore;

/**
 * VULN-39: запись/чтение файлового keystore'а в writable-локацию
 * со слабыми паролями. Покрывает семейство R017 / R033 / R034 / R035 / R036.
 *
 * Это **только статика**: на устройстве многие операции упадут
 * (BKS-провайдер может отсутствовать, permission не выдан, и т.д.),
 * но в DEX call-site остаётся, и именно его ловит сканер.
 *
 * Сигнатуры, которые должен увидеть статический сканер:
 *   - `KeyStore.getInstance("BKS"|"PKCS12")` (выбор файлового формата);
 *   - `KeyStore.store(java.io.OutputStream, char[])` (намерение записать);
 *   - литеральные пароли (`android`, `1234`, `password`, `changeit`, `letmein`);
 *   - target paths в writable-локациях:
 *       `Context.getFilesDir()` / `getCacheDir()`,
 *       `Environment.getExternalStorageDirectory()`,
 *       `openFileOutput(..., MODE_WORLD_WRITEABLE)`.
 */
final class KeystoreFileOps {

    private static final String TAG = "Vuln39";

    // Hardcoded слабые пароли — словарные / короткие / default.
    // Все объявлены `static final` → попадают в DEX как литералы.
    private static final String WEAK_PWD_ANDROID = "android";
    private static final String WEAK_PWD_NUMERIC = "1234";
    private static final String WEAK_PWD_DEFAULT = "password";
    private static final String WEAK_PWD_CHANGEIT = "changeit";
    private static final String WEAK_PWD_LETMEIN = "letmein";

    private KeystoreFileOps() {
    }

    static void runAll(Context ctx) {
        writeBksToFilesDir(ctx);
        writePkcs12ToExternal(ctx);
        writeBksWorldWriteable(ctx);
        readBksWithSamePassword(ctx);
        roundtripDifferentWeakPwds(ctx);
    }

    /**
     * R017 / R033 — запись BKS в **приватный** filesDir со слабым паролем.
     * Файл доступен на запись самому приложению. Атакующий с локальным
     * access (rooted device, backup) сможет подменить файл, а пароль
     * `android` тривиально подбирается.
     */
    static void writeBksToFilesDir(Context ctx) {
        try {
            KeyStore ks = KeyStore.getInstance("BKS");
            ks.load(null, null);
            File target = new File(ctx.getFilesDir(), "local.bks");
            try (FileOutputStream out = new FileOutputStream(target)) {
                // <-- VULN sink: writable target + weak password literal
                ks.store(out, WEAK_PWD_ANDROID.toCharArray());
            }
            Log.d(TAG, "wrote BKS to " + target.getAbsolutePath());
        } catch (Throwable ignored) {}
    }

    /**
     * R033 «в худшем виде»: запись PKCS#12 в **публичную** external
     * storage директорию + 4-значный numeric password. Любой app с
     * `READ_EXTERNAL_STORAGE` (то есть практически любой) скачивает
     * файл, и `1234` подбирается за миллисекунды.
     */
    static void writePkcs12ToExternal(Context ctx) {
        try {
            KeyStore ks = KeyStore.getInstance("PKCS12");
            ks.load(null, null);
            File target = new File(Environment.getExternalStorageDirectory(), "backup.p12");
            try (FileOutputStream out = new FileOutputStream(target)) {
                // <-- VULN sink: writable + public + 4-digit numeric password
                ks.store(out, WEAK_PWD_NUMERIC.toCharArray());
            }
            Log.d(TAG, "wrote PKCS12 to " + target.getAbsolutePath());
        } catch (Throwable ignored) {}
    }

    /**
     * R033 двойная ошибка: legacy `MODE_WORLD_WRITEABLE` (deprecated
     * с Android 7, но компилируется) + слабый пароль `password`. Это
     * означает, что любой app на устройстве может перезаписать наш
     * keystore.
     */
    static void writeBksWorldWriteable(Context ctx) {
        try {
            KeyStore ks = KeyStore.getInstance("BKS");
            ks.load(null, null);
            try (FileOutputStream out = ctx.openFileOutput("shared.bks", Context.MODE_WORLD_WRITEABLE)) {
                // <-- VULN sink: MODE_WORLD_WRITEABLE + weak password
                ks.store(out, WEAK_PWD_DEFAULT.toCharArray());
            }
            Log.d(TAG, "wrote BKS world-writeable");
        } catch (Throwable ignored) {}
    }

    /**
     * R035 / R036 — зеркальный сценарий: чтение того же файла с тем же
     * слабым паролем. Сканер видит «keystore + weak-password literal»
     * в обоих направлениях data-flow.
     */
    static void readBksWithSamePassword(Context ctx) {
        try {
            KeyStore ks = KeyStore.getInstance("BKS");
            File target = new File(ctx.getFilesDir(), "local.bks");
            try (FileInputStream input = new FileInputStream(target)) {
                // <-- VULN sink: keystore.load с тем же слабым паролем
                ks.load(input, WEAK_PWD_ANDROID.toCharArray());
            }
            Log.d(TAG, "loaded BKS aliases=" + ks.size());
        } catch (Throwable ignored) {}
    }

    /**
     * Grab-bag: ещё два словарных пароля (`changeit`, `letmein`)
     * для проверки, что сканер сверяет с **широким** словарём,
     * а не только с парой захардкоженных known-weak.
     */
    static void roundtripDifferentWeakPwds(Context ctx) {
        try {
            KeyStore ks1 = KeyStore.getInstance("BKS");
            ks1.load(null, null);
            try (FileOutputStream out = new FileOutputStream(new File(ctx.getCacheDir(), "ks_changeit.bks"))) {
                ks1.store(out, WEAK_PWD_CHANGEIT.toCharArray());
            }
            KeyStore ks2 = KeyStore.getInstance("BKS");
            ks2.load(null, null);
            try (FileOutputStream out = new FileOutputStream(new File(ctx.getCacheDir(), "ks_letmein.bks"))) {
                ks2.store(out, WEAK_PWD_LETMEIN.toCharArray());
            }
            Log.d(TAG, "wrote two BKS with dictionary passwords");
        } catch (Throwable ignored) {}
    }
}
