package com.masttest.vuln15;

import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

/**
 * Path Traversal через File I/O.
 *
 * Activity получает имя файла из Intent extras и читает его. Имя
 * не нормализуется (`getCanonicalPath`) и не проверяется по whitelist.
 *
 * Атака:
 *   Intent i = new Intent();
 *   i.setComponent(new ComponentName(
 *       "com.masttest.vuln15",
 *       "com.masttest.vuln15.FileReadActivity"));
 *   i.putExtra("filename", "../shared_prefs/secrets.xml");
 *   startActivity(i);
 *
 * Безопасный паттерн:
 *   File baseDir = new File(getFilesDir(), "user_files").getCanonicalFile();
 *   File target  = new File(baseDir, name).getCanonicalFile();
 *   if (!target.getPath().startsWith(baseDir.getPath() + File.separator)) throw ...;
 */
public class FileReadActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        String name = getIntent().getStringExtra("filename");
        if (name == null) return;
        // База — приватная папка filesDir/user_files. Идея безопасности:
        // ограничиться этой директорией. Реализована неправильно —
        // конкатенация путей без canonicalize.
        File base = new File(getFilesDir(), "user_files");
        File target = new File(base, name);       // <-- VULN sink: name может содержать "../"
        if (target.exists()) {
            String text = readAll(target);
            Log.w("FileRead", "Read " + target.getAbsolutePath() + ": " + take(text, 200));
            ((TextView) findViewById(R.id.tvTitle)).setText(take(text, 200));
        }
    }

    private static String readAll(File f) {
        StringBuilder sb = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new FileReader(f))) {
            char[] buf = new char[1024];
            int n;
            while ((n = br.read(buf)) != -1) {
                sb.append(buf, 0, n);
            }
        } catch (Exception ignored) {}
        return sb.toString();
    }

    private static String take(String s, int n) {
        return s.substring(0, Math.min(n, s.length()));
    }
}
