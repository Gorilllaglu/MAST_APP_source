package com.masttest.vuln33;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.WebSocket;
import okhttp3.WebSocketListener;
import java.net.URLEncoder;

public class MainActivity extends AppCompatActivity {

    private final String authToken = "eyJhbGciOiJIUzI1NiJ9.fake.fake";
    private final String username = "alice";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        try {
            // (1) HTTPS-запрос с токеном В query-параметрах URL.
            //     Серверы и proxy логируют URL-ы в access.log целиком,
            //     включая query-string. Также URL уходит в Referer
            //     заголовок при последующих запросах.
            String url = "https://api.example.com/profile"
                    + "?token=" + URLEncoder.encode(authToken, "UTF-8")     // <-- VULN sink
                    + "&user=" + URLEncoder.encode(username, "UTF-8");
            OkHttpClient client = new OkHttpClient();
            Request req = new Request.Builder().url(url).build();
            try { client.newCall(req).execute(); } catch (Throwable ignored) {}

            // (2) WebSocket-сообщение содержит JWT прямо в payload.
            //     Серверная сторона логирует фреймы целиком, плюс
            //     токен зачастую попадает в client-side debug tools.
            WebSocket ws = client.newWebSocket(
                    new Request.Builder().url("wss://realtime.example.com/socket").build(),
                    new WebSocketListener() {});
            ws.send(                                                        // <-- VULN sink
                    "{\"action\":\"auth\",\"jwt\":\"" + authToken + "\",\"user\":\"" + username + "\"}");

            // (3) POST с password в URL-форме (обычно так делают для
            //     legacy-API). HTTPS защищает body, но URL может попасть
            //     в access.log если сервер логирует не только path,
            //     а ещё и form-параметры.
            Request post = new Request.Builder()
                    .url("https://api.example.com/legacy_login?password=hunter2")  // <-- VULN: password в URL
                    .post(RequestBody.create(null, ""))
                    .build();
            try { client.newCall(post).execute(); } catch (Throwable ignored) {}
        } catch (Exception ignored) {}
    }
}
