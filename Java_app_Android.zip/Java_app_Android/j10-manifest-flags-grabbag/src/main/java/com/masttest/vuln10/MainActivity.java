package com.masttest.vuln10;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

/**
 * Все уязвимости этого app живут в AndroidManifest.xml.
 * Сам код Activity намеренно тривиален — нужен только чтобы APK собрался
 * и был запускаем.
 */
public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}
