package com.masttest.vuln20;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.os.Environment;
import android.webkit.CookieManager;
import androidx.appcompat.app.AppCompatActivity;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // (1) SQLite без шифрования с password в открытом виде.
        new SecretsDbHelper(this).insertCredentials("alice", "hunter2");

        // (2) Файл с MODE_WORLD_READABLE (флаг устарел, но статически
        //     обнаруживается).
        try (FileOutputStream fos = openFileOutput("creds.txt", Context.MODE_WORLD_READABLE)) {
            fos.write("password=hunter2\nauth_token=eyJhbGc...".getBytes());
        } catch (Exception ignored) {}

        // (3) WebView CookieManager — Cookie уезжает в стандартный
        //     Cookies.db без шифрования.
        CookieManager.getInstance().setCookie(
                "https://api.example.com",
                "auth=eyJhbGciOiJIUzI1NiJ9.fake.fake; Path=/; Secure");

        // (4) External storage — пишем секретный токен туда, где его
        //     прочитает любое приложение с READ_EXTERNAL_STORAGE.
        File ext = Environment.getExternalStorageDirectory();
        File out = new File(ext, "MAST_APP_BACKUP/secret_token.txt");
        if (out.getParentFile() != null) out.getParentFile().mkdirs();
        try (FileWriter w = new FileWriter(out)) {
            w.write("eyJhbGciOiJIUzI1NiJ9.exfil-target.fake");
        } catch (Exception ignored) {}
    }
}

/**
 * SQLite-хранилище без шифрования. Никакого SQLCipher / EncryptedDatabase —
 * password лежит в /data/data/<pkg>/databases/secrets.db в открытом виде.
 */
class SecretsDbHelper extends SQLiteOpenHelper {
    SecretsDbHelper(Context ctx) {
        super(ctx, "secrets.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE users (id INTEGER PRIMARY KEY, login TEXT, password TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
    }

    void insertCredentials(String login, String password) {
        // INSERT с password в plaintext — VULN sink
        getWritableDatabase().execSQL(
                "INSERT INTO users (login, password) VALUES (?, ?)",
                new Object[]{login, password});
    }
}
