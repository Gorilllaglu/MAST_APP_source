package com.masttest.vuln38;

import android.app.KeyguardManager;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Debug;
import java.io.File;

/**
 * VULN-38: восемь намеренно ОЧЕНЬ слабых RASP-проверок.
 *
 * Отличие от app 32 (`no-protections-baseline`): здесь проверки
 * **есть** — сканер должен это заметить и НЕ репортить R118/R119
 * (отсутствие). Но реализованы они так, что обходятся за минуту —
 * сканер должен зарепортить R116/R117/R120/R121/R122/R123 (слабая
 * реализация).
 *
 * Все проверки сделаны статически-видимыми: имена методов, имена
 * полей Build, литералы путей — всё доступно grep'у по DEX.
 */
final class WeakChecks {

    private WeakChecks() {
    }

    static final class Report {
        final boolean rootByOnePath;
        final boolean rootByTestKeys;
        final boolean emuByFingerprint;
        final boolean emuByHardware;
        final boolean debuggerByManifestFlag;
        final boolean integrityByHasSignature;
        final boolean fridaByOnePath;
        final boolean screenLockLegacy;

        Report(boolean rootByOnePath, boolean rootByTestKeys, boolean emuByFingerprint,
               boolean emuByHardware, boolean debuggerByManifestFlag,
               boolean integrityByHasSignature, boolean fridaByOnePath, boolean screenLockLegacy) {
            this.rootByOnePath = rootByOnePath;
            this.rootByTestKeys = rootByTestKeys;
            this.emuByFingerprint = emuByFingerprint;
            this.emuByHardware = emuByHardware;
            this.debuggerByManifestFlag = debuggerByManifestFlag;
            this.integrityByHasSignature = integrityByHasSignature;
            this.fridaByOnePath = fridaByOnePath;
            this.screenLockLegacy = screenLockLegacy;
        }

        @Override
        public String toString() {
            return "Report(rootByOnePath=" + rootByOnePath
                    + ", rootByTestKeys=" + rootByTestKeys
                    + ", emuByFingerprint=" + emuByFingerprint
                    + ", emuByHardware=" + emuByHardware
                    + ", debuggerByManifestFlag=" + debuggerByManifestFlag
                    + ", integrityByHasSignature=" + integrityByHasSignature
                    + ", fridaByOnePath=" + fridaByOnePath
                    + ", screenLockLegacy=" + screenLockLegacy + ")";
        }
    }

    static Report runAll(Context ctx) {
        return new Report(
                weakRootSinglePath(),
                weakRootByTestKeys(),
                weakEmulatorFingerprintOnly(),
                weakEmulatorHardwareOnly(),
                weakDebuggerFlagOnly(ctx),
                weakIntegrityHasSignatureOnly(ctx),
                weakFridaSinglePath(),
                weakScreenLockLegacy(ctx));
    }

    // ==================== R116 — Weak ROOT detection ====================

    /**
     * Проверяет ОДИН-единственный путь. Magisk не оставляет
     * `/system/app/Superuser.apk` — последние 6+ лет апдейт SuperSU
     * этот файл вообще не ставит. Обход: переименовать / не ставить
     * этот файл.
     *
     * Сильная реализация проверяла бы 15-30 путей + `which su` +
     * mount -o rw / + SafetyNet attestation.
     */
    private static boolean weakRootSinglePath() {
        return new File("/system/app/Superuser.apk").exists();
    }

    /**
     * Common mistake: разработчик путает «root detection» с проверкой
     * фабричных ключей (`test-keys` означает userdebug/eng AOSP-сборку,
     * не root). Это вообще не про root.
     */
    private static boolean weakRootByTestKeys() {
        return Build.TAGS != null && Build.TAGS.contains("test-keys");
    }

    // ==================== R117 — Weak EMULATOR detection ====================

    /**
     * Проверяет ТОЛЬКО `Build.FINGERPRINT.contains("generic")`.
     * Обходится:
     *   - Genymotion с custom fingerprint
     *   - изменение `ro.build.fingerprint` через kernel-mod
     *   - реальные устройства с rebranded firmware могут содержать
     *     "generic" в составе → ложноположительные срабатывания
     *
     * Сильная реализация комбинирует 6-8 fields из `Build`
     * (FINGERPRINT, MODEL, MANUFACTURER, HARDWARE, PRODUCT, DEVICE,
     * BOOTLOADER, BRAND) + наличие специфических файлов / property.
     */
    private static boolean weakEmulatorFingerprintOnly() {
        return Build.FINGERPRINT.contains("generic");
    }

    /**
     * Только AOSP-эмулятор. Bluestacks/MEmu/LDPlayer обходят легко —
     * у них `Build.HARDWARE` свой. Genymotion имеет `Build.HARDWARE`
     * вроде "vbox86" — тоже не "goldfish".
     */
    private static boolean weakEmulatorHardwareOnly() {
        return "goldfish".equals(Build.HARDWARE) || "ranchu".equals(Build.HARDWARE);
    }

    // ==================== R122 — Weak DEBUGGER detection ====================

    /**
     * Проверяет ТОЛЬКО manifest-флаг `android:debuggable`.
     * Это совершенно не покрывает реальные сценарии:
     *   - Frida через `ptrace` присоединяется к процессу без флага в манифесте.
     *   - JDWP можно открыть через `adb shell am set-debug-app`.
     *
     * Сильная реализация дополнительно проверяет
     * `Debug.isDebuggerConnected()`, наличие `tracerpid` в
     * `/proc/self/status`, и tries to detect Frida-server.
     */
    private static boolean weakDebuggerFlagOnly(Context ctx) {
        int flags = ctx.getApplicationInfo().flags;
        // Намеренно НЕ вызываем Debug.isDebuggerConnected() —
        // это была бы дополнительная (сильная) проверка.
        Class<?> unused = Debug.class;  // ссылка на класс, чтобы он попал в DEX
        return (flags & ApplicationInfo.FLAG_DEBUGGABLE) != 0;
    }

    // ==================== R123 — Weak INTEGRITY check ====================

    /**
     * «Проверка подписи» которая просто смотрит, что подпись вообще
     * присутствует. Любой re-signed APK (с любым подписавшим)
     * пройдёт эту проверку.
     *
     * Сильная реализация хэширует подпись (SHA-256) и сверяет с
     * захардкоженным known-good значением.
     */
    @SuppressWarnings("deprecation")
    private static boolean weakIntegrityHasSignatureOnly(Context ctx) {
        PackageManager pm = ctx.getPackageManager();
        try {
            PackageInfo info = pm.getPackageInfo(ctx.getPackageName(), PackageManager.GET_SIGNATURES);
            // Проверяем только что массив не пуст — подпись есть.
            // Никакой сверки SHA-256 с ожидаемым отпечатком нет.
            return info.signatures != null && info.signatures.length > 0;
        } catch (Throwable t) {
            return false;
        }
    }

    // ==================== R120 — Weak FRIDA detection ====================

    /**
     * Проверка наличия ОДНОГО файла `frida-server` в стандартном
     * пути. Обходится переименованием бинаря или запуском
     * frida-gadget из памяти.
     *
     * Сильная реализация сканирует TCP-порты 27042/27047, ищет
     * `/proc/self/maps` на наличие `frida` или `gum-js-loop`,
     * проверяет /data/local/tmp/re.frida.server.
     */
    private static boolean weakFridaSinglePath() {
        return new File("/data/local/tmp/frida-server").exists();
    }

    // ==================== R121 — Weak SCREEN-LOCK check ====================

    /**
     * Использует deprecated `isKeyguardSecure()` (API 16+,
     * deprecated на API 23+). Правильный API — `isDeviceSecure()`
     * (API 23+), который точнее различает PIN/pattern/password
     * vs swipe-unlock.
     *
     * Помимо этого, ни тот, ни другой API не реагирует на
     * биометрию-как-единственный-фактор корректно — нужно
     * комбинировать с BiometricManager.canAuthenticate.
     */
    @SuppressWarnings("deprecation")
    private static boolean weakScreenLockLegacy(Context ctx) {
        KeyguardManager km = (KeyguardManager) ctx.getSystemService(Context.KEYGUARD_SERVICE);
        return km.isKeyguardSecure();  // вместо km.isDeviceSecure()
    }
}
