package com.masttest.vuln03;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.security.KeyChain;
import android.util.Log;
import java.security.PrivateKey;
import java.security.cert.X509Certificate;

/**
 * VULN-03 / Service 2
 * Использование доступного на чтение хранилища ключей (Android KeyChain)
 * с приватными ключами, защищёнными слабым паролем.
 * Категория: M1 Improper Credential Usage / R018 / R035.
 *
 * Сценарий: пользователь установил PKCS#12 сертификат в системный
 * KeyChain (через Settings → Security → Install). Приложение читает
 * приватный ключ по hardcoded alias. PKCS#12 файл предположительно
 * защищён слабым паролем `android` (известно из onboarding-инструкции
 * приложения — литерал в коде).
 */
public class KeyChainReadablePrivateWeakService extends Service {

    private static final String TAG = "Vuln03-S2-KCWeak";
    private static final String ALIAS = "vuln03_keychain_private_alias";
    // Hardcoded weak PKCS12 password — литерал в DEX, маркер слабой защиты.
    private static final String WEAK_PKCS12_PASSWORD = "android";

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        new Thread(() -> {
            try {
                // VULN sink: чтение приватного ключа из системного
                // (файлового) KeyChain. Ключ был импортирован с
                // hardcoded weak PKCS12 password.
                PrivateKey privateKey = KeyChain.getPrivateKey(this, ALIAS);
                X509Certificate[] chain = KeyChain.getCertificateChain(this, ALIAS);
                Log.d(TAG, "Read from KeyChain alias=" + ALIAS
                        + ", key.algo=" + (privateKey != null ? privateKey.getAlgorithm() : null)
                        + ", chain.size=" + (chain != null ? chain.length : 0)
                        + ", pkcs12_password_was=" + WEAK_PKCS12_PASSWORD);
            } catch (Exception ignored) {}
        }).start();
        return START_NOT_STICKY;
    }
}
