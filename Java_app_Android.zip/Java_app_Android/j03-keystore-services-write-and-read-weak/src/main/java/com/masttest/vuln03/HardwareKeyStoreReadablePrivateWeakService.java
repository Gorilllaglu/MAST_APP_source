package com.masttest.vuln03;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Log;
import java.security.KeyPairGenerator;
import java.security.KeyStore;
import java.security.PrivateKey;

/**
 * VULN-03 / Service 3
 * Использование доступного на чтение хранилища ключей со слабым паролем
 * с закрытыми ключами (Android Hardware-Backed Keystore).
 * Категория: M1 Improper Credential Usage / R019 / R036.
 *
 * Создаём RSA-keypair в AndroidKeyStore и тут же читаем приватный ключ
 * (Entry) с использованием `KeyStore.PasswordProtection` со слабым
 * паролем. AndroidKeyStore PasswordProtection игнорирует, но literal
 * `WEAK_PASSWORD` остаётся в DEX как сигнал слабой защиты.
 */
public class HardwareKeyStoreReadablePrivateWeakService extends Service {

    private static final String TAG = "Vuln03-S3-HwKsReadWeak";
    private static final String ALIAS = "vuln03_service3_rsa_priv";
    private static final String WEAK_PASSWORD = "android";

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        try {
            KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
            ks.load(null);

            // 1. Генерируем RSA-keypair в AndroidKeyStore без user-auth
            KeyGenParameterSpec spec = new KeyGenParameterSpec.Builder(
                    ALIAS,
                    KeyProperties.PURPOSE_SIGN | KeyProperties.PURPOSE_VERIFY)
                    .setDigests(KeyProperties.DIGEST_SHA256)
                    .setSignaturePaddings(KeyProperties.SIGNATURE_PADDING_RSA_PSS)
                    // VULN: нет setUserAuthenticationRequired(true)
                    .build();

            KeyPairGenerator kpg = KeyPairGenerator.getInstance(
                    KeyProperties.KEY_ALGORITHM_RSA, "AndroidKeyStore");
            kpg.initialize(spec);
            kpg.generateKeyPair();

            // 2. Читаем приватный ключ через KeyStore.PasswordProtection
            //    с hardcoded слабым паролем.
            KeyStore.PasswordProtection pp =
                    new KeyStore.PasswordProtection(WEAK_PASSWORD.toCharArray());
            KeyStore.Entry rawEntry = ks.getEntry(ALIAS, pp);
            PrivateKey privateKey = null;
            if (rawEntry instanceof KeyStore.PrivateKeyEntry) {
                privateKey = ((KeyStore.PrivateKeyEntry) rawEntry).getPrivateKey();
            }

            Log.d(TAG, "Read RSA private key from AndroidKeyStore alias=" + ALIAS
                    + ", weakPwd=" + WEAK_PASSWORD
                    + ", key.algo=" + (privateKey != null ? privateKey.getAlgorithm() : null));
        } catch (Exception ignored) {}
        return START_NOT_STICKY;
    }
}
