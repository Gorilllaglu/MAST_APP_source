package com.masttest.vuln03;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Log;
import java.security.KeyStore;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;

/**
 * VULN-03 / Service 1
 * Использование доступного на запись хранилища ключей
 * (Android Hardware-Backed Keystore).
 * Категория: M9 Insecure Data Storage / R017.
 *
 * Сервис безусловно пишет AES-ключ в AndroidKeyStore при каждом старте.
 * Защиты доступа (user authentication) нет — ключ доступен фоновым
 * процессам после первой разблокировки устройства.
 */
public class HardwareKeyStoreWriteService extends Service {

    private static final String TAG = "Vuln03-S1-HwKsWrite";
    private static final String ALIAS = "vuln03_service1_writable_aes";

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        try {
            KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
            ks.load(null);

            KeyGenParameterSpec spec = new KeyGenParameterSpec.Builder(
                    ALIAS,
                    KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                    // VULN sink: запись (generateKey) разрешена без аутентификации
                    .build();

            KeyGenerator gen = KeyGenerator.getInstance(
                    KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
            gen.init(spec);
            SecretKey key = gen.generateKey();
            Log.d(TAG, "Wrote AES key to AndroidKeyStore alias=" + ALIAS
                    + ", algo=" + key.getAlgorithm());
        } catch (Exception ignored) {}
        return START_NOT_STICKY;
    }
}
