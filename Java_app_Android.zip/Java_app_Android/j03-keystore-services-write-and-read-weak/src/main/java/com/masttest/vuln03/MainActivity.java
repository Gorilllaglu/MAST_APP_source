package com.masttest.vuln03;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        try { startService(new Intent(this, HardwareKeyStoreWriteService.class)); } catch (Exception ignored) {}
        try { startService(new Intent(this, KeyChainReadablePrivateWeakService.class)); } catch (Exception ignored) {}
        try { startService(new Intent(this, HardwareKeyStoreReadablePrivateWeakService.class)); } catch (Exception ignored) {}
    }
}
