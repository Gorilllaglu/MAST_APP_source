package com.masttest.vuln22;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

/**
 * Activity, которая возвращает результат через setResult() —
 * и в этот результат кладёт чувствительные данные. Если эту
 * Activity запустят через startActivityForResult, вызывающий
 * (любое экспортированное приложение) получит token и user_id
 * назад как обычные intent extras.
 *
 * Категория R114 (sensitive в setResult Intent).
 */
public class LoginResultActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        String authToken = "eyJhbGciOiJIUzI1NiJ9.afterLogin.fake";
        String userId = "user-12345";

        Intent data = new Intent();
        data.putExtra("auth_token", authToken);       // <-- VULN sink
        data.putExtra("user_id", userId);             // <-- VULN sink
        setResult(Activity.RESULT_OK, data);
        finish();
    }
}
