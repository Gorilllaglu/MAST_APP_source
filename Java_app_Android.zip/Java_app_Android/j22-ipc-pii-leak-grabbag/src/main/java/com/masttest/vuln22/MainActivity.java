package com.masttest.vuln22;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        String username = "alice";
        String password = "hunter2";
        String authToken = "eyJhbGciOiJIUzI1NiJ9.fake.fake";

        // (1) Implicit Intent для Activity (ACTION_SEND), несущий PII
        //     в EXTRA_TEXT. Любое приложение, которое обрабатывает
        //     ACTION_SEND с text/plain, получит эти данные.
        Intent shareIntent = new Intent(Intent.ACTION_SEND);
        shareIntent.setType("text/plain");
        shareIntent.putExtra(
                Intent.EXTRA_TEXT,
                "user=" + username + " password=" + password + " token=" + authToken);
        // startActivity действительно дёргается, чтобы у сканера с
        // reachability-анализом был полный data-flow от putExtra до
        // системного диспатчера. try/catch глотает ActivityNotFound,
        // если на устройстве нет приёмника text/plain.
        try { startActivity(Intent.createChooser(shareIntent, "Share")); } catch (Exception ignored) {}

        // (2) Implicit Intent для Service (без setPackage). Любой
        //     сервис на устройстве, заявивший action ACTION_PROCESS_TEXT,
        //     получит password в Extra.
        Intent implicitServiceIntent = new Intent("com.example.ACTION_PROCESS_TEXT");
        implicitServiceIntent.putExtra("password", password);
        try { startService(implicitServiceIntent); } catch (Exception ignored) {}

        // (3) Implicit Broadcast с PII.
        Intent implicitBroadcast = new Intent("com.example.ACTION_USER_LOGIN");
        implicitBroadcast.putExtra("auth_token", authToken);
        implicitBroadcast.putExtra("user", username);
        try { sendBroadcast(implicitBroadcast); } catch (Exception ignored) {}
    }
}
