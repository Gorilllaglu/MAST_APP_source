package com.masttest.vuln19;

import android.os.Bundle;
import android.util.Log;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // Просто упоминаем, чтобы R8 не выкинул
        try {
            Log.d("Vuln19", "trustAll=" + TlsClients.trustAllClient()
                    + ", plain=" + TlsClients.noPinningClient()
                    + ", weak=" + TlsClients.hostnameOnlyPinningClient());
        } catch (Exception ignored) {}
    }
}
