package com.masttest.vuln19;

import okhttp3.CertificatePinner;
import okhttp3.OkHttpClient;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

/**
 * Сборная солянка ошибок TLS-конфигурации.
 */
final class TlsClients {

    private TlsClients() {
    }

    /**
     * (1) TRUST-ALL клиент. Все три типичных «отключения проверок»:
     *     - X509TrustManager.checkClientTrusted/checkServerTrusted с пустым
     *       телом (молча принимает любой сертификат).
     *     - HostnameVerifier, всегда возвращающий true (любой hostname OK).
     *     - SSLContext, инициализированный нашим trust-all менеджером.
     *
     *     Категория R013 (вариант), R098.
     */
    static OkHttpClient trustAllClient() throws Exception {
        final X509TrustManager trustAll = new X509TrustManager() {        // <-- VULN
            @Override
            public void checkClientTrusted(X509Certificate[] chain, String authType) {}
            @Override
            public void checkServerTrusted(X509Certificate[] chain, String authType) {}
            @Override
            public X509Certificate[] getAcceptedIssuers() {
                return new X509Certificate[0];
            }
        };
        SSLContext sslContext = SSLContext.getInstance("TLS");
        sslContext.init(null, new TrustManager[]{trustAll}, new SecureRandom());
        SSLSocketFactory sslSocketFactory = sslContext.getSocketFactory();
        HostnameVerifier acceptAll = (hostname, session) -> true;          // <-- VULN

        return new OkHttpClient.Builder()
                .sslSocketFactory(sslSocketFactory, trustAll)
                .hostnameVerifier(acceptAll)
                .build();
    }

    /**
     * (2) Клиент БЕЗ pinning'а. Использует системные trust-anchors,
     *     но ничего не пинит — любой CA в системе будет принят, в том
     *     числе пользовательский корпоративный CA. Категория R098.
     */
    static OkHttpClient noPinningClient() {
        return new OkHttpClient.Builder().build();                         // <-- VULN: no CertificatePinner
    }

    /**
     * (3) Слабый pinning: проверка хостнейма через HostnameVerifier
     *     (по сути сравнение строки) вместо проверки SPKI хеша через
     *     CertificatePinner. Любой сертификат с правильным CN/SAN
     *     для api.example.com будет принят, в том числе выписанный
     *     произвольным CA. Категория R099.
     */
    static OkHttpClient hostnameOnlyPinningClient() {
        HostnameVerifier byHostname = (hostname, session) ->
                "api.example.com".equals(hostname);                        // <-- VULN: weak "pinning"
        return new OkHttpClient.Builder()
                .hostnameVerifier(byHostname)
                // CertificatePinner намеренно НЕ установлен — проверка
                // только по hostname.
                .build();
    }

    /**
     * Контрольный пример «сделано правильно» — НЕ должен попасть в отчёт.
     */
    @SuppressWarnings("unused")
    static OkHttpClient safePinnedClient() {
        CertificatePinner pinner = new CertificatePinner.Builder()
                .add(
                        "api.example.com",
                        "sha256/AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=")
                .build();
        return new OkHttpClient.Builder().certificatePinner(pinner).build();
    }
}
