package com.masttest.vuln34;

import android.content.Context;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Random;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // (1) MODE_WORLD_WRITEABLE — намеренно небезопасный режим для
        //     SharedPreferences и файлов. Атрибут официально deprecated,
        //     но компилируется и попадает в bytecode. Категория R139.
        getSharedPreferences("public", Context.MODE_WORLD_WRITEABLE)        // <-- VULN
                .edit()
                .putString("key", "value")
                .apply();

        // (2) java.util.Random для генерации «секрета». Random — линейный
        //     конгруэнтный генератор, предсказуем после нескольких
        //     samples. Категория R128 / R139.
        String sessionToken = generateSessionTokenInsecurely();
    }

    /**
     * Генератор «токена сессии» на основе java.util.Random.
     * После пары наблюдений можно предсказать следующие токены.
     */
    private String generateSessionTokenInsecurely() {
        Random r = new Random();                                           // <-- VULN: not SecureRandom
        byte[] bytes = new byte[16];
        r.nextBytes(bytes);
        StringBuilder sb = new StringBuilder();
        for (byte b : bytes) {
            sb.append(String.format("%02x", b));
        }
        return sb.toString();
    }
}
