package com.masttest.vuln34;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

/**
 * VULN-34 (часть 3): IPC DoS-crash.
 *
 * Activity exported=true, читает строку из Intent и приводит её
 * к Int БЕЗ try/catch. Любое стороннее приложение, отправив
 * `putExtra("amount", "not-a-number")` через явный ComponentName,
 * мгновенно валит наше приложение. Если этот же crash идёт в
 * приватной активности, доступной через deeplink — массовый DoS
 * пользовательских устройств.
 *
 * Категория R150.
 */
public class CrashOnBadDataActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        String amountStr = getIntent().getStringExtra("amount");
        if (amountStr == null) return;
        // <-- VULN sink: NumberFormatException не пойман — приложение
        // падает на любом невалидном вводе.
        int amount = Integer.parseInt(amountStr);
    }
}
