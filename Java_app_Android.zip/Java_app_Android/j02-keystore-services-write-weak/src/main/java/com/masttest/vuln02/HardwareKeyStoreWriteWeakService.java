package com.masttest.vuln02;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Log;
import java.security.KeyStore;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;

/**
 * VULN-02 / Service 1
 * Использование доступного на запись хранилища ключей со слабым паролем.
 * Реализация: Android Hardware-Backed Keystore.
 * Категория: M9 Insecure Data Storage / R017 / R033.
 *
 * Слабости в одной функции:
 *   - keystore = AndroidKeyStore (hardware-backed на устройствах с TEE)
 *   - ключ создаётся БЕЗ setUserAuthenticationRequired(true)
 *     → доступен после первого unlock без биометрии/PIN
 *   - hardcoded WEAK_PASSWORD используется как маркер слабой защиты
 *     (попадает в DEX как литерал)
 *   - alias захардкожен и предсказуем
 */
public class HardwareKeyStoreWriteWeakService extends Service {

    private static final String TAG = "Vuln02-S1-HwKs";
    private static final String WEAK_PASSWORD = "android";   // hardcoded weak password
    private static final String ALIAS = "vuln02_service1_aes_key";

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        try {
            KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
            ks.load(null);

            KeyGenParameterSpec spec = new KeyGenParameterSpec.Builder(
                    ALIAS,
                    KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                    // VULN sink: setUserAuthenticationRequired(true) НЕ вызван →
                    // доступ к ключу без биометрии/PIN. Любой код в процессе app
                    // может его использовать.
                    .build();

            KeyGenerator gen = KeyGenerator.getInstance(
                    KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
            gen.init(spec);
            SecretKey key = gen.generateKey();

            // VULN sink: дополнительная попытка получить entry со слабым
            // паролем — для AndroidKeyStore PasswordProtection игнорируется,
            // но literal `android` остаётся в DEX как hardcoded weak password.
            KeyStore.PasswordProtection pp =
                    new KeyStore.PasswordProtection(WEAK_PASSWORD.toCharArray());
            try {
                ks.getEntry(ALIAS, pp);
            } catch (Exception ignored) {}

            Log.d(TAG, "wrote alias=" + ALIAS + " to AndroidKeyStore (weakPwd="
                    + WEAK_PASSWORD + "), key=" + key);
        } catch (Exception ignored) {}
        return START_NOT_STICKY;
    }
}
