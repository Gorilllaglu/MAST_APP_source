package com.masttest.vuln02;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.security.KeyChain;
import android.util.Log;
import java.security.PrivateKey;
import java.security.cert.X509Certificate;

/**
 * VULN-02 / Service 2
 * Использование файлового хранилища ключей — Android KeyChain.
 * Категория: M9 Insecure Data Storage / R025 / R042 (file-based keystore).
 *
 * Android KeyChain — системное файловое хранилище ключей (физически
 * в `/data/misc/keystore/` либо `/data/misc/user/<id>/keystore/`).
 * Приватные ключи, установленные пользователем (через Settings → Security
 * → Install from storage), доступны приложениям через KeyChain API
 * **по alias** — это уязвимый паттерн, если alias захардкожен и приложение
 * запрашивает любые ключи без подтверждения пользователя.
 */
public class KeyChainAccessService extends Service {

    private static final String TAG = "Vuln02-S2-KeyChain";
    // Hardcoded alias — типичный «корпоративный» сертификат-клиент
    private static final String ALIAS = "corp_client_cert";

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        // KeyChain.getPrivateKey блокирующий — нельзя на UI thread.
        new Thread(() -> {
            try {
                // VULN sink: чтение приватного ключа из системного
                // (файлового) KeyChain по hardcoded alias, без подтверждения
                // пользователя в текущей сессии.
                PrivateKey privateKey = KeyChain.getPrivateKey(this, ALIAS);
                X509Certificate[] chain = KeyChain.getCertificateChain(this, ALIAS);
                Log.d(TAG, "Loaded from KeyChain: alias=" + ALIAS
                        + ", key=" + (privateKey != null ? privateKey.getAlgorithm() : null)
                        + ", chain.size=" + (chain != null ? chain.length : 0));
            } catch (Exception ignored) {}
        }).start();
        return START_NOT_STICKY;
    }
}
