package com.masttest.vuln02;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // Запускаем оба уязвимых сервиса — реальный call-site
        // должен быть виден в DEX для статического сканера.
        try { startService(new Intent(this, HardwareKeyStoreWriteWeakService.class)); } catch (Exception ignored) {}
        try { startService(new Intent(this, KeyChainAccessService.class)); } catch (Exception ignored) {}
    }
}
