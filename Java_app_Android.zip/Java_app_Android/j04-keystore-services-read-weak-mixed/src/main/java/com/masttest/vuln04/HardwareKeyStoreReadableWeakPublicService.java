package com.masttest.vuln04;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Log;
import java.security.KeyPairGenerator;
import java.security.KeyStore;
import java.security.PublicKey;
import java.security.cert.Certificate;

/**
 * VULN-04 / Service 1
 * Использование доступного на чтение хранилища ключей со слабым паролем
 * (Android Hardware-Backed Keystore), содержащим открытые ключи.
 * Категория: M1 Improper Credential Usage / R020 / R037.
 *
 * Создаём RSA keypair в AndroidKeyStore и читаем PUBLIC часть через
 * `KeyStore.getCertificate(alias).publicKey`. Дополнительно — попытка
 * получить entry с hardcoded weak password literal в DEX.
 */
public class HardwareKeyStoreReadableWeakPublicService extends Service {

    private static final String TAG = "Vuln04-S1-PubWeak";
    private static final String ALIAS = "vuln04_service1_rsa_pub";
    private static final String WEAK_PASSWORD = "1234";

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        try {
            KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
            ks.load(null);

            KeyGenParameterSpec spec = new KeyGenParameterSpec.Builder(
                    ALIAS,
                    KeyProperties.PURPOSE_SIGN | KeyProperties.PURPOSE_VERIFY)
                    .setDigests(KeyProperties.DIGEST_SHA256)
                    .setSignaturePaddings(KeyProperties.SIGNATURE_PADDING_RSA_PSS)
                    // VULN: нет setUserAuthenticationRequired(true)
                    .build();
            KeyPairGenerator kpg = KeyPairGenerator.getInstance(
                    KeyProperties.KEY_ALGORITHM_RSA, "AndroidKeyStore");
            kpg.initialize(spec);
            kpg.generateKeyPair();

            // Чтение публичного ключа через сертификат + попытка с weak pwd.
            Certificate cert = ks.getCertificate(ALIAS);
            PublicKey publicKey = cert != null ? cert.getPublicKey() : null;
            KeyStore.PasswordProtection pp =
                    new KeyStore.PasswordProtection(WEAK_PASSWORD.toCharArray());
            try { ks.getEntry(ALIAS, pp); } catch (Exception ignored) {}

            Log.d(TAG, "Read PUBLIC key alias=" + ALIAS
                    + ", algo=" + (publicKey != null ? publicKey.getAlgorithm() : null)
                    + ", format=" + (publicKey != null ? publicKey.getFormat() : null)
                    + ", weakPwd=" + WEAK_PASSWORD);
        } catch (Exception ignored) {}
        return START_NOT_STICKY;
    }
}
