package com.masttest.vuln04;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.security.KeyChain;
import android.util.Log;
import java.security.PrivateKey;
import java.security.cert.X509Certificate;

/**
 * VULN-04 / Service 2
 * Использование доступного на чтение файлового хранилища ключей
 * (Android KeyChain).
 * Категория: M9 Insecure Data Storage / R021 / R038.
 *
 * Чтение приватного ключа из системного KeyChain (физически файлы в
 * `/data/misc/keystore/`) по hardcoded alias. Этот сервис — про
 * **способ хранения** (файловое системное), без weak-password layer
 * (это уже отдельная категория, см. Service 3).
 */
public class KeyChainReadableFileService extends Service {

    private static final String TAG = "Vuln04-S2-KCRead";
    private static final String ALIAS = "vuln04_keychain_file_alias";

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        new Thread(() -> {
            try {
                // VULN sink: чтение приватного ключа из системного
                // (файлового) KeyChain.
                PrivateKey privateKey = KeyChain.getPrivateKey(this, ALIAS);
                X509Certificate[] chain = KeyChain.getCertificateChain(this, ALIAS);
                Log.d(TAG, "Read from KeyChain alias=" + ALIAS
                        + ", key.algo=" + (privateKey != null ? privateKey.getAlgorithm() : null)
                        + ", chain.size=" + (chain != null ? chain.length : 0));
            } catch (Exception ignored) {}
        }).start();
        return START_NOT_STICKY;
    }
}
