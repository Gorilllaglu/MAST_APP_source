package com.masttest.vuln04;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        try { startService(new Intent(this, HardwareKeyStoreReadableWeakPublicService.class)); } catch (Exception ignored) {}
        try { startService(new Intent(this, KeyChainReadableFileService.class)); } catch (Exception ignored) {}
        try { startService(new Intent(this, HardwareKeyStorePrivateWeakService.class)); } catch (Exception ignored) {}
    }
}
