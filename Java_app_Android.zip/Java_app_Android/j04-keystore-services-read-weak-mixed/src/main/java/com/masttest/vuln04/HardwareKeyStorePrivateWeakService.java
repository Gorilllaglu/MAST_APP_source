package com.masttest.vuln04;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Log;
import java.security.KeyPairGenerator;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.spec.ECGenParameterSpec;

/**
 * VULN-04 / Service 3
 * Использование хранилища ключей с приватными ключами, защищёнными
 * слабым паролем (Android Hardware-Backed Keystore).
 * Категория: M1 Improper Credential Usage / R022 / R039.
 *
 * Создаём EC-keypair (P-256) в AndroidKeyStore и используем приватный
 * ключ с попыткой `KeyStore.PasswordProtection(weak)`. Алиас передан
 * захардкоженным; пароль `letmein` попадает в DEX как hardcoded weak
 * literal.
 */
public class HardwareKeyStorePrivateWeakService extends Service {

    private static final String TAG = "Vuln04-S3-PrivWeak";
    private static final String ALIAS = "vuln04_service3_ec_priv";
    private static final String WEAK_PASSWORD = "letmein";

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        try {
            KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
            ks.load(null);

            KeyGenParameterSpec spec = new KeyGenParameterSpec.Builder(
                    ALIAS,
                    KeyProperties.PURPOSE_SIGN | KeyProperties.PURPOSE_VERIFY)
                    .setDigests(KeyProperties.DIGEST_SHA256)
                    .setAlgorithmParameterSpec(new ECGenParameterSpec("secp256r1"))
                    // VULN: нет setUserAuthenticationRequired(true) → ключ
                    // используется без биометрии/PIN
                    .build();
            KeyPairGenerator kpg = KeyPairGenerator.getInstance(
                    KeyProperties.KEY_ALGORITHM_EC, "AndroidKeyStore");
            kpg.initialize(spec);
            kpg.generateKeyPair();

            // VULN sink: чтение приватного ключа с weak password literal.
            KeyStore.PasswordProtection pp =
                    new KeyStore.PasswordProtection(WEAK_PASSWORD.toCharArray());
            KeyStore.Entry rawEntry = ks.getEntry(ALIAS, pp);
            PrivateKey privateKey = null;
            if (rawEntry instanceof KeyStore.PrivateKeyEntry) {
                privateKey = ((KeyStore.PrivateKeyEntry) rawEntry).getPrivateKey();
            }
            Log.d(TAG, "Read EC private key alias=" + ALIAS
                    + ", weakPwd=" + WEAK_PASSWORD
                    + ", key.algo=" + (privateKey != null ? privateKey.getAlgorithm() : null));
        } catch (Exception ignored) {}
        return START_NOT_STICKY;
    }
}
