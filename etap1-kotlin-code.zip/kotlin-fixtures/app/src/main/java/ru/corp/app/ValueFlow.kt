package ru.corp.app

import ru.sberbank.cerbersdk.sdk_framework.AuthorizationMode
import ru.sberbank.cerbersdk.sdk_framework.BuildType
import ru.sberbank.cerbersdk.sdk_framework.CerberSDKApplication
import ru.sberbank.cerbersdk.sdk_framework.CerberSDKApplicationDelegate

/**
 * K07 insecure-auth-mode-variable и K14 non-production-build-type-variable.
 * Оба правила ловят значение, которое не передано в конструктор напрямую,
 * а течёт через переменную, возврат функции или условное выражение.
 */
object ValueFlow {

    /** K07-TP-1. Режим в локальной переменной. */
    fun authModeInLocal(): CerberSDKApplicationDelegate {
        val mode = AuthorizationMode.LEGACY
        return CerberSDKApplicationDelegate(authorizationMode = mode)
    }

    /** K07-TP-2. Режим возвращён функцией. */
    fun resolveAuthMode(): AuthorizationMode {
        return AuthorizationMode.NONE
    }

    /** K07-TP-3. Режим выбран условным выражением. */
    fun authModeConditional(isDebug: Boolean): AuthorizationMode {
        return if (isDebug) AuthorizationMode.EXTERNAL else AuthorizationMode.CERBER
    }

    /** K14-TP-1. Тип сборки в локальной переменной. */
    fun buildTypeInLocal(): CerberSDKApplicationDelegate {
        val bt = BuildType.DEV2
        return CerberSDKApplicationDelegate(buildType = bt)
    }

    /** K14-TP-2. Тип сборки возвращён функцией. */
    fun resolveBuildType(): BuildType {
        return BuildType.PSI
    }

    /** K14-TP-3. Тип сборки выбран условным выражением. */
    fun buildTypeConditional(isProd: Boolean): BuildType {
        return if (isProd) BuildType.PROM else BuildType.IFT
    }

    /** K07-TN-1. Безопасный режим в переменной: молчание. */
    fun secureAuthModeInLocal(): CerberSDKApplicationDelegate {
        val mode = AuthorizationMode.CERBER
        return CerberSDKApplicationDelegate(authorizationMode = mode)
    }

    /** K14-TN-1. Продуктовый тип сборки в переменной: молчание. */
    fun promBuildTypeInLocal(): CerberSDKApplicationDelegate {
        val bt = BuildType.PROM
        return CerberSDKApplicationDelegate(buildType = bt)
    }

    /**
     * K07-PROBE-1, K14-PROBE-1. Значение приходит снаружи параметром функции.
     * Статике неизвестно, какое оно, и правило ловить тут нечего — но
     * реальный разработчик пишет именно так, и это дыра по сути.
     */
    fun fromParameter(mode: AuthorizationMode, bt: BuildType): CerberSDKApplicationDelegate {
        return CerberSDKApplicationDelegate(authorizationMode = mode, buildType = bt)
    }
}

/** K11 missing-delegate-creation: делегат получен не свежим экземпляром. */

/** K11-TP-1. Делегат из внешнего источника, а не создан на месте. */
class InjectedDelegateApplication(
    private val injected: CerberSDKApplicationDelegate
) : Application(), CerberSDKApplication {
    override val delegate: CerberSDKApplicationDelegate = injected
}

/** K11-TP-2. Делегат из геттера объекта-поставщика. */
object DelegateProvider {
    val shared = CerberSDKApplicationDelegate(secureInitialCheck = true)
}

class ProvidedDelegateApplication : Application(), CerberSDKApplication {
    override val delegate: CerberSDKApplicationDelegate = DelegateProvider.shared
}

/** K11-TN-1. Делегат создан на месте с явными параметрами: молчание. */
class FreshDelegateApplication : Application(), CerberSDKApplication {
    override val delegate = CerberSDKApplicationDelegate(
        secureInitialCheck = true,
        secureScreen = true,
        secureClipboard = true,
        authorizationMode = AuthorizationMode.CERBER,
        buildType = BuildType.PROM
    )
}
