package ru.corp.app

import ru.sberbank.cerbersdk.sdk_framework.AuthorizationMode
import ru.sberbank.cerbersdk.sdk_framework.BuildType
import ru.sberbank.cerbersdk.sdk_framework.CerberSDKApplication
import ru.sberbank.cerbersdk.sdk_framework.CerberSDKApplicationDelegate

/**
 * Сторона TN для тех же правил. Любая находка здесь означает переcрабатывание.
 */

/** K04-TN-1, K06-TN-1, K08-TN-1, K09-TN-1, K12-TN-1, K13-TN-1, K15-TN-1. Эталонная интеграция. */
class SecureApplication : Application(), CerberSDKApplication {
    override val delegate = CerberSDKApplicationDelegate(
        secureInitialCheck = true,
        secureScreen = true,
        secureClipboard = true,
        disablePasswordlessAuth = false,
        authorizationMode = AuthorizationMode.CERBER,
        buildType = BuildType.PROM
    )
}

/** K04-TN-2. Параметры переданы позиционно, значения безопасные. */
class PositionalSecureApplication : Application(), CerberSDKApplication {
    override val delegate = CerberSDKApplicationDelegate(
        true, true, true, false, AuthorizationMode.CERBER, BuildType.PROM
    )
}

/**
 * K12-PROBE-1. Класс не наследует Application, интерфейс SDK ему не нужен.
 * Правило K12 построено на наследовании от Application, поэтому ожидается молчание.
 */
class NotAnApplication {
    fun doWork() {
        Log.d("app", "plain class")
    }
}
