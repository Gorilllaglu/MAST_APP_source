package ru.corp.app

import ru.sberbank.cerbersdk.sdk_framework.AuthorizationMode
import ru.sberbank.cerbersdk.sdk_framework.BuildType
import ru.sberbank.cerbersdk.sdk_framework.CerberSDKApplication
import ru.sberbank.cerbersdk.sdk_framework.CerberSDKApplicationDelegate

/**
 * Сторона TP для правил по конструктору делегата и по классу Application.
 * K04 default-constructor-used, K06 insecure-auth-mode, K08 insecure-clipboard-disabled,
 * K09 insecure-screen-disabled, K12 missing-sdk-application-interface,
 * K13 non-production-build-type, K15 passwordless-auth-disabled.
 */

/** K04-TP-1. Конструктор без аргументов: все защиты выключены по умолчанию. */
class DefaultCtorApplication : Application(), CerberSDKApplication {
    override val delegate = CerberSDKApplicationDelegate()
}

/** K09-TP-1. Защита экрана выключена явно. */
class ScreenOffApplication : Application(), CerberSDKApplication {
    override val delegate = CerberSDKApplicationDelegate(
        secureInitialCheck = true,
        secureScreen = false,
        secureClipboard = true
    )
}

/** K08-TP-1. Защита буфера обмена выключена явно. */
class ClipboardOffApplication : Application(), CerberSDKApplication {
    override val delegate = CerberSDKApplicationDelegate(
        secureInitialCheck = true,
        secureScreen = true,
        secureClipboard = false
    )
}

/** K15-TP-1. Беспарольная аутентификация отключена. */
class PasswordlessOffApplication : Application(), CerberSDKApplication {
    override val delegate = CerberSDKApplicationDelegate(
        secureInitialCheck = true,
        disablePasswordlessAuth = true
    )
}

/** K06-TP-1. Режим авторизации не CERBER. */
class NonCerberAuthApplication : Application(), CerberSDKApplication {
    override val delegate = CerberSDKApplicationDelegate(
        secureInitialCheck = true,
        authorizationMode = AuthorizationMode.NONE
    )
}

/** K06-TP-2. Другой не-CERBER режим: проверяет регекс с отрицательным просмотром. */
class ExternalAuthApplication : Application(), CerberSDKApplication {
    override val delegate = CerberSDKApplicationDelegate(
        secureInitialCheck = true,
        authorizationMode = AuthorizationMode.EXTERNAL
    )
}

/** K13-TP-1. Непродуктовый тип сборки. */
class DevBuildApplication : Application(), CerberSDKApplication {
    override val delegate = CerberSDKApplicationDelegate(
        secureInitialCheck = true,
        buildType = BuildType.DEV1
    )
}

/** K13-TP-2. Ещё один непродуктовый тип: IFT. */
class IftBuildApplication : Application(), CerberSDKApplication {
    override val delegate = CerberSDKApplicationDelegate(
        secureInitialCheck = true,
        buildType = BuildType.IFT
    )
}

/** K12-TP-1. Application без интерфейса CerberSDKApplication. */
class PlainApplication : Application() {
    fun onCreateStub() {
        Log.d("app", "started without CerberSDKApplication")
    }
}
