package ru.corp.app.transfer

import ru.corp.app.Log
import ru.sberbank.cerbersdk.sdk_framework.CerberFileReceiver
import ru.sberbank.cerbersdk.sdk_framework.Uri

/**
 * K05 file-received-no-caller-check. Паттерн правила ждёт сигнатуру
 * onFileReceived($URI: Uri, $PKG: String) — именно с типом Uri. В первом
 * прогоне первый параметр был String, и правило молчало: причина в фикстурах.
 */

/** K05-TP-1. Параметр callingPackage не используется вовсе. */
class OpenFileReceiver : CerberFileReceiver {
    override fun onFileReceived(uri: Uri, callingPackage: String) {
        importDocument(uri)
    }

    private fun importDocument(uri: Uri) {}
}

/** K05-TP-2. callingPackage только логируется, решение на него не опирается. */
class LoggingFileReceiver : CerberFileReceiver {
    override fun onFileReceived(uri: Uri, callingPackage: String) {
        Log.d("transfer", "from " + callingPackage)
        importDocument(uri)
    }

    private fun importDocument(uri: Uri) {}
}

/** K05-TN-1. Сверка через contains по белому списку. Молчание обязательно. */
class GuardedFileReceiver : CerberFileReceiver {

    private val allowed = setOf("ru.sberbank.sberapps", "ru.sberbank.sberdocs")

    override fun onFileReceived(uri: Uri, callingPackage: String) {
        if (!allowed.contains(callingPackage)) {
            return
        }
        importDocument(uri)
    }

    private fun importDocument(uri: Uri) {}
}

/** K05-TN-2. Сверка равенством, ранний выход. Молчание обязательно. */
class GuardedFileReceiverEarly : CerberFileReceiver {
    override fun onFileReceived(uri: Uri, callingPackage: String) {
        if (callingPackage != "ru.sberbank.sberapps") return
        importDocument(uri)
    }

    private fun importDocument(uri: Uri) {}
}

/** K05-TN-3. Сверка через in по коллекции — отдельный pattern-not правила. */
class GuardedFileReceiverIn : CerberFileReceiver {

    private val allowed = listOf("ru.sberbank.sberapps")

    override fun onFileReceived(uri: Uri, callingPackage: String) {
        if (callingPackage in allowed) {
            importDocument(uri)
        }
    }

    private fun importDocument(uri: Uri) {}
}

/** K05-TN-4. Сверка через equals — ещё один pattern-not правила. */
class GuardedFileReceiverEquals : CerberFileReceiver {
    override fun onFileReceived(uri: Uri, callingPackage: String) {
        if (callingPackage.equals("ru.sberbank.sberapps")) {
            importDocument(uri)
        }
    }

    private fun importDocument(uri: Uri) {}
}
