package ru.corp.app.transfer

import ru.corp.app.Log
import ru.sberbank.cerbersdk.sdk_framework.CerberFileReceiver

/**
 * K05 file-received-no-caller-check: onFileReceived не проверяет callingPackage.
 */

/** K05-TP-1. Параметр callingPackage не используется вовсе. */
class OpenFileReceiver : CerberFileReceiver {
    override fun onFileReceived(uri: String, callingPackage: String) {
        importDocument(uri)
    }

    private fun importDocument(uri: String) {}
}

/** K05-TP-2. callingPackage только логируется, решение на него не опирается. */
class LoggingFileReceiver : CerberFileReceiver {
    override fun onFileReceived(uri: String, callingPackage: String) {
        Log.d("transfer", "from " + callingPackage)
        importDocument(uri)
    }

    private fun importDocument(uri: String) {}
}

/** K05-TN-1. callingPackage сверен с белым списком. Молчание. */
class GuardedFileReceiver : CerberFileReceiver {

    private val allowed = setOf("ru.sberbank.sberapps", "ru.sberbank.sberdocs")

    override fun onFileReceived(uri: String, callingPackage: String) {
        if (!allowed.contains(callingPackage)) {
            return
        }
        importDocument(uri)
    }

    private fun importDocument(uri: String) {}
}

/** K05-TN-2. Ранний выход по несовпадению, обратный порядок условия. Молчание. */
class GuardedFileReceiverEarly : CerberFileReceiver {
    override fun onFileReceived(uri: String, callingPackage: String) {
        if (callingPackage != "ru.sberbank.sberapps") return
        importDocument(uri)
    }

    private fun importDocument(uri: String) {}
}
