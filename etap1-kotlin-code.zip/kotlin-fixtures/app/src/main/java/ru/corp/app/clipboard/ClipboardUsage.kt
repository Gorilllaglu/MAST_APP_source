package ru.corp.app.clipboard

import ru.corp.app.Log
import ru.sberbank.cerbersdk.sdk_framework.CerberCopyPasteBuffer
import ru.sberbank.cerbersdk.sdk_framework.WriteResult

/**
 * K03 clipboard-write-result-ignored.
 */
object ClipboardUsage {

    /** K03-TP-1. Результат записи отброшен. */
    fun copyAccountNumber(value: String) {
        CerberCopyPasteBuffer.write(value)
    }

    /** K03-TP-2. Результат ушёл только в журнал. */
    fun copyAndLog(value: String) {
        Log.d("clipboard", "result=" + CerberCopyPasteBuffer.write(value))
    }

    /** K03-TN-1. Результат сверен с SUCCESS. Молчание. */
    fun copyChecked(value: String): Boolean {
        val r = CerberCopyPasteBuffer.write(value)
        return r == WriteResult.SUCCESS
    }

    /** K03-TN-2. Обработаны все три состояния. Молчание. */
    fun copyHandled(value: String): String {
        return when (CerberCopyPasteBuffer.write(value)) {
            WriteResult.SUCCESS -> "ok"
            WriteResult.TRUNCATED -> "truncated"
            WriteResult.FAILURE -> "failed"
        }
    }
}
