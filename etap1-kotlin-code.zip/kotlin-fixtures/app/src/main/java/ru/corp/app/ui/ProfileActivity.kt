package ru.corp.app.ui

import ru.corp.app.AppCompatActivity
import ru.corp.app.observeAuthState
import ru.corp.app.requestCerberAuth
import ru.sberbank.cerbersdk.sdk_framework.AuthState

/**
 * K01 activity-missing-auth-onresume и K02 auth-requested-but-not-observed.
 */

/** K01-TP-1. onResume переопределён, requestCerberAuth не вызывается. */
class ProfileActivity : AppCompatActivity() {
    override fun onResume() {
        super.onResume()
        loadProfile()
    }

    private fun loadProfile() {}
}

/** K01-TP-2. То же во фрагменте: регекс правила покрывает Fragment. */
class SettingsFragment : AppCompatActivity() {
    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {}
}

/** K02-TP-1. Авторизация запрошена, состояние не наблюдается. */
class PaymentsActivity : AppCompatActivity() {
    override fun onResume() {
        super.onResume()
        requestCerberAuth(this)
    }
}

/** K01-TN-1, K02-TN-1. Эталон: запрос и наблюдение на месте. Молчание. */
class DocumentsActivity : AppCompatActivity() {
    override fun onResume() {
        super.onResume()
        requestCerberAuth(this)
        observeAuthState { state ->
            if (state is AuthState.LoggedOut) {
                finishWork()
            }
        }
    }

    private fun finishWork() {}
}

/**
 * K01-PROBE-1. onResume не переопределён вовсе: экран не проверяет авторизацию
 * при возврате, но правило построено на переопределении onResume,
 * поэтому ожидается молчание. По сути дефект тот же.
 */
class ReportsActivity : AppCompatActivity() {
    fun load() {}
}

/**
 * K02-PROBE-1. Наблюдение вынесено в другой класс.
 * Правило требует вызова в том же классе, поэтому ожидается сработка,
 * хотя интеграция фактически корректная. Проверяет склонность к ложным.
 */
class SplitAuthActivity : AppCompatActivity() {
    override fun onResume() {
        super.onResume()
        requestCerberAuth(this)
    }
}

class SplitAuthObserver {
    fun start() {
        observeAuthState { }
    }
}
