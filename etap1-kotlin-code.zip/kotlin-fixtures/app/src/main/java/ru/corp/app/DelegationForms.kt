package ru.corp.app

import ru.sberbank.cerbersdk.sdk_framework.AuthorizationMode
import ru.sberbank.cerbersdk.sdk_framework.BuildType
import ru.sberbank.cerbersdk.sdk_framework.CerberSDKApplication
import ru.sberbank.cerbersdk.sdk_framework.CerberSDKApplicationDelegate

/**
 * K11 missing-delegate-creation. Паттерны правила описаны через котлиновское
 * делегирование: class $APP : CerberSDKApplication by $DELEGATE. В первом
 * прогоне фикстуры реализовывали свойство интерфейса вручную, и правило
 * молчало — причина была в фикстурах.
 */

private val sharedDelegate = CerberSDKApplicationDelegate(secureInitialCheck = true)

/** K11-TP-3. Делегат взят из свойства файла, а не создан на месте. */
class SharedDelegateApp : CerberSDKApplication by sharedDelegate

/** K11-TP-4. Делегат пришёл параметром конструктора, с базовым классом. */
class InjectedDelegateApp(
    injected: CerberSDKApplicationDelegate
) : Application(), CerberSDKApplication by injected

/** K11-TP-5. Делегат получен из объекта-поставщика. */
object DelegateHolder {
    val instance = CerberSDKApplicationDelegate(secureInitialCheck = true)
}

class HolderDelegateApp : CerberSDKApplication by DelegateHolder.instance

/** K11-TN-2. Делегат создан на месте с явными параметрами. Молчание обязательно. */
class FreshDelegateApp : CerberSDKApplication by CerberSDKApplicationDelegate(
    secureInitialCheck = true,
    secureScreen = true,
    secureClipboard = true,
    authorizationMode = AuthorizationMode.CERBER,
    buildType = BuildType.PROM
)

/** K11-TN-3. То же с базовым классом. Молчание обязательно. */
class FreshDelegateWithBaseApp : Application(), CerberSDKApplication by CerberSDKApplicationDelegate(
    secureInitialCheck = true,
    secureScreen = true,
    secureClipboard = true
)
