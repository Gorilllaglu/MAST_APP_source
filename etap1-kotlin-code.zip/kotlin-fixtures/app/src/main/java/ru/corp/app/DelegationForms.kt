package ru.corp.app

import ru.sberbank.cerbersdk.sdk_framework.AuthorizationMode
import ru.sberbank.cerbersdk.sdk_framework.BuildType
import ru.sberbank.cerbersdk.sdk_framework.CerberSDKApplication
import ru.sberbank.cerbersdk.sdk_framework.CerberSDKApplicationDelegate

/**
 * K11 missing-delegate-creation.
 * Паттерны правила требуют ТЕЛО класса в фигурных скобках. В прошлом прогоне
 * фикстуры были написаны классами без тела, и правило молчало — причина
 * была в фикстурах, второй раз подряд.
 */

private val sharedDelegate = CerberSDKApplicationDelegate(secureInitialCheck = true)

/** K11-TP-3. Делегат из свойства файла, без базового класса, с телом. */
class SharedDelegateApp : CerberSDKApplication by sharedDelegate {
    fun onCreateStub() {
        Log.d("app", "shared delegate")
    }
}

/** K11-TP-4. Делегат параметром конструктора, с базовым классом и телом. */
class InjectedDelegateApp(
    injected: CerberSDKApplicationDelegate
) : Application(), CerberSDKApplication by injected {
    fun onCreateStub() {
        Log.d("app", "injected delegate")
    }
}

/** K11-TP-5. Делегат из объекта-поставщика, с телом. */
object DelegateHolder {
    val instance = CerberSDKApplicationDelegate(secureInitialCheck = true)
}

class HolderDelegateApp : Application(), CerberSDKApplication by DelegateHolder.instance {
    fun onCreateStub() {
        Log.d("app", "holder delegate")
    }
}

/** K11-TP-6. Делегат из геттера свойства класса. */
class GetterDelegateApp(
    private val provider: DelegateProviderContract
) : Application(), CerberSDKApplication by provider.delegate {
    fun onCreateStub() {
        Log.d("app", "getter delegate")
    }
}

interface DelegateProviderContract {
    val delegate: CerberSDKApplicationDelegate
}

/** K11-TN-2. Делегат создан на месте, без базового класса, с телом. Молчание. */
class FreshDelegateApp : CerberSDKApplication by CerberSDKApplicationDelegate(
    secureInitialCheck = true,
    secureScreen = true,
    secureClipboard = true,
    authorizationMode = AuthorizationMode.CERBER,
    buildType = BuildType.PROM
) {
    fun onCreateStub() {
        Log.d("app", "fresh delegate")
    }
}

/** K11-TN-3. Делегат создан на месте, с базовым классом и телом. Молчание. */
class FreshDelegateWithBaseApp : Application(), CerberSDKApplication by CerberSDKApplicationDelegate(
    secureInitialCheck = true,
    secureScreen = true,
    secureClipboard = true
) {
    fun onCreateStub() {
        Log.d("app", "fresh delegate with base")
    }
}
