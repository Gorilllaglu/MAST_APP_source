package ru.corp.app

import ru.sberbank.cerbersdk.sdk_framework.AuthorizationMode
import ru.sberbank.cerbersdk.sdk_framework.BuildType
import ru.sberbank.cerbersdk.sdk_framework.CerberSDKApplicationDelegate

/**
 * K06 insecure-auth-mode. Паттерн правила ждёт перечисление ПОЗИЦИОННЫМ
 * аргументом: $METHOD(..., AuthorizationMode.$MODE, ...). В первом прогоне
 * фикстуры были написаны с именованными аргументами и правило молчало —
 * причина была в фикстурах.
 */
object AuthModePositional {

    /** K06-TP-3. Позиционный аргумент, режим NONE. */
    fun insecureNone(): CerberSDKApplicationDelegate =
        CerberSDKApplicationDelegate(true, true, true, false, AuthorizationMode.NONE, BuildType.PROM)

    /** K06-TP-4. Позиционный аргумент, режим EXTERNAL. */
    fun insecureExternal(): CerberSDKApplicationDelegate =
        CerberSDKApplicationDelegate(true, true, true, false, AuthorizationMode.EXTERNAL, BuildType.PROM)

    /** K06-TP-5. Передача режима в произвольный метод, не в конструктор делегата. */
    fun configure(mode: AuthorizationMode) {}

    fun applyLegacy() {
        configure(AuthorizationMode.LEGACY)
    }

    /** K06-TN-2. Позиционный аргумент, режим CERBER. Молчание обязательно. */
    fun secure(): CerberSDKApplicationDelegate =
        CerberSDKApplicationDelegate(true, true, true, false, AuthorizationMode.CERBER, BuildType.PROM)

    /** K06-TN-3. CERBER в произвольный метод. Молчание обязательно. */
    fun applyCerber() {
        configure(AuthorizationMode.CERBER)
    }
}
