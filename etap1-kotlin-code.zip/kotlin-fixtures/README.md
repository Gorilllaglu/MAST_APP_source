# Исходный код для проверки 15 непроверенных Kotlin-правил

Этап 1. Каждое правило получило индекс `K01`–`K15`, маркеры в комментариях кода. `TP` — правило обязано сработать, `TN` — обязано промолчать, `PROBE` — форма, поведение на которой заранее не известно и является предметом теста.

Прогонять с правилами из `../kotlin/unverified/`.

## Карта правил

| Индекс | Правило | Что ловит | Маркеры |
|---|---|---|---|
| K01 | `cerber-activity-missing-auth-onresume` | `onResume()` переопределён без `requestCerberAuth(this)` | TP-1, TP-2, TN-1, PROBE-1 |
| K02 | `cerber-auth-requested-but-not-observed` | `requestCerberAuth()` без `observeAuthState()` в том же классе | TP-1, TN-1, PROBE-1 |
| K03 | `cerber-clipboard-write-result-ignored` | результат `CerberCopyPasteBuffer.write()` не проверен | TP-1, TP-2, TN-1, TN-2 |
| K04 | `cerber-default-constructor-used` | `CerberSDKApplicationDelegate()` без аргументов | TP-1, TN-1, TN-2 |
| K05 | `cerber-file-received-no-caller-check` | `onFileReceived()` не проверяет `callingPackage` | TP-1, TP-2, TN-1, TN-2 |
| K06 | `cerber-insecure-auth-mode` | режим авторизации не `CERBER` | TP-1, TP-2, TN-1 |
| K07 | `cerber-insecure-auth-mode-variable` | режим течёт через переменную, возврат, условие | TP-1, TP-2, TP-3, TN-1, PROBE-1 |
| K08 | `cerber-insecure-clipboard-disabled` | `secureClipboard = false` | TP-1, TN-1 |
| K09 | `cerber-insecure-screen-disabled` | `secureScreen = false` | TP-1, TN-1 |
| K10 | `cerber-isolated-service-not-isolated` | `IsolatedService` без `android:isolatedProcess="true"` | TP-1, TP-2, TN-1, TN-2, PROBE-1 |
| K11 | `cerber-missing-delegate-creation` | делегат получен не свежим экземпляром | TP-1, TP-2, TN-1 |
| K12 | `cerber-missing-sdk-application-interface` | `Application` без интерфейса `CerberSDKApplication` | TP-1, TN-1, PROBE-1 |
| K13 | `cerber-non-production-build-type` | непродуктовый `BuildType` в конструкторе | TP-1, TP-2, TN-1 |
| K14 | `cerber-non-production-build-type-variable` | тип сборки течёт через переменную, возврат, условие | TP-1, TP-2, TP-3, TN-1, PROBE-1 |
| K15 | `cerber-passwordless-auth-disabled` | `disablePasswordlessAuth = true` | TP-1, TN-1 |

Всего 51 маркер: 25 TP, 20 TN, 6 PROBE.

## Где что лежит

`CorpApplication.kt` — сторона TP по конструктору делегата и по классу Application: K04, K06, K08, K09, K12, K13, K15.

`CorpApplicationTn.kt` — сторона TN тех же правил, включая эталонную интеграцию со всеми безопасными значениями и вариант с позиционными аргументами.

`ValueFlow.kt` — K07 и K14: значение в локальной переменной, возвращённое функцией, выбранное условным выражением. Плюс K11 — делегат из конструктора класса и из объекта-поставщика.

`ui/ProfileActivity.kt` — K01 и K02: `onResume` без запроса авторизации, запрос без наблюдения, эталон с обоими.

`clipboard/ClipboardUsage.kt` — K03: результат отброшен, результат в журнал, результат сверен, результат разобран через `when`.

`transfer/FileReceiver.kt` — K05: `callingPackage` не используется, только логируется, сверен с белым списком, ранний выход.

`app/src/main/AndroidManifest.xml` — K10. Правило объявлено с `languages: xml`, поэтому цель в манифесте, а не в Kotlin.

`stubs/` — объявления типов SDK и платформы. Только объявления, вызовов нет: ожидается ноль находок по всем правилам, это контрольный файл.

## На что смотреть в первую очередь при триаже

Шесть PROBE-маркеров — формы, по которым заранее не ясно, как поведёт себя правило, и по ним понадобится ваше решение.

`K01-PROBE-1` — `onResume` не переопределён вовсе. Экран авторизацию при возврате не проверяет, но правило построено на переопределении, так что скорее всего промолчит. Дефект по сути тот же.

`K02-PROBE-1` — наблюдение состояния вынесено в отдельный класс. Правило требует вызова в том же классе, значит вероятна сработка на корректной интеграции.

`K07-PROBE-1`, `K14-PROBE-1` — значение приходит параметром функции извне. Статике неизвестно, какое оно; ловить нечего, но разработчики пишут именно так.

`K10-PROBE-1` — изоляция задана через `android:process` с отдельным именем вместо `isolatedProcess`. Это не эквивалент, защита слабее, правилом форма не описана.

`K12-PROBE-1` — класс не наследует `Application`, интерфейс SDK ему не нужен. Ожидается молчание.

## Чего в фикстурах нет намеренно

Предсказаний о поведении движка. Правила уже входят в набор sastav, поэтому конструкции вроде `pattern-not-inside`, `metavariable-regex` и `metavariable-pattern` считаем рабочими до появления подтверждённого негатива по итогам этого прогона.

В `insecure-auth-mode` используется регекс с отрицательным просмотром вперёд `^(?!CERBER$)[A-Z0-9_]+$`. Под него в фикстурах две TP-формы с разными не-CERBER значениями и одна TN с `CERBER` — если просмотр не поддержан, это будет видно по сработке на TN.
