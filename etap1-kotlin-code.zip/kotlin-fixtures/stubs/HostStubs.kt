package ru.corp.app

import ru.sberbank.cerbersdk.sdk_framework.AuthState

/** Заглушки платформы и host-app под фикстуры. */

open class Application

open class AppCompatActivity {
    open fun onResume() {}
    open fun onPause() {}
}

fun requestCerberAuth(target: Any) {}

fun observeAuthState(cb: (AuthState) -> Unit) {}

object Log {
    fun d(tag: String, msg: String) {}
}
