package ru.sberbank.cerbersdk.sdk_framework

/** Заглушки под фикстуры: только объявления, вызовов нет, находок быть не должно. */

enum class AuthorizationMode { CERBER, NONE, EXTERNAL, LEGACY }

enum class BuildType { PROM, DEV1, DEV2, IFT, PSI }

enum class WriteResult { SUCCESS, TRUNCATED, FAILURE }

sealed class AuthState {
    object Authorized : AuthState()
    object Pin : AuthState()
    object LoggedOut : AuthState()
}

interface CerberSDKApplication {
    fun initializeSdk()
}

class CerberSDKApplicationDelegate(
    val secureInitialCheck: Boolean = false,
    val secureScreen: Boolean = false,
    val secureClipboard: Boolean = false,
    val disablePasswordlessAuth: Boolean = false,
    val authorizationMode: AuthorizationMode = AuthorizationMode.CERBER,
    val buildType: BuildType = BuildType.PROM
) : CerberSDKApplication {
    override fun initializeSdk() {}
}

object CerberCopyPasteBuffer {
    fun write(data: String): WriteResult = WriteResult.SUCCESS
    fun read(): String = ""
}

/** Заглушка платформенного Uri: правило K05 требует именно этот тип параметра. */
class Uri

interface CerberFileReceiver {
    fun onFileReceived(uri: Uri, callingPackage: String)
}
