package ru.sberbank.cerbersdk.sdk_framework

/** Заглушки под фикстуры: только объявления, вызовов нет, находок быть не должно. */

enum class AuthorizationMode { CERBER, NONE, EXTERNAL, LEGACY }

enum class BuildType { PROM, DEV1, DEV2, IFT, PSI }

enum class WriteResult { SUCCESS, TRUNCATED, FAILURE }

sealed class AuthState {
    object Authorized : AuthState()
    object Pin : AuthState()
    object LoggedOut : AuthState()
}

class CerberSDKApplicationDelegate(
    val secureInitialCheck: Boolean = false,
    val secureScreen: Boolean = false,
    val secureClipboard: Boolean = false,
    val disablePasswordlessAuth: Boolean = false,
    val authorizationMode: AuthorizationMode = AuthorizationMode.CERBER,
    val buildType: BuildType = BuildType.PROM
)

interface CerberSDKApplication {
    val delegate: CerberSDKApplicationDelegate
}

object CerberCopyPasteBuffer {
    fun write(data: String): WriteResult = WriteResult.SUCCESS
    fun read(): String = ""
}

interface CerberFileReceiver {
    fun onFileReceived(uri: String, callingPackage: String)
}
