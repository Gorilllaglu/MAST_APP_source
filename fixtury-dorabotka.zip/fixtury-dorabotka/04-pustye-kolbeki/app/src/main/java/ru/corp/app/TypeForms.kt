package ru.corp.app

import android.net.Uri
import ru.sberbank.cerbersdk.CerberCallbacks
import ru.sberbank.cerbersdk.CerberCallbacksNullableBoth
import ru.sberbank.cerbersdk.CerberCallbacksNullablePkg
import ru.sberbank.cerbersdk.CerberCallbacksNullableUri

/**
 * Контроль доработки четырёх правил на пустые колбэки и маркера
 * cerber-file-received-no-caller-check.
 *
 * Правка внесла два изменения. Первое: у onLogout, onNoAuthDetected и
 * onUserChanged список форм пустого тела выровнен по эталону - пусто,
 * один return, один Unit, тело-выражение = Unit. Второе: у обоих правил по
 * onFileReceived добавлены все четыре написания типов параметров.
 *
 * Прошлый прогон: клетки L03-PROBE-1, L05-PROBE-1 и L02-PROBE-2 молчали,
 * это и было основанием.
 */

/** DL03-TP-1. onLogout телом из одного Unit. */
class LogoutUnitBody : CerberCallbacks {
    override fun onLogout() {
        Unit
    }
}

/** DL04-TP-1. onUserChanged телом из одного Unit. */
class UserChangedUnitBody : CerberCallbacks {
    override fun onUserChanged() {
        Unit
    }
}

/** DL05-TP-1. onNoAuthDetected телом из одного Unit. */
class NoAuthUnitBody : CerberCallbacks {
    override fun onNoAuthDetected() {
        Unit
    }
}

/** DL05-TP-2. onNoAuthDetected телом из одного return. */
class NoAuthReturnBody : CerberCallbacks {
    override fun onNoAuthDetected() {
        return
    }
}

/** DL03-TP-2. onLogout телом из одного return. */
class LogoutReturnBody : CerberCallbacks {
    override fun onLogout() {
        return
    }
}

/** DL03-TN-1. onLogout с настоящим телом. Молчание. */
class LogoutRealBody : CerberCallbacks {
    private var token: String? = "t"

    override fun onLogout() {
        token = null
    }
}

/** DL02-TP-1. onFileReceived, Uri обнуляемый, пустое тело. */
class FileNullableUriEmpty : CerberCallbacksNullableUri {
    override fun onFileReceived(uri: Uri?, pkg: String) { }
}

/** DL02-TP-2. Uri обнуляемый, тело-выражение. */
class FileNullableUriUnit : CerberCallbacksNullableUri {
    override fun onFileReceived(uri: Uri?, pkg: String) = Unit
}

/** DL02-TP-3. Обнуляемый пакет, пустое тело. */
class FileNullablePkgEmpty : CerberCallbacksNullablePkg {
    override fun onFileReceived(uri: Uri, pkg: String?) { }
}

/** DL02-TP-4. Оба типа обнуляемые, тело из одного return. */
class FileNullableBothReturn : CerberCallbacksNullableBoth {
    override fun onFileReceived(uri: Uri?, pkg: String?) {
        return
    }
}

/** DL02-TP-5. Оба типа необнуляемые, тело из одного Unit. */
class FileUnitBody : CerberCallbacks {
    override fun onFileReceived(uri: Uri, pkg: String) {
        Unit
    }
}

/**
 * DL02-TN-1. Обнуляемые типы, настоящее тело: файл копируется к себе.
 * Правило на пустой колбэк обязано молчать. Маркер
 * cerber-file-received-no-caller-check обязан СРАБОТАТЬ: он отмечает
 * наличие приёмника, а не пустоту тела.
 */
class FileNullableRealBody : CerberCallbacksNullableBoth {
    private val received = mutableListOf<String>()

    override fun onFileReceived(uri: Uri?, pkg: String?) {
        if (uri != null && pkg != null) {
            received.add(pkg)
        }
    }
}
