package ru.corp.app.clipboard

import android.content.ClipData
import android.content.ClipboardManager
import android.net.Uri

/**
 * Контроль доработки правила cerber-host-clipboard-bypass.
 * Прошлый прогон: девять лишних находок из двенадцати. Строка
 * setPrimaryClip(ClipData.newPlainText(...)) подходила сразу под две
 * альтернативы одного pattern-either, и движок выдавал её дважды.
 * Правка отсекает внешний узел четырьмя pattern-not.
 *
 * ПРОВЕРЯТЬ ЧИСЛО НАХОДОК, А НЕ ТОЛЬКО ИХ НАЛИЧИЕ. На каждой клетке ниже
 * должна быть РОВНО ОДНА находка. Ноль находок на DE01-TP-2 означает, что
 * отрицание в этом движке гасит и вложенный узел - тогда правку надо
 * откатить и принять дубли.
 */

object DedupForms {

    /** DE01-TP-1. Запись готовой вырезки из переменной. Ровно одна находка. */
    fun copyPrepared(cm: ClipboardManager, clip: ClipData) {
        cm.setPrimaryClip(clip)
    }

    /** DE01-TP-2. Сборка и запись одним выражением. Было две находки, должна стать одна. */
    fun copyInline(cm: ClipboardManager, text: String) {
        cm.setPrimaryClip(ClipData.newPlainText("label", text))
    }

    /** DE01-TP-3. Только сборка вырезки, записи нет. Ровно одна находка. */
    fun buildOnly(text: String): ClipData {
        return ClipData.newPlainText("label", text)
    }

    /** DE01-TP-4. Запись результата своей функции. Ровно одна находка. */
    fun copyViaHelper(cm: ClipboardManager, text: String) {
        cm.setPrimaryClip(buildOnly(text))
    }

    /** DE01-TP-5. Сборка через newRawUri и запись одним выражением. Одна находка. */
    fun copyRawUri(cm: ClipboardManager, uri: Uri) {
        cm.setPrimaryClip(ClipData.newRawUri("label", uri))
    }
}
