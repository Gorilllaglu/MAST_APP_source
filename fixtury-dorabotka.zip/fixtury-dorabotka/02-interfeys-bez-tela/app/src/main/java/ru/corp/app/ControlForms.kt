package ru.corp.app

import ru.sberbank.cerbersdk.sdk_framework.CerberSDKApplication
import ru.sberbank.cerbersdk.sdk_framework.CerberSDKApplicationDelegate

/**
 * Контроль доработки правила cerber-missing-sdk-application-interface в том
 * окружении, где прошлый прогон дал восемь ложных: все классы набора объявлены
 * без тела. После правки обе клетки TN обязаны замолчать, клетка TP - сработать.
 */

/** DK16-TP-1. Без тела, интеграции нет. Сработка обязательна. */
class PlainNoBodyApp : Application()

/** DK16-TN-1. Без тела, делегирование на литеральный конструктор в одну строку. */
class ShortDelegateApp : Application(), CerberSDKApplication by CerberSDKApplicationDelegate(secureInitialCheck = true)
