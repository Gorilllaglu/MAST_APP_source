package ru.corp.app

import ru.sberbank.cerbersdk.sdk_framework.CerberSDKApplication
import ru.sberbank.cerbersdk.sdk_framework.CerberSDKApplicationDelegate

/**
 * Контроль доработки правила cerber-missing-sdk-application-interface.
 * Правка добавила восемь исключений: формы без тела класса и делегирование
 * на произвольное выражение, а не только на литеральный вызов конструктора.
 * Клетки TP здесь обязаны СРАБОТАТЬ: они доказывают, что правка не погасила
 * правило целиком. Клетки TN обязаны ЗАМОЛЧАТЬ.
 */

private val ownDelegate = CerberSDKApplicationDelegate(
    secureInitialCheck = true,
    secureScreen = true,
    secureClipboard = true
)

object DelegateVault {
    val instance = CerberSDKApplicationDelegate(
        secureInitialCheck = true,
        secureScreen = true,
        secureClipboard = true
    )
}

interface AnalyticsHost {
    fun trackScreen(name: String)
}

/** DK12-TP-1. Без тела, интерфейс не церберовский. Интеграции нет, сработка обязательна. */
class AnalyticsOnlyApp : Application(), AnalyticsHost {
    override fun trackScreen(name: String) {
        Log.d("app", name)
    }
}

/** DK12-TP-2. Без тела и без интерфейсов вовсе. Сработка обязательна. */
class BareNoBodyApp : Application()

/** DK12-TP-3. С телом, интерфейс один и не церберовский. Сработка обязательна. */
class LoggingOnlyApp : Application(), AnalyticsHost {
    override fun trackScreen(name: String) {
        Log.d("app", name)
    }

    fun onCreateStub() {
        Log.d("app", "logging only")
    }
}

/** DK12-TN-1. Без тела, интерфейс реализован напрямую. Молчание. */
class DirectNoBodyApp : Application(), CerberSDKApplication {
    override fun initializeSdk() {}
}

/** DK12-TN-2. Без тела, делегирование на свойство файла. Самый трудный случай правки. */
class VarDelegateNoBodyApp : Application(), CerberSDKApplication by ownDelegate

/** DK12-TN-3. Без тела, делегирование на свойство объекта. */
class VaultDelegateNoBodyApp : Application(), CerberSDKApplication by DelegateVault.instance

/** DK12-TN-4. Без тела, делегирование на литеральный конструктор, запись в одну строку. */
class InlineDelegateNoBodyApp : Application(), CerberSDKApplication by CerberSDKApplicationDelegate(secureInitialCheck = true)

/** DK12-TN-5. С телом, делегирование на свойство файла. */
class VarDelegateBodyApp : Application(), CerberSDKApplication by ownDelegate {
    fun onCreateStub() {
        Log.d("app", "var delegate with body")
    }
}

/** DK12-TN-6. Два интерфейса, церберовский второй, с телом. */
class MixedBodyApp : Application(), AnalyticsHost, CerberSDKApplication by ownDelegate {
    override fun trackScreen(name: String) {
        Log.d("app", name)
    }
}

/** DK12-TN-7. Два интерфейса, церберовский второй, без тела. */
class MixedNoBodyApp : Application(), AnalyticsHost, CerberSDKApplication by DelegateVault.instance

/**
 * DK12-PROBE-1. Три интерфейса, церберовский третий. В положительных шаблонах
 * перечислены формы до двух интерфейсов, но на правиле L01 измерено, что
 * движок терпит лишние интерфейсы. Если здесь молчание - терпит и тут,
 * и исключения достаточно. Если сработка - в исключения нужна форма на три.
 */
class ThreeFaceApp : Application(), AnalyticsHost, Runnable, CerberSDKApplication by ownDelegate {
    override fun trackScreen(name: String) {
        Log.d("app", name)
    }

    override fun run() {
        Log.d("app", "run")
    }
}
