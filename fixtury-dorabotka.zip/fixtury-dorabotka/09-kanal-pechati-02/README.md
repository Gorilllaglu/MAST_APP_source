# 09. Канал печати, форма с получателем

Правило: `cerber-print-channel`, WARNING + INFO.

Контрольный набор к набору 08. Тот же системный сервис печати, но вызов записан с получателем:

```kotlin
Context.getSystemService(Context.PRINT_SERVICE) as PrintManager
```

В прогоне 5 ноября эта клетка сработала.

## Ожидания

| Клетка | Что в ней | Ожидание |
|---|---|---|
| `E09-TP-1` | `PrintHelper(Context).printBitmap(...)` | сработка |
| `E09-TP-2` | `webView.createPrintDocumentAdapter(...)` | сработка |
| `E09-TP-3` | `Context.getSystemService(Context.PRINT_SERVICE)` | сработка |
| `E09-TN-1` | `webView.loadUrl(...)` | молчание по печати |

Сравнение с набором 08 и есть смысл этой пары: `E09-TP-3` и `S05-TP-3` — один вызов в двух написаниях.
