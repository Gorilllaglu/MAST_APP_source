package ru.corp.app

import ru.sberbank.cerbersdk.SecureCheck
import ru.sberbank.cerbersdk.SecureCheck.DEVICE_COMPLIANT
import ru.sberbank.cerbersdk.SecureCheck.MDM_CONFIG_TAMPERED
import ru.sberbank.cerbersdk.SecureCheck.ROOT_DETECTED
import ru.sberbank.cerbersdk.SecureChecker

/**
 * Контроль доработки правила cerber-secure-check-wrong-state-comparison.
 * Правка добавила три небезопасных состояния из шести и неквалифицированные
 * формы обращения к значениям перечисления. Прошлый прогон: клетки
 * L08-PROBE-3 и L08-PROBE-4 молчали, это и было основанием.
 */

private fun deny(reason: String) {
    reason.length
}

class StoreGates(private val checker: SecureChecker) {

    /** DL08-TP-1. Третье добавленное состояние, равенство. */
    fun gateStoreMissing() {
        if (checker.performChecks() == SecureCheck.SBERAPPS_NOT_FOUND) {
            deny("store missing")
        }
    }

    /** DL08-TP-2. Четвёртое добавленное состояние, отрицание. */
    fun gateStoreDown() {
        if (checker.performChecks() != SecureCheck.SBERAPPS_STORE_UNAVAILABLE) {
            deny("allow")
        }
    }

    /** DL08-TP-3. Пятое добавленное состояние, равенство. */
    fun gateMdmTampered() {
        if (checker.performChecks() == SecureCheck.MDM_CONFIG_TAMPERED) {
            deny("mdm tampered")
        }
    }

    /** DL08-TP-4. Неквалифицированная форма: значение импортировано. */
    fun gateImportedRoot() {
        if (checker.performChecks() == ROOT_DETECTED) {
            deny("root")
        }
    }

    /** DL08-TP-5. Неквалифицированная форма, отрицание. */
    fun gateImportedTampered() {
        if (checker.performChecks() != MDM_CONFIG_TAMPERED) {
            deny("allow")
        }
    }

    /** DL08-TN-1. Правильная форма, квалифицированная. Молчание. */
    fun gateCompliantQualified() {
        if (checker.performChecks() == SecureCheck.DEVICE_COMPLIANT) {
            deny("allow")
        }
    }

    /**
     * DL08-TN-2. Правильная форма, неквалифицированная. Молчание.
     * Контроль того, что в список неквалифицированных форм не попало
     * DEVICE_COMPLIANT: иначе правило начнёт ругаться на корректный код.
     */
    fun gateCompliantImported() {
        if (checker.performChecks() == DEVICE_COMPLIANT) {
            deny("allow")
        }
    }

    /**
     * DL08-PROBE-1. Обратный порядок операндов. Ожидается пропуск:
     * в шаблонах вызов стоит слева. Форма для Kotlin неестественная,
     * клетка держит границу на виду.
     */
    fun gateYoda() {
        if (SecureCheck.ROOT_DETECTED == checker.performChecks()) {
            deny("root")
        }
    }
}
