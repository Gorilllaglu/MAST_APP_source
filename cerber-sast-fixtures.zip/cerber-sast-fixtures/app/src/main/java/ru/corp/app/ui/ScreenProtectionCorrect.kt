package ru.corp.app.ui

import android.app.Activity
import android.os.Bundle
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity

/**
 * Фикстура правила cerber-flag-secure-cleared, сторона TN.
 * Проверяет, что правило не срабатывает на выставлении защиты, на снятии
 * других флагов и на чтении состояния. Любая находка в этом файле, кроме
 * R2-PROBE-3, означает переcрабатывание.
 */
class StatementActivity : AppCompatActivity() {

    /**
     * R2-TN-1. Эталонное поведение: защита экрана выставляется, а не снимается.
     * Обе формы, addFlags и setFlags с маской, должны молчать.
     */
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        window.setFlags(
            WindowManager.LayoutParams.FLAG_SECURE,
            WindowManager.LayoutParams.FLAG_SECURE
        )
    }
}

/**
 * R2-TN-2. Снимается другой флаг окна, именованной константой.
 * FLAG_KEEP_SCREEN_ON к защите от снимков отношения не имеет.
 */
fun stopKeepingScreenOn(activity: Activity) {
    activity.window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
}

/**
 * R2-TN-3. Снимается другой флаг окна, числовым литералом.
 * 128 это FLAG_KEEP_SCREEN_ON, не 8192.
 */
fun stopKeepingScreenOnNumeric(activity: Activity) {
    activity.window.clearFlags(128)
}

/**
 * R2-TN-4. Состояние защиты читается, а не меняется.
 * FLAG_SECURE в коде присутствует, но ни clearFlags, ни снятия бита нет.
 */
fun isScreenProtected(activity: Activity): Boolean {
    val flags = activity.window.attributes.flags
    return flags and WindowManager.LayoutParams.FLAG_SECURE != 0
}

/**
 * R2-TN-5. Защита снимается и сразу возвращается в рамках одного экрана
 * (типовой приём для системного диалога печати). Находка здесь ожидается:
 * clearFlags присутствует, и правило обязано его увидеть. Маркер нужен,
 * чтобы в CI такой случай разбирался глазами, а не считался ложным.
 */
fun withProtectionTemporarilyOff(activity: Activity, block: () -> Unit) {
    activity.window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
    try {
        block()
    } finally {
        activity.window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
    }
}

/** Свой держатель битовых признаков приложения. К окну отношения не имеет. */
class FeatureFlagMask(private var mask: Int) {
    fun clearFlags(flags: Int) {
        mask = mask and flags.inv()
    }
}

/**
 * R2-PROBE-3. Метод-омоним clearFlags у своего класса, и то же самое число 8192.
 * Паттерн $WIN.clearFlags(8192) получателя не типизирует, поэтому находка здесь
 * ожидается и будет ложной. Если прогон это подтвердит, правилу нужен
 * либо focus-metavariable с типизацией, либо привязка к Window.
 */
fun dropAnalyticsFeature(mask: FeatureFlagMask) {
    mask.clearFlags(8192)
}
