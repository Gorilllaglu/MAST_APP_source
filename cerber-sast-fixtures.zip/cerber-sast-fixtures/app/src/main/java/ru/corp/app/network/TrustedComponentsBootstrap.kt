package ru.corp.app.network

import ru.corp.app.di.CerberSdkDelegate

/**
 * Фикстура правила cerber-trusted-components-usage-marker, сторона TP.
 * Файл лежит в host-app, вне любого из путей из paths.exclude,
 * поэтому находки здесь и есть доказательство наличия интеграции.
 */
object TrustedComponentsBootstrap {

    /** R4-TP-1. Ровно те формы, что описаны в правиле: плоский доступ. */
    fun primeTrustedComponents(delegate: CerberSdkDelegate) {
        val cached = delegate.trustedComponents.getFromCache()
        if (cached.isEmpty()) {
            delegate.trustedComponents.download()
        }
    }

    /** R4-TP-2. Формы с ?. и !! на втором хопе, как перечислено в правиле. */
    fun refreshTrustedComponents(delegate: CerberSdkDelegate) {
        delegate.trustedComponents?.getFromCache()
        delegate.trustedComponents!!.download()
    }

    /**
     * R4-PROBE-1. Безопасный вызов на ПЕРВОМ хопе. Такой формы в правиле нет:
     * все шесть паттернов ожидают точку перед trustedComponents.
     * Если прогон здесь ничего не найдёт, интеграция через nullable-делегат
     * будет считаться отсутствующей, и CI упадёт на рабочем коде.
     */
    fun refreshViaNullableDelegate(delegate: CerberSdkDelegate?) {
        delegate?.trustedComponents?.getFromCache()
        delegate?.trustedComponents?.download()
    }

    /**
     * R4-PROBE-2. Делегат получен через промежуточную переменную и
     * свойство-алиас. Проверяет, не привязано ли правило к имени делегата.
     */
    fun refreshViaAlias(delegate: CerberSdkDelegate) {
        val tc = delegate.trustedComponents
        tc.getFromCache()
        tc.download()
    }
}
