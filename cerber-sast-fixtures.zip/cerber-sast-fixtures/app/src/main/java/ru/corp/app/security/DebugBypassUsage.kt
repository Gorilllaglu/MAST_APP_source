package ru.corp.app.security

import ru.sberbank.cerbersdk.sdk_framework.DebugBypassChecker
import ru.sberbank.cerbersdk.sdk_framework.SecureCheck
import ru.sberbank.cerbersdk.sdk_framework.SecureChecker
import ru.corp.app.di.CerberSdkDelegate

/**
 * Фикстура правила cerber-debug-bypass-checker-present.
 * Сценарий: приложение оставило в релизной ветке отладочное послабление проверок.
 */
object LaunchGate {

    /**
     * R1-TP-1. Прямой статический вызов.
     * Покрывает сразу три альтернативы правила: точный паттерн,
     * $X.shouldBypassRootEmulatorCheck() и DebugBypassChecker.$METHOD(...).
     */
    fun isDeviceTrustedForLaunch(): Boolean {
        if (DebugBypassChecker.shouldBypassRootEmulatorCheck()) {
            return true
        }
        return SecureChecker.performChecks() == SecureCheck.DEVICE_COMPLIANT
    }

    /**
     * R1-TP-2. Вызов через произвольный получатель плюс второй метод чекера.
     * Проверяет, что $X.shouldBypassRootEmulatorCheck() ловит экземплярную форму,
     * а DebugBypassChecker.$METHOD(...) ловит shouldBypassSecureScreen().
     */
    fun applyDebugRelaxations(delegate: CerberSdkDelegate): Boolean {
        val bypass = delegate.debugBypassChecker
        val skipRootCheck = bypass.shouldBypassRootEmulatorCheck()
        val skipScreenGuard = DebugBypassChecker.shouldBypassSecureScreen()
        return skipRootCheck || skipScreenGuard
    }

    /**
     * R1-PROBE-1. Формы, которых в правиле нет. Ожидаемо не сработает,
     * хотя семантически это то же самое отладочное послабление.
     * Нужны, чтобы решить, добирать ли правило.
     */
    fun reflectiveRelaxation(): Boolean {
        val cls = Class.forName("ru.sberbank.cerbersdk.sdk_framework.DebugBypassChecker")
        val m = cls.getMethod("shouldBypassRootEmulatorCheck")
        return m.invoke(null) as Boolean
    }
}
