package ru.corp.app.security

import ru.sberbank.cerbersdk.sdk_framework.DebugBypassChecker
import ru.sberbank.cerbersdk.sdk_framework.SecureCheck
import ru.sberbank.cerbersdk.sdk_framework.SecureChecker
import ru.corp.app.analytics.Analytics

/**
 * Фикстура правила cerber-debug-bypass-checker-present, сторона TN.
 * Проверяет, что правило не срабатывает на правильной интеграции и на коде
 * приложения, похожем по именам. Любая находка в этом файле, кроме R1-TN-5,
 * означает переcрабатывание.
 */
object CorrectLaunchGate {

    /**
     * R1-TN-1. Эталонная интеграция: проверки выполняются, результат сверяется,
     * отладочного послабления нет вообще. Молчание обязательно.
     */
    fun isDeviceTrustedForLaunch(): Boolean {
        val posture = SecureChecker.performChecks()
        return posture == SecureCheck.DEVICE_COMPLIANT
    }

    /**
     * R1-TN-2. Свои фича-флаги приложения с похожими именами.
     * shouldBypassRootCheck отличается от shouldBypassRootEmulatorCheck
     * двумя словами, и правило не должно его ловить: иначе любой фича-флаг
     * приложения со словом Bypass начнёт давать находки.
     */
    fun warmCaches(): Boolean {
        if (AppFeatureGate.shouldBypassCache()) {
            return true
        }
        return AppFeatureGate.shouldBypassRootCheck()
    }

    /**
     * R1-TN-3. Имя класса и метода SDK встречается в строковых литералах:
     * событие аналитики и правило для обфускатора. Это не код, молчание обязательно.
     */
    fun reportIntegrationPosture(analytics: Analytics) {
        analytics.track("cerber_debug_bypass_checker_absent")
        analytics.track("DebugBypassChecker.shouldBypassRootEmulatorCheck")
        val keepRule = "-keep class ru.sberbank.cerbersdk.sdk_framework.DebugBypassChecker { *; }"
        analytics.track(keepRule)
    }

    /**
     * R1-TN-4. Метод с тем же именем у своего класса приложения.
     * Здесь правило сработает по альтернативе $X.shouldBypassRootEmulatorCheck(),
     * хотя к SDK вызов отношения не имеет. Ожидание сознательно помечено как
     * допустимое переcрабатывание: имя слишком специфично, чтобы встретиться
     * случайно, но если такой класс в приложении появится, правило даст шум.
     */
    fun localHomonym(gate: LocalSecurityGate): Boolean {
        return gate.shouldBypassRootEmulatorCheck()
    }

    /**
     * R1-TN-5. Обёртка приложения прячет вызов SDK за свойством.
     * Находка ожидается здесь, на геттере, где вызов фактически есть.
     * Потребитель свойства ниже находки давать не должен — правило работает
     * по месту вызова, и для этой задачи этого достаточно.
     */
    object BypassFacade {
        val rootCheckDisabled: Boolean
            get() = DebugBypassChecker.shouldBypassRootEmulatorCheck()
    }

    /** R1-TN-6. Потребитель обёртки: вызова SDK нет, молчание обязательно. */
    fun useFacade(): Boolean {
        return BypassFacade.rootCheckDisabled
    }
}

/** Свои фича-флаги приложения. К CerberSDK отношения не имеют. */
object AppFeatureGate {
    fun shouldBypassCache(): Boolean = false
    fun shouldBypassRootCheck(): Boolean = false
}

/** Свой гейт приложения с методом-омонимом. Нужен для R1-TN-4. */
class LocalSecurityGate {
    fun shouldBypassRootEmulatorCheck(): Boolean = false
}
