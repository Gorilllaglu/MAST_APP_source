package ru.corp.app.security

import ru.sberbank.cerbersdk.sdk_framework.DebugBypassChecker

/**
 * Фикстура правила cerber-debug-bypass-checker-present, отдельный пробник.
 *
 * R1-PROBE-3. Импорт отладочного чекера присутствует, вызовов нет.
 * Правило ловит вызовы, поэтому находок тут не ожидается.
 *
 * Это не TN и не TP, а решение, которое надо принять: сообщение правила
 * говорит «DebugBypassChecker found in code», и неиспользуемый импорт
 * формально под эту формулировку подпадает, потому что показывает, что
 * приложение знает о классе. Если такие случаи надо ловить, нужен отдельный
 * паттерн на импорт либо грубая текстовая проверка в CI. Если не надо,
 * формулировку сообщения стоит сузить до вызова.
 */
object DebugBypassImportOnly {

    fun describeDependency(): String {
        return "integration references " + DebugBypassChecker::class.java.simpleName
    }
}
