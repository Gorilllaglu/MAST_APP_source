package ru.corp.app.security

import ru.sberbank.cerbersdk.sdk_framework.SecureCheck
import ru.sberbank.cerbersdk.sdk_framework.SecureChecker
import android.util.Log

/**
 * Фикстура правила cerber-secure-check-result-ignored.
 * TP — результат performChecks() не участвует в принятии решения.
 * TN — результат сохранён, сверен или возвращён; правило срабатывать не должно.
 *
 * Внимание: TN-функции здесь не «на всякий случай». Правило построено на
 * pattern-not к объемлющим конструкциям, а pattern в нём матчит само выражение
 * вызова. Если semgrep сопоставляет pattern-not по диапазону совпадения,
 * диапазоны не совпадут и исключения не применятся — тогда все пять TN ниже
 * дадут ложные срабатывания. Этот файл нужен, чтобы увидеть это прогоном.
 */
object DeviceComplianceGate {

    /** R3-TP-1. Вызов как самостоятельный оператор, результат отброшен. */
    fun warmUpSecurityChecks(checker: SecureChecker) {
        checker.performChecks()
    }

    /** R3-TP-2. Результат уходит только в журнал, решение не принимается. */
    fun logSecurityPosture(checker: SecureChecker) {
        Log.d("compliance", "posture=" + checker.performChecks())
    }

    /** R3-TN-1. Результат сохранён в val и сверен с DEVICE_COMPLIANT. */
    fun enforceCompliance(checker: SecureChecker): Boolean {
        val result = checker.performChecks()
        if (result != SecureCheck.DEVICE_COMPLIANT) {
            return false
        }
        return true
    }

    /** R3-TN-2. Результат сохранён в val с явным типом. */
    fun enforceComplianceTyped(checker: SecureChecker): Boolean {
        val result: SecureCheck = checker.performChecks()
        return result == SecureCheck.DEVICE_COMPLIANT
    }

    /** R3-TN-3. Результат сохранён в var. */
    fun enforceComplianceVar(checker: SecureChecker): Boolean {
        var result = checker.performChecks()
        return result == SecureCheck.DEVICE_COMPLIANT
    }

    /** R3-TN-4. Присваивание в ранее объявленную переменную. */
    fun enforceComplianceReassign(checker: SecureChecker): Boolean {
        var result: SecureCheck = SecureCheck.DEVICE_COMPLIANT
        result = checker.performChecks()
        return result == SecureCheck.DEVICE_COMPLIANT
    }

    /** R3-TN-5. Результат возвращён вызывающему. */
    fun currentPosture(checker: SecureChecker): SecureCheck {
        return checker.performChecks()
    }

    /** R3-TN-6. Сверка прямо в условии, равенство. */
    fun isCompliantEq(checker: SecureChecker): Boolean {
        if (checker.performChecks() == SecureCheck.DEVICE_COMPLIANT) {
            return true
        }
        return false
    }

    /** R3-TN-7. Сверка прямо в условии, неравенство. */
    fun isCompliantNeq(checker: SecureChecker): Boolean {
        if (checker.performChecks() != SecureCheck.DEVICE_COMPLIANT) {
            return false
        }
        return true
    }

    /**
     * R3-PROBE-1. Семантически дефект: результат сохранён, но ни с чем не сверен
     * и ни на что не влияет. Правило это пропустит, потому что форма присваивания
     * входит в список исключений. Нужен для оценки полноты правила.
     */
    fun storeAndForget(checker: SecureChecker) {
        val result = checker.performChecks()
        Log.d("compliance", result.toString())
    }

    /**
     * R3-PROBE-2. Результат сверен не с DEVICE_COMPLIANT, а с одним конкретным
     * состоянием: остальные небезопасные состояния проходят как разрешённые.
     * Форма попадает под pattern-not, то есть правило промолчит.
     */
    fun isCompliantPartial(checker: SecureChecker): Boolean {
        if (checker.performChecks() != SecureCheck.ROOT_DETECTED) {
            return true
        }
        return false
    }
}
