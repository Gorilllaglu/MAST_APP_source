package ru.corp.app.ui

import android.app.Activity
import android.os.Bundle
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity

/**
 * Фикстура правила cerber-flag-secure-cleared.
 * Сценарий: экран снимает защиту от снимков, выставленную политикой SDK.
 */
class ReceiptPreviewActivity : AppCompatActivity() {

    /**
     * R2-TP-1. Именованная константа платформы.
     * Соответствует паттерну $WIN.clearFlags(WindowManager.LayoutParams.FLAG_SECURE).
     */
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
    }
}

/**
 * R2-TP-2. Числовой литерал того же флага, получатель составной.
 * Соответствует паттерну $WIN.clearFlags(8192), где $WIN = activity.window.
 */
fun allowScreenshotsForOnboarding(activity: Activity) {
    activity.window.clearFlags(8192)
}

/**
 * R2-PROBE-1. Шестнадцатеричная запись того же значения.
 * Сработает только если константная подстановка semgrep приводит 0x2000 к 8192.
 */
fun allowScreenshotsHex(activity: Activity) {
    activity.window.clearFlags(0x2000)
}

/**
 * R2-PROBE-2. Снятие флага без clearFlags. Правило эти формы не описывает,
 * а эффект тот же: защита экрана выключена.
 */
fun dropSecureFlagWithoutClearFlags(activity: Activity) {
    activity.window.setFlags(0, WindowManager.LayoutParams.FLAG_SECURE)
    val attrs = activity.window.attributes
    attrs.flags = attrs.flags and WindowManager.LayoutParams.FLAG_SECURE.inv()
    activity.window.attributes = attrs
}
