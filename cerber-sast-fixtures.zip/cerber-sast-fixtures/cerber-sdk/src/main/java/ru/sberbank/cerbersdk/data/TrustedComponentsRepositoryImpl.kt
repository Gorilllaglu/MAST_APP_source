package ru.sberbank.cerbersdk.data

import ru.corp.app.di.CerberSdkDelegate

/**
 * Фикстура правила cerber-trusted-components-usage-marker, сторона TN.
 * Те же самые вызовы, но внутри библиотеки: путь содержит cerber-sdk,
 * то есть должен отсекаться paths.exclude. Находок здесь быть не должно,
 * иначе маркер начнёт считать внутренние вызовы SDK за интеграцию host-app
 * и CI пройдёт на приложении, где интеграции нет.
 */
internal class TrustedComponentsRepositoryImpl(
    private val delegate: CerberSdkDelegate
) {

    /** R4-TN-1. Внутренний вызов библиотеки, плоский доступ. */
    fun warmCache() {
        delegate.trustedComponents.getFromCache()
    }

    /** R4-TN-2. Внутренний вызов библиотеки, загрузка. */
    fun syncFromServer() {
        delegate.trustedComponents.download()
    }
}
