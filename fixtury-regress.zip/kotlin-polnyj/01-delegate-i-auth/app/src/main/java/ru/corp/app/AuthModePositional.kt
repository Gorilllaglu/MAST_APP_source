package ru.corp.app

import ru.sberbank.cerbersdk.sdk_framework.AuthorizationMode
import ru.sberbank.cerbersdk.sdk_framework.BuildType
import ru.sberbank.cerbersdk.sdk_framework.CerberSDKApplicationDelegate
import ru.sberbank.cerbersdk.sdk_framework.WhiteListOptions

/**
 * K06 insecure-auth-mode. Паттерн правила ждёт перечисление ПОЗИЦИОННЫМ
 * аргументом: $METHOD(..., AuthorizationMode.$MODE, ...). В первом прогоне
 * фикстуры были написаны с именованными аргументами и правило молчало —
 * причина была в фикстурах.
 */
object AuthModePositional {

    /** K06-TP-3. Позиционный аргумент, режим NONE. */
    fun insecureNone(): CerberSDKApplicationDelegate =
        CerberSDKApplicationDelegate(AuthorizationMode.NONE, BuildType.PROM, false, true, true, true, false, null, WhiteListOptions(), false)

    /** K06-TP-4. Позиционный аргумент, режим EXTERNAL. */
    fun insecureExternal(): CerberSDKApplicationDelegate =
        CerberSDKApplicationDelegate(AuthorizationMode.EXTERNAL, BuildType.PROM, false, true, true, true, false, null, WhiteListOptions(), false)

    /** K06-TP-5. Передача режима в произвольный метод, не в конструктор делегата. */
    fun configure(mode: AuthorizationMode) {}

    fun applyLegacy() {
        configure(AuthorizationMode.LEGACY)
    }

    /**
     * K06-TN-2. Позиционные аргументы в реальном порядке конструктора SDK,
     * значения безопасные. Молчание обязательно по всем правилам флагов.
     */
    fun secure(): CerberSDKApplicationDelegate =
        CerberSDKApplicationDelegate(AuthorizationMode.CERBER, BuildType.PROM, false, true, true, true, false, null, WhiteListOptions(), false)

    /** K06-TN-3. CERBER в произвольный метод. Молчание обязательно. */
    fun applyCerber() {
        configure(AuthorizationMode.CERBER)
    }
}
