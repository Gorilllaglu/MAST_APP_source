package ru.sberbank.cerbersdk.sdk_framework

/** Заглушки под фикстуры: только объявления, вызовов нет, находок быть не должно. */

enum class AuthorizationMode { CERBER, NONE, EXTERNAL, LEGACY }

enum class BuildType { PROM, DEV1, DEV2, IFT, PSI }

enum class WriteResult { SUCCESS, TRUNCATED, FAILURE }

sealed class AuthState {
    object Authorized : AuthState()
    object Pin : AuthState()
    object LoggedOut : AuthState()
}

interface CerberSDKApplication {
    fun initializeSdk()
}

class SberMagOptions

class WhiteListOptions(val packages: List<String> = emptyList())

/**
 * Порядок параметров сверен с метаданными SDK: именно в этом порядке их
 * передают позиционно, и шаблоны правил привязаны к номеру аргумента.
 */
class CerberSDKApplicationDelegate(
    val authorizationMode: AuthorizationMode = AuthorizationMode.CERBER,
    val buildType: BuildType = BuildType.PROM,
    val isolated: Boolean = false,
    val secureInitialCheck: Boolean = true,
    val secureScreen: Boolean = true,
    val secureClipboard: Boolean = true,
    val enableTestServerPinning: Boolean = false,
    val sberMagOptions: SberMagOptions? = null,
    val whiteListOptions: WhiteListOptions = WhiteListOptions(),
    val disablePasswordlessAuth: Boolean = false,
    val observeAuthStateWithoutActivity: Boolean = false
) : CerberSDKApplication {
    override fun initializeSdk() {}
}

object CerberCopyPasteBuffer {
    fun write(data: String): WriteResult = WriteResult.SUCCESS
    fun read(): String = ""
}

/** Заглушка платформенного Uri: правило K05 требует именно этот тип параметра. */
class Uri

interface CerberFileReceiver {
    fun onFileReceived(uri: Uri, callingPackage: String)
}
