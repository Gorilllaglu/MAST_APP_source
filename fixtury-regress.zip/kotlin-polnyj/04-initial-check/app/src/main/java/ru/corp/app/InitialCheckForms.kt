package ru.corp.app

import ru.sberbank.cerbersdk.sdk_framework.AuthorizationMode
import ru.sberbank.cerbersdk.sdk_framework.CerberSDKApplication
import ru.sberbank.cerbersdk.sdk_framework.CerberSDKApplicationDelegate

/**
 * K16 cerber-secure-initial-check-disabled, переработанное правило.
 * K17 cerber-secure-initial-check-dynamic, дополнительное правило на предложение.
 *
 * Ветка правила с метапеременной в этой позиции не измерялась ни разу: во всех
 * прежних фикстурах, котлиновских и джава, значение было литералом true или false.
 * Клетки K16-TP-2 и K16-TP-3 закрывают этот пробел.
 */

/**
 * Клетки K17 описывают динамическую форму флага secureChecks. Отдельного
 * правила на сам флаг в наборе нет: предложение было отклонено, поэтому
 * клетки помечены PROBE и молчание по ним — норма.
 */

/** K17-PROBE-1. Канонический динамический флаг: условие читает реальный флейвор. */
val secureChecks = when {
    BuildConfig.FLAVOR.contains(FlavorStand.PROM.stand, true) -> true
    else -> false
}

/**
 * K17-PROBE-2. Дефектная форма того же флага, снятая с разбора SberApps:
 * сверка идёт с зашитой строкой, а не с BuildConfig.FLAVOR. Переименование
 * флейвора молча выключает RASP, и ни один тест этого не покажет.
 */
object BuildFlags {
    val secureChecks = "promDef".contains("prom")
}

/** K16-TP-1. Литерал false. Первая ветка правила, форма измерена ранее. */
class InitialCheckOffApp : Application(), CerberSDKApplication by CerberSDKApplicationDelegate(
    secureInitialCheck = false,
    secureScreen = true,
    secureClipboard = true
)

/** K16-TP-2. Чужое имя флага. Вторая ветка правила, форма измеряется впервые. */
class ForeignFlagApp : Application(), CerberSDKApplication by CerberSDKApplicationDelegate(
    secureInitialCheck = raspEnabled,
    secureScreen = true,
    secureClipboard = true
)

/** K16-TP-3. Значение вычислено выражением на месте. Проверяет, берёт ли метапеременная выражение. */
class ExpressionFlagApp : Application(), CerberSDKApplication by CerberSDKApplicationDelegate(
    secureInitialCheck = !BuildConfig.DEBUG,
    secureScreen = true,
    secureClipboard = true
)

/**
 * K16-TP-4. Тот же канонический флаг, но взятый с квалификатором.
 * Правило сработает: исключения перечисляют буквальные имена, а не суффиксы.
 * Клетка нужна как точка решения — молчать здесь или нет.
 */
class QualifiedFlagApp : Application(), CerberSDKApplication by CerberSDKApplicationDelegate(
    secureInitialCheck = BuildFlags.secureChecks,
    secureScreen = true,
    secureClipboard = true
)

/** K16-TN-1. Литерал true: защита включена всегда. Молчание. */
class InitialCheckOnApp : Application(), CerberSDKApplication by CerberSDKApplicationDelegate(
    secureInitialCheck = true,
    secureScreen = true,
    secureClipboard = true
)

/**
 * K16-TN-2. Реальная продуктовая форма из приложения: два первых аргумента
 * позиционные, остальные именованные, флаг динамический. Главная клетка правки:
 * до неё правило срабатывало именно здесь, на корректном коде.
 */
@HiltAndroidApp
class MainApp : Application(), CerberSDKApplication by CerberSDKApplicationDelegate(
    AuthorizationMode.CERBER,
    cerberBuildType,
    secureClipboard = true,
    secureInitialCheck = secureChecks,
    secureScreen = true,
    enableTestServerPinning = true
)

/** K16-TN-3. Тот же флаг функцией. Молчание. */
class FunctionFlagApp : Application(), CerberSDKApplication by CerberSDKApplicationDelegate(
    secureInitialCheck = secureChecks(),
    secureScreen = true,
    secureClipboard = true
)

/**
 * K16-PROBE-1. Параметр не передан вовсе. По умолчанию в SDK он false,
 * то есть защита выключена, но правило сейчас молчит: оно требует, чтобы
 * secureInitialCheck был в списке аргументов. Клетка измеряет этот пробел.
 */
class OmittedFlagApp : Application(), CerberSDKApplication by CerberSDKApplicationDelegate(
    authorizationMode = AuthorizationMode.CERBER,
    secureScreen = true,
    secureClipboard = true
)
