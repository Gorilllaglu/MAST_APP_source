package ru.corp.app

import android.widget.EditText
import android.widget.TextView
import ru.sberbank.cerbersdk.AllowedTextActionsCallBack
import ru.sberbank.cerbersdk.disableSharing

/** S07 text-selection-without-sdk-actions, S10 selection-callback-not-sdk. */

/** Своя реализация колбэка: выглядит защитой, ею не является. */
class MyActionModeCallback

class SelectionScreens {

    /** S07-TP-1. Выделение включено сеттером, колбэк не поставлен. */
    fun setupPlainSetter(view: TextView) {
        view.setTextIsSelectable(true)
    }

    /** S07-TP-2. Выделение включено свойством, колбэк не поставлен. */
    fun setupPlainProperty(view: TextView) {
        view.isTextSelectable = true
    }

    /** S07-TN-1. Выделение и штатный колбэк через свойство, одна функция. */
    fun setupWithCallbackProperty(view: TextView) {
        view.setTextIsSelectable(true)
        view.customSelectionActionModeCallback = AllowedTextActionsCallBack
    }

    /** S07-TN-2. Выделение и штатный колбэк через сеттер, одна функция. */
    fun setupWithCallbackSetter(view: TextView) {
        view.isTextSelectable = true
        view.setCustomSelectionActionModeCallback(AllowedTextActionsCallBack)
    }

    /**
     * S07-PROBE-1. Выделение в одной функции, штатный колбэк в другой функции
     * того же класса. Ожидается СРАБАТЫВАНИЕ: это ровно то ложное, которое даст
     * вынос установки в базовый класс или в обвязку команды. Клетка измеряет
     * размер проблемы, а не корректность правила.
     */
    fun enableSelectionHere(view: TextView) {
        view.setTextIsSelectable(true)
    }

    fun installCallbackElsewhere(view: TextView) {
        view.customSelectionActionModeCallback = AllowedTextActionsCallBack
    }

    /** S10-TP-1. Свой колбэк через свойство. */
    fun installOwnProperty(view: TextView) {
        view.customSelectionActionModeCallback = MyActionModeCallback()
    }

    /** S10-TP-2. Свой колбэк через сеттер. */
    fun installOwnSetter(view: TextView) {
        view.setCustomSelectionActionModeCallback(MyActionModeCallback())
    }

    /**
     * S10-TN-3. Штатный защитный хелпер disableSharing() из утилит SDK.
     * Молчание обязательно: он ставит блокирующий колбэк, то есть является
     * предписанной защитой, а не её обходом. Из положительных шаблонов
     * правила убран.
     */
    fun installDeprecated(field: EditText) {
        field.disableSharing()
    }

    /** S10-TP-4. Свой колбэк на меню курсора. */
    fun installOwnInsertion(view: TextView) {
        view.customInsertionActionModeCallback = MyActionModeCallback()
    }

    /** S10-TN-1. Штатный колбэк через свойство. */
    fun installSdkProperty(view: TextView) {
        view.customSelectionActionModeCallback = AllowedTextActionsCallBack
    }

    /** S10-TN-2. Штатный колбэк через сеттер. */
    fun installSdkSetter(view: TextView) {
        view.setCustomSelectionActionModeCallback(AllowedTextActionsCallBack)
    }
}
