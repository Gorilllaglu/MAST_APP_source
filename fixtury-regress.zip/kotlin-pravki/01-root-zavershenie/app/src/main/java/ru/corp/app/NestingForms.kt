package ru.corp.app

import ru.sberbank.cerbersdk.CerberCallbacks
import kotlin.system.exitProcess

/**
 * Контроль доработки правила cerber-root-detected-no-termination.
 * Правка добавила к исключениям один уровень вложенности: завершение внутри
 * ветки if и внутри ветки else. Прошлый прогон: клетка L07-PROBE-2 давала
 * ложную на корректном коде, это и было основанием.
 */

private fun report(message: String) {
    message.length
}

/** DL07-TN-1. Завершение внутри if. До правки - ложная, после - молчание. */
class NestedIfExit : CerberCallbacks {
    override fun onRootDetected() {
        report("root detected")
        if (System.currentTimeMillis() > 0) {
            exitProcess(1)
        }
    }
}

/** DL07-TN-2. Завершение внутри if, форма с finish. */
class NestedIfFinish : CerberCallbacks {
    fun finish() {}

    override fun onRootDetected() {
        report("root detected")
        if (System.currentTimeMillis() > 0) {
            finish()
        }
    }
}

/** DL07-TN-3. Завершение в ветке else. */
class NestedElseExit : CerberCallbacks {
    override fun onRootDetected() {
        if (System.currentTimeMillis() < 0) {
            report("clock skew")
        } else {
            exitProcess(1)
        }
    }
}

/** DL07-TN-4. Завершение единственным оператором внутри if, без соседей. */
class NestedIfOnlyStatement : CerberCallbacks {
    override fun onRootDetected() {
        if (System.currentTimeMillis() > 0) exitProcess(1)
    }
}

/**
 * DL07-TP-1. Завершение на два уровня вложенности. Ожидается СРАБОТКА:
 * правка добавила один уровень, не произвольную глубину. Клетка измеряет,
 * где именно проходит новая граница.
 */
class DoubleNestedExit : CerberCallbacks {
    override fun onRootDetected() {
        if (System.currentTimeMillis() > 0) {
            if (System.nanoTime() > 0) {
                exitProcess(1)
            }
        }
    }
}

/**
 * DL07-TP-2. Завершение в ветке when. Ожидается СРАБОТКА: в исключениях
 * перечислены if и else, when не перечислен. Если молчание - многоточие
 * доходит во when само, и формы на when не нужны.
 */
class WhenBranchExit : CerberCallbacks {
    override fun onRootDetected() {
        when (System.currentTimeMillis() > 0) {
            true -> exitProcess(1)
            false -> report("skip")
        }
    }
}

/** DL07-TP-3. Только запись в журнал. Контроль: сработка обязательна. */
class LogOnlyResponse : CerberCallbacks {
    override fun onRootDetected() {
        report("root detected, continuing anyway")
    }
}
