package ru.sberbank.cerbersdk

enum class SecureCheck {
    ROOT_DETECTED,
    EMULATOR_DETECTED,
    DEVICE_LOCKED,
    SBERAPPS_NOT_FOUND,
    SBERAPPS_STORE_UNAVAILABLE,
    MDM_CONFIG_TAMPERED,
    DEVICE_COMPLIANT
}

class SecureChecker {
    fun performChecks(): SecureCheck = SecureCheck.DEVICE_COMPLIANT
}

interface CerberCallbacks {
    fun onLogout() { trace("logout") }
    fun onUserChanged() { trace("user changed") }
    fun onNoAuthDetected() { trace("no auth") }
    fun onRootDetected() { trace("root") }
    fun onFileReceived(uri: android.net.Uri, pkg: String) { trace("file from " + pkg) }

    fun trace(message: String) {}
}
