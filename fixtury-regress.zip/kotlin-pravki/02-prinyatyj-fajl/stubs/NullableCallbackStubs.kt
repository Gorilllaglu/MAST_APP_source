package ru.sberbank.cerbersdk

import android.net.Uri

/**
 * В SDK CerberCallbacks объявлен в Java без аннотаций обнуляемости:
 *
 *     void onFileReceived(Uri uri, String str);
 *
 * Для Kotlin это платформенные типы, поэтому переопределение законно писать
 * и как Uri, и как Uri?, и как String, и как String?. Компилятора у фикстур
 * нет, но заглушки ниже делают все четыре написания легальным Kotlin, чтобы
 * клетки читались как настоящий код приложения. В реальном приложении все
 * четыре написания переопределяют один и тот же Java-интерфейс.
 */

interface CerberCallbacksNullableUri {
    fun onFileReceived(uri: Uri?, pkg: String) { trace("file from " + pkg) }
    fun trace(message: String) {}
}

interface CerberCallbacksNullablePkg {
    fun onFileReceived(uri: Uri, pkg: String?) { trace("file received") }
    fun trace(message: String) {}
}

interface CerberCallbacksNullableBoth {
    fun onFileReceived(uri: Uri?, pkg: String?) { trace("file received") }
    fun trace(message: String) {}
}
