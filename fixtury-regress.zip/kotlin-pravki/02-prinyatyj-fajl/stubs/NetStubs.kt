package android.net

class Uri {
    val path: String = ""
    companion object { fun parse(value: String): Uri = Uri() }
}
