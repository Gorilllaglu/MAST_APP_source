# Что здесь лежит

Семь файлов. Остальные шестнадцать правил из `java/unverified/` не менялись — берите их из того набора, что у вас уже есть.

Все семь файлов прогнаны парсером YAML, ошибок нет.

## izmeneno/ — пять изменённых правил

| Файл | Что изменено |
|---|---|
| `cerber-java-default-constructor-used.yaml` | добавлено `pattern-not: new CerberSDKApplicationDelegate($ARG, ...)` |
| `cerber-java-file-received-no-caller-check.yaml` | добавлены четыре исключения на ранний выход через отрицание |
| `cerber-java-clipboard-write-result-ignored.yaml` | добавлены двенадцать исключений на сверку результата в `return` |
| `cerber-java-insecure-auth-mode-variable.yaml` | переписана ветвь 1, свёрнуты исключения ветви 2 |
| `cerber-java-insecure-clipboard-disabled.yaml` | исправлена позиция аргумента: `false` шестым, а не третьим |

## pochineno/ — один файл, из-за которого прогон не стартовал

`cerber-java-file-received-callback-empty.yaml` — правило не менялось ни на букву, в файле был посторонний текст после правила:

```
Этап 3. Дополнительные правила по методике – нужно решение от CerberSDK
```

Это остаток исходного `rulesTZ.txt`, не вычищенный при разборе на отдельные YAML. Файл не парсился, а одно невалидное правило обрывает весь `--config`. Текст удалён, правило осталось прежним.

## novoe/ — одно новое правило

`cerber-java-direct-okhttp-client.yaml` — Java-версия правила okhttp, этап 3. Класть в отдельную папку или в общую, как вам удобнее: оно самостоятельное.
