# Джава-блок: 48 правил

Блок закрыт полностью. Каждому правилу котлиновского блока есть джавовский аналог, кроме одного: `cerber-compose-text-selection` — из Java в Compose не пишут.

**Критичность приравнена к котлиновской у всех 48.** Сверено построчно: рассинхронов ноль. Было десять.

| | было | стало |
|---|---|---|
| правил в блоке | 27 | 48 |
| рассинхронов критичности | 10 | 0 |
| правил с `severity: INFO` (значение из набора убрано) | 1 | 0 |

## Партии

Одно негодное правило в `--config` рушит весь прогон, а какое именно — движок не говорит. Партии сложены по риску: грузите в порядке номеров, между партиями прогоняйте.

### batch-1 — 18 правил, шаблоны не менялись

Восьми выправлена полка критичности, десять перенесены как были.

| Правило | Полка была | Полка стала |
|---|---|---|
| `cerber-java-missing-delegate-creation` | WARNING+MEDIUM | WARNING+INFO |
| `cerber-java-insecure-screen-disabled` | WARNING+HIGH | **ERROR**+HIGH |
| `cerber-java-non-production-build-type` | WARNING+HIGH | WARNING+**INFO** |
| `cerber-java-non-production-build-type-variable` | WARNING+MEDIUM | WARNING+**INFO** |
| `cerber-java-activity-missing-auth-onresume` | ERROR+HIGH | ERROR+**MEDIUM** |
| `cerber-java-activity-no-lifecycle-override` | WARNING+MEDIUM | WARNING+**INFO** |
| `cerber-java-auth-requested-but-not-observed` | WARNING+MEDIUM | WARNING+**INFO** |
| `cerber-trusted-components-usage-marker-java` | **INFO**+MEDIUM | **WARNING+INFO** |

### batch-2 — 9 правил, доработка шаблонов

- `cerber-secure-check-wrong-state-comparison-java` — было три небезопасных состояния из шести, стало шесть, в трёх формах записи: `==`, `!=` и `.equals`. Было 9 шаблонов, стало 36.
- `cerber-java-root-detected-no-termination` — добавлена вложенность: завершение в ветви `if`, в ветви `else` и под условием без фигурных скобок. Полка выправлена с ERROR+MEDIUM на WARNING+LOW. Было 6 фильтров, стало 24.
- `cerber-java-logout-callback-empty`, `cerber-java-no-auth-detected-ignored`, `cerber-java-user-changed-callback-empty`, `cerber-java-file-received-callback-empty` — добавлена форма тела из одного `return;`. У `onUserChanged` она была, у остальных трёх нет — то же расхождение, что было в котлиновском блоке.
- `cerber-java-file-received-no-caller-check` — роль правила сменилась на маркер наличия приёмника файлов, как в котлиновском блоке. Одиннадцать исключений убраны, добавлена метка `rule_type: marker`, полка выправлена с ERROR+MEDIUM на WARNING+INFO.
- `cerber-java-clipboard-write-result-ignored` — якорь сужен с `$BUF.write(...)` плюс `metavariable-regex` по имени до `CerberCopyPasteBuffer.write(...)`. Прежний ловил любой `write`: потоки, сокеты, логгеры. Правило сократилось с 60 узлов до 12.
- `cerber-java-insecure-clipboard-disabled` — сообщение выровнено по котлиновскому: добавлена оговорка про значение, которое правило прочитать не может.

### batch-3 — 15 новых правил на коде

`host-clipboard-bypass`, `received-file-not-copied`, `transfer-temp-file-not-deleted`, `text-selection-without-sdk-actions`, `text-drag-and-drop`, `selection-callback-not-sdk`, `webview-selection-unrestricted`, `system-share-channel`, `external-storage-export`, `print-channel`, `host-pin-screen`, `own-certificate-expiry-logic`, `ipc-identity-fallback-open`, `ipc-identity-from-payload`, `app-integrity-check-marker`.

Это переводы котлиновских правил на джавовский синтаксис, а не копии. Что изменилось при переводе:

- свойства стали вызовами: `view.isTextSelectable = true` → `view.setTextIsSelectable(true)`, `cert.notAfter` → `cert.getNotAfter()`, `intent.action = X` → `intent.setAction(X)`;
- конструкторы получили `new`: `Intent(ACTION_SEND)` → `new Intent(Intent.ACTION_SEND)`, `File($PATH)` → `new File($PATH)`;
- `catch ($E: $T)` → `catch ($T $E)`;
- формы `runCatching { }.getOrDefault(true)` выброшены — это конструкция Kotlin, в Java есть только `try/catch`;
- формы Compose выброшены: `LocalClipboardManager.current`, `Modifier.dragAndDropSource`, `KeyboardType.NumberPassword`, `SelectionContainer`;
- добавлены джавовские формы, которых в котлине нет: `getSystemService(ClipboardManager.class)`, `setTransformationMethod(PasswordTransformationMethod.getInstance())`, `Runtime.getRuntime().exit(...)`, `ExtensionsKt.disableSharing(...)`.

Из `host-pin-screen` и `text-drag-and-drop` соответственно убраны упоминания Compose в тексте сообщения.

### batch-4 — 6 XML-правил

`exported-component-no-permission`, `multiprocess-ipc-exported`, `isolated-service-not-isolated`, `text-selection-enabled-layout`, `host-pin-screen-layout`, `signature-whitelist-plaintext`.

Это побайтовые копии котлиновских правил с изменённым только идентификатором: `languages: xml`, шаблоны и сообщения те же. Нужны, чтобы джавовский пресет сам покрывал манифест и ресурсы, не требуя котлиновского рядом.

`isolated-service-not-isolated` в прежней таблице стоял как «не нужен для Java». Это была непоследовательность: правило работает по манифесту, а манифест есть у любого приложения. Дублирую его вместе с остальными пятью, и в таблице статус надо сменить с «не требуется» на «готово».
