package ru.corp.app

import ru.sberbank.cerbersdk.SecureCheck
import ru.sberbank.cerbersdk.SecureChecker

/** L08 cerber-secure-check-wrong-state-comparison. */

private fun block(reason: String) {
    reason.length
}

class LaunchGates(private val checker: SecureChecker) {

    /** L08-TP-1. Сравнение только с ROOT_DETECTED. */
    fun gateRoot() {
        if (checker.performChecks() == SecureCheck.ROOT_DETECTED) {
            block("root")
        }
    }

    /** L08-TP-2. Отрицание по EMULATOR_DETECTED. */
    fun gateEmulator() {
        if (checker.performChecks() != SecureCheck.EMULATOR_DETECTED) {
            block("ok")
        }
    }

    /** L08-TP-3. Сравнение только с DEVICE_LOCKED. */
    fun gateLocked() {
        if (checker.performChecks() == SecureCheck.DEVICE_LOCKED) {
            block("locked")
        }
    }

    /** L08-TN-1. Сравнение с DEVICE_COMPLIANT: правильная форма. */
    fun gateCompliant() {
        if (checker.performChecks() == SecureCheck.DEVICE_COMPLIANT) {
            block("allow")
        }
    }

    /** L08-TN-2. Отрицание по DEVICE_COMPLIANT: тоже правильная форма. */
    fun gateNotCompliant() {
        if (checker.performChecks() != SecureCheck.DEVICE_COMPLIANT) {
            block("deny")
        }
    }

    /**
     * L08-PROBE-1. Результат положен в переменную и сравнивается ниже.
     * Ожидается пропуск: шаблоны требуют вызов на месте сравнения.
     * Форма очень частая, и это главный пропуск правила.
     */
    fun gateViaVariable() {
        val state = checker.performChecks()
        if (state == SecureCheck.ROOT_DETECTED) {
            block("root")
        }
    }

    /**
     * L08-PROBE-2. Разбор через when. Ожидается пропуск: сравнения как
     * выражения тут нет, есть ветка when.
     */
    fun gateViaWhen() {
        when (checker.performChecks()) {
            SecureCheck.ROOT_DETECTED -> block("root")
            else -> block("allow")
        }
    }

    /**
     * L08-PROBE-3. Сравнение с состоянием, которого в правиле нет.
     * В перечислении SDK семь значений, правило перечисляет три небезопасных.
     * Дефект тот же, ожидается пропуск. Клетка обосновывает доработку правила.
     */
    fun gateUnlistedState() {
        if (checker.performChecks() == SecureCheck.MDM_CONFIG_TAMPERED) {
            block("tampered")
        }
    }

    /** L08-PROBE-4. То же со вторым неперечисленным состоянием. */
    fun gateUnlistedStoreState() {
        if (checker.performChecks() != SecureCheck.SBERAPPS_NOT_FOUND) {
            block("allow")
        }
    }
}
