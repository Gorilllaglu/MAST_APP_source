package ru.corp.app;

import android.util.Log;

import ru.sberbank.cerbersdk.clipboard.CerberCopyPasteBuffer;
import ru.sberbank.cerbersdk.clipboard.WriteResult;

/** L04-5, ожидается МОЛЧАНИЕ. Сверка в return через equals. Проверяет внесённое исключение. */
public class ReturnEquals {

    private final CerberCopyPasteBuffer buffer = new CerberCopyPasteBuffer();

    public boolean copy(String text) {
        WriteResult result = buffer.write(text);
        return result.equals(WriteResult.SUCCESS);
    }
}
