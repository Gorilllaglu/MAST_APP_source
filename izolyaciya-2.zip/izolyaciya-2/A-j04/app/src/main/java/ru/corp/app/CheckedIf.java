package ru.corp.app;

import android.util.Log;

import ru.sberbank.cerbersdk.clipboard.CerberCopyPasteBuffer;
import ru.sberbank.cerbersdk.clipboard.WriteResult;

/** L04-3, ожидается МОЛЧАНИЕ. Сверка через if. */
public class CheckedIf {

    private final CerberCopyPasteBuffer buffer = new CerberCopyPasteBuffer();

    public void copy(String text) {
        WriteResult result = buffer.write(text);
        if (result == WriteResult.SUCCESS) {
            Log.d("clipboard", "ok");
        }
    }
}
