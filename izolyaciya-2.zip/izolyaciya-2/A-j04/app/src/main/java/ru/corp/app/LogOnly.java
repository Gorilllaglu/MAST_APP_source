package ru.corp.app;

import android.util.Log;

import ru.sberbank.cerbersdk.clipboard.CerberCopyPasteBuffer;
import ru.sberbank.cerbersdk.clipboard.WriteResult;

/** L04-2, ожидается СРАБОТКА. Результат объявлен и только залогирован. В общем файле эта клетка (J04-TP-2) ПРОМОЛЧАЛА. Здесь она одна, и сверять её не с чем. */
public class LogOnly {

    private final CerberCopyPasteBuffer buffer = new CerberCopyPasteBuffer();

    public void copy(String text) {
        WriteResult result = buffer.write(text);
        Log.d("clipboard", "write returned " + result);
    }
}
