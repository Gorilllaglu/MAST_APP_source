package ru.corp.app;

import android.util.Log;

import ru.sberbank.cerbersdk.clipboard.CerberCopyPasteBuffer;
import ru.sberbank.cerbersdk.clipboard.WriteResult;

/** L04-6, ожидается МОЛЧАНИЕ. Сверка в return через отрицаемый equals. Проверяет внесённое исключение. */
public class ReturnNegEquals {

    private final CerberCopyPasteBuffer buffer = new CerberCopyPasteBuffer();

    public boolean copy(String text) {
        WriteResult result = buffer.write(text);
        return !result.equals(WriteResult.FAILURE);
    }
}
