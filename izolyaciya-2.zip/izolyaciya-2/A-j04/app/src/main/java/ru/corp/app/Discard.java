package ru.corp.app;

import android.util.Log;

import ru.sberbank.cerbersdk.clipboard.CerberCopyPasteBuffer;
import ru.sberbank.cerbersdk.clipboard.WriteResult;

/** L04-1, ожидается СРАБОТКА. Результат отброшен. Ветвь 1. */
public class Discard {

    private final CerberCopyPasteBuffer buffer = new CerberCopyPasteBuffer();

    public void copy(String text) {
        buffer.write(text);
    }
}
