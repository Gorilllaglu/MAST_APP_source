package ru.corp.app;

import android.util.Log;

import ru.sberbank.cerbersdk.clipboard.CerberCopyPasteBuffer;
import ru.sberbank.cerbersdk.clipboard.WriteResult;

/** L04-7, ожидается СРАБОТКА. Результат передан в метод, нигде не сравнён. */
public class Delegate {

    private final CerberCopyPasteBuffer buffer = new CerberCopyPasteBuffer();

    public void copy(String text) {
        WriteResult result = buffer.write(text);
        handle(result);
    }

    private void handle(WriteResult result) {
        Log.d("clipboard", String.valueOf(result));
    }
}
