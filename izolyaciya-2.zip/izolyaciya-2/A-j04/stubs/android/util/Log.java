package android.util;

public final class Log {
    private Log() {
    }

    public static int d(String tag, String msg) {
        throw new UnsupportedOperationException("stub");
    }

    public static int w(String tag, String msg) {
        throw new UnsupportedOperationException("stub");
    }
}
