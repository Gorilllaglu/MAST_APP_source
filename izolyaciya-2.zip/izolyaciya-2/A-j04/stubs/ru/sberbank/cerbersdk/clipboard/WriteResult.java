package ru.sberbank.cerbersdk.clipboard;

public enum WriteResult {
    SUCCESS,
    TRUNCATED,
    FAILURE
}
