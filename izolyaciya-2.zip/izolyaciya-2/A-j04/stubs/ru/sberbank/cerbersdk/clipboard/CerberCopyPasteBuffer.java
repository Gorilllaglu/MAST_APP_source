package ru.sberbank.cerbersdk.clipboard;

public class CerberCopyPasteBuffer {
    public WriteResult write(String value) {
        throw new UnsupportedOperationException("stub");
    }
}
