package ru.corp.app;

import java.util.concurrent.TimeUnit;

import javax.net.ssl.HostnameVerifier;

import okhttp3.Interceptor;
import okhttp3.InterceptorFactory;
import okhttp3.OkHttpClient;
import okhttp3.PlainInterceptor;

/**
 * Матрица на одну гипотезу: второй new в том же выражении подавляет совпадение.
 *
 * Основание. В прогоне 2026-10-27 правило cerber-java-direct-okhttp-client дало
 * 12 сработок и 4 молчания, и разделение оказалось ровным по одному признаку.
 * Промолчали OJ-TP-4, OJ-TP-6, OJ-TP-8 и OJ-PROBE-3 — у всех четырёх в том же
 * выражении есть второй new не-okhttp типа, аргументом или объемлющий.
 * Сработали все двенадцать клеток, где такого new нет. Исключений из этого
 * правила в прогоне не было ни одного.
 *
 * Ни одна клетка ниже не подпадает ни под одно исключение правила:
 * везде addInterceptor, а не addNetworkInterceptor, и PlainInterceptor не
 * назван ни в одном исключении. То есть каждая обязана сработать, и всякое
 * молчание — это и есть измеряемый эффект.
 *
 * Ключевая клетка — B-6. Если закон про «то же выражение», она СРАБОТАЕТ:
 * там new OkHttpClient.Builder() стоит отдельным оператором, а new
 * PlainInterceptor() — в следующем. Если же она промолчит, значит дело не в
 * выражении, а в области видимости метода, и формулировку надо менять.
 */
public final class SecondNewMatrix {

    private SecondNewMatrix() {
    }

    /** B-1. Аргумент — параметр. Второго new нет. Ожидается СРАБОТКА. */
    public static OkHttpClient b1(Interceptor given) {
        return new OkHttpClient.Builder()
                .addInterceptor(given)
                .build();
    }

    /** B-2. Аргумент — конструктор. Второй new есть. Ожидается МОЛЧАНИЕ. */
    public static OkHttpClient b2() {
        return new OkHttpClient.Builder()
                .addInterceptor(new PlainInterceptor())
                .build();
    }

    /** B-3. Аргументы — литералы. Второго new нет. Ожидается СРАБОТКА. */
    public static OkHttpClient b3() {
        return new OkHttpClient.Builder()
                .connectTimeout(30, TimeUnit.SECONDS)
                .build();
    }

    /** B-4. Аргумент — параметр. Второго new нет. Ожидается СРАБОТКА. */
    public static OkHttpClient b4(HostnameVerifier given) {
        return new OkHttpClient.Builder()
                .hostnameVerifier(given)
                .build();
    }

    /** B-5. Аргумент — анонимный класс. Второй new есть. Ожидается МОЛЧАНИЕ. */
    public static OkHttpClient b5() {
        return new OkHttpClient.Builder()
                .hostnameVerifier(new HostnameVerifier() {
                    @Override
                    public boolean verify(String hostname, Object session) {
                        return true;
                    }
                })
                .build();
    }

    /**
     * B-6. КЛЮЧЕВАЯ КЛЕТКА. Второй new есть, но в другом операторе.
     * Закон про выражение — сработает. Закон про метод — промолчит.
     */
    public static OkHttpClient b6() {
        OkHttpClient.Builder builder = new OkHttpClient.Builder();
        builder.addInterceptor(new PlainInterceptor());
        return builder.build();
    }

    /** B-7. Объемлющий new. Ожидается МОЛЧАНИЕ. */
    public static Holder b7() {
        return new Holder(new OkHttpClient.Builder().build());
    }

    /** B-8. Аргумент — вызов метода, не конструктор. Контроль. Ожидается СРАБОТКА. */
    public static OkHttpClient b8(InterceptorFactory factory) {
        return new OkHttpClient.Builder()
                .addInterceptor(factory.create())
                .build();
    }

    public static class Holder {
        private final OkHttpClient client;

        public Holder(OkHttpClient client) {
            this.client = client;
        }

        public OkHttpClient client() {
            return client;
        }
    }
}
