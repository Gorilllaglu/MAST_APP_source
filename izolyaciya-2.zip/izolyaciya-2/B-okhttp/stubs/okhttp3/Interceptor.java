package okhttp3;

public interface Interceptor {
    Object intercept(Object chain);
}
