package okhttp3;

public class InterceptorFactory {
    public Interceptor create() {
        throw new UnsupportedOperationException("stub");
    }
}
