package okhttp3;

public class CertificatePinner {
    public static class Builder {
        public Builder add(String pattern, String... pins) {
            throw new UnsupportedOperationException("stub");
        }

        public CertificatePinner build() {
            throw new UnsupportedOperationException("stub");
        }
    }
}
