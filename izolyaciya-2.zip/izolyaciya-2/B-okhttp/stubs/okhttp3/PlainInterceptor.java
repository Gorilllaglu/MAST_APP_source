package okhttp3;

/** Имя НЕ совпадает ни с одним перехватчиком, названным в исключениях правила. */
public class PlainInterceptor implements Interceptor {
    @Override
    public Object intercept(Object chain) {
        throw new UnsupportedOperationException("stub");
    }
}
