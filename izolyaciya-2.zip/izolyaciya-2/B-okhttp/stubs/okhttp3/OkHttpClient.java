package okhttp3;

import java.util.concurrent.TimeUnit;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.X509TrustManager;

public class OkHttpClient {

    public OkHttpClient() {
        throw new UnsupportedOperationException("stub");
    }

    public static class Builder {
        public Builder addInterceptor(Interceptor interceptor) {
            throw new UnsupportedOperationException("stub");
        }

        public Builder addNetworkInterceptor(Interceptor interceptor) {
            throw new UnsupportedOperationException("stub");
        }

        public Builder certificatePinner(CertificatePinner pinner) {
            throw new UnsupportedOperationException("stub");
        }

        public Builder connectTimeout(long timeout, TimeUnit unit) {
            throw new UnsupportedOperationException("stub");
        }

        public Builder readTimeout(long timeout, TimeUnit unit) {
            throw new UnsupportedOperationException("stub");
        }

        public Builder sslSocketFactory(SSLSocketFactory factory, X509TrustManager manager) {
            throw new UnsupportedOperationException("stub");
        }

        public Builder hostnameVerifier(HostnameVerifier verifier) {
            throw new UnsupportedOperationException("stub");
        }

        public OkHttpClient build() {
            throw new UnsupportedOperationException("stub");
        }
    }
}
