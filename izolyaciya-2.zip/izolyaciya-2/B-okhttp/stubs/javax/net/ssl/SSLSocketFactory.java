package javax.net.ssl;

public abstract class SSLSocketFactory {
}
