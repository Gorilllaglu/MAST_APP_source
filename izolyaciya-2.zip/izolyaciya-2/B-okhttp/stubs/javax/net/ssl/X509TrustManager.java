package javax.net.ssl;

public interface X509TrustManager {
    void checkServerTrusted(Object[] chain, String authType);

    void checkClientTrusted(Object[] chain, String authType);

    Object[] getAcceptedIssuers();
}
